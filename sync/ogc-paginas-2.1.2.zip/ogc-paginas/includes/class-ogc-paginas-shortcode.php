<?php
/**
 * Shortcode [ogc_pagina id="portada"] (también my-services, about, practica-ogc y contacto).
 *
 * Imprime TAL CUAL (con su JSON-LD, estilos y script de la cuenta atrás) el HTML de esa página que viene en el
 * manifiesto en uso: el incluido en el plugin o el remoto con firma Ed25519 verificada. Nunca imprime nada que venga
 * del visitante ni de los atributos del shortcode: el atributo «id» solo elige entre 5 nombres fijos.
 * Los huecos «[…]» (Stripe, etc.) se rellenan con los Ajustes, como en las demás páginas.
 * Si no hay contenido para ese id, no imprime nada (los administradores ven un aviso).
 *
 * Caché: opción ogc_paginas_sc (no autocargada), que se rehace sola cuando cambia el manifiesto, la versión del
 * plugin o los Ajustes.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Shortcode {

	const OPCION = 'ogc_paginas_sc';

	/** @var array|null */
	private static $cache = null;

	public static function registrar() {
		add_shortcode( 'ogc_pagina', array( __CLASS__, 'render' ) );
	}

	/** Identificador de la fuente: si cambia, la caché se rehace. */
	private static function fuente_id() {
		$f = OGC_Paginas_Manifiesto::archivo();
		$e = OGC_Paginas_Sync::estado();
		return md5(
			( defined( 'OGC_PAGINAS_VERSION' ) ? OGC_PAGINAS_VERSION : '' ) . '|' . ( is_readable( $f ) ? filemtime( $f ) . ':' . filesize( $f ) : '-' )
			. '|' . (int) $e['serie'] . ':' . $e['sha256'] . ':' . $e['aplicado'] . '|' . md5( serialize( OGC_Paginas_Huecos::ajustes() ) ) // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		);
	}

	public static function vaciar_cache() {
		self::$cache = null;
		if ( function_exists( 'delete_option' ) ) {
			delete_option( self::OPCION );
		}
	}

	/**
	 * HTML listo de cada id (null si no hay).
	 *
	 * @return array id => array( 'html' => string|null, 'pendientes' => array )
	 */
	public static function contenidos() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}
		$id = self::fuente_id();
		$c  = get_option( self::OPCION, null );
		if ( is_array( $c ) && isset( $c['id'], $c['p'] ) && $c['id'] === $id && is_array( $c['p'] ) ) {
			$out = array();
			foreach ( $c['p'] as $k => $v ) {
				$html        = null === $v['h'] ? null : base64_decode( (string) $v['h'], true );
				$out[ $k ]   = array(
					'html'       => false === $html ? null : $html,
					'pendientes' => (array) $v['x'],
				);
			}
			self::$cache = $out;
			return $out;
		}
		// Rehacer desde el manifiesto en uso (ya validado: hash de cada HTML comprobado).
		$m   = OGC_Paginas_Manifiesto::cargar();
		$ph  = is_array( $m ) && isset( $m['posicionan_html'] ) && is_array( $m['posicionan_html'] ) ? $m['posicionan_html'] : array();
		$out = array();
		$gua = array();
		foreach ( OGC_Paginas_Manifiesto::IDS_POSICIONAN as $k => $ruta ) {
			$html = null;
			$pend = array();
			if ( isset( $ph[ $k ] ) && is_array( $ph[ $k ] ) && '' !== trim( $ph[ $k ]['html'] ) ) {
				$r    = OGC_Paginas_Huecos::resolver( $ph[ $k ]['html'] );
				$html = $r['html'];
				$pend = $r['pendientes'];
			}
			$out[ $k ] = array(
				'html'       => $html,
				'pendientes' => $pend,
			);
			$gua[ $k ] = array(
				'h' => null === $html ? null : base64_encode( $html ),
				'x' => $pend,
			);
		}
		if ( is_array( $m ) ) {
			update_option(
				self::OPCION,
				array(
					'id' => $id,
					'p'  => $gua,
				),
				false
			);
		}
		self::$cache = $out;
		return $out;
	}

	/**
	 * @param array|string $atts Atributos.
	 * @return string
	 */
	public static function render( $atts ) {
		$atts = is_array( $atts ) ? $atts : array();
		$id   = isset( $atts['id'] ) ? strtolower( trim( (string) $atts['id'] ) ) : '';
		if ( ! array_key_exists( $id, OGC_Paginas_Manifiesto::IDS_POSICIONAN ) ) {
			return self::aviso_admin( 'id no válido en [ogc_pagina]. Usa portada, my-services, about, practica-ogc o contacto.' );
		}
		$c = self::contenidos();
		if ( empty( $c[ $id ]['html'] ) ) {
			return self::aviso_admin( 'todavía no hay contenido para [ogc_pagina id="' . $id . '"] en el paquete. Los visitantes no ven nada aquí.' );
		}
		$html = $c[ $id ]['html'];
		if ( $c[ $id ]['pendientes'] ) {
			$html = self::aviso_admin( 'a este contenido le faltan datos (' . implode( ' ', $c[ $id ]['pendientes'] ) . '): rellénalos en Herramientas → OGC Páginas → Ajustes.' ) . $html;
		}
		// Contenido firmado: se imprime tal cual (JSON-LD, estilos y scripts incluidos).
		return $html;
	}

	private static function aviso_admin( $texto ) {
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( 'manage_options' ) ) {
			return '';
		}
		return '<div class="ogc-aviso-admin" style="border:2px dashed #b26a00;padding:8px 12px;margin:8px 0;background:#fff8e5;color:#1f2937;font:14px/1.4 sans-serif">OGC Páginas (solo lo ven los administradores): ' . esc_html( $texto ) . '</div>';
	}
}
