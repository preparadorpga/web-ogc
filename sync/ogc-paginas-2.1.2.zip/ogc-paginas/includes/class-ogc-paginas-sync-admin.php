<?php
/**
 * Pestaña «Actualización automática» de Herramientas → OGC Páginas y sus acciones (admin-post).
 * Todo con nonce; ver: manage_options; cambiar o aplicar: manage_options + unfiltered_html.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Sync_Admin {

	private static function url_volver() {
		return admin_url( 'tools.php?page=ogc-paginas&tab=sync' );
	}

	private static function puede() {
		return current_user_can( 'manage_options' ) && current_user_can( 'unfiltered_html' );
	}

	private static function terminar( array $lineas ) {
		set_transient( 'ogc_paginas_resultado_' . get_current_user_id(), $lineas, 10 * MINUTE_IN_SECONDS );
		wp_safe_redirect( self::url_volver() );
		exit;
	}

	private static function exigir( $nonce ) {
		if ( ! self::puede() ) {
			wp_die( 'Sin permiso: hace falta un usuario Administrador que pueda guardar HTML sin filtrar.', 403 );
		}
		check_admin_referer( $nonce );
	}

	public static function pagina() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$res = get_transient( 'ogc_paginas_resultado_' . get_current_user_id() );
		if ( is_array( $res ) && $res ) {
			delete_transient( 'ogc_paginas_resultado_' . get_current_user_id() );
			echo '<div class="notice notice-info"><p><strong>' . esc_html( (string) array_shift( $res ) ) . '</strong></p>';
			if ( $res ) {
				echo '<ul style="list-style:disc;margin-left:20px">';
				foreach ( $res as $l ) {
					echo '<li>' . esc_html( (string) $l ) . '</li>';
				}
				echo '</ul>';
			}
			echo '</div>';
		}
		$a  = OGC_Paginas_Sync::ajustes();
		$e  = OGC_Paginas_Sync::estado();
		$m  = OGC_Paginas_Manifiesto::cargar();
		$cp = OGC_Paginas_Sync::clave_publica();
		$dis = self::puede() ? '' : ' disabled';

		echo '<p>El plugin comprueba <strong>cada hora</strong> si hay un paquete nuevo publicado en la URL de abajo. Solo lo aplica si está <strong>firmado</strong> por Preparador OGC (firma Ed25519) y es <strong>más nuevo</strong> que el aplicado. Lo aplica igual que el botón «Sincronizar» (revisión previa, nunca toca páginas que no sean suyas) y lo anota en el registro de la pestaña Páginas. Si algo falla, no cambia nada y avisa en el escritorio.</p>';

		// Estado.
		$res_txt = array(
			''             => 'todavía no se ha comprobado',
			'aplicado'     => 'versión nueva aplicada',
			'al_dia'       => 'al día (sin novedades)',
			'reversion'    => 'el paquete publicado es más antiguo que el aplicado: ignorado',
			'error'        => 'ERROR (no se ha aplicado nada)',
			'vuelta_atras' => 'se volvió a la versión anterior',
		);
		echo '<table class="widefat striped" style="max-width:900px"><tbody>';
		echo '<tr><th style="width:260px">Actualización automática</th><td>' . ( $a['auto'] ? '<strong style="color:#2e7d32">Activada</strong>' : '<strong style="color:#b26a00">Desactivada</strong>' ) . ( wp_next_scheduled( OGC_Paginas_Sync::CRON ) ? ' · próxima comprobación: ' . esc_html( get_date_from_gmt( gmdate( 'Y-m-d H:i:s', (int) wp_next_scheduled( OGC_Paginas_Sync::CRON ) ), 'd/m/Y H:i' ) ) : '' ) . '</td></tr>';
		echo '<tr><th>Contenido en uso</th><td>' . ( $m ? ( 'remoto' === OGC_Paginas_Manifiesto::origen() ? 'Paquete firmado <strong>serie ' . (int) $m['serie'] . '</strong> (generado el ' . esc_html( (string) ( $m['generado'] ?? '' ) ) . ')' : 'El incluido en el plugin (paquete ' . esc_html( (string) ( $m['version'] ?? '' ) ) . ', ' . esc_html( (string) ( $m['generado'] ?? '' ) ) . ')' ) : '<em>' . esc_html( OGC_Paginas_Manifiesto::error() ) . '</em>' ) . '</td></tr>';
		echo '<tr><th>Última comprobación</th><td>' . esc_html( '' === $e['comprobado'] ? '—' : $e['comprobado'] ) . ' · ' . esc_html( $res_txt[ $e['resultado'] ] ?? $e['resultado'] ) . '</td></tr>';
		if ( '' !== $e['error'] ) {
			echo '<tr><th>Último error</th><td style="color:#b32d2e">' . esc_html( $e['error_fecha'] . ' · ' . $e['error'] ) . '</td></tr>';
		}
		echo '<tr><th>Última versión aplicada</th><td>' . esc_html( '' === $e['aplicado'] ? '—' : $e['aplicado'] ) . ' · serie más alta aplicada: ' . (int) $e['serie_max'] . '</td></tr>';
		echo '</tbody></table>';

		echo '<p style="margin-top:12px">';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin-right:12px">';
		wp_nonce_field( 'ogc_paginas_sync_comprobar' );
		echo '<input type="hidden" name="action" value="ogc_paginas_sync_comprobar"><button class="button button-primary"' . $dis . '>Comprobar ahora</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( is_array( get_option( OGC_Paginas_Sync::OPC_ANTERIOR, null ) ) ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block">';
			wp_nonce_field( 'ogc_paginas_sync_volver' );
			echo '<input type="hidden" name="action" value="ogc_paginas_sync_volver"><label><input type="checkbox" name="confirmo" value="1" required> Confirmo</label> <button class="button"' . $dis . '>Volver a la versión anterior</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</p>';

		// Ajustes.
		echo '<h2>Ajustes</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ogc_paginas_sync_ajustes' );
		echo '<input type="hidden" name="action" value="ogc_paginas_sync_ajustes"><table class="form-table"><tbody>';
		echo '<tr><th scope="row">Actualización automática</th><td><label><input type="checkbox" name="auto" value="1"' . ( $a['auto'] ? ' checked' : '' ) . '> Activada (comprobar cada hora y aplicar los paquetes firmados nuevos)</label></td></tr>';
		echo '<tr><th scope="row"><label for="ogc-sync-url">URL del paquete</label></th><td><input class="large-text code" type="url" id="ogc-sync-url" name="url" value="' . esc_attr( $a['url'] ) . '"><p class="description">Carpeta donde están manifiesto.json y manifiesto.sig. Por defecto: <code>' . esc_html( OGC_Paginas_Sync::URL_DEFECTO ) . '</code></p></td></tr>';
		$mask = OGC_Paginas_Sync::token_mascara();
		echo '<tr><th scope="row"><label for="ogc-sync-token">Token de GitHub (solo lectura)</label></th><td><input class="regular-text code" type="password" id="ogc-sync-token" name="token" value="" autocomplete="new-password" placeholder="' . esc_attr( '' === $mask ? 'Solo si el repositorio es privado' : 'Guardado: ' . $mask . ' (déjalo vacío para conservarlo)' ) . '">';
		if ( '' !== $mask ) {
			echo ' <label><input type="checkbox" name="borrar_token" value="1"> Borrar el token</label>';
		}
		echo '<p class="description">Solo hace falta si el repositorio de GitHub es <strong>privado</strong>: un token «fine-grained» con permiso de solo lectura de contenidos de ese repositorio. Nunca se muestra entero y solo se envía a GitHub.</p></td></tr>';
		echo '</tbody></table>';
		echo '<p><button class="button button-primary"' . $dis . '>Guardar ajustes</button></p></form>'; // phpcs:ignore WordPress.Security.EscapeOutput

		// Shortcodes.
		echo '<h2>Páginas que posicionan: shortcode</h2>';
		echo '<p>Para que una de estas páginas se actualice sola, en Elementor sustituye <strong>una sola vez</strong> su widget «HTML» por un widget <strong>«Shortcode»</strong> con el código de la tabla. Si el paquete no trae contenido para esa página, el shortcode no muestra nada a los visitantes (y a ti te sale un aviso).</p>';
		echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>Página</th><th>Shortcode</th><th>Contenido en el paquete</th></tr></thead><tbody>';
		$c = OGC_Paginas_Shortcode::contenidos();
		foreach ( OGC_Paginas_Manifiesto::IDS_POSICIONAN as $id => $ruta ) {
			$tiene = ! empty( $c[ $id ]['html'] );
			echo '<tr><td><code>/' . esc_html( '' === $ruta ? '' : $ruta . '/' ) . '</code></td><td><code>[ogc_pagina id="' . esc_html( $id ) . '"]</code></td><td>' . ( $tiene ? 'Sí (' . esc_html( number_format_i18n( strlen( $c[ $id ]['html'] ) / 1024, 0 ) ) . ' KB)' : '<em>Todavía no</em>' ) . '</td></tr>';
		}
		echo '</tbody></table>';

		if ( class_exists( 'OGC_Paginas_Blog_Admin' ) ) {
			OGC_Paginas_Blog_Admin::seccion_plugin();
		}

		// Clave pública.
		echo '<h2>Clave pública de la firma</h2>';
		echo '<p>En uso: <code>' . esc_html( base64_encode( $cp[0] ) ) . '</code> ' . ( $cp[1] ? '(la que trae el plugin)' : '<strong>(sustituida en Ajustes)</strong>' ) . '</p>';
		echo '<details><summary>Sustituir la clave pública (solo si te lo pedimos: por ejemplo, si se regenera la clave de firma)</summary>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ogc_paginas_sync_clave' );
		echo '<input type="hidden" name="action" value="ogc_paginas_sync_clave"><p><input class="large-text code" type="text" name="clave" value="" placeholder="Clave pública nueva (44 caracteres). Vacío = volver a la que trae el plugin"></p>';
		echo '<p><label><input type="checkbox" name="confirmo" value="1" required> Confirmo que esta clave me la ha dado Preparador OGC. Con una clave equivocada, la web aceptaría paquetes firmados por otra persona.</label></p>';
		echo '<p><button class="button"' . $dis . '>Guardar clave</button></p></form></details>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public static function guardar_ajustes() {
		self::exigir( 'ogc_paginas_sync_ajustes' );
		$e = array(
			'url'          => isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ), array( 'https' ) ) : '',
			'auto'         => ! empty( $_POST['auto'] ),
			'token'        => isset( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '',
			'borrar_token' => ! empty( $_POST['borrar_token'] ),
		);
		$l = OGC_Paginas_Sync::guardar_ajustes( $e );
		OGC_Paginas_Sincronizador::registrar( array( 'AJUSTES DE ACTUALIZACIÓN AUTOMÁTICA · ' . $l[0] ), false );
		self::terminar( $l );
	}

	public static function comprobar() {
		self::exigir( 'ogc_paginas_sync_comprobar' );
		self::terminar( OGC_Paginas_Sync::comprobar( 'manual' ) );
	}

	public static function volver() {
		self::exigir( 'ogc_paginas_sync_volver' );
		if ( empty( $_POST['confirmo'] ) ) {
			wp_die( 'Marca la casilla de confirmación.' );
		}
		self::terminar( OGC_Paginas_Sync::volver() );
	}

	public static function clave() {
		self::exigir( 'ogc_paginas_sync_clave' );
		if ( empty( $_POST['confirmo'] ) ) {
			wp_die( 'Marca la casilla de confirmación.' );
		}
		$c = isset( $_POST['clave'] ) ? sanitize_text_field( wp_unslash( $_POST['clave'] ) ) : '';
		$r = OGC_Paginas_Sync::cambiar_clave( $c );
		$l = true === $r ? array( '' === trim( $c ) ? 'Clave pública: se vuelve a usar la que trae el plugin.' : 'Clave pública sustituida. Pulsa «Comprobar ahora».' ) : array( $r );
		OGC_Paginas_Sincronizador::registrar( array( 'CLAVE PÚBLICA · ' . $l[0] ), false );
		self::terminar( $l );
	}
}
