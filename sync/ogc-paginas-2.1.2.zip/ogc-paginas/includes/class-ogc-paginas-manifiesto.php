<?php
/**
 * Lectura y validación del manifiesto (datos/manifiesto.json).
 * El JSON se trata solo como datos: se validan tipos, rutas y hash; nunca se evalúa nada.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Manifiesto {

	/**
	 * Rutas que el plugin no crea, edita ni borra NUNCA (las 5 que posicionan y la página de entradas).
	 * La portada y la página de entradas se protegen además por su ID (Ajustes → Lectura).
	 */
	const PROTEGIDAS = array( '', 'my-services', 'about', 'practica-ogc', 'contacto', 'blog' );

	/** @var array|null */
	private static $cache = null;

	/** @var string */
	private static $error = '';

	public static function archivo() {
		return OGC_PAGINAS_DIR . '/datos/manifiesto.json';
	}

	public static function error() {
		return self::$error;
	}

	public static function es_protegida( $ruta ) {
		$ruta = trim( (string) $ruta, '/' );
		if ( in_array( $ruta, self::PROTEGIDAS, true ) ) {
			return true;
		}
		// Tampoco nada que cuelgue de la página de entradas.
		return 0 === strpos( $ruta, 'blog/' );
	}

	/** @var string Origen del manifiesto cargado: «incluido» (datos/ del plugin) o «remoto» (actualización firmada). */
	private static $origen = '';

	public static function origen() {
		return self::$origen;
	}

	/** Olvida el manifiesto en memoria (tras aplicar o volver atrás una actualización). */
	public static function reiniciar() {
		self::$cache  = null;
		self::$error  = '';
		self::$origen = '';
	}

	/**
	 * Devuelve el manifiesto validado o null (ver error()).
	 * Desde 2.0.0: si hay una actualización remota aplicada (firma Ed25519 verificada, ver OGC_Paginas_Sync) y su
	 * «serie» es igual o mayor que la del manifiesto incluido en el plugin, se usa esa; si no, el incluido.
	 *
	 * @return array|null
	 */
	public static function cargar() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}
		$incluido = null;
		$err_inc  = '';
		$f        = self::archivo();
		if ( is_readable( $f ) ) {
			$incluido = self::desde_json( (string) file_get_contents( $f ), $err_inc ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		} else {
			$err_inc = 'No se encuentra datos/manifiesto.json dentro del plugin.';
		}
		$remoto = class_exists( 'OGC_Paginas_Sync' ) ? OGC_Paginas_Sync::manifiesto_aplicado() : null;
		if ( is_array( $remoto ) && ( ! $incluido || (int) ( $remoto['serie'] ?? 0 ) >= (int) ( $incluido['serie'] ?? 0 ) ) ) {
			self::$origen = 'remoto';
			self::$cache  = $remoto;
			return $remoto;
		}
		if ( ! $incluido ) {
			self::$error = $err_inc;
			return null;
		}
		self::$origen = 'incluido';
		self::$cache  = $incluido;
		return $incluido;
	}

	/**
	 * Valida un manifiesto (texto JSON) sin guardarlo en memoria. Solo datos: nunca se ejecuta nada de él.
	 *
	 * @param string $json  Texto JSON.
	 * @param string $error Salida: motivo del rechazo.
	 * @return array|null
	 */
	public static function desde_json( $json, &$error = '' ) {
		$m = json_decode( (string) $json, true );
		if ( ! is_array( $m ) || ! isset( $m['paginas'] ) || ! is_array( $m['paginas'] ) ) {
			$error = 'El manifiesto no es un JSON válido.';
			return null;
		}
		if ( 1 !== (int) ( $m['formato'] ?? 0 ) ) {
			$error = 'Formato de manifiesto desconocido.';
			return null;
		}
		$paginas = array();
		$vistas  = array();
		foreach ( $m['paginas'] as $i => $p ) {
			$ok = self::validar( $p );
			if ( true !== $ok ) {
				$error = sprintf( 'Página n.º %d del manifiesto descartada: %s', (int) $i + 1, $ok );
				return null;
			}
			if ( isset( $vistas[ $p['ruta'] ] ) ) {
				$error = 'Ruta repetida en el manifiesto: /' . $p['ruta'] . '/';
				return null;
			}
			$vistas[ $p['ruta'] ] = true;
			$paginas[]            = $p;
		}
		usort(
			$paginas,
			static function ( $a, $b ) {
				return (int) $a['orden'] - (int) $b['orden'];
			}
		);
		$m['paginas'] = $paginas;
		$ok           = self::validar_posicionan_html( $m['posicionan_html'] ?? array() );
		if ( true !== $ok ) {
			$error = $ok;
			return null;
		}
		// 2.1.0 · robots.txt y llms.txt firmados.
		if ( class_exists( 'OGC_Paginas_Seo' ) ) {
			$ok = OGC_Paginas_Seo::validar( $m );
			if ( true !== $ok ) {
				$error = $ok;
				return null;
			}
		}
		// 2.1.0 · entradas del blog: si una no es válida, se rechaza el manifiesto entero.
		if ( class_exists( 'OGC_Paginas_Blog' ) ) {
			$ok = OGC_Paginas_Blog::validar_lista( $m['entradas'] ?? null, $m );
			if ( true !== $ok ) {
				$error = $ok;
				return null;
			}
		}
		return $m;
	}

	/** Identificadores del shortcode [ogc_pagina id="…"] → ruta de la página que posiciona. */
	const IDS_POSICIONAN = array(
		'portada'      => '',
		'my-services'  => 'my-services',
		'about'        => 'about',
		'practica-ogc' => 'practica-ogc',
		'contacto'     => 'contacto',
	);

	/**
	 * «posicionan_html» (2.0.0): HTML de las 5 páginas que posicionan para el shortcode. Cada entrada es null (aún sin
	 * contenido) u objeto con html y su sha256. Solo se admiten los 5 identificadores fijos.
	 *
	 * @param mixed $ph Valor del manifiesto.
	 * @return true|string
	 */
	public static function validar_posicionan_html( $ph ) {
		if ( ! is_array( $ph ) ) {
			return 'posicionan_html no es un objeto';
		}
		foreach ( $ph as $id => $e ) {
			if ( ! is_string( $id ) || ! array_key_exists( $id, self::IDS_POSICIONAN ) ) {
				return 'posicionan_html: identificador no permitido';
			}
			if ( null === $e ) {
				continue;
			}
			if ( ! is_array( $e ) || ! isset( $e['html'], $e['hash'] ) || ! is_string( $e['html'] ) || ! is_string( $e['hash'] ) ) {
				return 'posicionan_html: entrada «' . $id . '» no válida';
			}
			if ( ! hash_equals( $e['hash'], hash( 'sha256', $e['html'] ) ) ) {
				return 'posicionan_html: el HTML de «' . $id . '» está dañado (hash distinto)';
			}
		}
		return true;
	}

	/**
	 * @param mixed $p Entrada del manifiesto.
	 * @return true|string
	 */
	private static function validar( $p ) {
		if ( ! is_array( $p ) ) {
			return 'no es un objeto';
		}
		$texto = array( 'ruta', 'slug', 'madre', 'titulo', 'titulo_migas', 'seo_titulo', 'seo_meta', 'frase_clave', 'archivo', 'hash', 'hash_contenido', 'contenido', 'estado_destino' );
		foreach ( $texto as $k ) {
			if ( ! isset( $p[ $k ] ) || ! is_string( $p[ $k ] ) ) {
				return 'falta el campo ' . $k;
			}
		}
		if ( ! isset( $p['huecos'] ) || ! is_array( $p['huecos'] ) || ! isset( $p['orden'] ) || ! is_int( $p['orden'] ) || ! isset( $p['noindex'] ) || ! is_bool( $p['noindex'] ) ) {
			return 'campos huecos/orden/noindex no válidos';
		}
		if ( ! preg_match( '#^[a-z0-9-]+(/[a-z0-9-]+)*$#', $p['ruta'] ) ) {
			return 'ruta no válida';
		}
		if ( self::es_protegida( $p['ruta'] ) ) {
			return 'intenta tocar una página protegida (/' . $p['ruta'] . '/)';
		}
		$partes = explode( '/', $p['ruta'] );
		$slug   = array_pop( $partes );
		if ( $slug !== $p['slug'] || implode( '/', $partes ) !== $p['madre'] ) {
			return 'slug o madre no cuadran con la ruta /' . $p['ruta'] . '/';
		}
		$ini = "<!-- wp:html -->\n";
		$fin = "\n<!-- /wp:html -->";
		if ( 0 !== strpos( $p['contenido'], $ini ) || substr( $p['contenido'], -strlen( $fin ) ) !== $fin ) {
			return 'el contenido no va en un bloque HTML personalizado';
		}
		if ( ! hash_equals( $p['hash_contenido'], hash( 'sha256', $p['contenido'] ) ) ) {
			return 'el contenido de /' . $p['ruta'] . '/ está dañado (hash distinto)';
		}
		if ( ! in_array( $p['estado_destino'], array( 'draft', 'publish' ), true ) ) {
			return 'estado no válido';
		}
		if ( ( 'draft' === $p['estado_destino'] ) !== ( count( $p['huecos'] ) > 0 ) ) {
			return 'estado y huecos no cuadran';
		}
		return true;
	}
}
