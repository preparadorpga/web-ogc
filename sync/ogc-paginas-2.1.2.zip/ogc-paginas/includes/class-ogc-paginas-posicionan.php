<?php
/**
 * Las 5 páginas que posicionan: SOLO los campos de Yoast (título SEO, meta descripción y frase clave).
 * Nunca se toca su contenido, su título (H1), su slug, su estado ni nada más.
 * Antes de escribir se guardan los valores anteriores (meta _ogc_paginas_yoast_anterior) para «Restaurar Yoast anterior».
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Posicionan {

	const META_ANTERIOR = '_ogc_paginas_yoast_anterior';
	const RUTAS         = array( '', 'my-services', 'about', 'practica-ogc', 'contacto' );
	const CAMPOS        = array(
		'seo_titulo'  => '_yoast_wpseo_title',
		'seo_meta'    => '_yoast_wpseo_metadesc',
		'frase_clave' => '_yoast_wpseo_focuskw',
	);

	/**
	 * Entradas válidas del manifiesto (las rutas se comprueban contra la lista fija de arriba).
	 *
	 * @return array
	 */
	public static function entradas( array $m ) {
		$out = array();
		foreach ( (array) ( $m['posicionan_yoast'] ?? array() ) as $e ) {
			if ( ! is_array( $e ) || ! isset( $e['ruta'], $e['nombre'], $e['seo_titulo'], $e['seo_meta'], $e['frase_clave'] ) ) {
				continue;
			}
			if ( ! in_array( $e['ruta'], self::RUTAS, true ) || ! is_string( $e['seo_titulo'] ) || ! is_string( $e['seo_meta'] ) || ! is_string( $e['frase_clave'] ) ) {
				continue;
			}
			$out[ $e['ruta'] ] = $e;
		}
		return $out;
	}

	/**
	 * La página de WordPress: la portada por Ajustes → Lectura; las otras 4 por su dirección.
	 *
	 * @return WP_Post|null
	 */
	public static function pagina( $ruta ) {
		if ( '' === $ruta ) {
			if ( 'page' !== get_option( 'show_on_front' ) ) {
				return null;
			}
			$p = get_post( (int) get_option( 'page_on_front' ) );
		} else {
			$p = get_page_by_path( $ruta, OBJECT, 'page' );
		}
		return ( $p instanceof WP_Post && 'page' === $p->post_type && 'trash' !== $p->post_status ) ? $p : null;
	}

	public static function actuales( $id ) {
		$v = array();
		foreach ( self::CAMPOS as $k => $meta ) {
			$v[ $k ] = (string) get_post_meta( $id, $meta, true );
		}
		return $v;
	}

	/**
	 * Estado de cada una: falta / al_dia / pendiente; y si hay copia para restaurar.
	 */
	public static function estado( array $m ) {
		$filas = array();
		foreach ( self::entradas( $m ) as $ruta => $e ) {
			$p = self::pagina( $ruta );
			$f = array(
				'e'        => $e,
				'post'     => $p,
				'estado'   => 'falta',
				'actual'   => array(),
				'anterior' => null,
			);
			if ( $p ) {
				$f['actual']   = self::actuales( $p->ID );
				$f['estado']   = ( $f['actual']['seo_titulo'] === $e['seo_titulo'] && $f['actual']['seo_meta'] === $e['seo_meta'] && $f['actual']['frase_clave'] === $e['frase_clave'] ) ? 'al_dia' : 'pendiente';
				$ant           = get_post_meta( $p->ID, self::META_ANTERIOR, true );
				$f['anterior'] = is_array( $ant ) ? $ant : null;
			}
			$filas[ $ruta ] = $f;
		}
		return $filas;
	}

	/**
	 * Escribe los 3 campos de Yoast en las rutas elegidas (o lo simula).
	 *
	 * @return array Líneas de registro.
	 */
	public static function aplicar( array $m, array $rutas, $simular ) {
		$lineas = array( ( $simular ? 'SIMULACIÓN · ' : '' ) . 'Yoast de las páginas que posicionan (solo título SEO, meta y frase clave; el contenido no se toca)' );
		foreach ( self::estado( $m ) as $ruta => $f ) {
			if ( ! in_array( $ruta, $rutas, true ) ) {
				continue;
			}
			$url = '/' . ( '' === $ruta ? '' : $ruta . '/' );
			if ( ! $f['post'] ) {
				$lineas[] = 'OMITIDA ' . $url . ' · no se encuentra la página' . ( '' === $ruta ? ' (Ajustes → Lectura no tiene una página estática de inicio: el título de la portada se pone en Yoast → Ajustes → Página de inicio)' : '' ) . '.';
				continue;
			}
			if ( 'al_dia' === $f['estado'] ) {
				$lineas[] = 'AL DÍA ' . $url . ' · no hace falta cambiar nada.';
				continue;
			}
			$cambios = array();
			foreach ( self::CAMPOS as $k => $meta ) {
				if ( $f['actual'][ $k ] !== $f['e'][ $k ] ) {
					$cambios[] = $k . ': «' . $f['actual'][ $k ] . '» → «' . $f['e'][ $k ] . '»';
				}
			}
			if ( $simular ) {
				$lineas[] = '[simulación] ' . $url . ' · ' . implode( ' · ', $cambios );
				continue;
			}
			// Copia de los valores anteriores (solo si no hay ya una pendiente de restaurar: así se conserva el original).
			if ( ! is_array( get_post_meta( $f['post']->ID, self::META_ANTERIOR, true ) ) ) {
				$copia          = $f['actual'];
				$copia['fecha'] = current_time( 'mysql' );
				update_post_meta( $f['post']->ID, self::META_ANTERIOR, $copia );
			}
			foreach ( self::CAMPOS as $k => $meta ) {
				update_post_meta( $f['post']->ID, $meta, wp_slash( $f['e'][ $k ] ) );
			}
			clean_post_cache( $f['post']->ID );
			$lineas[] = 'YOAST ACTUALIZADO ' . $url . ' (ID ' . (int) $f['post']->ID . ') · ' . implode( ' · ', $cambios );
		}
		return $lineas;
	}

	/**
	 * Devuelve los 3 campos a los valores guardados antes del primer cambio.
	 *
	 * @return array Líneas de registro.
	 */
	public static function restaurar( array $m, $ruta ) {
		$f = self::estado( $m )[ $ruta ] ?? null;
		if ( ! $f || ! $f['post'] || ! is_array( $f['anterior'] ) ) {
			return array( 'No hay valores anteriores guardados para esa página.' );
		}
		foreach ( self::CAMPOS as $k => $meta ) {
			$v = (string) ( $f['anterior'][ $k ] ?? '' );
			if ( '' === $v ) {
				delete_post_meta( $f['post']->ID, $meta );
			} else {
				update_post_meta( $f['post']->ID, $meta, wp_slash( $v ) );
			}
		}
		delete_post_meta( $f['post']->ID, self::META_ANTERIOR );
		clean_post_cache( $f['post']->ID );
		return array( 'YOAST RESTAURADO /' . ( '' === $ruta ? '' : $ruta . '/' ) . ' · título SEO «' . ( $f['anterior']['seo_titulo'] ?? '' ) . '», meta y frase clave como estaban el ' . ( $f['anterior']['fecha'] ?? '' ) . '.' );
	}
}
