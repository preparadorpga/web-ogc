<?php
/**
 * Entradas del blog (2.1.0): el plugin crea y actualiza las entradas que trae el manifiesto firmado («entradas»).
 *
 * Reglas:
 *   - Solo entradas (post_type «post»). Las que crea llevan la meta _ogc_blog_gestionada = 1 y _ogc_blog_slug.
 *   - Fecha en el manifiesto en UTC (fecha_gmt) y en hora de Madrid (fecha, informativa). Si la fecha es futura, se guarda
 *     «Programada» (future); si ya ha pasado, «Publicada». Una entrada ya publicada nunca se despublica ni cambia de fecha;
 *     si Vicente la pasa a borrador, pendiente o privada, se respeta.
 *   - Nunca toca una entrada que no creó él. Si ya existe una entrada con el mismo slug (por ejemplo, porque se importó el
 *     WXR), la ADOPTA solo si coincide con la del WXR original (sha256 del contenido, o título + fecha); si no, la omite y avisa.
 *   - Solo reescribe las que cambian (hash) y antes guarda una revisión. kses se quita solo durante la escritura y se restaura.
 *   - Una entrada que el plugin creó y que está en la papelera, o que se borró definitivamente, no se vuelve a crear.
 *   - Imagen destacada opcional: solo una de las imágenes del manifiesto (img/…, png/jpg/webp, sha256 comprobado), ya
 *     copiada en wp-content/uploads/ogc/. El adjunto se crea una vez y se reutiliza.
 * El contenido es un dato firmado: se guarda como post_content; el plugin nunca evalúa nada de él.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Blog {

	const META_GESTIONADA = '_ogc_blog_gestionada';
	const META_SLUG       = '_ogc_blog_slug';
	const META_HASH       = '_ogc_blog_hash';
	const META_GUARDADO   = '_ogc_blog_guardado';
	const META_VERSION    = '_ogc_blog_version';
	const META_IMAGEN     = '_ogc_blog_imagen';      // En el adjunto: «img/nombre.ext|sha256».
	const OPC_ESTADO      = 'ogc_paginas_blog_estado';
	const OPC_BORRADAS    = 'ogc_paginas_blog_borradas';

	const MAX_ENTRADAS  = 500;
	const MAX_CONTENIDO = 1048576;
	const RE_SLUG       = '/^[a-z0-9]+(-[a-z0-9]+)*$/';
	const RE_FECHA      = '/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/';
	const RE_HASH       = '/^[0-9a-f]{64}$/';

	/** @var string */
	private static $version_en_curso = '';

	// ------------------------------------------------------------------ Validación (solo datos)

	/**
	 * Valida la lista «entradas» de un manifiesto. Lista vacía o ausente = sin entradas.
	 *
	 * @param mixed $e Valor de «entradas».
	 * @param array $m Manifiesto (para las imágenes).
	 * @return true|string
	 */
	public static function validar_lista( $e, array $m ) {
		if ( null === $e ) {
			return true;
		}
		if ( ! is_array( $e ) || ( $e && array_keys( $e ) !== range( 0, count( $e ) - 1 ) ) ) {
			return 'entradas del blog: no es una lista';
		}
		if ( count( $e ) > self::MAX_ENTRADAS ) {
			return 'entradas del blog: demasiadas';
		}
		$imgs = array();
		$l    = OGC_Paginas_Imagenes::lista( $m );
		if ( is_array( $l ) ) {
			foreach ( $l as $i ) {
				$imgs[ $i['ruta'] ] = $i;
			}
		}
		$vistos = array();
		foreach ( $e as $n => $x ) {
			$ok = self::validar_una( $x, $imgs );
			if ( true !== $ok ) {
				return sprintf( 'Entrada n.º %d del blog descartada: %s', (int) $n + 1, $ok );
			}
			if ( isset( $vistos[ $x['slug'] ] ) ) {
				return 'Entrada del blog repetida: ' . $x['slug'];
			}
			$vistos[ $x['slug'] ] = true;
		}
		return true;
	}

	private static function fecha_valida( $f ) {
		if ( ! is_string( $f ) || ! preg_match( self::RE_FECHA, $f, $p ) ) {
			return false;
		}
		return checkdate( (int) $p[2], (int) $p[3], (int) $p[1] ) && (int) $p[1] >= 2020 && (int) $p[1] <= 2100 && (int) $p[4] < 24 && (int) $p[5] < 60 && (int) $p[6] < 60;
	}

	private static function terminos_validos( $t, $min, $max ) {
		if ( ! is_array( $t ) || count( $t ) < $min || count( $t ) > $max || ( $t && array_keys( $t ) !== range( 0, count( $t ) - 1 ) ) ) {
			return false;
		}
		foreach ( $t as $x ) {
			if ( ! is_array( $x ) || ! isset( $x['nombre'], $x['slug'] ) || ! is_string( $x['nombre'] ) || ! is_string( $x['slug'] ) ) {
				return false;
			}
			$n = trim( $x['nombre'] );
			if ( '' === $n || strlen( $n ) > 100 || preg_match( '/[<>"]/', $n ) || strlen( $x['slug'] ) > 100 || ! preg_match( self::RE_SLUG, $x['slug'] ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @return true|string
	 */
	private static function validar_una( $x, array $imgs ) {
		if ( ! is_array( $x ) ) {
			return 'no es un objeto';
		}
		foreach ( array( 'slug', 'titulo', 'contenido', 'hash_contenido', 'extracto', 'fecha', 'fecha_gmt', 'seo_titulo', 'seo_meta', 'frase_clave', 'titulo_migas', 'hash' ) as $k ) {
			if ( ! isset( $x[ $k ] ) || ! is_string( $x[ $k ] ) ) {
				return 'falta el campo ' . $k;
			}
		}
		if ( strlen( $x['slug'] ) > 190 || ! preg_match( self::RE_SLUG, $x['slug'] ) ) {
			return 'slug no válido';
		}
		if ( '' === trim( $x['titulo'] ) || strlen( $x['titulo'] ) > 300 || '' === trim( $x['contenido'] ) || strlen( $x['contenido'] ) > self::MAX_CONTENIDO ) {
			return 'título o contenido vacío o demasiado largo';
		}
		if ( strlen( $x['extracto'] ) > 1000 || strlen( $x['seo_titulo'] ) > 300 || strlen( $x['seo_meta'] ) > 500 || strlen( $x['frase_clave'] ) > 200 || strlen( $x['titulo_migas'] ) > 200 ) {
			return 'extracto o campos de Yoast demasiado largos';
		}
		if ( ! preg_match( self::RE_HASH, $x['hash'] ) || ! preg_match( self::RE_HASH, $x['hash_contenido'] ) || ! hash_equals( $x['hash_contenido'], hash( 'sha256', $x['contenido'] ) ) ) {
			return 'el contenido de «' . $x['slug'] . '» está dañado (hash distinto)';
		}
		if ( ! self::fecha_valida( $x['fecha_gmt'] ) || ! self::fecha_valida( $x['fecha'] ) ) {
			return 'fecha no válida';
		}
		if ( ! isset( $x['categorias'] ) || ! self::terminos_validos( $x['categorias'], 1, 10 ) ) {
			return 'categorías no válidas';
		}
		if ( ! isset( $x['etiquetas'] ) || ! self::terminos_validos( $x['etiquetas'], 0, 30 ) ) {
			return 'etiquetas no válidas';
		}
		if ( isset( $x['imagen'] ) && null !== $x['imagen'] ) {
			$i = $x['imagen'];
			if ( ! is_array( $i ) || ! isset( $i['ruta'], $i['alt'] ) || ! is_string( $i['ruta'] ) || ! is_string( $i['alt'] ) || strlen( $i['alt'] ) > 300 ) {
				return 'imagen destacada mal descrita';
			}
			if ( ! isset( $imgs[ $i['ruta'] ] ) ) {
				return 'la imagen destacada ' . $i['ruta'] . ' no está en la lista de imágenes firmadas';
			}
		}
		if ( isset( $x['wxr'] ) && null !== $x['wxr'] ) {
			$w = $x['wxr'];
			if ( ! is_array( $w ) || ! isset( $w['hash'], $w['titulo'], $w['fecha'] ) || ! is_string( $w['titulo'] ) || ! is_string( $w['hash'] ) || ! preg_match( self::RE_HASH, $w['hash'] ) || ! self::fecha_valida( $w['fecha'] ) ) {
				return 'datos del WXR original no válidos';
			}
		}
		return true;
	}

	/** Entradas del manifiesto (ya validado). */
	public static function entradas( array $m ) {
		return isset( $m['entradas'] ) && is_array( $m['entradas'] ) ? $m['entradas'] : array();
	}

	// ------------------------------------------------------------------ Búsquedas

	private static function es_gestionada( $p ) {
		return $p && '1' === (string) get_post_meta( $p->ID, self::META_GESTIONADA, true );
	}

	/** Entrada que creó (o adoptó) el plugin para ese slug, aunque Vicente le haya cambiado la dirección. */
	public static function gestionada( $slug ) {
		$ids = get_posts(
			array(
				'post_type'        => 'post',
				'post_status'      => array( 'publish', 'future', 'draft', 'pending', 'private', 'trash' ),
				'meta_key'         => self::META_SLUG, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'       => $slug, // phpcs:ignore WordPress.DB.SlowDBQuery
				'numberposts'      => 5,
				'fields'           => 'ids',
				'orderby'          => 'ID',
				'order'            => 'ASC',
				'suppress_filters' => true,
				'no_found_rows'    => true,
			)
		);
		foreach ( (array) $ids as $id ) {
			$p = get_post( $id );
			if ( $p && 'post' === $p->post_type && self::es_gestionada( $p ) ) {
				return $p;
			}
		}
		return null;
	}

	/** Entrada (de quien sea, fuera de la papelera) que tiene hoy ese slug. */
	public static function por_slug( $slug ) {
		$ids = get_posts(
			array(
				'post_type'        => 'post',
				'name'             => $slug,
				'post_status'      => array( 'publish', 'future', 'draft', 'pending', 'private' ),
				'numberposts'      => 1,
				'fields'           => 'ids',
				'suppress_filters' => true,
				'no_found_rows'    => true,
			)
		);
		$p = $ids ? get_post( (int) $ids[0] ) : null;
		return ( $p && 'post' === $p->post_type ) ? $p : null;
	}

	/** Mismo criterio que el publicador (Python): finales de línea \n y sin espacios al principio y al final. */
	public static function normalizar( $t ) {
		return trim( str_replace( "\r\n", "\n", (string) $t ) );
	}

	/**
	 * ¿La entrada ajena es la del fichero WXR original (o la misma que trae el paquete)?
	 *
	 * @return string Criterio que coincide, o '' si no coincide.
	 */
	public static function coincide_wxr( $post, array $x ) {
		$h = hash( 'sha256', self::normalizar( $post->post_content ) );
		$w = isset( $x['wxr'] ) && is_array( $x['wxr'] ) ? $x['wxr'] : null;
		if ( $w && hash_equals( $w['hash'], $h ) ) {
			return 'el contenido del WXR (hash)';
		}
		if ( hash_equals( hash( 'sha256', self::normalizar( $x['contenido'] ) ), $h ) ) {
			return 'el contenido del paquete (hash)';
		}
		if ( $w && trim( (string) $post->post_title ) === trim( $w['titulo'] ) && (string) $post->post_date === $w['fecha'] ) {
			return 'el título y la fecha del WXR';
		}
		return '';
	}

	public static function borradas() {
		$b = get_option( self::OPC_BORRADAS, array() );
		return is_array( $b ) ? $b : array();
	}

	/** before_delete_post: si se borra definitivamente una entrada del plugin, se anota para no volver a crearla. */
	public static function al_borrar( $id ) {
		$p = get_post( $id );
		if ( ! $p || 'post' !== $p->post_type || ! self::es_gestionada( $p ) ) {
			return;
		}
		$slug = (string) get_post_meta( $p->ID, self::META_SLUG, true );
		if ( '' === $slug ) {
			return;
		}
		$b          = self::borradas();
		$b[ $slug ] = current_time( 'mysql' );
		update_option( self::OPC_BORRADAS, array_slice( $b, -500, null, true ), false );
	}

	// ------------------------------------------------------------------ Plan

	/** ¿La fecha (UTC) es futura? */
	public static function es_futura( $gmt, $ahora = null ) {
		$t = strtotime( $gmt . ' UTC' );
		return false !== $t && $t > ( null === $ahora ? time() : (int) $ahora );
	}

	/**
	 * Qué se haría con cada entrada.
	 *
	 * @return array Filas: x, estado (nueva|al_dia|cambiada|adoptar|omitida), accion (crear|actualizar|adoptar|nada), motivo, post, a_mano.
	 */
	public static function plan( array $m ) {
		$filas   = array();
		$borr    = self::borradas();
		foreach ( self::entradas( $m ) as $x ) {
			$f    = array(
				'x'      => $x,
				'estado' => '',
				'accion' => 'nada',
				'motivo' => '',
				'post'   => null,
				'a_mano' => false,
			);
			$post = self::gestionada( $x['slug'] );
			if ( $post ) {
				$f['post'] = $post;
				if ( 'trash' === $post->post_status ) {
					$f['estado'] = 'omitida';
					$f['motivo'] = 'Está en la papelera: el plugin no la vuelve a crear ni la toca. Restáurala si la quieres.';
				} else {
					$f['estado'] = hash_equals( (string) get_post_meta( $post->ID, self::META_HASH, true ), $x['hash'] ) ? 'al_dia' : 'cambiada';
					$g           = (string) get_post_meta( $post->ID, self::META_GUARDADO, true );
					$f['a_mano'] = ( '' !== $g && md5( (string) $post->post_content ) !== $g );
					if ( 'cambiada' === $f['estado'] ) {
						$f['accion'] = 'actualizar';
					}
				}
			} elseif ( isset( $borr[ $x['slug'] ] ) ) {
				$f['estado'] = 'omitida';
				$f['motivo'] = 'La borraste definitivamente en WordPress (' . $borr[ $x['slug'] ] . '): el plugin no la vuelve a crear.';
			} else {
				$otra = self::por_slug( $x['slug'] );
				if ( $otra ) {
					$f['post'] = $otra;
					$c         = self::coincide_wxr( $otra, $x );
					if ( '' !== $c ) {
						$f['estado'] = 'adoptar';
						$f['accion'] = 'adoptar';
						$f['motivo'] = 'Ya existía (coincide con ' . $c . '): el plugin la adopta y la pone al día, con revisión previa.';
					} else {
						$f['estado'] = 'omitida';
						$f['motivo'] = 'Ya existe una entrada con esta dirección que no creó el plugin y no coincide con la del fichero WXR original: no se toca. Si es una copia vieja de este artículo, muévela a la papelera y vuelve a sincronizar.';
					}
				} else {
					$f['estado'] = 'nueva';
					$f['accion'] = 'crear';
				}
			}
			$filas[] = $f;
		}
		return $filas;
	}

	/**
	 * Estado con que se guarda. Publicada se queda publicada (nunca se despublica); borrador, pendiente y privada se
	 * respetan; si no, programada si la fecha es futura y publicada si ya ha pasado.
	 */
	public static function estado_final( array $x, $post, $ahora = null ) {
		if ( $post && in_array( $post->post_status, array( 'publish', 'draft', 'pending', 'private' ), true ) ) {
			return $post->post_status;
		}
		return self::es_futura( $x['fecha_gmt'], $ahora ) ? 'future' : 'publish';
	}

	// ------------------------------------------------------------------ Ejecución

	/** Huella del conjunto de entradas (para saber si hay algo nuevo que aplicar). */
	public static function firma( array $m ) {
		$s = '';
		foreach ( self::entradas( $m ) as $x ) {
			$s .= $x['slug'] . ':' . $x['hash'] . "\n";
		}
		return hash( 'sha256', $s );
	}

	public static function estado() {
		$e = get_option( self::OPC_ESTADO, array() );
		return array_merge(
			array(
				'firma'       => '',
				'firma_error' => '',
				'fecha'       => '',
			),
			is_array( $e ) ? $e : array()
		);
	}

	/**
	 * WP-Cron y «Comprobar ahora»: si el manifiesto en uso trae entradas que todavía no se han aplicado (por ejemplo, tras
	 * instalar la 2.1.0 con un paquete ya aplicado por la 2.0.0), las aplica. No repite cada hora un mismo fallo.
	 *
	 * @return array Líneas.
	 */
	public static function si_pendiente( $quien = 'automática' ) {
		$m = OGC_Paginas_Manifiesto::cargar();
		if ( ! $m || ! self::entradas( $m ) ) {
			return array();
		}
		$e = self::estado();
		$f = self::firma( $m );
		if ( $f === $e['firma'] || ( 'automática' === $quien && $f === $e['firma_error'] ) ) {
			return array();
		}
		return self::ejecutar( $m, false, $quien );
	}

	/**
	 * Crea, adopta o actualiza las entradas (o lo simula).
	 *
	 * @param array  $m       Manifiesto validado.
	 * @param bool   $simular true = no escribe nada.
	 * @param string $quien   «manual» o «automática» (solo para el registro).
	 * @return array Líneas.
	 */
	public static function ejecutar( array $m, $simular, $quien = 'manual' ) {
		$ok = self::validar_lista( $m['entradas'] ?? null, $m );
		if ( true !== $ok ) {
			$l = array( 'BLOG · no se aplica nada: ' . $ok );
			self::registrar( $l, $simular );
			return $l;
		}
		$filas = self::plan( $m );
		if ( ! $filas ) {
			return array();
		}
		self::$version_en_curso = (string) ( $m['version'] ?? '' ) . ( isset( $m['serie'] ) ? '#' . (int) $m['serie'] : '' );
		$lineas = array();
		$n      = array(
			'crear'      => 0,
			'adoptar'    => 0,
			'actualizar' => 0,
			'omitida'    => 0,
			'error'      => 0,
		);
		$con_img = false;
		foreach ( $filas as $f ) {
			if ( 'nada' !== $f['accion'] && ! empty( $f['x']['imagen'] ) ) {
				$con_img = true;
			}
		}
		if ( $con_img && ! $simular ) {
			$li = OGC_Paginas_Imagenes::instalar( $m, false ); // Copia desde img/ las que falten en uploads/ogc/ (las remotas ya están).
			if ( count( $li ) > 1 ) {
				$lineas = array_merge( $lineas, $li );
			}
		}
		$kses_activo = (bool) has_filter( 'content_save_pre', 'wp_filter_post_kses' );
		if ( ! $simular ) {
			kses_remove_filters(); // Contenido firmado; solo durante la escritura.
		}
		try {
			foreach ( $filas as $f ) {
				$x   = $f['x'];
				$url = '/blog/' . $x['slug'] . '/';
				if ( 'omitida' === $f['estado'] ) {
					$lineas[] = 'OMITIDA ' . $url . ' · ' . $f['motivo'];
					++$n['omitida'];
					continue;
				}
				if ( 'nada' === $f['accion'] ) {
					continue;
				}
				$estado = self::estado_final( $x, $f['post'] );
				$verbo  = array(
					'crear'      => 'CREAR ',
					'adoptar'    => 'ADOPTAR Y ACTUALIZAR ',
					'actualizar' => 'ACTUALIZAR ',
				)[ $f['accion'] ];
				$texto  = $verbo . $url . ' como ' . ( 'future' === $estado ? 'PROGRAMADA para el ' . $x['fecha'] . ' (Madrid)' : self::nombre_estado( $estado ) );
				if ( 'adoptar' === $f['accion'] ) {
					$texto .= ' · ' . $f['motivo'];
				}
				if ( $f['a_mano'] ) {
					$texto .= ' · tenía cambios hechos a mano en WordPress: quedan en el historial de revisiones';
				}
				if ( $simular ) {
					$lineas[] = '[simulación] ' . $texto;
					++$n[ $f['accion'] ];
					continue;
				}
				$r = self::escribir( $x, $f['post'], 'adoptar' === $f['accion'], $estado, $m );
				if ( is_wp_error( $r ) ) {
					$lineas[] = 'ERROR ' . $url . ' · ' . $r->get_error_message();
					++$n['error'];
					continue;
				}
				$real = (string) get_post_field( 'post_name', (int) $r );
				if ( '' !== $real && $real !== $x['slug'] ) {
					$texto .= ' · OJO: WordPress le ha puesto el slug «' . $real . '» porque «' . $x['slug'] . '» estaba ocupado (revísalo)';
				}
				$lineas[] = $texto . ' · ID ' . (int) $r;
				++$n[ $f['accion'] ];
			}
		} finally {
			if ( ! $simular && $kses_activo ) {
				kses_init_filters();
			}
		}
		array_unshift(
			$lineas,
			sprintf(
				'%s · %d entradas en el paquete · %d creadas, %d adoptadas, %d actualizadas, %d omitidas, %d errores.',
				$simular ? 'BLOG · SIMULACIÓN (no se ha cambiado nada)' : 'BLOG · ' . ( 'automática' === $quien ? 'SINCRONIZACIÓN AUTOMÁTICA' : 'SINCRONIZACIÓN' ),
				count( $filas ),
				$n['crear'],
				$n['adoptar'],
				$n['actualizar'],
				$n['omitida'],
				$n['error']
			)
		);
		if ( ! $simular ) {
			$e = self::estado();
			if ( $n['error'] ) {
				$e['firma_error'] = self::firma( $m );
			} else {
				$e['firma']       = self::firma( $m );
				$e['firma_error'] = '';
			}
			$e['fecha'] = current_time( 'mysql' );
			update_option( self::OPC_ESTADO, $e, false );
		}
		$hay = $n['crear'] + $n['adoptar'] + $n['actualizar'] + $n['error'] + $n['omitida'];
		if ( $simular || $hay || 'manual' === $quien ) {
			self::registrar( $lineas, $simular );
		}
		return $lineas;
	}

	private static function registrar( array $l, $simular ) {
		if ( class_exists( 'OGC_Paginas_Sincronizador' ) ) {
			OGC_Paginas_Sincronizador::registrar( $l, $simular );
		}
	}

	public static function nombre_estado( $s ) {
		$t = array(
			'publish' => 'publicada',
			'future'  => 'programada',
			'draft'   => 'borrador',
			'pending' => 'pendiente',
			'private' => 'privada',
			'trash'   => 'papelera',
		);
		return $t[ $s ] ?? $s;
	}

	/**
	 * @return int|WP_Error ID de la entrada.
	 */
	private static function escribir( array $x, $post, $adoptar, $estado, array $m ) {
		$meta = array(
			self::META_GESTIONADA   => '1',
			self::META_SLUG         => $x['slug'],
			self::META_HASH         => $x['hash'],
			self::META_VERSION      => self::$version_en_curso,
			'_yoast_wpseo_title'    => $x['seo_titulo'],
			'_yoast_wpseo_metadesc' => $x['seo_meta'],
			'_yoast_wpseo_focuskw'  => $x['frase_clave'],
			'_yoast_wpseo_bctitle'  => $x['titulo_migas'],
			// Indexable y con el canonical por defecto de Yoast (la propia URL).
			'_yoast_wpseo_meta-robots-noindex' => '0',
			'_yoast_wpseo_canonical'           => '',
		);
		$arr  = array(
			'post_type'      => 'post',
			'post_title'     => $x['titulo'],
			'post_name'      => $x['slug'],
			'post_content'   => $x['contenido'],
			'post_excerpt'   => $x['extracto'],
			'post_status'    => $estado,
			'comment_status' => 'closed',
			'ping_status'    => 'closed',
			'meta_input'     => $meta,
		);
		if ( ! $post || 'publish' !== $post->post_status ) {
			// Una entrada ya publicada conserva su fecha; el resto toma la del paquete (UTC → hora del sitio).
			$arr['post_date_gmt'] = $x['fecha_gmt'];
			$arr['post_date']     = get_date_from_gmt( $x['fecha_gmt'] );
			$arr['edit_date']     = true;
		}
		if ( $post ) {
			if ( 'post' !== $post->post_type ) {
				return new WP_Error( 'ogc_tipo', 'no es una entrada; no se toca.' );
			}
			if ( ! $adoptar && ! self::es_gestionada( $post ) ) {
				return new WP_Error( 'ogc_no_gestionada', 'la entrada no es del plugin; no se toca.' );
			}
			if ( $adoptar && ( self::es_gestionada( $post ) || '' === self::coincide_wxr( $post, $x ) ) ) {
				return new WP_Error( 'ogc_no_adoptable', 'la entrada ya no coincide con la del WXR original; no se toca.' );
			}
			if ( wp_revisions_enabled( $post ) ) {
				wp_save_post_revision( $post->ID );
			}
			$arr['ID'] = (int) $post->ID;
			$id        = wp_update_post( wp_slash( $arr ), true );
		} else {
			$arr['post_author'] = get_current_user_id() ? get_current_user_id() : ( class_exists( 'OGC_Paginas_Sync' ) ? OGC_Paginas_Sync::autor() : 0 );
			$id                 = wp_insert_post( wp_slash( $arr ), true );
		}
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		if ( ! $id ) {
			return new WP_Error( 'ogc_sin_id', 'WordPress no ha guardado la entrada.' );
		}
		$id = (int) $id;
		foreach ( array( 'category' => 'categorias', 'post_tag' => 'etiquetas' ) as $tax => $k ) {
			$ids = array();
			foreach ( $x[ $k ] as $t ) {
				$tid = self::termino( $t, $tax );
				if ( $tid ) {
					$ids[] = $tid;
				}
			}
			if ( $ids || 'post_tag' === $tax ) {
				wp_set_object_terms( $id, $ids, $tax, false );
			}
		}
		if ( ! empty( $x['imagen'] ) ) {
			$att = self::adjunto( $x['imagen'], $m );
			if ( $att ) {
				set_post_thumbnail( $id, $att );
			}
		}
		update_post_meta( $id, self::META_GUARDADO, md5( (string) get_post_field( 'post_content', $id, 'raw' ) ) );
		return $id;
	}

	/** ID del término (categoría o etiqueta) por su slug; lo crea si no existe. */
	private static function termino( array $t, $tax ) {
		$e = term_exists( $t['slug'], $tax );
		if ( $e ) {
			return (int) ( is_array( $e ) ? $e['term_id'] : $e );
		}
		$r = wp_insert_term( $t['nombre'], $tax, array( 'slug' => $t['slug'] ) );
		if ( is_wp_error( $r ) ) {
			return 0;
		}
		return (int) $r['term_id'];
	}

	/**
	 * Adjunto de la imagen destacada (se crea una vez a partir de wp-content/uploads/ogc/<nombre>, ya comprobada).
	 *
	 * @return int ID del adjunto o 0.
	 */
	public static function adjunto( array $img, array $m ) {
		$l = OGC_Paginas_Imagenes::lista( $m );
		$i = null;
		foreach ( is_array( $l ) ? $l : array() as $c ) {
			if ( $c['ruta'] === $img['ruta'] ) {
				$i = $c;
			}
		}
		$dir = OGC_Paginas_Imagenes::destino();
		if ( ! $i || '' === $dir ) {
			return 0;
		}
		$file = $dir . '/' . $i['nombre'];
		if ( ! is_readable( $file ) || ! hash_equals( $i['sha256'], (string) hash_file( 'sha256', $file ) ) ) {
			return 0;
		}
		$clave = $i['ruta'] . '|' . $i['sha256'];
		$ids   = get_posts(
			array(
				'post_type'        => 'attachment',
				'post_status'      => 'inherit',
				'meta_key'         => self::META_IMAGEN, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'       => $clave, // phpcs:ignore WordPress.DB.SlowDBQuery
				'numberposts'      => 1,
				'fields'           => 'ids',
				'suppress_filters' => true,
				'no_found_rows'    => true,
			)
		);
		if ( $ids ) {
			$att = (int) $ids[0];
		} else {
			$up  = wp_upload_dir( null, false );
			$att = wp_insert_attachment(
				array(
					'post_mime_type' => OGC_Paginas_Imagenes::TIPOS[ $i['ext'] ],
					'post_title'     => '' !== $img['alt'] ? $img['alt'] : $i['nombre'],
					'post_content'   => '',
					'post_status'    => 'inherit',
					'guid'           => rtrim( (string) ( $up['baseurl'] ?? '' ), '/' ) . '/ogc/' . $i['nombre'],
				),
				$file,
				0,
				true
			);
			if ( is_wp_error( $att ) || ! $att ) {
				return 0;
			}
			$att = (int) $att;
			if ( ! function_exists( 'wp_generate_attachment_metadata' ) && is_readable( ABSPATH . 'wp-admin/includes/image.php' ) ) {
				require_once ABSPATH . 'wp-admin/includes/image.php';
			}
			if ( function_exists( 'wp_generate_attachment_metadata' ) ) {
				wp_update_attachment_metadata( $att, wp_generate_attachment_metadata( $att, $file ) );
			}
			update_post_meta( $att, self::META_IMAGEN, $clave );
		}
		update_post_meta( $att, '_wp_attachment_image_alt', $img['alt'] );
		return $att;
	}
}
