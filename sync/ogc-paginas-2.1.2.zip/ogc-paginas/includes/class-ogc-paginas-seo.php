<?php
/**
 * Indexación (2.1.0): robots.txt virtual, /llms.txt, IndexNow y comprobaciones (mapas del sitio de Yoast, visibilidad).
 *
 *   - robots.txt: filtro robots_txt con el texto FIRMADO del manifiesto («robots_txt»: bots de IA permitidos, admin
 *     bloqueado, línea Sitemap). Si la web está en «Disuadir a los motores de búsqueda», se respeta lo de WordPress y se
 *     avisa. Si hay un robots.txt físico en la raíz, el filtro no actúa: se muestra en la pantalla (nunca se borra).
 *   - /llms.txt: lo sirve el plugin (template_redirect, text/plain) con el texto firmado («llms_txt»).
 *   - IndexNow: clave generada una vez (opción), servida en /<clave>.txt. Cuando se publica o actualiza una página o
 *     entrada GESTIONADA (incluida la publicación de una programada), se envían sus URL a api.indexnow.org al final de
 *     la petición (POST JSON, máx. 100 por llamada, tiempo corto, sin esperar la respuesta). Registro en la pantalla.
 * Los textos son datos firmados; se imprimen como texto plano, nunca se evalúan.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Seo {

	const OPC_INDEXNOW = 'ogc_paginas_indexnow';      // clave + registro.
	const OPC_TEXTOS   = 'ogc_paginas_seo_textos';    // caché de robots/llms (no autocargada).
	const ENDPOINT     = 'https://api.indexnow.org/indexnow';
	const MAX_TEXTO    = 65536;
	const MAX_URLS     = 100;

	/** @var array URL pendientes de enviar en esta petición. */
	private static $cola = array();

	/** @var bool */
	private static $apagado = false;

	// ------------------------------------------------------------------ Validación del manifiesto

	/**
	 * «robots_txt» y «llms_txt»: null u objeto {texto, hash}.
	 *
	 * @return true|string
	 */
	public static function validar( array $m ) {
		foreach ( array( 'robots_txt', 'llms_txt' ) as $k ) {
			if ( ! isset( $m[ $k ] ) || null === $m[ $k ] ) {
				continue;
			}
			$e = $m[ $k ];
			if ( ! is_array( $e ) || ! isset( $e['texto'], $e['hash'] ) || ! is_string( $e['texto'] ) || ! is_string( $e['hash'] ) ) {
				return $k . ': no válido';
			}
			if ( strlen( $e['texto'] ) > self::MAX_TEXTO || ! hash_equals( $e['hash'], hash( 'sha256', $e['texto'] ) ) ) {
				return $k . ': demasiado largo o dañado (hash distinto)';
			}
			if ( false !== strpos( $e['texto'], '<?' ) || false !== strpos( $e['texto'], "\0" ) ) {
				return $k . ': contenido no permitido';
			}
		}
		return true;
	}

	/** Textos del manifiesto en uso (con caché que se rehace sola al cambiar el paquete o la versión). */
	public static function textos() {
		$f    = OGC_Paginas_Manifiesto::archivo();
		$e    = OGC_Paginas_Sync::estado();
		$id   = md5( ( defined( 'OGC_PAGINAS_VERSION' ) ? OGC_PAGINAS_VERSION : '' ) . '|' . ( is_readable( $f ) ? filemtime( $f ) . ':' . filesize( $f ) : '-' ) . '|' . $e['sha256'] . ':' . $e['aplicado'] . ':' . (int) $e['serie'] );
		$c    = get_option( self::OPC_TEXTOS, null );
		if ( is_array( $c ) && ( $c['id'] ?? '' ) === $id ) {
			return $c;
		}
		$m = OGC_Paginas_Manifiesto::cargar();
		$c = array(
			'id'     => $id,
			'robots' => ( $m && ! empty( $m['robots_txt']['texto'] ) ) ? $m['robots_txt']['texto'] : '',
			'llms'   => ( $m && ! empty( $m['llms_txt']['texto'] ) ) ? $m['llms_txt']['texto'] : '',
		);
		if ( $m ) {
			delete_option( self::OPC_TEXTOS );
			add_option( self::OPC_TEXTOS, $c, '', 'no' );
		}
		return $c;
	}

	// ------------------------------------------------------------------ robots.txt y llms.txt

	/** Filtro robots_txt. */
	public static function robots( $salida, $publico ) {
		if ( ! $publico ) {
			return $salida; // «Disuadir a los motores de búsqueda»: manda WordPress (y la pantalla avisa).
		}
		$t = self::textos()['robots'];
		return '' === $t ? $salida : $t;
	}

	public static function robots_fisico() {
		return file_exists( ABSPATH . 'robots.txt' ) ? ABSPATH . 'robots.txt' : '';
	}

	public static function llms_fisico() {
		return file_exists( ABSPATH . 'llms.txt' ) ? ABSPATH . 'llms.txt' : '';
	}

	/** Ruta pedida relativa a la portada, sin barras. */
	private static function ruta() {
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		return OGC_Paginas_Blog_Direccion::ruta_pedida( $uri, $home );
	}

	/**
	 * Qué texto corresponde a una ruta: array( tipo, texto ) o null.
	 */
	public static function texto_para( $ruta ) {
		if ( 'llms.txt' === $ruta ) {
			$t = self::textos()['llms'];
			return '' === $t ? null : array( 'llms', $t );
		}
		$k = self::clave( false );
		if ( '' !== $k && $k . '.txt' === $ruta ) {
			return array( 'indexnow', $k );
		}
		return null;
	}

	/** template_redirect (prioridad 0): /llms.txt y /<clave IndexNow>.txt. */
	public static function servir() {
		$r = self::texto_para( self::ruta() );
		if ( ! $r ) {
			return;
		}
		if ( function_exists( 'status_header' ) ) {
			status_header( 200 );
		}
		if ( ! headers_sent() ) {
			header( 'Content-Type: text/plain; charset=utf-8' );
			header( 'X-Content-Type-Options: nosniff' );
			header( 'Cache-Control: public, max-age=3600' );
		}
		echo $r[1]; // phpcs:ignore WordPress.Security.EscapeOutput -- texto plano firmado (o la clave), con Content-Type text/plain y nosniff.
		exit;
	}

	// ------------------------------------------------------------------ IndexNow

	/** Clave IndexNow (32 hexadecimales). Con $crear, la genera la primera vez. */
	public static function clave( $crear = true ) {
		$o = get_option( self::OPC_INDEXNOW, array() );
		$o = is_array( $o ) ? $o : array();
		if ( isset( $o['clave'] ) && is_string( $o['clave'] ) && preg_match( '/^[0-9a-f]{32}$/', $o['clave'] ) ) {
			return $o['clave'];
		}
		if ( ! $crear ) {
			return '';
		}
		$o['clave'] = bin2hex( random_bytes( 16 ) );
		update_option( self::OPC_INDEXNOW, $o, true );
		return $o['clave'];
	}

	private static function es_gestionada( $p ) {
		if ( 'page' === $p->post_type ) {
			return '1' === (string) get_post_meta( $p->ID, '_ogc_paginas_gestionada', true );
		}
		if ( 'post' === $p->post_type ) {
			return '1' === (string) get_post_meta( $p->ID, '_ogc_blog_gestionada', true );
		}
		return false;
	}

	/** transition_post_status: página o entrada gestionada que queda publicada (nueva, actualizada o programada que se publica). */
	public static function al_cambiar_estado( $nuevo, $viejo, $post ) {
		if ( 'publish' !== $nuevo || ! is_object( $post ) || ! self::es_gestionada( $post ) ) {
			return;
		}
		if ( '1' === (string) get_post_meta( $post->ID, '_yoast_wpseo_meta-robots-noindex', true ) ) {
			return; // Las noindex (p. ej. «Gracias») no se envían.
		}
		$u = get_permalink( $post );
		if ( is_string( $u ) && 0 === strpos( $u, home_url( '/' ) ) ) {
			self::$cola[ $u ] = true;
		}
	}

	public static function cola() {
		return array_keys( self::$cola );
	}

	/** Cuerpos de las llamadas (máx. 100 URL cada una). */
	public static function cuerpos( array $urls ) {
		$host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$k    = self::clave();
		$out  = array();
		foreach ( array_chunk( array_values( array_unique( $urls ) ), self::MAX_URLS ) as $trozo ) {
			$out[] = array(
				'host'        => $host,
				'key'         => $k,
				'keyLocation' => home_url( '/' . $k . '.txt' ),
				'urlList'     => $trozo,
			);
		}
		return $out;
	}

	/** shutdown: envía la cola (sin esperar respuesta). Solo si la web es pública y no es local. */
	public static function enviar() {
		if ( self::$apagado || ! self::$cola ) {
			return array();
		}
		$urls        = self::cola();
		self::$cola  = array();
		$host        = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		if ( '1' !== (string) get_option( 'blog_public' ) || '' === $host || false === strpos( $host, '.' ) || preg_match( '/(\.local|\.test|localhost)$/', $host ) ) {
			return array();
		}
		$n = 0;
		foreach ( self::cuerpos( $urls ) as $c ) {
			wp_remote_post(
				self::ENDPOINT,
				array(
					'timeout'  => 3,
					'blocking' => false,
					'headers'  => array( 'Content-Type' => 'application/json; charset=utf-8' ),
					'body'     => wp_json_encode( $c ),
				)
			);
			++$n;
		}
		$o        = get_option( self::OPC_INDEXNOW, array() );
		$o        = is_array( $o ) ? $o : array();
		$reg      = isset( $o['registro'] ) && is_array( $o['registro'] ) ? $o['registro'] : array();
		array_unshift(
			$reg,
			array(
				'fecha'    => current_time( 'mysql' ),
				'urls'     => count( $urls ),
				'llamadas' => $n,
				'ejemplo'  => array_slice( $urls, 0, 5 ),
			)
		);
		$o['registro'] = array_slice( $reg, 0, 20 );
		update_option( self::OPC_INDEXNOW, $o, true );
		return $urls;
	}

	// ------------------------------------------------------------------ Comprobaciones

	/**
	 * @return array bien (líneas), avisos (líneas).
	 */
	public static function comprobar() {
		$bien   = array();
		$avisos = array();
		if ( '1' === (string) get_option( 'blog_public' ) ) {
			$bien[] = 'La web es visible para los buscadores (Ajustes > Lectura: «Disuadir a los motores de búsqueda» desmarcado).';
		} else {
			$avisos[] = 'La web está en «Disuadir a los motores de búsqueda»: Google no la indexa. Paso: Ajustes > Lectura > desmarca «Disuadir a los motores de búsqueda de indexar este sitio» > Guardar cambios.';
		}
		$w = get_option( 'wpseo', array() );
		if ( ! defined( 'WPSEO_VERSION' ) && ! is_array( $w ) ) {
			$avisos[] = 'Yoast SEO no parece estar activo: no hay mapa del sitio XML (sitemap_index.xml). Paso: Plugins > Yoast SEO > Activar.';
		} elseif ( is_array( $w ) && array_key_exists( 'enable_xml_sitemap', $w ) && ! $w['enable_xml_sitemap'] ) {
			$avisos[] = 'Los mapas del sitio XML de Yoast están desactivados. Paso: Yoast SEO > Ajustes > Ajustes del sitio > Características del sitio > «Mapas del sitio XML»: activado > Guardar.';
		} else {
			$bien[] = 'Mapas del sitio XML de Yoast activados: ' . home_url( '/sitemap_index.xml' );
		}
		$t = self::textos();
		$f = self::robots_fisico();
		if ( '' !== $f ) {
			$avisos[] = 'Hay un archivo robots.txt FÍSICO en la carpeta raíz: manda él y el plugin no puede servir el suyo (no se borra). Si quieres el del plugin (con los bots de IA y la línea Sitemap), bórralo desde el administrador de archivos del hosting o desde Yoast SEO > Herramientas > Editor de archivos. Contenido actual: ' . substr( (string) file_get_contents( $f ), 0, 1500 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		} elseif ( '' !== $t['robots'] ) {
			$bien[] = 'robots.txt lo sirve el plugin (bots de IA permitidos, /wp-admin/ bloqueado y línea Sitemap): ' . home_url( '/robots.txt' );
		}
		if ( '' !== self::llms_fisico() ) {
			$avisos[] = 'Hay un archivo llms.txt FÍSICO en la carpeta raíz: manda él (no se actualiza solo). Si quieres el del plugin, bórralo desde el administrador de archivos del hosting.';
		} elseif ( '' !== $t['llms'] ) {
			$bien[] = '/llms.txt lo sirve el plugin y se actualiza con cada paquete firmado: ' . home_url( '/llms.txt' );
		}
		$k = self::clave( false );
		$bien[] = '' === $k ? 'IndexNow: la clave se crea con el primer envío.' : 'IndexNow activo (Bing, Yandex, Seznam, Naver…): clave en ' . home_url( '/' . $k . '.txt' );
		return array(
			'bien'   => $bien,
			'avisos' => $avisos,
		);
	}

	/** admin_notices: solo lo grave (web oculta a los buscadores o sin mapas del sitio). */
	public static function aviso() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$c = self::comprobar();
		foreach ( $c['avisos'] as $a ) {
			if ( false !== strpos( $a, 'Disuadir' ) || false !== strpos( $a, 'Mapas del sitio' ) || false !== strpos( $a, 'mapa del sitio' ) ) {
				echo '<div class="notice notice-warning"><p><strong>OGC Páginas · indexación:</strong> ' . esc_html( $a ) . '</p></div>';
			}
		}
	}

	/** Sección de la pestaña «Blog y SEO». */
	public static function seccion() {
		$c = self::comprobar();
		echo '<h2>Indexación (buscadores y asistentes de IA)</h2><ul style="list-style:disc;margin-left:20px">';
		foreach ( $c['bien'] as $l ) {
			echo '<li style="color:#2e7d32">' . esc_html( $l ) . '</li>';
		}
		foreach ( $c['avisos'] as $l ) {
			echo '<li style="color:#b26a00"><strong>Aviso:</strong> ' . esc_html( $l ) . '</li>';
		}
		echo '</ul>';
		$o   = get_option( self::OPC_INDEXNOW, array() );
		$reg = is_array( $o ) && isset( $o['registro'] ) && is_array( $o['registro'] ) ? $o['registro'] : array();
		if ( $reg ) {
			echo '<details><summary>Envíos a IndexNow (últimos ' . (int) count( $reg ) . ')</summary><ul style="list-style:disc;margin-left:20px">';
			foreach ( $reg as $r ) {
				echo '<li>' . esc_html( ( $r['fecha'] ?? '' ) . ' · ' . (int) ( $r['urls'] ?? 0 ) . ' URL · ' . implode( ', ', (array) ( $r['ejemplo'] ?? array() ) ) ) . '</li>';
			}
			echo '</ul></details>';
		}
	}

	/** Solo para las pruebas: no enviar nada en shutdown. */
	public static function apagar() {
		self::$apagado = true;
	}
}
