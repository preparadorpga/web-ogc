<?php
/**
 * Pestaña «Blog» de Herramientas → OGC Páginas (2.1.0): dirección del blog, entradas del paquete y sus botones.
 * Ver: manage_options. Cambiar: manage_options + unfiltered_html, siempre con nonce.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Blog_Admin {

	private static function url_volver() {
		return admin_url( 'tools.php?page=ogc-paginas&tab=blog' );
	}

	private static function puede() {
		return current_user_can( 'manage_options' ) && current_user_can( 'unfiltered_html' );
	}

	private static function terminar( array $lineas ) {
		set_transient( 'ogc_paginas_resultado_' . get_current_user_id(), $lineas, 10 * MINUTE_IN_SECONDS );
		wp_safe_redirect( self::url_volver() );
		exit;
	}

	public static function pagina() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$res = get_transient( 'ogc_paginas_resultado_' . get_current_user_id() );
		if ( is_array( $res ) && $res ) {
			delete_transient( 'ogc_paginas_resultado_' . get_current_user_id() );
			echo '<div class="notice notice-info"><p><strong>' . esc_html( (string) array_shift( $res ) ) . '</strong></p>';
			if ( $res ) {
				echo '<ul style="list-style:disc;margin-left:20px">';
				foreach ( $res as $l ) {
					echo '<li>' . esc_html( (string) $l ) . '</li>';
				}
				echo '</ul>';
			}
			echo '</div>';
		}
		$dis = self::puede() ? '' : ' disabled';

		if ( class_exists( 'OGC_Paginas_Seo' ) ) {
			OGC_Paginas_Seo::seccion();
		}

		// Dirección del blog.
		$c = OGC_Paginas_Blog_Direccion::comprobar();
		echo '<h2>Dirección del blog</h2>';
		echo '<ul style="list-style:disc;margin-left:20px">';
		foreach ( $c['bien'] as $l ) {
			echo '<li style="color:#2e7d32">' . esc_html( $l ) . '</li>';
		}
		foreach ( $c['avisos'] as $l ) {
			echo '<li style="color:#b26a00"><strong>Aviso:</strong> ' . esc_html( $l ) . '</li>';
		}
		echo '</ul>';
		if ( $c['boton'] ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'ogc_paginas_blog_direccion' );
			echo '<input type="hidden" name="action" value="ogc_paginas_blog_direccion">';
			echo '<p><label><input type="checkbox" name="confirmo" value="1" required> Confirmo: cambiar el slug de la página de entradas a «blog» y redirigir con 301 la dirección antigua a /blog/.</label></p>';
			echo '<p><button class="button button-primary"' . $dis . '>Cambiar dirección del blog a /blog/</button></p></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		} elseif ( '' !== $c['motivo'] ) {
			echo '<p><em>' . esc_html( $c['motivo'] ) . '</em></p>';
		}

		// Entradas.
		$m = OGC_Paginas_Manifiesto::cargar();
		echo '<h2>Entradas del blog</h2>';
		if ( ! $m ) {
			echo '<div class="notice notice-error"><p>' . esc_html( OGC_Paginas_Manifiesto::error() ) . '</p></div>';
			return;
		}
		$filas = OGC_Paginas_Blog::plan( $m );
		if ( ! $filas ) {
			echo '<p>El paquete en uso no trae entradas del blog.</p>';
			return;
		}
		$e = OGC_Paginas_Blog::estado();
		echo '<p>El plugin crea las entradas <strong>programadas</strong> con su fecha (hora de Madrid) o <strong>publicadas</strong> si la fecha ya ha pasado, con categoría, etiquetas, extracto y Yoast. Con la actualización automática activada lo hace solo (cada hora); este botón lo hace ahora. Nunca toca entradas que no haya creado él (salvo adoptar las del fichero WXR original, si lo importaste) y guarda una revisión antes de cambiar una. <strong>No hace falta importar ningún fichero.</strong></p>';
		echo '<p>Última aplicación: ' . esc_html( '' === $e['fecha'] ? 'todavía ninguna' : $e['fecha'] ) . '.</p>';
		$txt = array(
			'nueva'    => 'Se crea',
			'al_dia'   => 'Al día',
			'cambiada' => 'Se actualiza (con revisión)',
			'adoptar'  => 'Se adopta y se actualiza',
			'omitida'  => 'Omitida',
		);
		echo '<table class="widefat striped"><thead><tr><th>Fecha (Madrid)</th><th>Entrada</th><th>En WordPress</th><th>Qué hará</th></tr></thead><tbody>';
		foreach ( $filas as $f ) {
			$x = $f['x'];
			echo '<tr><td>' . esc_html( substr( $x['fecha'], 0, 16 ) ) . '</td><td><strong>' . esc_html( $x['titulo'] ) . '</strong><br><code>/blog/' . esc_html( $x['slug'] ) . '/</code></td><td>';
			if ( $f['post'] ) {
				echo esc_html( OGC_Paginas_Blog::nombre_estado( $f['post']->post_status ) ) . ' · ID ' . (int) $f['post']->ID;
			} else {
				echo '—';
			}
			echo '</td><td>' . esc_html( $txt[ $f['estado'] ] ?? $f['estado'] ) . ( $f['a_mano'] ? ' · editada a mano' : '' ) . ( '' !== $f['motivo'] ? '<br><small>' . esc_html( $f['motivo'] ) . '</small>' : '' ) . '</td></tr>';
		}
		echo '</tbody></table>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ogc_paginas_blog_sincronizar' );
		echo '<input type="hidden" name="action" value="ogc_paginas_blog_sincronizar">';
		echo '<p><label><input type="checkbox" name="simular" value="1" checked> <strong>Solo vista previa (simular)</strong></label></p>';
		echo '<p><button class="button button-primary"' . $dis . '>Sincronizar entradas del blog</button></p></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public static function sincronizar() {
		if ( ! self::puede() ) {
			wp_die( 'Sin permiso: hace falta un usuario Administrador que pueda guardar HTML sin filtrar.', 403 );
		}
		check_admin_referer( 'ogc_paginas_blog_sincronizar' );
		$m = OGC_Paginas_Manifiesto::cargar();
		if ( ! $m ) {
			wp_die( esc_html( OGC_Paginas_Manifiesto::error() ) );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		$l = OGC_Paginas_Blog::ejecutar( $m, ! empty( $_POST['simular'] ), 'manual' );
		self::terminar( $l ? $l : array( 'El paquete no trae entradas del blog.' ) );
	}

	public static function direccion() {
		if ( ! self::puede() ) {
			wp_die( 'Sin permiso: hace falta un usuario Administrador.', 403 );
		}
		check_admin_referer( 'ogc_paginas_blog_direccion' );
		if ( empty( $_POST['confirmo'] ) ) {
			wp_die( 'Marca la casilla de confirmación.' );
		}
		self::terminar( OGC_Paginas_Blog_Direccion::cambiar() );
	}

	/** Pestaña «Actualización automática»: actualizaciones del propio plugin (se llama desde OGC_Paginas_Sync_Admin). */
	public static function seccion_plugin() {
		$c   = get_site_transient( OGC_Paginas_Autoactualizar::CACHE );
		$d   = is_array( $c ) && isset( $c['j'] ) ? OGC_Paginas_Autoactualizar::validar( $c['j'] ) : null;
		$err = get_option( OGC_Paginas_Autoactualizar::OPC_ERROR, null );
		echo '<h2>Actualizaciones del propio plugin</h2>';
		echo '<p>Versión instalada: <strong>' . esc_html( OGC_Paginas_Autoactualizar::version_instalada() ) . '</strong> · última publicada (firmada): <strong>' . esc_html( is_array( $d ) ? $d['version'] : 'sin comprobar' ) . '</strong>.';
		if ( is_array( $err ) && ! empty( $err['error'] ) ) {
			echo ' <span style="color:#b32d2e">Último error (' . esc_html( (string) $err['fecha'] ) . '): ' . esc_html( (string) $err['error'] ) . '</span>';
		}
		echo '</p><p>Las versiones nuevas del plugin llegan como una actualización normal de WordPress (Plugins y Escritorio > Actualizaciones), solo si están firmadas por Preparador OGC y el zip coincide con el firmado. Para que se instalen solas: <strong>Plugins > OGC Páginas > «Activar actualizaciones automáticas»</strong>.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ogc_paginas_auto_buscar' );
		echo '<input type="hidden" name="action" value="ogc_paginas_auto_buscar"><button class="button"' . ( self::puede() ? '' : ' disabled' ) . '>Buscar actualización del plugin ahora</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public static function buscar() {
		if ( ! current_user_can( 'update_plugins' ) || ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sin permiso.', 403 );
		}
		check_admin_referer( 'ogc_paginas_auto_buscar' );
		set_transient( 'ogc_paginas_resultado_' . get_current_user_id(), OGC_Paginas_Autoactualizar::buscar_ahora(), 10 * MINUTE_IN_SECONDS );
		wp_safe_redirect( admin_url( 'tools.php?page=ogc-paginas&tab=sync' ) );
		exit;
	}
}
