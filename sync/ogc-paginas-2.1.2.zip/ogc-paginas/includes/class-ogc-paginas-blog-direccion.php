<?php
/**
 * Dirección del blog (2.1.0): comprueba que la página de entradas sea /blog/ y que las entradas cuelguen de /blog/.
 *
 *   - Solo AVISA (con el paso exacto) si la página de entradas no tiene el slug «blog» o si la estructura de enlaces
 *     permanentes no es /blog/%postname%/. No cambia nada por su cuenta (riesgo SEO).
 *   - Botón «Cambiar dirección del blog a /blog/» (acción explícita, con confirmación, nonce y permisos): cambia el slug
 *     de la página de entradas a «blog» y guarda la dirección antigua para una redirección 301 interna
 *     /<antigua>/… → /blog/… (template_redirect, solo cuando la dirección antigua da 404: nunca tapa una página real).
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Blog_Direccion {

	const OPC_301    = 'ogc_paginas_blog_301';   // array( 'desde' => array( slug => fecha ) ).
	const SLUG       = 'blog';
	const ESTRUCTURA = '/blog/%postname%/';

	/**
	 * Diagnóstico.
	 *
	 * @return array ok (bool), pagina (WP_Post|null), avisos (líneas), boton (bool), motivo_sin_boton.
	 */
	public static function comprobar() {
		$r   = array(
			'ok'      => true,
			'pagina'  => null,
			'avisos'  => array(),
			'bien'    => array(),
			'boton'   => false,
			'motivo'  => '',
		);
		$pid = (int) get_option( 'page_for_posts' );
		$p   = $pid ? get_post( $pid ) : null;
		if ( ! $p || 'page' !== $p->post_type || 'trash' === $p->post_status ) {
			$r['ok']       = false;
			$r['avisos'][] = 'No hay «Página de entradas». Paso: Ajustes > Lectura > «Tu página de inicio muestra»: Una página estática; «Página de entradas»: elige la página «Blog» (si no existe, créala en Páginas > Añadir nueva con el título «Blog» y el slug «blog», sin contenido) > Guardar cambios.';
			$r['motivo']   = 'Primero hay que elegir la página de entradas en Ajustes > Lectura.';
		} else {
			$r['pagina'] = $p;
			if ( self::SLUG === $p->post_name && 0 === (int) $p->post_parent ) {
				$r['bien'][] = 'La página de entradas es «' . $p->post_title . '» (ID ' . (int) $p->ID . ') con la dirección /blog/.';
				if ( 'Blog' !== $p->post_title ) {
					$r['avisos'][] = 'Sugerencia: el título de la página de entradas es «' . $p->post_title . '»; puede ser simplemente «Blog» (Páginas > editar > título). No cambia la dirección.';
				}
			} else {
				$r['ok']       = false;
				$antigua       = self::ruta_de( $p );
				$r['avisos'][] = 'La página de entradas es «' . $p->post_title . '» con la dirección /' . $antigua . '/, no /blog/. El plugin NO la cambia solo (riesgo SEO). Para cambiarla, pulsa el botón de abajo (cambia el slug a «blog» y crea la redirección 301 /' . $antigua . '/ → /blog/) o hazlo a mano: Páginas > «' . $p->post_title . '» > Edición rápida > Slug: blog (y título «Blog») > Actualizar; después, en Herramientas > Redirection > Añadir nueva: URL de origen /' . $antigua . '/ · URL de destino /blog/ · 301 (la regla ya está en redirecciones_redirection.csv).';
				$ocupa = get_page_by_path( self::SLUG, OBJECT, 'page' );
				if ( $ocupa && (int) $ocupa->ID !== (int) $p->ID ) {
					$r['motivo'] = 'Ya hay otra página con la dirección /blog/ («' . $ocupa->post_title . '», ID ' . (int) $ocupa->ID . '). Muévela a la papelera o cámbiale el slug, o elígela a ella como página de entradas en Ajustes > Lectura.';
				} elseif ( (int) $p->post_parent ) {
					$r['motivo'] = 'La página de entradas cuelga de otra página: quítale la página superior a mano (Atributos de página > Superior: ninguna).';
				} else {
					$r['boton'] = true;
				}
			}
		}
		$e = (string) get_option( 'permalink_structure' );
		if ( self::ESTRUCTURA === $e ) {
			$r['bien'][] = 'Enlaces permanentes: /blog/%postname%/ (las entradas quedan en /blog/nombre-de-la-entrada/).';
		} else {
			$r['ok']       = false;
			$r['avisos'][] = 'Enlaces permanentes: ahora es «' . ( '' === $e ? 'Simple (?p=123)' : $e ) . '» y las entradas tienen que quedar en /blog/nombre-de-la-entrada/ (los artículos se enlazan entre sí así). El plugin no lo cambia solo. Paso: Ajustes > Enlaces permanentes > «Estructura personalizada»: /blog/%postname%/ > Guardar cambios. Las páginas no cambian de dirección. La entrada antigua ya tiene su 301 en redirecciones_redirection.csv.';
		}
		if ( 'page' !== get_option( 'show_on_front' ) ) {
			$r['ok']       = false;
			$r['avisos'][] = 'La portada muestra las últimas entradas. Paso: Ajustes > Lectura > «Una página estática» (Portada: la portada; Página de entradas: Blog).';
		}
		$d = self::redirecciones();
		if ( $d ) {
			$r['bien'][] = 'Redirección 301 interna activa: ' . implode( ', ', array_map( static function ( $s ) { return '/' . $s . '/'; }, array_keys( $d ) ) ) . ' → /blog/ (y lo que cuelga de ella).';
		}
		return $r;
	}

	private static function ruta_de( $p ) {
		$u = function_exists( 'get_page_uri' ) ? (string) get_page_uri( $p ) : (string) $p->post_name;
		return '' === $u ? (string) $p->post_name : $u;
	}

	/** Direcciones antiguas que se redirigen a /blog/. */
	public static function redirecciones() {
		$o = get_option( self::OPC_301, array() );
		$d = is_array( $o ) && isset( $o['desde'] ) && is_array( $o['desde'] ) ? $o['desde'] : array();
		$out = array();
		foreach ( $d as $s => $f ) {
			if ( is_string( $s ) && preg_match( '/^[a-z0-9]+(-[a-z0-9]+)*$/', $s ) && self::SLUG !== $s ) {
				$out[ $s ] = $f;
			}
		}
		return $out;
	}

	/**
	 * Botón «Cambiar dirección del blog a /blog/». Comprueba de nuevo todo antes de tocar nada.
	 *
	 * @return array Líneas.
	 */
	public static function cambiar() {
		$c = self::comprobar();
		$p = $c['pagina'];
		if ( ! $p ) {
			return array( 'No se ha cambiado nada: ' . $c['motivo'] );
		}
		if ( self::SLUG === $p->post_name && 0 === (int) $p->post_parent ) {
			return array( 'La página de entradas ya tiene la dirección /blog/: no hay nada que cambiar.' );
		}
		if ( ! $c['boton'] ) {
			return array( 'No se ha cambiado nada: ' . $c['motivo'] );
		}
		$antigua = (string) $p->post_name;
		if ( ! preg_match( '/^[a-z0-9]+(-[a-z0-9]+)*$/', $antigua ) ) {
			return array( 'No se ha cambiado nada: el slug actual («' . $antigua . '») no es una dirección sencilla; cámbialo a mano y crea la redirección en Redirection.' );
		}
		$r = wp_update_post(
			array(
				'ID'        => (int) $p->ID,
				'post_name' => self::SLUG,
			),
			true
		);
		if ( is_wp_error( $r ) || ! $r ) {
			return array( 'No se ha cambiado nada: WordPress no ha guardado la página' . ( is_wp_error( $r ) ? ' (' . $r->get_error_message() . ')' : '' ) . '.' );
		}
		$real = (string) get_post_field( 'post_name', (int) $p->ID );
		if ( self::SLUG !== $real ) {
			wp_update_post(
				array(
					'ID'        => (int) $p->ID,
					'post_name' => $antigua,
				)
			);
			return array( 'No se ha cambiado nada: WordPress no deja usar «blog» (puso «' . $real . '», seguramente porque hay un archivo de la biblioteca o una página en la papelera con ese nombre). Se ha dejado /' . $antigua . '/. Vacía la papelera de páginas o cambia el nombre de ese archivo y vuelve a probar.' );
		}
		$o = get_option( self::OPC_301, array() );
		$o = is_array( $o ) ? $o : array();
		if ( ! isset( $o['desde'] ) || ! is_array( $o['desde'] ) ) {
			$o['desde'] = array();
		}
		$o['desde'][ $antigua ] = current_time( 'mysql' );
		update_option( self::OPC_301, $o, true );
		$l = array(
			'DIRECCIÓN DEL BLOG cambiada: /' . $antigua . '/ → /blog/ (página «' . $p->post_title . '», ID ' . (int) $p->ID . '). Redirección 301 interna activa desde /' . $antigua . '/ (y /' . $antigua . '/page/2/…).',
			'Si usas el plugin Redirection, puedes añadir también allí la regla /' . $antigua . '/ → /blog/ (301): no hay conflicto. Vacía la caché si tienes una.',
		);
		if ( class_exists( 'OGC_Paginas_Sincronizador' ) ) {
			OGC_Paginas_Sincronizador::registrar( $l, false );
		}
		return $l;
	}

	/**
	 * Ruta pedida relativa a la portada (sin barras al principio ni al final) o null.
	 */
	public static function ruta_pedida( $uri, $home_path ) {
		$path = (string) wp_parse_url( (string) $uri, PHP_URL_PATH );
		$home = '/' . trim( (string) $home_path, '/' );
		$home = '/' === $home ? '' : $home;
		if ( '' !== $home ) {
			if ( 0 !== strpos( $path, $home . '/' ) && $path !== $home ) {
				return null;
			}
			$path = substr( $path, strlen( $home ) );
		}
		return trim( rawurldecode( $path ), '/' );
	}

	/**
	 * Destino de la 301 para una ruta, o '' si no toca redirigir.
	 */
	public static function destino( $ruta ) {
		if ( null === $ruta || '' === $ruta ) {
			return '';
		}
		foreach ( array_keys( self::redirecciones() ) as $s ) {
			if ( $ruta === $s || 0 === strpos( $ruta, $s . '/' ) ) {
				$resto = substr( $ruta, strlen( $s ) );
				if ( '' !== $resto && ! preg_match( '#^(/[A-Za-z0-9_-]+)+$#', $resto ) ) {
					return home_url( '/' . self::SLUG . '/' );
				}
				return home_url( '/' . self::SLUG . $resto . '/' );
			}
		}
		return '';
	}

	/** template_redirect: 301 desde la dirección antigua del blog (solo si da 404). */
	public static function redirigir() {
		if ( ! self::redirecciones() || ! function_exists( 'is_404' ) || ! is_404() ) {
			return;
		}
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$d    = self::destino( self::ruta_pedida( $uri, $home ) );
		if ( '' === $d ) {
			return;
		}
		if ( wp_safe_redirect( $d, 301, 'OGC Paginas' ) ) { // WordPress devuelve true si ha redirigido.
			exit;
		}
	}
}
