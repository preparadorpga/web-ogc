<?php
/**
 * Actualización automática FIRMADA (2.0.0).
 *
 * Cada hora (WP-Cron) y con «Comprobar ahora»:
 *   1. Descarga <URL del paquete>/manifiesto.json y manifiesto.sig (solo https, sin redirecciones, tiempo y tamaño
 *      máximos, wp_safe_remote_get: nada de direcciones internas).
 *   2. Verifica la firma Ed25519 (sodium_crypto_sign_verify_detached) de los bytes exactos del JSON con la clave
 *      pública incrustada aquí (o la de Ajustes, si un administrador la ha sustituido). Sin firma válida no se aplica nada.
 *   3. Valida el manifiesto igual que el incluido (OGC_Paginas_Manifiesto::desde_json) y además: plugin, serie
 *      creciente (anti-reversión: nunca una serie igual o menor que la mayor ya aplicada) y fecha razonable.
 *   4. Descarga y valida las imágenes que el manifiesto lista (misma URL base, png/jpg/webp, nunca svg, tamaño y
 *      sha256 firmados) a wp-content/uploads/ogc/. Si una falla, no se aplica nada.
 *   5. Guarda el manifiesto (con su firma) y aplica la sincronización EXACTAMENTE como el botón «Sincronizar»
 *      (OGC_Paginas_Sincronizador::ejecutar: nunca toca páginas no gestionadas, revisión previa, kses solo durante la escritura).
 *   6. Lo anota en el registro. Si algo falla, lo anota (sin repetir el mismo error cada hora) y avisa en el escritorio.
 *
 * El JSON se trata solo como datos: nunca se evalúa nada.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Sync {

	/** Clave pública Ed25519 (base64, 32 bytes). La privada está solo en el equipo de publicación, nunca en el repo. */
	const CLAVE_PUBLICA = 'ugbcuuCLyxi4XdOZpFfFPXVf5CSTb3wnPtgALby01bM=';
	const URL_DEFECTO   = 'https://raw.githubusercontent.com/preparadorpga/web-ogc/main/sync/';

	const OPC_AJUSTES   = 'ogc_paginas_sync';           // url, auto, autor.
	const OPC_TOKEN     = 'ogc_paginas_sync_token';     // no autocargada; nunca se muestra entera.
	const OPC_CLAVE     = 'ogc_paginas_sync_clave';     // clave pública sustituta (vacía = la incrustada).
	const OPC_ESTADO    = 'ogc_paginas_sync_estado';    // serie aplicada, serie máxima, último error…
	const OPC_ACTUAL    = 'ogc_paginas_sync_actual';    // manifiesto aplicado + firma (no autocargada).
	const OPC_ANTERIOR  = 'ogc_paginas_sync_anterior';  // el anterior (para «Volver a la versión anterior»).
	const OPC_CERROJO   = 'ogc_paginas_sync_cerrojo';
	const CRON          = 'ogc_paginas_sync_cron';

	const MAX_MANIFIESTO = 8388608;   // 8 MB.
	const MAX_FIRMA      = 1024;
	const MAX_IMAGEN     = 3145728;   // 3 MB por imagen.
	const MAX_IMAGENES   = 60;
	const TIMEOUT        = 15;
	const FECHA_MINIMA   = 1767225600; // 01/01/2026.

	/** Hosts a los que se puede enviar el token de GitHub (nunca a otro, aunque se cambie la URL). */
	const HOSTS_TOKEN = array( 'raw.githubusercontent.com', 'api.github.com', 'github.com' );

	/** @var array|null Manifiesto remoto aplicado (verificado) en memoria. */
	private static $aplicado = null;

	/** @var bool */
	private static $aplicado_leido = false;

	// ------------------------------------------------------------------ Ajustes

	public static function ajustes() {
		$a = get_option( self::OPC_AJUSTES, array() );
		$a = is_array( $a ) ? $a : array();
		return array(
			'url'   => isset( $a['url'] ) && self::url_valida( $a['url'] ) ? $a['url'] : self::URL_DEFECTO,
			'auto'  => isset( $a['auto'] ) ? (bool) $a['auto'] : true,
			'autor' => isset( $a['autor'] ) ? (int) $a['autor'] : 0,
		);
	}

	/** https, host con letras/números/puntos/guiones y ruta que acaba en «/». Sin usuario, consulta ni fragmento. */
	public static function url_valida( $u ) {
		return is_string( $u ) && strlen( $u ) < 300 && (bool) preg_match( '#^https://[a-z0-9]([a-z0-9.-]*[a-z0-9])?(:[0-9]{2,5})?/([A-Za-z0-9._~%-]+/)*$#', $u ) && false === strpos( $u, '..' );
	}

	public static function token_valido( $t ) {
		return is_string( $t ) && (bool) preg_match( '/^[A-Za-z0-9_]{20,255}$/', $t );
	}

	/** Token enmascarado para la pantalla (solo los 4 últimos caracteres). */
	public static function token_mascara() {
		$t = (string) get_option( self::OPC_TOKEN, '' );
		return '' === $t ? '' : str_repeat( '•', 8 ) . substr( $t, -4 );
	}

	/**
	 * Guarda los ajustes. Devuelve las líneas para el aviso.
	 *
	 * @param array $e url, auto, token, borrar_token.
	 */
	public static function guardar_ajustes( array $e ) {
		$a      = self::ajustes();
		$lineas = array();
		$url    = isset( $e['url'] ) ? trim( (string) $e['url'] ) : '';
		if ( '' === $url ) {
			$url = self::URL_DEFECTO;
		}
		if ( '/' !== substr( $url, -1 ) ) {
			$url .= '/';
		}
		if ( self::url_valida( $url ) ) {
			$a['url'] = $url;
		} else {
			$lineas[] = 'La URL del paquete no es válida (tiene que empezar por https:// y acabar en /): se mantiene la anterior.';
		}
		$a['auto']  = ! empty( $e['auto'] );
		$a['autor'] = (int) get_current_user_id();
		update_option( self::OPC_AJUSTES, $a, false );
		if ( ! empty( $e['borrar_token'] ) ) {
			delete_option( self::OPC_TOKEN );
			$lineas[] = 'Token de GitHub borrado.';
		} elseif ( isset( $e['token'] ) && '' !== trim( (string) $e['token'] ) ) {
			$t = trim( (string) $e['token'] );
			if ( self::token_valido( $t ) ) {
				delete_option( self::OPC_TOKEN );
				add_option( self::OPC_TOKEN, $t, '', 'no' ); // no autocargada.
				$lineas[] = 'Token de GitHub guardado (' . self::token_mascara() . ').';
			} else {
				$lineas[] = 'El token no tiene el formato de un token de GitHub: no se ha guardado.';
			}
		}
		self::programar();
		array_unshift( $lineas, 'Ajustes de la actualización automática guardados: ' . ( $a['auto'] ? 'ACTIVADA' : 'DESACTIVADA' ) . ' · ' . $a['url'] );
		return $lineas;
	}

	/** Clave pública en uso (bytes) y si es la incrustada. */
	public static function clave_publica() {
		$c = (string) get_option( self::OPC_CLAVE, '' );
		if ( '' !== $c ) {
			$b = base64_decode( $c, true );
			if ( false !== $b && 32 === strlen( $b ) ) {
				return array( $b, false );
			}
		}
		return array( base64_decode( self::CLAVE_PUBLICA ), true );
	}

	/**
	 * Sustituye la clave pública (o vuelve a la incrustada con $b64 = '').
	 *
	 * @return true|string
	 */
	public static function cambiar_clave( $b64 ) {
		$b64 = trim( (string) $b64 );
		if ( '' === $b64 ) {
			delete_option( self::OPC_CLAVE );
			return true;
		}
		$b = base64_decode( $b64, true );
		if ( false === $b || 32 !== strlen( $b ) ) {
			return 'La clave pública tiene que ser el texto base64 de 32 bytes que da publicar_sync.py (44 caracteres acabados en «=»).';
		}
		update_option( self::OPC_CLAVE, base64_encode( $b ), false );
		return true;
	}

	/** Administrador que firma las páginas creadas sin usuario (WP-Cron). */
	public static function autor() {
		$a = self::ajustes()['autor'];
		if ( $a && function_exists( 'user_can' ) && user_can( $a, 'manage_options' ) ) {
			return $a;
		}
		if ( function_exists( 'get_users' ) ) {
			$u = get_users(
				array(
					'role'    => 'administrator',
					'number'  => 1,
					'orderby' => 'ID',
					'fields'  => 'ID',
				)
			);
			if ( $u ) {
				return (int) $u[0];
			}
		}
		return 0;
	}

	public static function estado() {
		$e = get_option( self::OPC_ESTADO, array() );
		return array_merge(
			array(
				'serie'          => 0,  // serie del manifiesto remoto en uso.
				'serie_max'      => 0,  // mayor serie aplicada nunca (anti-reversión).
				'fecha_unix'     => 0,
				'sha256'         => '',
				'aplicado'       => '',
				'comprobado'     => '',
				'resultado'      => '',
				'error'          => '',
				'error_fecha'    => '',
			),
			is_array( $e ) ? $e : array()
		);
	}

	private static function guardar_estado( array $e ) {
		update_option( self::OPC_ESTADO, $e, true );
	}

	// ------------------------------------------------------------------ WP-Cron

	public static function programar() {
		if ( ! function_exists( 'wp_next_scheduled' ) ) {
			return;
		}
		$auto = self::ajustes()['auto'];
		$hay  = wp_next_scheduled( self::CRON );
		if ( $auto && ! $hay ) {
			wp_schedule_event( time() + 300, 'hourly', self::CRON );
		} elseif ( ! $auto && $hay ) {
			wp_clear_scheduled_hook( self::CRON );
		}
	}

	public static function desprogramar() {
		if ( function_exists( 'wp_clear_scheduled_hook' ) ) {
			wp_clear_scheduled_hook( self::CRON );
		}
	}

	public static function cron() {
		if ( ! self::ajustes()['auto'] ) {
			return;
		}
		self::comprobar( 'automática' );
	}

	// ------------------------------------------------------------------ Firma y validación

	/**
	 * @return true|string
	 */
	public static function verificar_firma( $json, $firma_texto, $clave = null ) {
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return 'Este servidor no tiene sodium (PHP 7.2+ o WordPress 5.2+): no se puede verificar la firma.';
		}
		$firma = base64_decode( trim( (string) $firma_texto ), true );
		if ( false === $firma || 64 !== strlen( $firma ) ) {
			return 'La firma (manifiesto.sig) no tiene el formato esperado.';
		}
		if ( null === $clave ) {
			$clave = self::clave_publica()[0];
		}
		try {
			$ok = sodium_crypto_sign_verify_detached( $firma, (string) $json, $clave );
		} catch ( Exception $e ) {
			$ok = false;
		} catch ( Error $e ) { // phpcs:ignore PHPCompatibility
			$ok = false;
		}
		return $ok ? true : 'FIRMA NO VÁLIDA: el manifiesto no lo ha firmado Preparador OGC (o se ha alterado). No se aplica nada.';
	}

	/**
	 * Valida un manifiesto firmado: estructura (como el incluido) + campos de la sincronización.
	 *
	 * @param string $json   Bytes del JSON (ya con firma verificada).
	 * @param array  $estado Estado actual (para la anti-reversión).
	 * @param bool   $nuevo  true = exige serie mayor que la máxima aplicada.
	 * @return array|string Manifiesto o motivo del rechazo.
	 */
	public static function validar( $json, array $estado, $nuevo = true ) {
		$err = '';
		$m   = OGC_Paginas_Manifiesto::desde_json( $json, $err );
		if ( ! $m ) {
			return 'Formato: ' . $err;
		}
		if ( 'ogc-paginas' !== ( $m['plugin'] ?? '' ) ) {
			return 'Formato: el manifiesto no es de OGC Páginas.';
		}
		if ( ! isset( $m['serie'], $m['fecha_unix'] ) || ! is_int( $m['serie'] ) || ! is_int( $m['fecha_unix'] ) || $m['serie'] < 1 ) {
			return 'Formato: faltan la serie o la fecha del manifiesto.';
		}
		if ( $m['fecha_unix'] < self::FECHA_MINIMA || $m['fecha_unix'] > time() + DAY_IN_SECONDS ) {
			return 'Fecha del manifiesto no razonable (' . gmdate( 'Y-m-d H:i', $m['fecha_unix'] ) . ' UTC): no se aplica.';
		}
		if ( $nuevo && $m['serie'] <= (int) $estado['serie_max'] ) {
			return 'reversion';
		}
		if ( $nuevo && $m['fecha_unix'] < (int) $estado['fecha_unix'] ) {
			return 'Fecha anterior a la del manifiesto aplicado con una serie mayor: no se aplica (posible reversión).';
		}
		$imgs = self::imagenes_de( $m );
		if ( ! is_array( $imgs ) ) {
			return 'Formato: ' . $imgs;
		}
		return $m;
	}

	/**
	 * Lista de imágenes validada (sin descargar). Mismas reglas que las imágenes incluidas en el plugin
	 * (OGC_Paginas_Imagenes::lista): img/<nombre>.(png|jpg|webp), nunca svg, máx. 3 MB, sha256 y bytes firmados.
	 *
	 * @return array|string
	 */
	public static function imagenes_de( array $m ) {
		$l = OGC_Paginas_Imagenes::lista( $m );
		if ( is_array( $l ) && count( $l ) > self::MAX_IMAGENES ) {
			return 'demasiadas imágenes';
		}
		return $l;
	}

	/**
	 * Comprueba los bytes de una imagen descargada.
	 *
	 * @return true|string
	 */
	public static function validar_imagen( array $i, $bytes ) {
		if ( strlen( $bytes ) !== $i['bytes'] || strlen( $bytes ) > self::MAX_IMAGEN ) {
			return 'tamaño distinto del firmado';
		}
		if ( ! hash_equals( $i['sha256'], hash( 'sha256', $bytes ) ) ) {
			return 'contenido distinto del firmado (sha256)';
		}
		$esperado = OGC_Paginas_Imagenes::TIPOS[ $i['ext'] ] ?? '-';
		$tipo     = OGC_Paginas_Imagenes::tipo( $bytes );
		if ( $tipo !== $esperado ) {
			return 'no es una imagen ' . $esperado . ' (detectado: ' . ( $tipo ? $tipo : 'desconocido' ) . ')';
		}
		return true;
	}

	// ------------------------------------------------------------------ Descargas

	/**
	 * Descarga <URL base><relativa>. Solo desde la URL base, sin redirecciones.
	 *
	 * @return string|WP_Error
	 */
	public static function descargar( $relativa, $max ) {
		if ( ! preg_match( '#^[a-z0-9][a-z0-9._/-]*$#', $relativa ) || false !== strpos( $relativa, '..' ) || false !== strpos( $relativa, '//' ) ) {
			return new WP_Error( 'ogc_ruta', 'ruta no permitida' );
		}
		$base = self::ajustes()['url'];
		$url  = $base . $relativa;
		$cab  = array( 'Accept' => 'application/octet-stream, application/json, image/*' );
		$tok  = (string) get_option( self::OPC_TOKEN, '' );
		$host = strtolower( (string) wp_parse_url( $base, PHP_URL_HOST ) );
		if ( '' !== $tok && in_array( $host, self::HOSTS_TOKEN, true ) ) {
			$cab['Authorization'] = 'Bearer ' . $tok;
		}
		$r = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => self::TIMEOUT,
				'redirection'         => 0,
				'limit_response_size' => $max + 1,
				'headers'             => $cab,
				'user-agent'          => 'OGC-Paginas/' . ( defined( 'OGC_PAGINAS_VERSION' ) ? OGC_PAGINAS_VERSION : '2' ),
			)
		);
		if ( is_wp_error( $r ) ) {
			return new WP_Error( 'ogc_red', $relativa . ': ' . $r->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		if ( 200 !== $code ) {
			$extra = ( 404 === $code && '' === $tok ) ? ' (si el repositorio es privado, pon el token de GitHub en Ajustes)' : '';
			return new WP_Error( 'ogc_http', $relativa . ': HTTP ' . $code . $extra );
		}
		$body = (string) wp_remote_retrieve_body( $r );
		if ( strlen( $body ) > $max ) {
			return new WP_Error( 'ogc_tam', $relativa . ': demasiado grande (máx. ' . (int) ( $max / 1048576 ) . ' MB)' );
		}
		return $body;
	}

	// ------------------------------------------------------------------ Almacén del manifiesto aplicado

	private static function empaquetar( $json, $firma ) {
		if ( function_exists( 'gzdeflate' ) ) {
			return array(
				'c' => 'gz64',
				'd' => base64_encode( gzdeflate( $json, 6 ) ),
				'f' => trim( $firma ),
			);
		}
		return array(
			'c' => 'b64',
			'd' => base64_encode( $json ),
			'f' => trim( $firma ),
		);
	}

	private static function desempaquetar( $x ) {
		if ( ! is_array( $x ) || ! isset( $x['c'], $x['d'], $x['f'] ) ) {
			return null;
		}
		$b = base64_decode( (string) $x['d'], true );
		if ( false === $b ) {
			return null;
		}
		if ( 'gz64' === $x['c'] ) {
			$b = function_exists( 'gzinflate' ) ? @gzinflate( $b, self::MAX_MANIFIESTO ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		return false === $b ? null : array( (string) $b, (string) $x['f'] );
	}

	/**
	 * Manifiesto remoto en uso (firma verificada de nuevo al leerlo) o null.
	 *
	 * @return array|null
	 */
	public static function manifiesto_aplicado() {
		if ( self::$aplicado_leido ) {
			return self::$aplicado;
		}
		self::$aplicado_leido = true;
		self::$aplicado       = null;
		$x                    = self::desempaquetar( get_option( self::OPC_ACTUAL, null ) );
		if ( ! $x || true !== self::verificar_firma( $x[0], $x[1] ) ) {
			return null;
		}
		$m = self::validar( $x[0], self::estado(), false );
		if ( is_array( $m ) ) {
			self::$aplicado = $m;
		}
		return self::$aplicado;
	}

	private static function olvidar() {
		self::$aplicado       = null;
		self::$aplicado_leido = false;
		OGC_Paginas_Manifiesto::reiniciar();
		if ( class_exists( 'OGC_Paginas_Shortcode' ) ) {
			OGC_Paginas_Shortcode::vaciar_cache();
		}
	}

	// ------------------------------------------------------------------ Cerrojo

	private static function cerrar() {
		if ( add_option( self::OPC_CERROJO, time(), '', 'no' ) ) {
			return true;
		}
		$t = (int) get_option( self::OPC_CERROJO, 0 );
		if ( $t && $t < time() - 15 * MINUTE_IN_SECONDS ) {
			update_option( self::OPC_CERROJO, time(), false );
			return true;
		}
		return false;
	}

	private static function abrir() {
		delete_option( self::OPC_CERROJO );
	}

	// ------------------------------------------------------------------ Comprobar y aplicar

	/**
	 * Descarga, verifica y, si hay una versión nueva, aplica. Devuelve líneas para el aviso.
	 *
	 * @param string $quien «automática» (WP-Cron) o «manual» («Comprobar ahora»).
	 * @return array
	 */
	public static function comprobar( $quien = 'manual' ) {
		if ( ! self::cerrar() ) {
			return array( 'Ya hay una comprobación en curso. Prueba dentro de unos minutos.' );
		}
		$estado               = self::estado();
		$estado['comprobado'] = current_time( 'mysql' );
		try {
			$r = self::comprobar_sin_cerrojo( $quien, $estado );
			// 2.1.0 · si no se ha aplicado un paquete nuevo (al día, error de descarga…), las entradas del manifiesto en uso
			// que aún no se hayan creado (por ejemplo, justo tras instalar la 2.1.0) se aplican igualmente.
			if ( class_exists( 'OGC_Paginas_Blog' ) && 'aplicado' !== self::estado()['resultado'] ) {
				$r = array_merge( $r, OGC_Paginas_Blog::si_pendiente( 'manual' === $quien ? 'manual' : 'automática' ) );
			}
		} finally {
			self::abrir();
		}
		return $r;
	}

	private static function fallo( array $estado, $msg, $quien ) {
		$repetido = ( $estado['error'] === $msg );
		$estado['error']       = $msg;
		$estado['error_fecha'] = current_time( 'mysql' );
		$estado['resultado']   = 'error';
		self::guardar_estado( $estado );
		if ( ! $repetido || 'manual' === $quien ) {
			OGC_Paginas_Sincronizador::registrar( array( 'ACTUALIZACIÓN ' . strtoupper( $quien ) . ' FALLIDA · no se ha aplicado nada', $msg ), false );
		}
		return array( 'No se ha aplicado nada: ' . $msg );
	}

	private static function comprobar_sin_cerrojo( $quien, array $estado ) {
		$json = self::descargar( 'manifiesto.json', self::MAX_MANIFIESTO );
		if ( is_wp_error( $json ) ) {
			return self::fallo( $estado, 'Descarga: ' . $json->get_error_message(), $quien );
		}
		$firma = self::descargar( 'manifiesto.sig', self::MAX_FIRMA );
		if ( is_wp_error( $firma ) ) {
			return self::fallo( $estado, 'Descarga: ' . $firma->get_error_message(), $quien );
		}
		$ok = self::verificar_firma( $json, $firma );
		if ( true !== $ok ) {
			return self::fallo( $estado, $ok, $quien );
		}
		$m = self::validar( $json, $estado, true );
		if ( 'reversion' === $m ) {
			$serie = (int) ( json_decode( $json, true )['serie'] ?? 0 );
			$estado['error']     = '';
			$estado['resultado'] = $serie === (int) $estado['serie_max'] ? 'al_dia' : 'reversion';
			self::guardar_estado( $estado );
			if ( 'reversion' === $estado['resultado'] ) {
				OGC_Paginas_Sincronizador::registrar( array( 'ACTUALIZACIÓN ' . strtoupper( $quien ) . ' · manifiesto firmado con serie ' . $serie . ' ANTERIOR a la ya aplicada (' . (int) $estado['serie_max'] . '): no se aplica (anti-reversión).' ), false );
				return array( 'El paquete publicado (serie ' . $serie . ') es anterior al ya aplicado (' . (int) $estado['serie_max'] . '): no se aplica.' );
			}
			return array( 'Sin novedades: el paquete publicado (serie ' . $serie . ') ya está aplicado.' );
		}
		if ( ! is_array( $m ) ) {
			return self::fallo( $estado, $m, $quien );
		}
		// Imágenes: todas descargadas y validadas ANTES de cambiar nada.
		$imgs = self::imagenes_de( $m );
		$bin  = array();
		foreach ( $imgs as $i ) {
			$destino = self::ruta_imagen( $i['ruta'] );
			if ( ! $destino ) {
				return self::fallo( $estado, 'No se puede escribir en wp-content/uploads/ogc/.', $quien );
			}
			if ( is_readable( $destino ) && hash_equals( $i['sha256'], (string) hash_file( 'sha256', $destino ) ) ) {
				continue; // Ya está.
			}
			$b = self::descargar( $i['ruta'], self::MAX_IMAGEN );
			if ( is_wp_error( $b ) ) {
				return self::fallo( $estado, 'Imagen: ' . $b->get_error_message(), $quien );
			}
			$v = self::validar_imagen( $i, $b );
			if ( true !== $v ) {
				return self::fallo( $estado, 'Imagen ' . $i['ruta'] . ' rechazada: ' . $v, $quien );
			}
			$bin[ $destino ] = $b;
		}
		foreach ( $bin as $destino => $b ) {
			if ( ! self::escribir_imagen( $destino, $b ) ) {
				return self::fallo( $estado, 'No se ha podido guardar ' . basename( $destino ) . ' en wp-content/uploads/ogc/.', $quien );
			}
		}
		// Guarda el manifiesto: el que había pasa a «anterior».
		$actual = get_option( self::OPC_ACTUAL, null );
		self::guardar_opcion( self::OPC_ANTERIOR, is_array( $actual ) ? $actual : array( 'incluido' => true ) );
		self::guardar_opcion( self::OPC_ACTUAL, self::empaquetar( $json, $firma ) );
		$estado['serie']      = $m['serie'];
		$estado['serie_max']  = max( (int) $estado['serie_max'], $m['serie'] );
		$estado['fecha_unix'] = $m['fecha_unix'];
		$estado['sha256']     = hash( 'sha256', $json );
		$estado['aplicado']   = current_time( 'mysql' );
		$estado['error']      = '';
		$estado['resultado']  = 'aplicado';
		self::guardar_estado( $estado );
		self::olvidar();
		OGC_Paginas_Sincronizador::registrar(
			array(
				'ACTUALIZACIÓN ' . strtoupper( $quien ) . ' · manifiesto serie ' . $m['serie'] . ' (' . ( $m['generado'] ?? '' ) . ', paquete ' . ( $m['version'] ?? '' ) . ') con FIRMA VÁLIDA · ' . count( $imgs ) . ' imágenes (' . count( $bin ) . ' nuevas) · se sincroniza a continuación',
			),
			false
		);
		return self::aplicar( $m );
	}

	/** Igual que el botón «Sincronizar» con todas las páginas marcadas y sin simular. */
	private static function aplicar( array $m ) {
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		$todas = array();
		foreach ( $m['paginas'] as $p ) {
			$todas[] = $p['ruta'];
		}
		$l = OGC_Paginas_Sincronizador::ejecutar( $m, $todas, false );
		self::purgar_cache_posicionan();
		// 2.1.0 · entradas del blog del mismo manifiesto.
		if ( class_exists( 'OGC_Paginas_Blog' ) ) {
			$l = array_merge( $l, OGC_Paginas_Blog::ejecutar( $m, false, 'automática' ) );
		}
		return $l;
	}

	/**
	 * Las 5 que posicionan no cambian en la base de datos (el shortcode lee el manifiesto): se vacía su caché de página
	 * en los plugins de caché más comunes (SiteGround, LiteSpeed, WP Rocket, W3 Total Cache) si están instalados.
	 */
	public static function purgar_cache_posicionan() {
		if ( ! function_exists( 'home_url' ) ) {
			return;
		}
		foreach ( OGC_Paginas_Manifiesto::IDS_POSICIONAN as $ruta ) {
			$url = home_url( '' === $ruta ? '/' : '/' . $ruta . '/' );
			if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
				sg_cachepress_purge_cache( $url );
			}
			if ( function_exists( 'w3tc_flush_url' ) ) {
				w3tc_flush_url( $url );
			}
			if ( function_exists( 'do_action' ) ) {
				do_action( 'litespeed_purge_url', $url );
			}
		}
		if ( function_exists( 'rocket_clean_home' ) ) {
			rocket_clean_home();
		}
		if ( function_exists( 'do_action' ) ) {
			do_action( 'ogc_paginas_actualizadas' );
		}
	}

	/**
	 * «Volver a la versión anterior»: reaplica el manifiesto anterior guardado (y el actual pasa a anterior).
	 * La serie máxima NO baja: la versión de la que se vuelve no se reaplica sola; solo una serie nueva.
	 *
	 * @return array Líneas.
	 */
	public static function volver() {
		if ( ! self::cerrar() ) {
			return array( 'Ya hay una comprobación en curso. Prueba dentro de unos minutos.' );
		}
		try {
			$ant    = get_option( self::OPC_ANTERIOR, null );
			$actual = get_option( self::OPC_ACTUAL, null );
			$estado = self::estado();
			if ( ! is_array( $ant ) ) {
				return array( 'No hay ninguna versión anterior guardada.' );
			}
			if ( ! empty( $ant['incluido'] ) ) {
				// La anterior era la del zip del plugin.
				delete_option( self::OPC_ACTUAL );
				self::guardar_opcion( self::OPC_ANTERIOR, is_array( $actual ) ? $actual : array( 'incluido' => true ) );
				$estado['serie'] = 0;
			} else {
				$x = self::desempaquetar( $ant );
				if ( ! $x || true !== self::verificar_firma( $x[0], $x[1] ) ) {
					return array( 'La versión anterior guardada no tiene una firma válida: no se aplica.' );
				}
				$m = self::validar( $x[0], $estado, false );
				if ( ! is_array( $m ) ) {
					return array( 'La versión anterior guardada no es válida: ' . $m );
				}
				self::guardar_opcion( self::OPC_ACTUAL, $ant );
				self::guardar_opcion( self::OPC_ANTERIOR, is_array( $actual ) ? $actual : array( 'incluido' => true ) );
				$estado['serie'] = $m['serie'];
			}
			$estado['resultado'] = 'vuelta_atras';
			$estado['aplicado']  = current_time( 'mysql' );
			self::guardar_estado( $estado );
			self::olvidar();
			$m = OGC_Paginas_Manifiesto::cargar();
			if ( ! $m ) {
				return array( 'No se puede cargar el manifiesto: ' . OGC_Paginas_Manifiesto::error() );
			}
			OGC_Paginas_Sincronizador::registrar( array( 'VUELTA A LA VERSIÓN ANTERIOR · ahora se usa ' . ( 'remoto' === OGC_Paginas_Manifiesto::origen() ? 'el manifiesto firmado serie ' . (int) $m['serie'] : 'el manifiesto incluido en el plugin' ) . '. La versión de la que se vuelve no se reaplica sola (solo una publicación nueva).' ), false );
			return self::aplicar( $m );
		} finally {
			self::abrir();
		}
	}

	private static function guardar_opcion( $k, $v ) {
		delete_option( $k );
		add_option( $k, $v, '', 'no' ); // no autocargada.
	}

	// ------------------------------------------------------------------ Imágenes en disco

	/** img/<nombre> → <uploads>/ogc/<nombre> (ruta ya validada: sin «..» ni subcarpetas). */
	public static function ruta_imagen( $ruta ) {
		$d = OGC_Paginas_Imagenes::destino();
		return '' === $d ? '' : $d . '/' . substr( $ruta, 4 );
	}

	private static function escribir_imagen( $destino, $b ) {
		$dir = dirname( $destino );
		if ( ! wp_mkdir_p( $dir ) ) {
			return false;
		}
		$tmp = $destino . '.tmp-' . wp_generate_password( 8, false );
		if ( false === file_put_contents( $tmp, $b ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			return false;
		}
		if ( ! @rename( $tmp, $destino ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return false;
		}
		return true;
	}

	// ------------------------------------------------------------------ Aviso en el escritorio

	public static function aviso() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$e = self::estado();
		if ( 'error' !== $e['resultado'] || '' === $e['error'] ) {
			return;
		}
		echo '<div class="notice notice-error"><p><strong>OGC Páginas · la actualización automática no se ha aplicado</strong> (' . esc_html( $e['error_fecha'] ) . '): ' . esc_html( $e['error'] ) . ' La web sigue como estaba. <a href="' . esc_url( admin_url( 'tools.php?page=ogc-paginas&tab=sync' ) ) . '">Ver detalles</a></p></div>';
	}
}
