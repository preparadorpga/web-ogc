<?php
/**
 * Actualización del PROPIO plugin (2.1.0) como una actualización normal de WordPress.
 *
 *   1. Filtro pre_set_site_transient_update_plugins (cuando WordPress comprueba actualizaciones, unas dos veces al día):
 *      descarga <URL del paquete>/plugin.json y plugin.json.sig (misma URL, mismas reglas de descarga y la MISMA clave
 *      Ed25519 que el manifiesto), verifica la firma y, si la versión publicada es MAYOR que la instalada, la ofrece como
 *      actualización (Plugins / Escritorio > Actualizaciones). Si no, la anota como «sin actualización», con lo que
 *      WordPress muestra el enlace «Activar actualizaciones automáticas» de este plugin.
 *   2. Filtro upgrader_pre_download: cuando WordPress va a descargar ESE paquete, lo descarga el plugin (misma URL base,
 *      sin redirecciones, máx. 20 MB), comprueba tamaño, sha256 firmados y que sea un zip; si algo no cuadra, WordPress
 *      no instala nada.
 *   3. Filtro plugins_api: la ventana «Ver detalles» muestra los datos firmados (nunca los de wordpress.org).
 * La cabecera «Update URI» del plugin impide además que WordPress.org ofrezca un plugin ajeno con el mismo nombre.
 * Las actualizaciones automáticas se activan en Plugins > «Activar actualizaciones automáticas» (decisión de Vicente).
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Autoactualizar {

	const JSON       = 'plugin.json';
	const FIRMA      = 'plugin.json.sig';
	const CACHE      = 'ogc_paginas_auto_info';   // transient: json + firma (se verifican de nuevo al usarlos).
	const OPC_ERROR  = 'ogc_paginas_auto_error';
	const MAX_JSON   = 65536;
	const MAX_ZIP    = 20971520;                  // 20 MB.
	const DURACION   = 21600;                     // 6 horas.
	const SLUG       = 'ogc-paginas';
	const TIPO       = 'ogc-paginas-plugin';

	public static function basename() {
		return defined( 'OGC_PAGINAS_FILE' ) && function_exists( 'plugin_basename' ) ? plugin_basename( OGC_PAGINAS_FILE ) : 'ogc-paginas/ogc-paginas.php';
	}

	public static function version_instalada() {
		return defined( 'OGC_PAGINAS_VERSION' ) ? OGC_PAGINAS_VERSION : '0.0.0';
	}

	/**
	 * Valida plugin.json (bytes con firma ya verificada).
	 *
	 * @return array|string
	 */
	public static function validar( $json ) {
		$d = json_decode( (string) $json, true );
		if ( ! is_array( $d ) ) {
			return 'plugin.json no es un JSON válido';
		}
		if ( self::TIPO !== ( $d['tipo'] ?? '' ) || self::SLUG !== ( $d['plugin'] ?? '' ) ) {
			return 'plugin.json no es de OGC Páginas';
		}
		foreach ( array( 'version', 'zip', 'sha256' ) as $k ) {
			if ( ! isset( $d[ $k ] ) || ! is_string( $d[ $k ] ) ) {
				return 'plugin.json: falta ' . $k;
			}
		}
		if ( ! preg_match( '/^\d{1,3}\.\d{1,3}\.\d{1,4}$/', $d['version'] ) ) {
			return 'plugin.json: versión no válida';
		}
		if ( 'ogc-paginas-' . $d['version'] . '.zip' !== $d['zip'] ) {
			return 'plugin.json: nombre del zip no válido';
		}
		if ( ! preg_match( '/^[0-9a-f]{64}$/', $d['sha256'] ) || ! isset( $d['bytes'] ) || ! is_int( $d['bytes'] ) || $d['bytes'] < 1000 || $d['bytes'] > self::MAX_ZIP ) {
			return 'plugin.json: sha256 o tamaño no válidos';
		}
		if ( ! isset( $d['fecha_unix'] ) || ! is_int( $d['fecha_unix'] ) || $d['fecha_unix'] < OGC_Paginas_Sync::FECHA_MINIMA || $d['fecha_unix'] > time() + DAY_IN_SECONDS ) {
			return 'plugin.json: fecha no razonable';
		}
		foreach ( array( 'requiere_wp', 'requiere_php', 'probado_wp' ) as $k ) {
			if ( isset( $d[ $k ] ) && ( ! is_string( $d[ $k ] ) || ! preg_match( '/^\d+(\.\d+){0,2}$/', $d[ $k ] ) ) ) {
				return 'plugin.json: ' . $k . ' no válido';
			}
		}
		if ( isset( $d['notas'] ) && ( ! is_string( $d['notas'] ) || strlen( $d['notas'] ) > 4000 ) ) {
			return 'plugin.json: notas no válidas';
		}
		return $d;
	}

	/**
	 * Información firmada de la última versión publicada (de la caché o descargada).
	 *
	 * @param bool $forzar true = descarga aunque haya caché.
	 * @return array|string Datos validados o motivo.
	 */
	public static function info( $forzar = false ) {
		$c = $forzar ? false : get_site_transient( self::CACHE );
		if ( is_array( $c ) && isset( $c['j'], $c['f'] ) ) {
			$ok = OGC_Paginas_Sync::verificar_firma( $c['j'], $c['f'] );
			if ( true === $ok ) {
				return self::validar( $c['j'] );
			}
		}
		$j = OGC_Paginas_Sync::descargar( self::JSON, self::MAX_JSON );
		if ( is_wp_error( $j ) ) {
			return self::error( 'Descarga: ' . $j->get_error_message() );
		}
		$f = OGC_Paginas_Sync::descargar( self::FIRMA, OGC_Paginas_Sync::MAX_FIRMA );
		if ( is_wp_error( $f ) ) {
			return self::error( 'Descarga: ' . $f->get_error_message() );
		}
		$ok = OGC_Paginas_Sync::verificar_firma( $j, $f );
		if ( true !== $ok ) {
			return self::error( 'plugin.json: ' . $ok );
		}
		$d = self::validar( $j );
		if ( ! is_array( $d ) ) {
			return self::error( $d );
		}
		set_site_transient(
			self::CACHE,
			array(
				'j' => $j,
				'f' => trim( $f ),
			),
			self::DURACION
		);
		delete_option( self::OPC_ERROR );
		return $d;
	}

	private static function error( $msg ) {
		update_option(
			self::OPC_ERROR,
			array(
				'fecha' => current_time( 'mysql' ),
				'error' => $msg,
			),
			false
		);
		return $msg;
	}

	public static function url_paquete( array $d ) {
		return OGC_Paginas_Sync::ajustes()['url'] . $d['zip'];
	}

	private static function item( array $d, $nueva ) {
		return (object) array(
			'id'            => self::basename(),
			'slug'          => self::SLUG,
			'plugin'        => self::basename(),
			'new_version'   => $nueva ? $d['version'] : self::version_instalada(),
			'url'           => 'https://organizacionygestioncomercial.es/',
			'package'       => $nueva ? self::url_paquete( $d ) : '',
			'requires'      => $d['requiere_wp'] ?? '6.0',
			'requires_php'  => $d['requiere_php'] ?? '7.4',
			'tested'        => $d['probado_wp'] ?? '',
			'icons'         => array(),
			'banners'       => array(),
			'banners_rtl'   => array(),
			'compatibility' => new stdClass(),
		);
	}

	/**
	 * pre_set_site_transient_update_plugins.
	 *
	 * @param mixed $t Transient de actualizaciones.
	 * @return mixed
	 */
	public static function filtro_transient( $t ) {
		if ( ! is_object( $t ) || empty( $t->checked ) ) {
			return $t;
		}
		$b = self::basename();
		$d = self::info();
		if ( ! is_array( $d ) ) {
			return $t; // Sin datos firmados: no se ofrece nada.
		}
		if ( ! isset( $t->response ) || ! is_array( $t->response ) ) {
			$t->response = array();
		}
		if ( ! isset( $t->no_update ) || ! is_array( $t->no_update ) ) {
			$t->no_update = array();
		}
		if ( version_compare( $d['version'], self::version_instalada(), '>' ) ) {
			$t->response[ $b ] = self::item( $d, true );
			unset( $t->no_update[ $b ] );
		} else {
			unset( $t->response[ $b ] ); // Nunca una versión igual o anterior (anti-reversión).
			$t->no_update[ $b ] = self::item( $d, false );
		}
		return $t;
	}

	/**
	 * upgrader_pre_download: descarga y comprueba NUESTRO paquete. Cualquier otro paquete sigue su camino.
	 *
	 * @return mixed false/WP_Error/ruta del archivo.
	 */
	public static function filtro_descarga( $reply, $package, $upgrader = null, $hook_extra = null ) {
		if ( false !== $reply || ! is_string( $package ) || 0 !== strpos( $package, OGC_Paginas_Sync::ajustes()['url'] . 'ogc-paginas-' ) ) {
			return $reply;
		}
		$d = self::info();
		if ( ! is_array( $d ) || self::url_paquete( $d ) !== $package ) {
			$d = self::info( true );
		}
		if ( ! is_array( $d ) ) {
			return new WP_Error( 'ogc_paquete', 'OGC Páginas: no se puede verificar la versión publicada (' . $d . '). No se instala nada.' );
		}
		if ( self::url_paquete( $d ) !== $package ) {
			return new WP_Error( 'ogc_paquete', 'OGC Páginas: el paquete pedido no es el de la versión firmada. No se instala nada.' );
		}
		if ( ! version_compare( $d['version'], self::version_instalada(), '>' ) ) {
			return new WP_Error( 'ogc_paquete', 'OGC Páginas: la versión publicada no es más nueva que la instalada. No se instala nada.' );
		}
		$zip = OGC_Paginas_Sync::descargar( $d['zip'], self::MAX_ZIP );
		if ( is_wp_error( $zip ) ) {
			return new WP_Error( 'ogc_paquete', 'OGC Páginas: ' . $zip->get_error_message() );
		}
		$v = self::comprobar_zip( $d, $zip );
		if ( true !== $v ) {
			self::registrar( 'ACTUALIZACIÓN DEL PLUGIN RECHAZADA · ' . $d['version'] . ' · ' . $v );
			return new WP_Error( 'ogc_paquete', 'OGC Páginas: ' . $v . ' No se instala nada.' );
		}
		$tmp = function_exists( 'wp_tempnam' ) ? wp_tempnam( $d['zip'] ) : tempnam( sys_get_temp_dir(), 'ogc' );
		if ( ! $tmp || false === file_put_contents( $tmp, $zip ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			return new WP_Error( 'ogc_paquete', 'OGC Páginas: no se ha podido guardar el paquete descargado.' );
		}
		self::registrar( 'ACTUALIZACIÓN DEL PLUGIN · paquete ' . $d['zip'] . ' con FIRMA VÁLIDA y sha256 correcto: WordPress lo instala (' . self::version_instalada() . ' → ' . $d['version'] . ').' );
		return $tmp;
	}

	/**
	 * @return true|string
	 */
	public static function comprobar_zip( array $d, $zip ) {
		if ( strlen( $zip ) !== $d['bytes'] ) {
			return 'el zip descargado no tiene el tamaño firmado.';
		}
		if ( ! hash_equals( $d['sha256'], hash( 'sha256', $zip ) ) ) {
			return 'el zip descargado no es el firmado (sha256 distinto).';
		}
		if ( 0 !== strncmp( $zip, "PK\x03\x04", 4 ) ) {
			return 'el archivo descargado no es un zip.';
		}
		return true;
	}

	/** plugins_api: «Ver detalles» con los datos firmados (nunca los de wordpress.org). */
	public static function filtro_api( $res, $action, $args ) {
		if ( 'plugin_information' !== $action || ! is_object( $args ) || self::SLUG !== ( $args->slug ?? '' ) ) {
			return $res;
		}
		$d = self::info();
		if ( ! is_array( $d ) ) {
			return $res;
		}
		$nueva = version_compare( $d['version'], self::version_instalada(), '>' );
		return (object) array(
			'name'          => 'OGC Páginas',
			'slug'          => self::SLUG,
			'version'       => $d['version'],
			'author'        => 'Preparador OGC',
			'requires'      => $d['requiere_wp'] ?? '6.0',
			'requires_php'  => $d['requiere_php'] ?? '7.4',
			'tested'        => $d['probado_wp'] ?? '',
			'last_updated'  => gmdate( 'Y-m-d H:i:s', $d['fecha_unix'] ),
			'download_link' => $nueva ? self::url_paquete( $d ) : '',
			'sections'      => array(
				'description' => esc_html( 'Plugin privado de Preparador OGC: páginas, entradas del blog y actualizaciones firmadas.' ),
				'changelog'   => nl2br( esc_html( (string) ( $d['notas'] ?? '' ) ) ),
			),
		);
	}

	/** «Buscar actualización del plugin ahora» (pestaña Actualización automática). */
	public static function buscar_ahora() {
		delete_site_transient( self::CACHE );
		$d = self::info( true );
		if ( function_exists( 'wp_clean_plugins_cache' ) ) {
			wp_clean_plugins_cache( true );
		}
		if ( function_exists( 'wp_update_plugins' ) ) {
			wp_update_plugins();
		}
		if ( ! is_array( $d ) ) {
			return array( 'No se ha podido comprobar la versión publicada del plugin: ' . $d );
		}
		if ( version_compare( $d['version'], self::version_instalada(), '>' ) ) {
			return array( 'Hay una versión nueva del plugin: ' . $d['version'] . ' (tienes la ' . self::version_instalada() . '). Ve a Plugins y pulsa «Actualizar ahora», o espera a la actualización automática si la has activado.' );
		}
		return array( 'El plugin está al día (versión ' . self::version_instalada() . '; publicada: ' . $d['version'] . ').' );
	}

	private static function registrar( $l ) {
		if ( class_exists( 'OGC_Paginas_Sincronizador' ) ) {
			OGC_Paginas_Sincronizador::registrar( array( $l ), false );
		}
	}
}
