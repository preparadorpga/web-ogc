<?php
/**
 * Imágenes de producto que viajan DENTRO del plugin (rediseño 12/11/2026).
 *
 * Al pulsar «Sincronizar» (no en la simulación), copia las imágenes de la carpeta img/ del plugin a
 * wp-content/uploads/ogc/, que es donde las páginas las enlazan
 * (https://organizacionygestioncomercial.es/wp-content/uploads/ogc/NOMBRE).
 *
 * Seguridad (mismas reglas que las imágenes de la actualización firmada, OGC_Paginas_Sync):
 *   - Solo las que lista el manifiesto («imagenes»: ruta img/…, sha256 y bytes), nunca lo que haya suelto en la carpeta.
 *   - Ruta img/[a-z0-9_-]+.(png|jpg|webp): sin «..», sin subcarpetas raras, nunca svg ni php.
 *   - Tamaño máximo 3 MB; el sha256 y el tamaño del archivo tienen que coincidir con el manifiesto.
 *   - El tipo real (getimagesize o firma de bytes) tiene que coincidir con la extensión.
 *   - Escritura atómica (archivo temporal + rename) y solo dentro de <uploads>/ogc/.
 *   - Si el destino ya existe con el mismo sha256, no se toca.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Imagenes {

	const MAX_BYTES = 3145728;
	const TIPOS     = array(
		'png'  => 'image/png',
		'jpg'  => 'image/jpeg',
		'webp' => 'image/webp',
	);

	/** Carpeta img/ del plugin. */
	public static function origen() {
		return OGC_PAGINAS_DIR . '/img';
	}

	/** <uploads>/ogc (sin barra final) o '' si no hay carpeta de subidas. */
	public static function destino() {
		$u = wp_upload_dir( null, false );
		return empty( $u['basedir'] ) ? '' : rtrim( $u['basedir'], '/\\' ) . '/ogc';
	}

	/**
	 * Lista validada del manifiesto.
	 *
	 * @return array|string Lista o motivo del rechazo.
	 */
	public static function lista( array $m ) {
		$l = $m['imagenes'] ?? array();
		if ( ! is_array( $l ) || count( $l ) > 200 ) {
			return 'lista de imágenes no válida';
		}
		$out = array();
		foreach ( $l as $i ) {
			if ( ! is_array( $i ) || ! isset( $i['ruta'], $i['sha256'], $i['bytes'] ) || ! is_string( $i['ruta'] ) || ! is_string( $i['sha256'] ) || ! is_int( $i['bytes'] ) ) {
				return 'imagen mal descrita';
			}
			if ( ! preg_match( '#^img/([a-z0-9][a-z0-9_-]*)\.([a-z]+)$#', $i['ruta'], $mm ) || strlen( $i['ruta'] ) > 150 ) {
				return 'ruta de imagen no permitida: ' . $i['ruta'];
			}
			if ( ! isset( self::TIPOS[ $mm[2] ] ) ) {
				return 'extensión no permitida (solo png, jpg y webp): ' . $i['ruta'];
			}
			if ( $i['bytes'] < 1 || $i['bytes'] > self::MAX_BYTES || ! preg_match( '/^[0-9a-f]{64}$/', $i['sha256'] ) ) {
				return 'tamaño o hash no válido: ' . $i['ruta'];
			}
			$i['nombre'] = $mm[1] . '.' . $mm[2];
			$i['ext']    = $mm[2];
			$out[]       = $i;
		}
		return $out;
	}

	/** Tipo real de los bytes. */
	public static function tipo( $b ) {
		$info = function_exists( 'getimagesizefromstring' ) ? @getimagesizefromstring( $b ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( is_array( $info ) && ! empty( $info['mime'] ) ) {
			return $info['mime'];
		}
		if ( 0 === strncmp( $b, "\x89PNG\r\n\x1a\n", 8 ) ) {
			return 'image/png';
		}
		if ( 0 === strncmp( $b, "\xFF\xD8\xFF", 3 ) ) {
			return 'image/jpeg';
		}
		if ( 'RIFF' === substr( $b, 0, 4 ) && 'WEBP' === substr( $b, 8, 4 ) ) {
			return 'image/webp';
		}
		return '';
	}

	/**
	 * Copia (o simula) las imágenes del manifiesto.
	 *
	 * @param array $m       Manifiesto validado.
	 * @param bool  $simular true = solo informa.
	 * @return array Líneas para el registro.
	 */
	public static function instalar( array $m, $simular = false ) {
		$l = self::lista( $m );
		if ( ! is_array( $l ) ) {
			return array( 'IMÁGENES · no se copia ninguna: ' . $l );
		}
		if ( ! $l ) {
			return array();
		}
		$dir = self::destino();
		if ( '' === $dir || ( ! $simular && ! wp_mkdir_p( $dir ) ) ) {
			return array( 'IMÁGENES · ERROR: no se puede escribir en wp-content/uploads/ogc/.' );
		}
		$n      = array( 'copiadas' => 0, 'iguales' => 0, 'errores' => 0 );
		$lineas = array();
		foreach ( $l as $i ) {
			$src = self::origen() . '/' . $i['nombre'];
			$dst = $dir . '/' . $i['nombre'];
			if ( is_readable( $dst ) && hash_equals( $i['sha256'], (string) hash_file( 'sha256', $dst ) ) ) {
				++$n['iguales'];
				continue;
			}
			$b = is_readable( $src ) ? (string) file_get_contents( $src ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions
			$motivo = '';
			if ( strlen( $b ) !== $i['bytes'] ) {
				$motivo = 'falta en el plugin o tiene otro tamaño';
			} elseif ( ! hash_equals( $i['sha256'], hash( 'sha256', $b ) ) ) {
				$motivo = 'contenido distinto del manifiesto';
			} elseif ( self::TIPOS[ $i['ext'] ] !== self::tipo( $b ) ) {
				$motivo = 'no es una imagen ' . $i['ext'];
			}
			if ( '' !== $motivo ) {
				$lineas[] = 'IMÁGENES · ERROR ' . $i['nombre'] . ': ' . $motivo . '.';
				++$n['errores'];
				continue;
			}
			if ( $simular ) {
				$lineas[] = '[simulación] IMÁGENES · se copiaría ' . $i['nombre'];
				++$n['copiadas'];
				continue;
			}
			$tmp = $dst . '.tmp-' . wp_generate_password( 8, false );
			if ( false === file_put_contents( $tmp, $b ) || ! @rename( $tmp, $dst ) ) { // phpcs:ignore
				@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				$lineas[] = 'IMÁGENES · ERROR ' . $i['nombre'] . ': no se ha podido guardar.';
				++$n['errores'];
				continue;
			}
			++$n['copiadas'];
		}
		array_unshift( $lineas, sprintf( '%sIMÁGENES · %d %s a wp-content/uploads/ogc/, %d ya estaban, %d errores.', $simular ? '[simulación] ' : '', $n['copiadas'], $simular ? 'se copiarían' : 'copiadas', $n['iguales'], $n['errores'] ) );
		return $lineas;
	}

	/**
	 * Se engancha a admin_post_ogc_paginas_sincronizar con prioridad 5: corre justo antes de la sincronización
	 * (que es la que redirige). Mismas comprobaciones que ella: permiso, nonce y unfiltered_html.
	 */
	public static function al_sincronizar() {
		if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'unfiltered_html' ) ) {
			return;
		}
		check_admin_referer( 'ogc_paginas_sincronizar' );
		$simular = ! empty( $_POST['simular'] ); // phpcs:ignore WordPress.Security.NonceVerification
		$m       = OGC_Paginas_Manifiesto::cargar();
		if ( ! $m ) {
			return;
		}
		$lineas = self::instalar( $m, $simular );
		if ( $lineas ) {
			OGC_Paginas_Sincronizador::registrar( $lineas, $simular );
		}
	}
}
