<?php
/**
 * Escritorio → Herramientas → OGC Páginas: tabla de estado, «Sincronizar» (con «solo vista previa»),
 * «Adoptar» una página que ya existía y registro de lo hecho.
 * Solo administradores (manage_options; para escribir, además unfiltered_html) y siempre con nonce.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Admin {

	const SLUG = 'ogc-paginas';

	public static function menu() {
		add_management_page( 'OGC Páginas', 'OGC Páginas', 'manage_options', self::SLUG, array( __CLASS__, 'pagina' ) );
	}

	public static function enlace_ajustes( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'tools.php?page=' . self::SLUG ) ) . '">Abrir</a>' );
		return $links;
	}

	private static function url_volver() {
		return admin_url( 'tools.php?page=' . self::SLUG );
	}

	private static function puede_escribir() {
		return current_user_can( 'manage_options' ) && current_user_can( 'unfiltered_html' );
	}

	private static function estado_wp( $s ) {
		$t = array(
			'publish' => 'publicada',
			'draft'   => 'borrador',
			'pending' => 'pendiente',
			'private' => 'privada',
			'future'  => 'programada',
			'trash'   => 'papelera',
		);
		return $t[ $s ] ?? $s;
	}

	private static function etiqueta_estado( $f ) {
		$t = array(
			'nueva'    => array( 'Nueva', '#2E75B6' ),
			'al_dia'   => array( 'Al día', '#2e7d32' ),
			'cambiada' => array( 'Cambiada', '#b26a00' ),
			'omitida'  => array( 'Omitida', '#6b7280' ),
		);
		$e = $t[ $f['estado'] ] ?? array( $f['estado'], '#6b7280' );
		$h = '<span style="display:inline-block;padding:1px 8px;border-radius:10px;color:#fff;background:' . esc_attr( $e[1] ) . '">' . esc_html( $e[0] ) . '</span>';
		if ( $f['p']['huecos'] ) {
			$h .= ' <span style="display:inline-block;padding:1px 8px;border-radius:10px;background:#FFD23F;color:#1F4E79" title="' . esc_attr( implode( ' ', $f['p']['huecos'] ) ) . '">Con huecos «[…]»</span>';
		}
		if ( $f['a_mano'] ) {
			$h .= ' <span style="display:inline-block;padding:1px 8px;border-radius:10px;background:#EEF1F4;color:#4A4F55">Editada a mano</span>';
		}
		return $h;
	}

	private static function texto_accion( $f ) {
		if ( 'crear' === $f['accion'] || 'actualizar' === $f['accion'] ) {
			$a = 'crear' === $f['accion'] ? 'Se crea' : 'Se actualiza';
			return $a . ( $f['p']['huecos'] ? ' como BORRADOR' : ' y se publica' );
		}
		return $f['motivo'] ? $f['motivo'] : '—';
	}

	public static function pagina() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tab = isset( $_GET['tab'] ) && in_array( $_GET['tab'], array( 'ajustes', 'sync', 'blog' ), true ) ? sanitize_key( $_GET['tab'] ) : 'paginas'; // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="wrap"><h1>OGC Páginas</h1>';
		echo '<nav class="nav-tab-wrapper"><a class="nav-tab' . ( 'paginas' === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( self::url_volver() ) . '">Páginas</a><a class="nav-tab' . ( 'ajustes' === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( self::url_volver() . '&tab=ajustes' ) . '">Ajustes</a><a class="nav-tab' . ( 'sync' === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( self::url_volver() . '&tab=sync' ) . '">Actualización automática</a><a class="nav-tab' . ( 'blog' === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( self::url_volver() . '&tab=blog' ) . '">Blog y SEO</a></nav>';
		if ( 'blog' === $tab ) {
			OGC_Paginas_Blog_Admin::pagina();
			echo '</div>';
			return;
		}
		if ( 'sync' === $tab ) {
			OGC_Paginas_Sync_Admin::pagina();
			echo '</div>';
			return;
		}
		if ( 'ajustes' === $tab ) {
			self::pagina_ajustes();
			echo '</div>';
			return;
		}
		$m = OGC_Paginas_Manifiesto::cargar();
		if ( ! $m ) {
			echo '<div class="notice notice-error"><p>' . esc_html( OGC_Paginas_Manifiesto::error() ) . '</p></div></div>';
			return;
		}

		$res = get_transient( 'ogc_paginas_resultado_' . get_current_user_id() );
		if ( is_array( $res ) ) {
			delete_transient( 'ogc_paginas_resultado_' . get_current_user_id() );
			echo '<div class="notice notice-info"><p><strong>' . esc_html( array_shift( $res ) ) . '</strong></p>';
			if ( $res ) {
				echo '<ul style="list-style:disc;margin-left:20px">';
				foreach ( $res as $l ) {
					echo '<li>' . esc_html( $l ) . '</li>';
				}
				echo '</ul>';
			}
			echo '</div>';
		}

		if ( ! current_user_can( 'unfiltered_html' ) ) {
			echo '<div class="notice notice-error"><p>Tu usuario no puede guardar HTML sin filtrar (dibujos svg, formularios y scripts). Entra con el usuario <strong>Administrador</strong> del sitio para sincronizar.</p></div>';
		}
		if ( defined( 'WP_POST_REVISIONS' ) && ! WP_POST_REVISIONS ) {
			echo '<div class="notice notice-warning"><p>Las revisiones de WordPress están desactivadas (WP_POST_REVISIONS): al actualizar una página no quedará copia para volver atrás. Haz una copia de seguridad antes.</p></div>';
		}

		$filas = OGC_Paginas_Sincronizador::plan( $m );
		$cuenta = array(
			'nueva'    => 0,
			'al_dia'   => 0,
			'cambiada' => 0,
			'omitida'  => 0,
			'huecos'   => 0,
		);
		foreach ( $filas as $f ) {
			++$cuenta[ $f['estado'] ];
			if ( $f['p']['huecos'] ) {
				++$cuenta['huecos'];
			}
		}
		echo '<p>Paquete <strong>' . esc_html( $m['version'] ?? '' ) . '</strong> (generado el ' . esc_html( $m['generado'] ?? '' ) . ') · plugin ' . esc_html( OGC_PAGINAS_VERSION ) . ' · ' . (int) count( $filas ) . ' páginas: '
			. (int) $cuenta['nueva'] . ' nuevas, ' . (int) $cuenta['al_dia'] . ' al día, ' . (int) $cuenta['cambiada'] . ' cambiadas, ' . (int) $cuenta['omitida'] . ' omitidas; ' . (int) $cuenta['huecos'] . ' con huecos «[…]» (se guardan como borrador).</p>';
		echo '<p>«Sincronizar» nunca toca la portada, /my-services/, /about/, /practica-ogc/, /contacto/ (de esas 5 solo se actualiza Yoast, con su propio botón, más abajo), las entradas del blog (pestaña Blog) ni ninguna página que no esté en esta lista o que no haya creado el plugin.</p>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ogc_paginas_sincronizar' );
		echo '<input type="hidden" name="action" value="ogc_paginas_sincronizar">';
		echo '<table class="widefat striped"><thead><tr><td class="check-column"><input type="checkbox" checked aria-label="Marcar todas"></td><th>#</th><th>Página</th><th>Página superior</th><th>Estado</th><th>Qué hará «Sincronizar»</th></tr></thead><tbody>';
		foreach ( $filas as $f ) {
			$p = $f['p'];
			echo '<tr><th class="check-column"><input type="checkbox" class="ogc-pag-sel" name="rutas[]" value="' . esc_attr( $p['ruta'] ) . '" checked></th>';
			echo '<td>' . (int) $p['orden'] . '</td><td><strong>' . esc_html( $p['titulo'] ) . '</strong><br><code>/' . esc_html( $p['ruta'] ) . '/</code>';
			if ( $f['post'] && 'trash' !== $f['post']->post_status ) {
				echo ' · <a href="' . esc_url( get_edit_post_link( $f['post']->ID, 'url' ) ) . '">editar</a> · <a href="' . esc_url( get_permalink( $f['post'] ) ) . '" target="_blank" rel="noopener">ver</a> (' . esc_html( self::estado_wp( $f['post']->post_status ) ) . ')';
			}
			echo '<br><small>' . esc_html( $p['fase'] ) . '</small></td>';
			echo '<td>' . ( '' === $p['madre'] ? '—' : '<code>/' . esc_html( $p['madre'] ) . '/</code>' ) . '</td>';
			echo '<td>' . self::etiqueta_estado( $f ) . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput -- escapado dentro.
			echo '<td>' . esc_html( self::texto_accion( $f ) );
			if ( $p['huecos'] ) {
				echo '<br><small>Huecos sin dato ni sustituto: ' . esc_html( implode( ' ', $p['huecos'] ) ) . '</small>';
			}
			if ( ! empty( $p['notas'] ) ) {
				echo '<br><small>Rellenado: ' . esc_html( implode( ' · ', $p['notas'] ) ) . '</small>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		echo '<p><label><input type="checkbox" name="simular" value="1" checked> <strong>Solo vista previa (simular):</strong> enseña lo que haría sin cambiar nada.</label></p>';
		submit_button( 'Sincronizar', 'primary', 'submit', false, self::puede_escribir() ? array() : array( 'disabled' => 'disabled' ) );
		echo ' <span class="description">Solo se reescriben las páginas nuevas o cambiadas; antes se guarda una revisión (Página → Revisiones para volver atrás).</span>';
		echo '</form>';

		// ---------- Las 5 páginas que posicionan: solo Yoast ----------
		$pos = OGC_Paginas_Posicionan::estado( $m );
		if ( $pos ) {
			echo '<h2>Páginas que posicionan: solo los campos de Yoast</h2>';
			echo '<p>De estas 5 páginas el plugin <strong>no cambia el contenido, el título (H1), la dirección ni el estado</strong>. Este botón solo escribe el título SEO, la meta descripción y la frase clave de Yoast. Antes guarda los valores que hay ahora, para poder volver con «Restaurar Yoast anterior». Los bloques que se añaden a estas páginas se pegan a mano.</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'ogc_paginas_yoast_aplicar' );
			echo '<input type="hidden" name="action" value="ogc_paginas_yoast"><input type="hidden" name="op" value="aplicar">';
			echo '<table class="widefat striped"><thead><tr><td class="check-column"><input type="checkbox" checked aria-label="Marcar todas"></td><th>Página</th><th>Yoast ahora</th><th>Yoast nuevo</th><th>Estado</th></tr></thead><tbody>';
			foreach ( $pos as $ruta => $f ) {
				$e   = $f['e'];
				$url = '/' . ( '' === $ruta ? '' : $ruta . '/' );
				echo '<tr><th class="check-column"><input type="checkbox" name="rutas_yoast[]" value="' . esc_attr( '' === $ruta ? '_portada' : $ruta ) . '" checked></th>';
				echo '<td><strong>' . esc_html( $e['nombre'] ) . '</strong><br><code>' . esc_html( $url ) . '</code>' . ( $f['post'] ? ' · ID ' . (int) $f['post']->ID : '' ) . '</td>';
				if ( $f['post'] ) {
					echo '<td><small><strong>Título:</strong> ' . esc_html( $f['actual']['seo_titulo'] ) . '<br><strong>Meta:</strong> ' . esc_html( $f['actual']['seo_meta'] ) . '<br><strong>Frase clave:</strong> ' . esc_html( $f['actual']['frase_clave'] ) . '</small></td>';
				} else {
					echo '<td><em>No se encuentra la página' . ( '' === $ruta ? ' (Ajustes → Lectura: la portada no es una página estática)' : '' ) . '.</em></td>';
				}
				echo '<td><small><strong>Título:</strong> ' . esc_html( $e['seo_titulo'] ) . '<br><strong>Meta:</strong> ' . esc_html( $e['seo_meta'] ) . '<br><strong>Frase clave:</strong> ' . esc_html( $e['frase_clave'] ) . '</small></td>';
				echo '<td>' . esc_html( array( 'falta' => 'No encontrada', 'al_dia' => 'Al día', 'pendiente' => 'Por actualizar' )[ $f['estado'] ] ?? $f['estado'] );
				if ( is_array( $f['anterior'] ) ) {
					echo '<br><small>Copia del ' . esc_html( (string) ( $f['anterior']['fecha'] ?? '' ) ) . '</small>';
				}
				echo '</td></tr>';
			}
			echo '</tbody></table>';
			echo '<p><label><input type="checkbox" name="simular" value="1" checked> <strong>Solo vista previa (simular)</strong></label></p>';
			submit_button( 'Actualizar Yoast de las marcadas', 'primary', 'submit', false );
			echo '</form>';
			foreach ( $pos as $ruta => $f ) {
				if ( ! is_array( $f['anterior'] ) ) {
					continue;
				}
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin:6px 8px 0 0">';
				wp_nonce_field( 'ogc_paginas_yoast_restaurar' );
				echo '<input type="hidden" name="action" value="ogc_paginas_yoast"><input type="hidden" name="op" value="restaurar"><input type="hidden" name="ruta" value="' . esc_attr( '' === $ruta ? '_portada' : $ruta ) . '">';
				submit_button( 'Restaurar Yoast anterior de ' . ( '' === $ruta ? 'la portada' : '/' . $ruta . '/' ), 'secondary', 'submit', false );
				echo '</form>';
			}
		}

		$adoptables = array_filter(
			$filas,
			static function ( $f ) {
				return $f['adoptar'];
			}
		);
		if ( $adoptables ) {
			echo '<h2>Páginas que ya existían con la misma dirección</h2>';
			echo '<p>El plugin no las toca. Si una de ellas es la misma página (por ejemplo, la <strong>Tienda</strong> de WooCommerce, una vez desactivado WooCommerce), puedes «adoptarla»: no cambia nada ahora, y en la próxima sincronización se sustituye su contenido (con revisión previa para volver atrás).</p>';
			echo '<table class="widefat striped"><tbody>';
			foreach ( $adoptables as $f ) {
				$r = $f['p']['ruta'];
				echo '<tr><td><code>/' . esc_html( $r ) . '/</code> · ' . esc_html( get_the_title( $f['post'] ) ) . ' (ID ' . (int) $f['post']->ID . ', ' . esc_html( self::estado_wp( $f['post']->post_status ) ) . ')</td><td>';
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
				wp_nonce_field( 'ogc_paginas_adoptar_' . $r );
				echo '<input type="hidden" name="action" value="ogc_paginas_adoptar"><input type="hidden" name="ruta" value="' . esc_attr( $r ) . '">';
				echo '<label><input type="checkbox" name="confirmo" value="1" required> Confirmo que su contenido se puede sustituir</label> ';
				submit_button( 'Adoptar', 'secondary small', 'submit', false, self::puede_escribir() ? array() : array( 'disabled' => 'disabled' ) );
				echo '</form></td></tr>';
			}
			echo '</tbody></table>';
		}

		echo '<h2>Registro</h2>';
		$reg = get_option( OGC_Paginas_Sincronizador::OPCION_REGISTRO, array() );
		if ( ! is_array( $reg ) || ! $reg ) {
			echo '<p>Todavía no se ha hecho nada.</p>';
		} else {
			foreach ( array_slice( $reg, 0, 10 ) as $e ) {
				echo '<details style="margin:6px 0"><summary>' . esc_html( ( $e['fecha'] ?? '' ) . ' · ' . ( $e['usuario'] ?? '' ) . ' · ' . ( empty( $e['simular'] ) ? 'real' : 'simulación' ) . ' · ' . ( $e['lineas'][0] ?? '' ) ) . '</summary><ul style="list-style:disc;margin-left:20px">';
				foreach ( array_slice( (array) ( $e['lineas'] ?? array() ), 1 ) as $l ) {
					echo '<li>' . esc_html( $l ) . '</li>';
				}
				echo '</ul></details>';
			}
		}
		echo '</div>';
	}

	public static function sincronizar() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sin permiso.', 403 );
		}
		check_admin_referer( 'ogc_paginas_sincronizar' );
		$simular = ! empty( $_POST['simular'] );
		if ( ! $simular && ! current_user_can( 'unfiltered_html' ) ) {
			wp_die( 'Hace falta un usuario Administrador con permiso para guardar HTML sin filtrar.', 403 );
		}
		$m = OGC_Paginas_Manifiesto::cargar();
		if ( ! $m ) {
			wp_die( esc_html( OGC_Paginas_Manifiesto::error() ) );
		}
		$sel = isset( $_POST['rutas'] ) && is_array( $_POST['rutas'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['rutas'] ) ) : array();
		$sel = array_values( array_filter( $sel, static function ( $r ) { return (bool) preg_match( '#^[a-z0-9-]+(/[a-z0-9-]+)*$#', $r ); } ) );
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		$lineas = OGC_Paginas_Sincronizador::ejecutar( $m, $sel, $simular );
		set_transient( 'ogc_paginas_resultado_' . get_current_user_id(), $lineas, 10 * MINUTE_IN_SECONDS );
		wp_safe_redirect( self::url_volver() );
		exit;
	}

	public static function adoptar() {
		if ( ! self::puede_escribir() ) {
			wp_die( 'Sin permiso.', 403 );
		}
		$ruta = isset( $_POST['ruta'] ) ? sanitize_text_field( wp_unslash( $_POST['ruta'] ) ) : '';
		check_admin_referer( 'ogc_paginas_adoptar_' . $ruta );
		if ( empty( $_POST['confirmo'] ) ) {
			wp_die( 'Marca la casilla de confirmación.' );
		}
		$m = OGC_Paginas_Manifiesto::cargar();
		if ( ! $m ) {
			wp_die( esc_html( OGC_Paginas_Manifiesto::error() ) );
		}
		$r = OGC_Paginas_Sincronizador::adoptar( $m, $ruta );
		set_transient( 'ogc_paginas_resultado_' . get_current_user_id(), array( true === $r ? 'Página /' . $ruta . '/ adoptada. Pulsa «Sincronizar» para actualizarla.' : $r ), 10 * MINUTE_IN_SECONDS );
		wp_safe_redirect( self::url_volver() );
		exit;
	}

	private static function pagina_ajustes() {
		$aj = OGC_Paginas_Huecos::ajustes();
		echo '<p>Estos datos se ponen en las páginas <strong>al pulsar «Sincronizar»</strong>. Si cambias un ajuste, vuelve a la pestaña Páginas y sincroniza: solo se actualizan las páginas que lo usan.</p>';
		echo '<ul style="list-style:disc;margin-left:20px"><li><strong>Enlace de Stripe vacío:</strong> el botón abre WhatsApp (678 872 362) con el mensaje «Hola, me interesa … de OGC. ¿Cómo puedo comprarlo?» y dice «… por WhatsApp». En cuanto pegues el enlace y sincronices, vuelve a ser el botón de pago con tarjeta.</li><li><strong>Foto vacía:</strong> se quita la foto sin dejar hueco.</li><li><strong>NIF vacío:</strong> se quita «, [NIF]» de la frase. <strong>Proveedor vacío:</strong> se escribe «El proveedor de alojamiento web».</li><li><strong>Formulario de muestras vacío:</strong> la página de muestras se queda en borrador (el formulario no funcionaría).</li></ul>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'ogc_paginas_ajustes' );
		echo '<input type="hidden" name="action" value="ogc_paginas_ajustes">';
		$grupo = '';
		foreach ( OGC_Paginas_Huecos::campos() as $k => $c ) {
			if ( $c[2] !== $grupo ) {
				echo ( '' === $grupo ? '' : '</tbody></table>' ) . '<h2>' . esc_html( $c[2] ) . '</h2><table class="form-table"><tbody>';
				$grupo = $c[2];
			}
			$ph = 'url' === $c[1] ? ( 0 === strpos( $k, 'stripe_' ) ? 'https://buy.stripe.com/…' : 'https://…' ) : '';
			echo '<tr><th scope="row"><label for="ogc-' . esc_attr( $k ) . '">' . esc_html( $c[0] ) . '</label></th><td><input class="regular-text" type="' . ( 'url' === $c[1] ? 'url' : 'text' ) . '" id="ogc-' . esc_attr( $k ) . '" name="ajustes[' . esc_attr( $k ) . ']" value="' . esc_attr( $aj[ $k ] ) . '" placeholder="' . esc_attr( $ph ) . '"></td></tr>';
		}
		echo '</tbody></table>';
		submit_button( 'Guardar ajustes' );
		echo '</form>';
	}

	public static function guardar_ajustes() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sin permiso.', 403 );
		}
		check_admin_referer( 'ogc_paginas_ajustes' );
		$entrada = isset( $_POST['ajustes'] ) && is_array( $_POST['ajustes'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['ajustes'] ) ) : array();
		$malos   = OGC_Paginas_Huecos::guardar( $entrada );
		$lineas  = array( 'Ajustes guardados. Pulsa «Sincronizar» (con «simular» primero) para ponerlos en las páginas.' );
		if ( $malos ) {
			$lineas[] = 'No se han guardado por no ser válidos (los enlaces tienen que empezar por https://; el NIF, solo letras y números): ' . implode( ', ', $malos ) . '.';
		}
		OGC_Paginas_Sincronizador::registrar( array( 'AJUSTES guardados' . ( $malos ? ' (rechazados: ' . implode( ', ', $malos ) . ')' : '' ) ), false );
		set_transient( 'ogc_paginas_resultado_' . get_current_user_id(), $lineas, 10 * MINUTE_IN_SECONDS );
		wp_safe_redirect( self::url_volver() );
		exit;
	}

	public static function yoast() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sin permiso.', 403 );
		}
		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		if ( 'aplicar' !== $op && 'restaurar' !== $op ) {
			wp_die( 'Acción no válida.' );
		}
		check_admin_referer( 'ogc_paginas_yoast_' . $op );
		$m = OGC_Paginas_Manifiesto::cargar();
		if ( ! $m ) {
			wp_die( esc_html( OGC_Paginas_Manifiesto::error() ) );
		}
		$a_ruta = static function ( $r ) {
			$r = sanitize_text_field( (string) $r );
			return '_portada' === $r ? '' : $r;
		};
		if ( 'aplicar' === $op ) {
			$sel     = isset( $_POST['rutas_yoast'] ) && is_array( $_POST['rutas_yoast'] ) ? array_map( $a_ruta, wp_unslash( $_POST['rutas_yoast'] ) ) : array();
			$sel     = array_values( array_intersect( $sel, OGC_Paginas_Posicionan::RUTAS ) );
			$simular = ! empty( $_POST['simular'] );
			$lineas  = OGC_Paginas_Posicionan::aplicar( $m, $sel, $simular );
		} else {
			$ruta    = $a_ruta( isset( $_POST['ruta'] ) ? wp_unslash( $_POST['ruta'] ) : 'x' );
			$simular = false;
			$lineas  = in_array( $ruta, OGC_Paginas_Posicionan::RUTAS, true ) ? OGC_Paginas_Posicionan::restaurar( $m, $ruta ) : array( 'Página no válida.' );
		}
		OGC_Paginas_Sincronizador::registrar( $lineas, $simular );
		set_transient( 'ogc_paginas_resultado_' . get_current_user_id(), $lineas, 10 * MINUTE_IN_SECONDS );
		wp_safe_redirect( self::url_volver() );
		exit;
	}
}
