<?php
/**
 * Plan y ejecución de la sincronización.
 *
 * Estados: nueva · al día · cambiada · omitida (+ «con huecos [..]», que obliga a guardar como borrador).
 * Antes de nada, cada página pasa por OGC_Paginas_Huecos::resolver() (Ajustes o sustituto limpio): solo cuentan
 * como huecos los que no tienen ni valor ni sustituto.
 * Reglas:
 *   - Nunca toca las páginas protegidas (5 que posicionan + entradas), la portada ni la página de entradas
 *     (por ID), ninguna entrada del blog (solo post_type «page») ni páginas fuera del manifiesto.
 *   - Una página existente con esa dirección que no lleve la meta _ogc_paginas_gestionada no se toca: se avisa.
 *   - Solo reescribe las que cambian (hash), y antes guarda una revisión de WordPress.
 *   - Páginas con huecos «[…]» → borrador. Si la página ya está publicada y la versión nueva trae
 *     huecos, no se toca (nunca se despublica nada).
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Sincronizador {

	const META_GESTIONADA = '_ogc_paginas_gestionada';
	const META_RUTA       = '_ogc_paginas_ruta';
	const META_HASH       = '_ogc_paginas_hash';
	const META_GUARDADO   = '_ogc_paginas_hash_guardado';
	const META_VERSION    = '_ogc_paginas_version';
	const OPCION_REGISTRO = 'ogc_paginas_registro';

	/** @var string Versión del manifiesto que se está aplicando (se guarda en cada página). */
	private static $version_en_curso = '';

	/**
	 * Busca la página que creó el plugin para esa ruta (aunque Vicente le haya cambiado la dirección).
	 *
	 * @param string $ruta Ruta sin barras.
	 * @return WP_Post|null
	 */
	public static function gestionada( $ruta ) {
		$ids = get_posts(
			array(
				'post_type'        => 'page',
				'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future', 'trash' ),
				'meta_key'         => self::META_RUTA, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'       => $ruta, // phpcs:ignore WordPress.DB.SlowDBQuery
				'numberposts'      => 5,
				'fields'           => 'ids',
				'orderby'          => 'ID',
				'order'            => 'ASC',
				'suppress_filters' => true,
				'no_found_rows'    => true,
			)
		);
		foreach ( (array) $ids as $id ) {
			if ( '1' === get_post_meta( $id, self::META_GESTIONADA, true ) ) {
				return get_post( $id );
			}
		}
		return null;
	}

	/**
	 * Página que ocupa hoy esa dirección (sea de quien sea).
	 *
	 * @param string $ruta Ruta sin barras.
	 * @return WP_Post|null
	 */
	public static function por_direccion( $ruta ) {
		$p = get_page_by_path( $ruta, OBJECT, 'page' );
		return ( $p instanceof WP_Post && 'page' === $p->post_type ) ? $p : null;
	}

	/** IDs que nunca se tocan aunque coincidan: portada y página de entradas (Ajustes → Lectura). */
	public static function ids_protegidos() {
		return array_filter( array( (int) get_option( 'page_on_front' ), (int) get_option( 'page_for_posts' ) ) );
	}

	private static function es_gestionada( WP_Post $p ) {
		return '1' === get_post_meta( $p->ID, self::META_GESTIONADA, true );
	}

	/**
	 * Calcula qué se haría con cada página.
	 *
	 * @param array      $manifiesto Manifiesto validado.
	 * @param array|null $seleccion  Rutas marcadas (null = todas).
	 * @return array Filas.
	 */
	public static function plan( array $manifiesto, $seleccion = null ) {
		$filas      = array();
		$se_crean   = array(); // rutas que se crearán en esta pasada (para sus hijas).
		$protegidos = self::ids_protegidos();
		foreach ( $manifiesto['paginas'] as $p ) {
			$p = self::efectiva( $p );
			$f = array(
				'p'       => $p,
				'estado'  => '',
				'accion'  => 'nada',
				'motivo'  => '',
				'post'    => null,
				'a_mano'  => false,
				'adoptar' => false,
				'madre'   => 0,
			);
			$elegida = ( null === $seleccion ) || in_array( $p['ruta'], $seleccion, true );
			$post    = self::gestionada( $p['ruta'] );

			if ( OGC_Paginas_Manifiesto::es_protegida( $p['ruta'] ) ) {
				$f['estado'] = 'omitida';
				$f['motivo'] = 'Página protegida (de las que posicionan): el plugin no la toca nunca.';
			} elseif ( $post ) {
				$f['post'] = $post;
				if ( in_array( (int) $post->ID, $protegidos, true ) ) {
					$f['estado'] = 'omitida';
					$f['motivo'] = 'Es la portada o la página de entradas: no se toca.';
				} elseif ( 'trash' === $post->post_status ) {
					$f['estado'] = 'omitida';
					$f['motivo'] = 'Está en la papelera: restáurala o vacía la papelera para que se cree de nuevo.';
				} else {
					$f['estado'] = hash_equals( (string) get_post_meta( $post->ID, self::META_HASH, true ), $p['hash'] ) ? 'al_dia' : 'cambiada';
					$guardado    = (string) get_post_meta( $post->ID, self::META_GUARDADO, true );
					$f['a_mano'] = ( '' !== $guardado && md5( $post->post_content ) !== $guardado );
					if ( 'cambiada' === $f['estado'] ) {
						if ( $p['huecos'] && 'publish' === $post->post_status ) {
							// Nunca se despublica: una versión con huecos no sustituye a una página publicada.
							$f['estado'] = 'omitida';
							$f['motivo'] = 'La versión nueva tiene huecos «[…]» y esta página ya está publicada: se deja la publicada como está (pásala a borrador si quieres la versión nueva).';
						} else {
							$f['accion'] = 'actualizar';
						}
					}
				}
			} else {
				$otra = self::por_direccion( $p['ruta'] );
				if ( $otra ) {
					$f['estado']  = 'omitida';
					$f['post']    = $otra;
					$f['adoptar'] = ! in_array( (int) $otra->ID, $protegidos, true );
					$f['motivo']  = 'Ya existe una página con esta dirección que no creó el plugin: no se toca.' . ( $f['adoptar'] ? ' Si es la misma página (por ejemplo, la Tienda), usa «Adoptar» abajo.' : '' );
				} else {
					$f['estado'] = 'nueva';
					$f['accion'] = 'crear';
				}
			}

			// Página superior.
			if ( 'nada' !== $f['accion'] && '' !== $p['madre'] ) {
				$madre = self::gestionada( $p['madre'] );
				if ( ! $madre || 'trash' === $madre->post_status ) {
					$madre = self::por_direccion( $p['madre'] );
				}
				if ( $madre && 'trash' !== $madre->post_status ) {
					$f['madre'] = (int) $madre->ID;
				} elseif ( isset( $se_crean[ $p['madre'] ] ) ) {
					$f['madre'] = -1; // Se resuelve al ejecutar.
				} else {
					$f['estado'] = 'omitida';
					$f['accion'] = 'nada';
					$f['motivo'] = 'Falta la página superior /' . $p['madre'] . '/ (o no se ha seleccionado).';
				}
			}

			if ( 'nada' !== $f['accion'] && ! $elegida ) {
				$f['accion'] = 'nada';
				$f['motivo'] = 'No seleccionada en esta pasada.';
			}
			if ( 'crear' === $f['accion'] ) {
				$se_crean[ $p['ruta'] ] = true;
			}
			$filas[] = $f;
		}
		return $filas;
	}

	/**
	 * La página tal como se va a guardar: huecos rellenados con los Ajustes (o su sustituto), los huecos
	 * que quedan y un hash que cambia si cambia el manifiesto o un ajuste que afecte a la página.
	 */
	public static function efectiva( array $p ) {
		$r            = OGC_Paginas_Huecos::resolver( $p['contenido'] );
		$p['huecos_plantilla'] = $p['huecos'];
		$p['contenido'] = $r['html'];
		$p['huecos']    = $r['pendientes'];
		$p['notas']     = $r['notas'];
		$p['hash']      = hash( 'sha256', $p['hash'] . '|' . md5( $r['html'] ) . '|' . ( $r['pendientes'] ? 'draft' : 'publish' ) );
		return $p;
	}

	public static function tiene_huecos( $html ) {
		$sin = preg_replace( '/<!--.*?-->/s', '', (string) $html );
		return (bool) preg_match( '/\[[A-ZÁÉÍÓÚÜÑ_][A-ZÁÉÍÓÚÜÑ0-9_ :\-,.()\/ºª]{2,}\]/u', (string) $sin );
	}

	/**
	 * Ejecuta el plan (o lo simula).
	 *
	 * @param array $manifiesto Manifiesto validado.
	 * @param array $seleccion  Rutas marcadas.
	 * @param bool  $simular    true = no escribe nada.
	 * @return array Líneas de registro.
	 */
	public static function ejecutar( array $manifiesto, array $seleccion, $simular ) {
		$lineas = array();
		$filas  = self::plan( $manifiesto, $seleccion );
		self::$version_en_curso = (string) ( $manifiesto['version'] ?? '' ) . ( isset( $manifiesto['serie'] ) ? '#' . (int) $manifiesto['serie'] : '' );
		$ids    = array(); // ruta → ID creado en esta pasada.
		$n      = array(
			'crear'      => 0,
			'actualizar' => 0,
			'omitida'    => 0,
			'error'      => 0,
		);

		$kses_activo = (bool) has_filter( 'content_save_pre', 'wp_filter_post_kses' );
		if ( ! $simular ) {
			// Solo administradores con unfiltered_html llegan aquí (comprobado en OGC_Paginas_Admin).
			kses_remove_filters();
		}
		try {
			foreach ( $filas as $f ) {
				$p   = $f['p'];
				$url = '/' . $p['ruta'] . '/';
				if ( 'omitida' === $f['estado'] ) {
					$lineas[] = 'OMITIDA ' . $url . ' · ' . $f['motivo'];
					++$n['omitida'];
					continue;
				}
				if ( 'nada' === $f['accion'] ) {
					if ( '' !== $f['motivo'] ) {
						$lineas[] = 'SIN CAMBIOS ' . $url . ' · ' . $f['motivo'];
					}
					continue;
				}
				$madre = (int) $f['madre'];
				if ( -1 === $madre ) {
					$madre = isset( $ids[ $p['madre'] ] ) ? (int) $ids[ $p['madre'] ] : 0;
					if ( ! $madre && ! $simular ) {
						$lineas[] = 'ERROR ' . $url . ' · no se pudo crear antes su página superior /' . $p['madre'] . '/.';
						++$n['error'];
						continue;
					}
				}
				$estado = self::estado_final( $p, $f['post'] );
				$texto  = ( 'crear' === $f['accion'] ? 'CREAR ' : 'ACTUALIZAR ' ) . $url . ' como ' . ( 'publish' === $estado ? 'publicada' : ( 'draft' === $estado ? 'BORRADOR' : $estado ) );
				if ( $p['huecos'] ) {
					$texto .= ' (huecos: ' . implode( ' ', $p['huecos'] ) . ')';
				}
				if ( $f['a_mano'] ) {
					$texto .= ' · tenía cambios hechos a mano en WordPress: quedan en el historial de revisiones';
				}
				if ( $simular ) {
					$lineas[] = '[simulación] ' . $texto;
					$ids[ $p['ruta'] ] = 0;
					++$n[ $f['accion'] ];
					continue;
				}
				$r = self::escribir( $p, $f['post'], $madre, $estado );
				if ( is_wp_error( $r ) ) {
					$lineas[] = 'ERROR ' . $url . ' · ' . $r->get_error_message();
					++$n['error'];
					continue;
				}
				$ids[ $p['ruta'] ] = (int) $r;
				$real              = get_post_field( 'post_name', (int) $r );
				if ( $real !== $p['slug'] ) {
					$texto .= ' · OJO: WordPress le ha puesto el slug «' . $real . '» porque «' . $p['slug'] . '» estaba ocupado (revísalo)';
				}
				$lineas[] = $texto . ' · ID ' . (int) $r;
				++$n[ $f['accion'] ];
			}
		} finally {
			if ( ! $simular && $kses_activo ) {
				kses_init_filters();
			}
		}
		array_unshift(
			$lineas,
			sprintf(
				'%s · versión %s · %d creadas, %d actualizadas, %d omitidas, %d errores.',
				$simular ? 'SIMULACIÓN (no se ha cambiado nada)' : 'SINCRONIZACIÓN',
				$manifiesto['version'] ?? '?',
				$n['crear'],
				$n['actualizar'],
				$n['omitida'],
				$n['error']
			)
		);
		self::registrar( $lineas, $simular );
		return $lineas;
	}

	/**
	 * Estado con que se guarda: con huecos → borrador; sin huecos → publicada (salvo que Vicente
	 * la haya puesto privada, pendiente o programada: se respeta).
	 */
	private static function estado_final( array $p, $post ) {
		if ( $p['huecos'] ) {
			return ( $post && in_array( $post->post_status, array( 'pending', 'private' ), true ) ) ? $post->post_status : 'draft';
		}
		if ( $post && in_array( $post->post_status, array( 'pending', 'private', 'future' ), true ) ) {
			return $post->post_status;
		}
		return 'publish';
	}

	/**
	 * @return int|WP_Error ID de la página.
	 */
	private static function escribir( array $p, $post, $madre, $estado ) {
		$meta = array(
			self::META_GESTIONADA                 => '1',
			self::META_RUTA                       => $p['ruta'],
			self::META_HASH                       => $p['hash'],
			self::META_VERSION                    => self::$version_en_curso,
			// Yoast SEO.
			'_yoast_wpseo_title'                  => $p['seo_titulo'],
			'_yoast_wpseo_metadesc'               => $p['seo_meta'],
			'_yoast_wpseo_focuskw'                => $p['frase_clave'],
			'_yoast_wpseo_bctitle'                => $p['titulo_migas'],
			'_yoast_wpseo_meta-robots-noindex'    => $p['noindex'] ? '1' : '0',
			'_yoast_wpseo_canonical'              => '', // 2.1.0 · canonical por defecto de Yoast (la propia URL).
			// Neve: contenedor a ancho completo, sin barra lateral, sin imagen destacada (el título se muestra: es el H1).
			'neve_meta_container'                 => 'full-width',
			'neve_meta_sidebar'                   => 'full-width',
			'neve_meta_disable_featured_image'    => 'on',
		);
		$arr  = array(
			'post_type'      => 'page',
			'post_title'     => $p['titulo'],
			'post_name'      => $p['slug'],
			'post_parent'    => (int) $madre,
			'post_content'   => $p['contenido'],
			'post_status'    => $estado,
			'page_template'  => 'default',
			'comment_status' => 'closed',
			'ping_status'    => 'closed',
			'meta_input'     => $meta,
		);
		if ( $post ) {
			if ( 'page' !== $post->post_type || ! self::es_gestionada( $post ) ) {
				return new WP_Error( 'ogc_no_gestionada', 'la página no es del plugin; no se toca.' );
			}
			// Copia de la versión actual en el historial de revisiones, para poder volver atrás.
			if ( wp_revisions_enabled( $post ) ) {
				wp_save_post_revision( $post->ID );
			}
			$arr['ID'] = (int) $post->ID;
			$id        = wp_update_post( wp_slash( $arr ), true );
		} else {
			// En la actualización automática (WP-Cron) no hay usuario: autor = el administrador que la configuró.
			$arr['post_author'] = get_current_user_id() ? get_current_user_id() : ( class_exists( 'OGC_Paginas_Sync' ) ? OGC_Paginas_Sync::autor() : 0 );
			$id                 = wp_insert_post( wp_slash( $arr ), true );
		}
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		if ( ! $id ) {
			return new WP_Error( 'ogc_sin_id', 'WordPress no ha guardado la página.' );
		}
		update_post_meta( $id, self::META_GUARDADO, md5( (string) get_post_field( 'post_content', $id, 'raw' ) ) );
		return (int) $id;
	}

	/**
	 * Marca como del plugin una página que ya existía con la dirección del manifiesto (acción explícita
	 * de Vicente). No cambia su contenido: la próxima sincronización la actualizará (con revisión previa).
	 *
	 * @return true|string
	 */
	public static function adoptar( array $manifiesto, $ruta ) {
		$p = null;
		foreach ( $manifiesto['paginas'] as $x ) {
			if ( $x['ruta'] === $ruta ) {
				$p = $x;
			}
		}
		if ( ! $p || OGC_Paginas_Manifiesto::es_protegida( $ruta ) ) {
			return 'Esa dirección no está en el manifiesto o está protegida.';
		}
		if ( self::gestionada( $ruta ) ) {
			return 'Esa dirección ya la gestiona el plugin.';
		}
		$post = self::por_direccion( $ruta );
		if ( ! $post || in_array( (int) $post->ID, self::ids_protegidos(), true ) ) {
			return 'No hay una página adoptable en esa dirección.';
		}
		if ( wp_revisions_enabled( $post ) ) {
			wp_save_post_revision( $post->ID );
		}
		update_post_meta( $post->ID, self::META_GESTIONADA, '1' );
		update_post_meta( $post->ID, self::META_RUTA, $ruta );
		update_post_meta( $post->ID, self::META_HASH, '' );
		update_post_meta( $post->ID, self::META_GUARDADO, md5( $post->post_content ) );
		self::registrar( array( 'ADOPTADA /' . $ruta . '/ (ID ' . (int) $post->ID . '): desde ahora la gestiona el plugin. Su contenido no ha cambiado; se actualizará en la próxima sincronización.' ), false );
		return true;
	}

	public static function registrar( array $lineas, $simular ) {
		$reg = get_option( self::OPCION_REGISTRO, array() );
		if ( ! is_array( $reg ) ) {
			$reg = array();
		}
		$u = wp_get_current_user();
		array_unshift(
			$reg,
			array(
				'fecha'   => current_time( 'mysql' ),
				'usuario' => ( $u && ! empty( $u->user_login ) ) ? $u->user_login : 'automático',
				'simular' => (bool) $simular,
				'lineas'  => array_slice( $lineas, 0, 300 ),
			)
		);
		update_option( self::OPCION_REGISTRO, array_slice( $reg, 0, 20 ), false );
	}
}
