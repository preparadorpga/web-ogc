<?php
/**
 * Desinstalación (Plugins → Borrar). NO borra ninguna página.
 * Quita el registro y las marcas internas de versión y hash. Deja la marca _ogc_paginas_gestionada y la ruta
 * para que, si se vuelve a instalar, el plugin reconozca sus páginas y no las tome por ajenas.
 * (Desactivar o «Reemplazar el actual» al subir una versión nueva no ejecuta este archivo.)
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'ogc_paginas_registro' );
delete_post_meta_by_key( '_ogc_paginas_version' );
delete_post_meta_by_key( '_ogc_paginas_hash_guardado' );
// _ogc_paginas_hash se pone en blanco: tras reinstalar, las páginas salen como «cambiada» y se reescriben con revisión.
delete_post_meta_by_key( '_ogc_paginas_hash' );
delete_post_meta_by_key( '_ogc_paginas_yoast_anterior' );
delete_option( 'ogc_paginas_ajustes' );
// 2.0.0 · actualización automática: ajustes, token, clave sustituta, estado, manifiestos guardados, caché del shortcode y WP-Cron.
foreach ( array( 'ogc_paginas_sync', 'ogc_paginas_sync_token', 'ogc_paginas_sync_clave', 'ogc_paginas_sync_estado', 'ogc_paginas_sync_actual', 'ogc_paginas_sync_anterior', 'ogc_paginas_sync_cerrojo', 'ogc_paginas_sc', 'ogc_paginas_blog_estado', 'ogc_paginas_auto_error', 'ogc_paginas_seo_textos' ) as $ogc_opcion ) {
	delete_option( $ogc_opcion );
}
wp_clear_scheduled_hook( 'ogc_paginas_sync_cron' );
// 2.1.0 · NO se borran las entradas del blog ni sus marcas (_ogc_blog_*), ni la 301 del blog (ogc_paginas_blog_301) ni la lista
// de entradas borradas (ogc_paginas_blog_borradas): así una reinstalación no duplica ni recrea nada.
delete_site_transient( 'ogc_paginas_auto_info' );
