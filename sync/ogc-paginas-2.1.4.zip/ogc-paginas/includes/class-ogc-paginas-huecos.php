<?php
/**
 * Huecos «[…]» de las plantillas: se rellenan AL SINCRONIZAR con los Ajustes del plugin o, si el ajuste está
 * vacío, con un sustituto limpio (WhatsApp en lugar de Stripe, sin foto, sin NIF…). Solo los huecos que no tienen
 * ni valor ni sustituto dejan la página en borrador. El visitante nunca ve un «[».
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Huecos {

	const OPCION   = 'ogc_paginas_ajustes';

	/**
	 * Campos de Ajustes: clave => array( etiqueta, tipo, grupo ).
	 */
	public static function campos() {
		return array(
			'stripe_temario'      => array( 'Temario (362,50 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_supuestos'    => array( 'Supuestos (237,50 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_programacion' => array( 'Programación (186,25 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_pack'         => array( 'Pack completo (623,75 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_pack_10h'     => array( 'Pack completo + 10 h (1.248,75 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_pack_programacion' => array( 'Pack Programación (500 €; metadato ogc_producto = pack_programacion)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_clases_3h'    => array( 'Clases 3 h (225 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_clases_5h'    => array( 'Clases 5 h (350 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_clases_10h'   => array( 'Clases 10 h (625 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'foto_vicente'        => array( 'URL de la foto de Vicente (cuadrada, 288 px o más)', 'url', 'Foto' ),
			'nif'                 => array( 'NIF del titular', 'nif', 'Datos legales' ),
			'proveedor_hosting'   => array( 'Proveedor de alojamiento (nombre de la empresa)', 'texto', 'Datos legales' ),
			'form_muestras'       => array( 'Dirección de envío del formulario de muestras (action)', 'url', 'Formulario de muestras' ),
			'img_temario'         => array( 'Imagen del temario', 'url', 'Imágenes de producto (datos estructurados de la tienda; opcionales)' ),
			'img_supuestos'       => array( 'Imagen de los supuestos', 'url', 'Imágenes de producto (datos estructurados de la tienda; opcionales)' ),
			'img_programacion'    => array( 'Imagen de la programación', 'url', 'Imágenes de producto (datos estructurados de la tienda; opcionales)' ),
			'img_pack'            => array( 'Imagen del pack', 'url', 'Imágenes de producto (datos estructurados de la tienda; opcionales)' ),
			'img_pack_10h'        => array( 'Imagen del pack + 10 h', 'url', 'Imágenes de producto (datos estructurados de la tienda; opcionales)' ),
		);
	}

	/** Stripe: clave del hueco => array( ajuste, producto para el WhatsApp, ancla de /tienda/ ). */
	const STRIPE = array(
		'TEMARIO'      => array( 'stripe_temario', 'el temario completo', 'temario' ),
		'SUPUESTOS'    => array( 'stripe_supuestos', 'el dossier de supuestos prácticos', 'supuestos' ),
		'PROGRAMACION' => array( 'stripe_programacion', 'la programación didáctica', 'programacion' ),
		'PACK'         => array( 'stripe_pack', 'el pack completo (temario, supuestos y programación)', 'pack' ),
		'PACK_10H'     => array( 'stripe_pack_10h', 'el pack completo + 10 h de clases', 'pack-10h' ),
		'CLASES_3H'    => array( 'stripe_clases_3h', 'el pack de 3 h de clases online', 'clases' ),
		'CLASES_5H'    => array( 'stripe_clases_5h', 'el pack de 5 h de clases online', 'clases' ),
		'CLASES_10H'   => array( 'stripe_clases_10h', 'el pack de 10 h de clases online', 'clases' ),
	);

	/**
	 * Frases de proceso de pago que, sin enlace de Stripe, no deben prometer tarjeta (2.1.2: la compra sin Payment Link
	 * se pide por CORREO, no por WhatsApp; WhatsApp queda solo para pedir las ofertas de los packs y las clases de 10 h).
	 * 2.1.4 (Vicente, 13/11/2026 14:23: «todo a través de Stripe»): las ofertas por WhatsApp también se pagan con un enlace
	 * privado de Stripe (tarjeta, Bizum o Revolut); ya no se anuncia Bizum directo ni transferencia.
	 */
	const FRASES_SIN_STRIPE = array(
		'Pago con tarjeta, Apple Pay o Google Pay mediante Stripe; la factura llega al correo de compra y la descarga se activa al confirmar el pago.' => 'Para comprar, pulsa «Comprar»: se abre un correo con el producto ya escrito, te enviamos el enlace de pago y la descarga se activa al confirmar el pago.',
		'Pago con tarjeta, Apple Pay o Google Pay mediante Stripe; la factura se pide por correo y la descarga se activa al confirmar el pago.' => 'Para comprar, pulsa «Comprar»: se abre un correo con el producto ya escrito, te enviamos el enlace de pago y la descarga se activa al confirmar el pago.',
		'(«Comprar con tarjeta» en los packs; en los packs en oferta y las clases de 10 horas puedes además pedir la oferta por WhatsApp y te enviamos un enlace de pago de Stripe)' => '(«Comprar» abre un correo con el producto ya escrito y te enviamos el enlace de pago de Stripe; en los packs en oferta y las clases de 10 horas puedes además pedir la oferta por WhatsApp y te enviamos también un enlace de pago de Stripe)',
		'Pagas con tarjeta, Apple Pay o Google Pay en la página segura de Stripe.' => 'Nos escribes por correo con el botón «Comprar» y te enviamos el enlace de pago.',
		'Pagas el pack de horas con tarjeta, Apple Pay o Google Pay en la página segura de Stripe y recibes' => 'Nos escribes por correo, te enviamos el enlace de pago del pack de horas y recibes',
		'Stripe: tarjeta, Apple Pay, Google Pay' => 'Por correo: te enviamos el enlace de pago',
	);

	const IMAGENES = array(
		'OGC-TEMARIO'      => 'img_temario',
		'OGC-SUPUESTOS'    => 'img_supuestos',
		'OGC-PROGRAMACION' => 'img_programacion',
		'OGC-PACK'         => 'img_pack',
		'OGC-PACK-10H'     => 'img_pack_10h',
	);

	/**
	 * 2.1.3 · Botones que llegan YA resueltos a correo (para que una versión anterior del plugin, que no conoce su hueco,
	 * no deje la página en borrador) y marcados con data-ogc-hueco="ENLACE_STRIPE_…". Si hay Payment Link en Ajustes,
	 * la opción azul pasa a «Pago con tarjeta» / «Comprar con tarjeta» con el enlace de Stripe.
	 * Clave del marcador => array( ajuste, ancla de /tienda/ ).
	 */
	const MARCADOS = array(
		'ENLACE_STRIPE_PACK_PROGRAMACION' => array( 'stripe_pack_programacion', 'pack-programacion' ),
	);

	/** Notas internas opcionales: si no hay dato, se quitan (con el espacio anterior). */
	const OPCIONALES = '/ ?\[(?:CONFIRMAR:[^\]]*|AÑO Y EDITORIAL|AÑOS EN CADA EMPRESA|NOMBRE Y UNIVERSIDAD DE CADA MÁSTER|CENTRO O CENTROS Y MÓDULOS IMPARTIDOS POR CURSO, SI VICENTE QUIERE PUBLICARLOS)\]/u';

	/** @var array|null */
	private static $cache = null;

	public static function ajustes() {
		if ( null === self::$cache ) {
			$a           = get_option( self::OPCION, array() );
			self::$cache = array();
			foreach ( self::campos() as $k => $c ) {
				self::$cache[ $k ] = is_array( $a ) && isset( $a[ $k ] ) ? (string) $a[ $k ] : '';
			}
		}
		return self::$cache;
	}

	/**
	 * Valida un valor según su tipo. URL: solo https y sin comillas, espacios ni corchetes (se inserta tal cual
	 * en atributos HTML y en JSON-LD). NIF: letras, números y guion. Texto: sin etiquetas.
	 *
	 * @return string Valor limpio o '' si no es válido.
	 */
	public static function limpiar( $tipo, $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) {
			return '';
		}
		if ( 'url' === $tipo ) {
			return preg_match( '#^https://[^\s"\'<>\\\\\[\]{}`]+$#', $v ) && strlen( $v ) < 500 ? $v : '';
		}
		if ( 'nif' === $tipo ) {
			$v = strtoupper( str_replace( array( ' ', '.' ), '', $v ) );
			return preg_match( '/^[A-Z0-9-]{8,12}$/', $v ) ? $v : '';
		}
		$v = trim( wp_strip_all_tags( $v ) );
		return preg_match( '/^[^\[\]<>"]{1,120}$/u', $v ) ? $v : '';
	}

	/**
	 * Guarda los Ajustes. Devuelve los campos rechazados.
	 */
	public static function guardar( array $entrada ) {
		$out   = array();
		$malos = array();
		foreach ( self::campos() as $k => $c ) {
			$bruto     = isset( $entrada[ $k ] ) ? (string) $entrada[ $k ] : '';
			$out[ $k ] = self::limpiar( $c[1], $bruto );
			if ( '' !== trim( $bruto ) && '' === $out[ $k ] ) {
				$malos[] = $c[0];
			}
		}
		update_option( self::OPCION, $out, false );
		self::$cache = null;
		return $malos;
	}

	const CORREO = 'preparador@organizacionygestioncomercial.es';

	/** 2.1.2: sin Payment Link, «Comprar» abre un correo con el producto escrito (antes: WhatsApp). */
	public static function enlace_correo( $producto ) {
		return 'mailto:' . self::CORREO . '?subject=' . rawurlencode( 'Quiero comprar ' . $producto . ' de OGC' )
			. '&body=' . rawurlencode( "Hola:\n\nQuiero comprar " . $producto . " de OGC. Por favor, enviadme el enlace de pago.\n\nNombre y apellidos:\n" );
	}

	/** Texto del botón sin enlace de pago: «Comprar con tarjeta» → «Comprar» (el resto, igual). */
	private static function texto_compra( $t ) {
		$t = str_replace( array( ' con tarjeta', ' por WhatsApp' ), '', $t );
		return '' === trim( $t ) ? 'Comprar' : $t;
	}

	/**
	 * Rellena los huecos de un contenido.
	 *
	 * @param string     $html Contenido del manifiesto.
	 * @param array|null $aj   Ajustes (null = los guardados).
	 * @return array array( 'html' => …, 'pendientes' => huecos sin valor ni sustituto, 'notas' => qué se ha hecho )
	 */
	public static function resolver( $html, $aj = null ) {
		$aj         = null === $aj ? self::ajustes() : $aj;
		$notas      = array();
		$sin_stripe = false;

		// 1. Stripe.
		foreach ( self::STRIPE as $clave => $s ) {
			$h = '[ENLACE_STRIPE_' . $clave . ']';
			if ( false === strpos( $html, $h ) ) {
				continue;
			}
			$url = $aj[ $s[0] ] ?? '';
			if ( '' !== $url ) {
				$html    = str_replace( $h, $url, $html );
				$notas[] = 'Stripe ' . strtolower( $clave );
				continue;
			}
			$co = self::enlace_correo( $s[1] );
			$hq = preg_quote( $h, '/' );
			// Nota del pack «Tarjeta, Apple Pay o Google Pay (Stripe).» junto a su botón: se quita.
			$html = preg_replace( '/(<span class="ogc-precio-nota">[^<]*?IVA[^<.]*\.) Tarjeta, Apple Pay o Google Pay \(Stripe\)\.( [^<]*<\/span><a [^>]*href=")' . $hq . '/u', '$1$2' . $h, $html );
			$html = preg_replace( '/<p class="ogc-opcion-tit">Pago con tarjeta<\/p>(<span class="ogc-precio">[^<]*<\/span><span class="ogc-precio-nota">[^<]*<\/span><a [^>]*href=")' . $hq . '/u', '<p class="ogc-opcion-tit">Comprar</p>$1' . $h, $html );
			// Botones y enlaces: abren un correo con el producto escrito (nunca WhatsApp para comprar).
			$html = preg_replace_callback(
				'/(<a\b[^>]*\bhref=")' . $hq . '("[^>]*>)([^<]*)(<\/a>)/u',
				static function ( $m ) use ( $co ) {
					return $m[1] . esc_attr( $co ) . '" rel="nofollow' . $m[2] . self::texto_compra( $m[3] ) . $m[4];
				},
				$html
			);
			// JSON-LD (Offer.url): a la ficha del producto en la tienda.
			$html    = str_replace( '"url": "' . $h . '"', '"url": "' . self::url_sitio( '/tienda/#' . $s[2] ) . '"', $html );
			$notas[] = 'correo en lugar de Stripe (' . strtolower( $clave ) . ')';
			$sin_stripe = true;
		}
		// 1b. Botones marcados (2.1.3): correo por defecto; Stripe si hay enlace.
		foreach ( self::MARCADOS as $marca => $s ) {
			if ( false === strpos( $html, 'data-ogc-hueco="' . $marca . '"' ) ) {
				continue;
			}
			$url = $aj[ $s[0] ] ?? '';
			if ( '' === $url ) {
				$notas[] = 'correo en lugar de Stripe (' . strtolower( $marca ) . ')';
				continue;
			}
			$html    = preg_replace_callback(
				'/<div class="ogc-opcion ogc-opcion--tarjeta" data-ogc-hueco="' . preg_quote( $marca, '/' ) . '">(.*?)<\/div>/su',
				static function ( $m ) use ( $url ) {
					$c = str_replace( '<p class="ogc-opcion-tit">Comprar</p>', '<p class="ogc-opcion-tit">Pago con tarjeta</p>', $m[1] );
					$c = preg_replace( '/(<span class="ogc-precio-nota">[^<]*?IVA[^<.]*\.)( Desde)/u', '$1 Tarjeta, Apple Pay o Google Pay (Stripe).$2', $c, 1 );
					$c = preg_replace( '/<a class="ogc-btn ogc-btn--ancho" href="mailto:[^"]*" rel="nofollow">Comprar<\/a>/u', '<a class="ogc-btn ogc-btn--ancho" href="' . esc_attr( $url ) . '">Comprar con tarjeta</a>', $c );
					return '<div class="ogc-opcion ogc-opcion--tarjeta" data-ogc-hueco="stripe">' . $c . '</div>';
				},
				$html
			);
			$notas[] = 'Stripe ' . strtolower( $marca );
		}
		// Si algún botón de pago de la página va a WhatsApp, las frases que prometen pagar con tarjeta en Stripe
		// se cambian por otras que digan lo que pasa de verdad (se escribe por WhatsApp).
		if ( ! empty( $sin_stripe ) ) {
			$html = str_replace( array_keys( self::FRASES_SIN_STRIPE ), array_values( self::FRASES_SIN_STRIPE ), $html );
		}

		// 2. Foto de Vicente.
		if ( preg_match( '/\[(?:FOTO_VICENTE_\d+PX|URL_FOTO_VICENTE)\]/', $html ) ) {
			$foto = $aj['foto_vicente'] ?? '';
			if ( '' !== $foto ) {
				$html    = preg_replace( '/\[(?:FOTO_VICENTE_\d+PX|URL_FOTO_VICENTE)\]/', $foto, $html );
				$notas[] = 'foto';
			} else {
				// Ficha de autor: se quita la foto y la rejilla pasa a una sola columna.
				$html = preg_replace( '/(<aside class="ogc-autor"[^>]*)>\s*<img\b[^>]*\[FOTO_VICENTE_\d+PX\][^>]*>/u', '$1 style="grid-template-columns:minmax(0,1fr)">', $html );
				$html = preg_replace( '/[ \t]*<img\b[^>]*\[FOTO_VICENTE_\d+PX\][^>]*>[ \t]*\n?/u', '', $html );
				$html = preg_replace( '/\n[ \t]*"image": "\[URL_FOTO_VICENTE\]",/u', '', $html );
				$notas[] = 'sin foto';
			}
		}

		// 3. Imágenes de producto (solo JSON-LD de la tienda).
		foreach ( self::IMAGENES as $clave => $k ) {
			$h = '[URL_IMAGEN_' . $clave . ']';
			if ( false === strpos( $html, $h ) ) {
				continue;
			}
			$v    = $aj[ $k ] ?? '';
			$html = '' !== $v ? str_replace( $h, $v, $html ) : preg_replace( '/\n[ \t]*"image": "' . preg_quote( $h, '/' ) . '",/u', '', $html );
		}

		// 4. Datos legales y formulario.
		if ( false !== strpos( $html, '[NIF]' ) ) {
			$nif  = $aj['nif'] ?? '';
			$html = '' !== $nif ? str_replace( '[NIF]', esc_html( $nif ), $html ) : str_replace( ', [NIF]', '', $html );
		}
		if ( false !== strpos( $html, '[PROVEEDOR_HOSTING]' ) ) {
			$ph   = $aj['proveedor_hosting'] ?? '';
			$html = str_replace( '[PROVEEDOR_HOSTING]', '' !== $ph ? esc_html( $ph ) : 'El proveedor de alojamiento web', $html );
		}
		if ( false !== strpos( $html, '[URL_ACCION_FORMULARIO]' ) ) {
			if ( '' !== ( $aj['form_muestras'] ?? '' ) ) {
				$html = str_replace( '[URL_ACCION_FORMULARIO]', esc_attr( $aj['form_muestras'] ), $html );
			} else {
				// Sin la dirección de MailPoet la página se publica igual: el formulario se cambia por WhatsApp y correo
				// (nunca un botón «Pedir la muestra» que acabe en 404). Al pegar la dirección y sincronizar, vuelve el formulario.
				$html = preg_replace( '#<form\b[^>]*action="\[URL_ACCION_FORMULARIO\]"[^>]*>.*?</form>#s', self::bloque_muestras_sin_formulario(), $html, 1, $hechos );
				if ( $hechos ) {
					$html    = str_replace( '<h2 id="pedir">Formulario de registro</h2>', '<h2 id="pedir">Pide tus muestras</h2>', $html );
					// Los pasos del formulario (rellenar, confirmar el correo, recibir) no aplican: se resumen.
					$html    = preg_replace( '#<p>Para recibir las muestras hay que registrarse[^<]*</p>\s*<ol>.*?</ol>#s', '<p>Escríbenos por correo con tu email y tu teléfono y te enviamos las tres muestras.</p>', $html, 1 );
					$notas[] = 'muestras por WhatsApp y correo (falta el formulario)';
				}
			}
		}
		// El formulario ya lleva honeypot y doble confirmación: el hueco del captcha se quita.
		$html = preg_replace( '/[ \t]*<div class="ogc-campo">\[CAPTCHA_SIN_COOKIES_DE_TERCEROS\]<\/div>[ \t]*\n?/u', '', $html );

		// 5. Notas internas opcionales.
		$html = preg_replace( self::OPCIONALES, '', $html );

		return array(
			'html'       => $html,
			'pendientes' => self::pendientes( $html ),
			'notas'      => array_values( array_unique( $notas ) ),
		);
	}

	/**
	 * Bloque que sustituye al formulario de muestras si el plugin «OGC Ventas» no está activo (2.1.2: solo correo; las
	 * muestras no se piden por WhatsApp). También lo usa el shortcode [ogc_muestras_formulario] de reserva.
	 */
	public static function bloque_muestras_sin_formulario() {
		$co = self::CORREO;
		return '<div class="ogc-nota ogc-muestras-alternativa"><p>Pide tus muestras escribiéndonos a <a href="mailto:' . $co . '?subject=' . rawurlencode( 'Muestras de OGC' ) . '&amp;body=' . rawurlencode( "Hola:\n\nQuiero las tres muestras de OGC.\nEmail:\nTeléfono:\n" ) . '">preparador@<wbr>organizacionygestioncomercial.es</a> con tu email y tu teléfono. Te las enviamos en formato incompleto y con marca de agua.</p>'
			. '<p>Al escribirnos aceptas que usemos tu email y tu teléfono solo para enviarte las muestras, como explica la <a href="/privacidad/">política de privacidad</a> (titular: <a href="/aviso-legal/">aviso legal</a>).</p></div>';
	}

	/** Shortcode [ogc_muestras_formulario] de reserva: solo si «OGC Ventas» no lo ha registrado (2.1.2). */
	public static function registrar_shortcode_reserva() {
		if ( function_exists( 'shortcode_exists' ) && ! shortcode_exists( 'ogc_muestras_formulario' ) ) {
			add_shortcode( 'ogc_muestras_formulario', array( __CLASS__, 'bloque_muestras_sin_formulario' ) );
		}
	}

	/** Huecos que quedan (fuera de comentarios HTML). */
	public static function pendientes( $html ) {
		$sin = preg_replace( '/<!--.*?-->/s', '', (string) $html );
		preg_match_all( '/\[[A-ZÁÉÍÓÚÜÑ_][A-ZÁÉÍÓÚÜÑ0-9_ :\-,.()\/ºª]{2,}\]/u', (string) $sin, $m );
		return array_values( array_unique( $m[0] ) );
	}

	private static function url_sitio( $ruta ) {
		return function_exists( 'home_url' ) ? home_url( $ruta ) : 'https://organizacionygestioncomercial.es' . $ruta;
	}
}
