<?php
/**
 * Señales de entidad (2.1.5 · 16/11/2026, informe SEO semanal): completa la Organization que genera Yoast (#organization)
 * con los datos FIRMADOS del manifiesto («entidad»): alternateName, description, disambiguatingDescription, knowsAbout,
 * founder (Person de /vicente-ruiz/) y sameAs (solo perfiles propios y verificados de Preparador OGC).
 *
 *   - Nunca crea otra Organization ni cambia su @id, name, url, logo o email: solo AÑADE lo que falta y une las listas
 *     (alternateName, sameAs, knowsAbout) sin repetir. Si Yoast ya trae description o founder, se respetan.
 *   - Objetivo: desambiguar «OGC» (Organización y Gestión Comercial, FP) frente a otras entidades con la misma sigla
 *     (p. ej. una academia de la Guardia Civil) para buscadores y asistentes de IA.
 *   - Los datos son texto plano firmado: se validan (tipos, longitudes, https) y se imprimen dentro del JSON-LD de Yoast,
 *     que los codifica. Sin manifiesto o sin «entidad», no hace nada.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Entidad {

	const MAX_TEXTO = 400;
	const MAX_LISTA = 12;

	/**
	 * «entidad»: null u objeto {datos, hash} con hash = sha256 del JSON de datos (lo comprueba la firma del manifiesto;
	 * aquí solo se validan forma y contenido).
	 *
	 * @return true|string
	 */
	public static function validar( array $m ) {
		if ( ! isset( $m['entidad'] ) || null === $m['entidad'] ) {
			return true;
		}
		$e = $m['entidad'];
		if ( ! is_array( $e ) || ! isset( $e['datos'] ) || ! is_array( $e['datos'] ) ) {
			return 'entidad: no válida';
		}
		$d = $e['datos'];
		foreach ( array( 'description', 'disambiguatingDescription' ) as $k ) {
			if ( isset( $d[ $k ] ) && ( ! is_string( $d[ $k ] ) || ! self::texto_ok( $d[ $k ] ) ) ) {
				return 'entidad: ' . $k . ' no válido';
			}
		}
		foreach ( array( 'alternateName', 'knowsAbout' ) as $k ) {
			if ( isset( $d[ $k ] ) && ! self::lista_ok( $d[ $k ], false ) ) {
				return 'entidad: ' . $k . ' no válido';
			}
		}
		if ( isset( $d['sameAs'] ) && ! self::lista_ok( $d['sameAs'], true ) ) {
			return 'entidad: sameAs no válido (solo direcciones https://)';
		}
		if ( isset( $d['founder'] ) ) {
			$f = $d['founder'];
			if ( ! is_array( $f ) || ! isset( $f['name'], $f['url'] ) || ! is_string( $f['name'] ) || ! self::texto_ok( $f['name'] ) || ! self::url_ok( $f['url'] ) ) {
				return 'entidad: founder no válido';
			}
		}
		return true;
	}

	private static function texto_ok( $t ) {
		return '' !== trim( $t ) && strlen( $t ) <= self::MAX_TEXTO && false === strpos( $t, '<' ) && false === strpos( $t, "\0" );
	}

	private static function url_ok( $u ) {
		return is_string( $u ) && strlen( $u ) <= 300 && (bool) preg_match( '#^https://[a-z0-9.-]+\.[a-z]{2,}(/[A-Za-z0-9._~%/@-]*)?$#', $u );
	}

	private static function lista_ok( $l, $urls ) {
		if ( ! is_array( $l ) || count( $l ) > self::MAX_LISTA || array_values( $l ) !== $l ) {
			return false;
		}
		foreach ( $l as $v ) {
			if ( $urls ? ! self::url_ok( $v ) : ( ! is_string( $v ) || ! self::texto_ok( $v ) ) ) {
				return false;
			}
		}
		return true;
	}

	/** Datos en uso (de la caché de textos SEO, que se rehace sola al cambiar el paquete o la versión). */
	public static function datos() {
		$t = OGC_Paginas_Seo::textos();
		return ( isset( $t['entidad'] ) && is_array( $t['entidad'] ) ) ? $t['entidad'] : array();
	}

	/**
	 * Filtro wpseo_schema_organization: añade los datos firmados a la Organization de Yoast.
	 *
	 * @param mixed $data Pieza Organization de Yoast.
	 * @return mixed
	 */
	public static function organizacion( $data ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}
		$d = self::datos();
		if ( ! $d ) {
			return $data;
		}
		foreach ( array( 'alternateName', 'sameAs', 'knowsAbout' ) as $k ) {
			if ( empty( $d[ $k ] ) ) {
				continue;
			}
			$ya         = isset( $data[ $k ] ) ? ( is_array( $data[ $k ] ) ? $data[ $k ] : array( $data[ $k ] ) ) : array();
			$data[ $k ] = array_values( array_unique( array_merge( $ya, $d[ $k ] ) ) );
		}
		foreach ( array( 'description', 'disambiguatingDescription' ) as $k ) {
			if ( ! empty( $d[ $k ] ) && empty( $data[ $k ] ) ) {
				$data[ $k ] = $d[ $k ];
			}
		}
		if ( ! empty( $d['founder'] ) && empty( $data['founder'] ) ) {
			$f               = $d['founder'];
			$data['founder'] = array(
				'@type' => 'Person',
				'@id'   => $f['url'] . '#person',
				'name'  => $f['name'],
				'url'   => $f['url'],
			);
		}
		return $data;
	}
}
