<?php
/**
 * Plugin Name:       OGC Páginas · crear y actualizar las páginas nuevas
 * Description:       Crea o actualiza con un clic las páginas nuevas (con los enlaces de Stripe, la foto y los datos de sus Ajustes; sin Stripe, los botones van a WhatsApp) de Preparador OGC (guías, comunidades, bloques, temas, tienda…) a partir del manifiesto que lleva dentro: contenido en un bloque «HTML personalizado», página superior, campos de Yoast y ajustes de Neve. Se actualiza sola con paquetes firmados (Ed25519) publicados en GitHub. De las 5 páginas que posicionan solo actualiza, con su propio botón, el título SEO, la meta y la frase clave de Yoast (con copia para restaurar); su contenido solo se muestra con el shortcode [ogc_pagina] si Vicente lo pone. Desde 2.1.0 crea y programa también las entradas del blog del paquete firmado (nunca toca entradas que no creó él, salvo adoptar las del WXR original) y se actualiza a sí mismo como un plugin normal (paquete firmado). No toca páginas que no haya creado él. Herramientas → OGC Páginas.
 * Version:           2.1.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Preparador OGC
 * Update URI:        https://raw.githubusercontent.com/preparadorpga/web-ogc/main/sync/plugin.json
 * License:           GPL-2.0-or-later
 * Text Domain:       ogc-paginas
 *
 * Cómo funciona:
 *   datos/manifiesto.json lo genera web/wp_generadores/tecnico/empaquetar_paginas.py a partir de
 *   wp_entrega/paginas/ y de yoast_campos.xlsx. Cada versión nueva del plugin trae el manifiesto nuevo:
 *   se sube el zip («Reemplazar el actual») y se pulsa «Sincronizar».
 *
 * Imágenes (12/11/2026): las maquetas de producto viajan en img/ y «Sincronizar» las copia a wp-content/uploads/ogc/
 *   (solo las del manifiesto, con sha256, tamaño y tipo comprobados; ver includes/class-ogc-paginas-imagenes.php).
 *
 * Actualización automática (2.0.0): cada hora (WP-Cron) o con «Comprobar ahora» descarga manifiesto.json y
 *   manifiesto.sig de la «URL del paquete» (por defecto el repositorio público preparadorpga/web-ogc en GitHub), verifica
 *   la firma Ed25519 con la clave pública incrustada en includes/class-ogc-paginas-sync.php, exige una serie mayor que la
 *   aplicada (anti-reversión) y aplica la sincronización igual que el botón. Lo publica
 *   web/wp_generadores/tecnico/publicar_sync.py. Shortcode [ogc_pagina id="portada|my-services|about|practica-ogc|contacto"].
 *
 * Blog (2.1.0): «entradas» del manifiesto → entradas programadas/publicadas (includes/class-ogc-paginas-blog.php), pestaña
 *   Blog con la comprobación de la dirección /blog/ y el botón para cambiarla con 301 (class-ogc-paginas-blog-direccion.php).
 * Autoactualización del plugin (2.1.0): sync/plugin.json + .sig firmados con la misma clave y zip con sha256 firmado
 *   (includes/class-ogc-paginas-autoactualizar.php); llega como una actualización normal de WordPress.
 *
 * Seguridad:
 *   - Única llamada externa: la descarga del paquete firmado (solo desde la URL base, https, sin redirecciones, con
 *     tiempo y tamaño máximos). Sin firma válida no se aplica nada. El JSON solo se lee como datos (nunca se ejecuta nada de él).
 *   - Solo administradores (manage_options + unfiltered_html) y siempre con nonce.
 *   - Las páginas protegidas están escritas aquí, no en el JSON: un manifiesto erróneo no puede tocarlas.
 */

defined( 'ABSPATH' ) || exit;

define( 'OGC_PAGINAS_VERSION', '2.1.0' );
define( 'OGC_PAGINAS_DIR', __DIR__ );
define( 'OGC_PAGINAS_FILE', __FILE__ );

require_once __DIR__ . '/includes/class-ogc-paginas-manifiesto.php';
require_once __DIR__ . '/includes/class-ogc-paginas-huecos.php';
require_once __DIR__ . '/includes/class-ogc-paginas-sincronizador.php';
require_once __DIR__ . '/includes/class-ogc-paginas-posicionan.php';
require_once __DIR__ . '/includes/class-ogc-paginas-admin.php';
require_once __DIR__ . '/includes/class-ogc-paginas-imagenes.php';
require_once __DIR__ . '/includes/class-ogc-paginas-sync.php';
require_once __DIR__ . '/includes/class-ogc-paginas-sync-admin.php';
require_once __DIR__ . '/includes/class-ogc-paginas-shortcode.php';
require_once __DIR__ . '/includes/class-ogc-paginas-blog.php';
require_once __DIR__ . '/includes/class-ogc-paginas-blog-direccion.php';
require_once __DIR__ . '/includes/class-ogc-paginas-blog-admin.php';
require_once __DIR__ . '/includes/class-ogc-paginas-autoactualizar.php';
require_once __DIR__ . '/includes/class-ogc-paginas-seo.php';

add_action( 'admin_menu', array( 'OGC_Paginas_Admin', 'menu' ) );
add_action( 'admin_post_ogc_paginas_sincronizar', array( 'OGC_Paginas_Imagenes', 'al_sincronizar' ), 5 ); // Imágenes de img/ → uploads/ogc/ antes de sincronizar.
add_action( 'admin_post_ogc_paginas_sincronizar', array( 'OGC_Paginas_Admin', 'sincronizar' ) );
add_action( 'admin_post_ogc_paginas_adoptar', array( 'OGC_Paginas_Admin', 'adoptar' ) );
add_action( 'admin_post_ogc_paginas_yoast', array( 'OGC_Paginas_Admin', 'yoast' ) );
add_action( 'admin_post_ogc_paginas_ajustes', array( 'OGC_Paginas_Admin', 'guardar_ajustes' ) );
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( 'OGC_Paginas_Admin', 'enlace_ajustes' ) );

// 2.0.0 · Actualización automática firmada (Ed25519) y shortcode [ogc_pagina id="portada"].
add_action( 'init', array( 'OGC_Paginas_Shortcode', 'registrar' ) );
add_action( 'init', array( 'OGC_Paginas_Sync', 'programar' ) ); // Reprograma tras «Reemplazar el actual» (no ejecuta la activación).
add_action( OGC_Paginas_Sync::CRON, array( 'OGC_Paginas_Sync', 'cron' ) );
add_action( 'admin_notices', array( 'OGC_Paginas_Sync', 'aviso' ) );
add_action( 'admin_post_ogc_paginas_sync_ajustes', array( 'OGC_Paginas_Sync_Admin', 'guardar_ajustes' ) );
add_action( 'admin_post_ogc_paginas_sync_comprobar', array( 'OGC_Paginas_Sync_Admin', 'comprobar' ) );
add_action( 'admin_post_ogc_paginas_sync_volver', array( 'OGC_Paginas_Sync_Admin', 'volver' ) );
add_action( 'admin_post_ogc_paginas_sync_clave', array( 'OGC_Paginas_Sync_Admin', 'clave' ) );
register_activation_hook( __FILE__, array( 'OGC_Paginas_Sync', 'programar' ) );
register_deactivation_hook( __FILE__, array( 'OGC_Paginas_Sync', 'desprogramar' ) );

// 2.1.0 · Entradas del blog, dirección /blog/ (301 opcional) y actualización del propio plugin.
add_action( 'admin_post_ogc_paginas_blog_sincronizar', array( 'OGC_Paginas_Blog_Admin', 'sincronizar' ) );
add_action( 'admin_post_ogc_paginas_blog_direccion', array( 'OGC_Paginas_Blog_Admin', 'direccion' ) );
add_action( 'admin_post_ogc_paginas_auto_buscar', array( 'OGC_Paginas_Blog_Admin', 'buscar' ) );
add_action( 'before_delete_post', array( 'OGC_Paginas_Blog', 'al_borrar' ) );
add_action( 'template_redirect', array( 'OGC_Paginas_Blog_Direccion', 'redirigir' ), 1 );
add_filter( 'pre_set_site_transient_update_plugins', array( 'OGC_Paginas_Autoactualizar', 'filtro_transient' ) );
add_filter( 'upgrader_pre_download', array( 'OGC_Paginas_Autoactualizar', 'filtro_descarga' ), 10, 4 );
add_filter( 'plugins_api', array( 'OGC_Paginas_Autoactualizar', 'filtro_api' ), 10, 3 );

// 2.1.0 · Indexación: robots.txt virtual, /llms.txt, IndexNow y avisos (Yoast sitemaps, visibilidad).
add_filter( 'robots_txt', array( 'OGC_Paginas_Seo', 'robots' ), 99, 2 );
add_action( 'template_redirect', array( 'OGC_Paginas_Seo', 'servir' ), 0 );
add_action( 'transition_post_status', array( 'OGC_Paginas_Seo', 'al_cambiar_estado' ), 10, 3 );
add_action( 'shutdown', array( 'OGC_Paginas_Seo', 'enviar' ) );
add_action( 'admin_notices', array( 'OGC_Paginas_Seo', 'aviso' ) );
