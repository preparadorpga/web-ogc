=== OGC Páginas · crear y actualizar las páginas nuevas ===
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 2.1.0
License: GPL-2.0-or-later

Plugin privado de Preparador OGC. Lleva dentro (datos/manifiesto.json) todas las páginas nuevas de la web
con su contenido, página superior y campos de Yoast. Herramientas → OGC Páginas → Simular → Sincronizar.

- Nunca crea, edita ni borra la portada, /my-services/, /about/, /practica-ogc/, /contacto/, la página de entradas ni
  páginas que no haya creado él (las avisa; «Adoptar» es una acción explícita, página a página).
- Solo quedan en borrador las páginas con un hueco sin dato ni sustituto; el resto se publica.
- Solo reescribe las que cambian, y antes guarda una revisión para poder volver atrás.
- Neve: contenedor y barra lateral «full-width» e imagen destacada desactivada. Plantilla por defecto.
- Las 5 que posicionan: solo título SEO, meta y frase clave de Yoast, con su propio botón y «Restaurar Yoast anterior».
- Ajustes: enlaces de Stripe, foto, NIF, proveedor y formulario. Sin Stripe, los botones van a WhatsApp con mensaje; sin foto, se quita.
- 2.0.0 · Actualización automática FIRMADA: cada hora (y con «Comprobar ahora») descarga el paquete de
  https://raw.githubusercontent.com/preparadorpga/web-ogc/main/sync/, verifica la firma Ed25519 con la clave pública
  incrustada, exige una serie más nueva (anti-reversión) y sincroniza igual que el botón. Si algo falla, no cambia nada
  y avisa en el escritorio. Interruptor activada/desactivada, token de GitHub opcional y «Volver a la versión anterior».
- 2.0.0 · Shortcode [ogc_pagina id="portada"] (y my-services, about, practica-ogc, contacto): muestra el HTML firmado
  de esa página. Se pone una vez en Elementor (widget «Shortcode») y la página se actualiza sola.
- Única llamada externa: la descarga del paquete firmado. Al borrarlo no se borra ninguna página.

- 2.1.0 · BLOG: crea y programa las entradas del paquete firmado (programadas si la fecha es futura, publicadas si ya pasó),
  con categoría, etiquetas, extracto, Yoast e imagen destacada opcional. Nunca toca entradas ajenas; adopta solo las
  importadas con el WXR original (hash o título + fecha). El WXR ya no hace falta. Pestaña «Blog y SEO».
- 2.1.0 · Dirección /blog/: avisa si la página de entradas o los enlaces permanentes no son /blog/; botón (con
  confirmación) que cambia el slug a «blog» y crea una 301 interna desde la dirección antigua.
- 2.1.0 · Indexación: robots.txt virtual (bots de IA, Sitemap), /llms.txt, IndexNow y avisos (Yoast sitemaps, visibilidad).
- 2.1.0 · El propio plugin se actualiza como un plugin normal (sync/plugin.json firmado + zip con sha256 firmado). Para que
  se instale solo: Plugins > OGC Páginas > «Activar actualizaciones automáticas».

Instrucciones: LEEME_OGC_PAGINAS.md (carpeta OGC\web\wordpress\plugins).
Generador: web/wp_generadores/tecnico/empaquetar_paginas.py (--subir para una versión nueva).
