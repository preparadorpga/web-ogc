<?php
/**
 * Huecos «[…]» de las plantillas: se rellenan AL SINCRONIZAR con los Ajustes del plugin o, si el ajuste está
 * vacío, con un sustituto limpio (WhatsApp en lugar de Stripe, sin foto, sin NIF…). Solo los huecos que no tienen
 * ni valor ni sustituto dejan la página en borrador. El visitante nunca ve un «[».
 */

defined( 'ABSPATH' ) || exit;

class OGC_Paginas_Huecos {

	const OPCION   = 'ogc_paginas_ajustes';
	const WHATSAPP = '34678872362';

	/**
	 * Campos de Ajustes: clave => array( etiqueta, tipo, grupo ).
	 */
	public static function campos() {
		return array(
			'stripe_temario'      => array( 'Temario (362,50 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_supuestos'    => array( 'Supuestos (237,50 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_programacion' => array( 'Programación (186,25 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_pack'         => array( 'Pack completo (623,75 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_pack_10h'     => array( 'Pack completo + 10 h (1.248,75 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_clases_3h'    => array( 'Clases 3 h (225 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_clases_5h'    => array( 'Clases 5 h (350 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'stripe_clases_10h'   => array( 'Clases 10 h (625 €)', 'url', 'Enlaces de pago de Stripe (Payment Links)' ),
			'foto_vicente'        => array( 'URL de la foto de Vicente (cuadrada, 288 px o más)', 'url', 'Foto' ),
			'nif'                 => array( 'NIF del titular', 'nif', 'Datos legales' ),
			'proveedor_hosting'   => array( 'Proveedor de alojamiento (nombre de la empresa)', 'texto', 'Datos legales' ),
			'form_muestras'       => array( 'Dirección de envío del formulario de muestras (action)', 'url', 'Formulario de muestras' ),
			'img_temario'         => array( 'Imagen del temario', 'url', 'Imágenes de producto (datos estructurados de la tienda; opcionales)' ),
			'img_supuestos'       => array( 'Imagen de los supuestos', 'url', 'Imágenes de producto (datos estructurados de la tienda; opcionales)' ),
			'img_programacion'    => array( 'Imagen de la programación', 'url', 'Imágenes de producto (datos estructurados de la tienda; opcionales)' ),
			'img_pack'            => array( 'Imagen del pack', 'url', 'Imágenes de producto (datos estructurados de la tienda; opcionales)' ),
			'img_pack_10h'        => array( 'Imagen del pack + 10 h', 'url', 'Imágenes de producto (datos estructurados de la tienda; opcionales)' ),
		);
	}

	/** Stripe: clave del hueco => array( ajuste, producto para el WhatsApp, ancla de /tienda/ ). */
	const STRIPE = array(
		'TEMARIO'      => array( 'stripe_temario', 'el temario completo', 'temario' ),
		'SUPUESTOS'    => array( 'stripe_supuestos', 'el dossier de supuestos prácticos', 'supuestos' ),
		'PROGRAMACION' => array( 'stripe_programacion', 'la programación didáctica', 'programacion' ),
		'PACK'         => array( 'stripe_pack', 'el pack completo (temario, supuestos y programación)', 'pack' ),
		'PACK_10H'     => array( 'stripe_pack_10h', 'el pack completo + 10 h de clases', 'pack-10h' ),
		'CLASES_3H'    => array( 'stripe_clases_3h', 'el pack de 3 h de clases online', 'clases' ),
		'CLASES_5H'    => array( 'stripe_clases_5h', 'el pack de 5 h de clases online', 'clases' ),
		'CLASES_10H'   => array( 'stripe_clases_10h', 'el pack de 10 h de clases online', 'clases' ),
	);

	/** Frases de proceso de pago que, sin enlace de Stripe, no deben prometer tarjeta. */
	const FRASES_SIN_STRIPE = array(
		'Pago con tarjeta, Apple Pay o Google Pay mediante Stripe; la factura llega al correo de compra y la descarga se activa al confirmar el pago.' => 'Para comprar, pulsa el botón y escríbenos por WhatsApp: te indicamos cómo pagar, la factura llega al correo de compra y la descarga se activa al confirmar el pago.',
		'(«Comprar con tarjeta» en los packs; si prefieres otra opción de pago, el botón amarillo abre WhatsApp y te respondemos)' => '(el botón abre WhatsApp con el mensaje ya escrito y te respondemos con las opciones de pago)',
		'Pagas con tarjeta, Apple Pay o Google Pay en la página segura de Stripe.' => 'Nos escribes por WhatsApp y te indicamos cómo pagar.',
		'Pagas el pack de horas con tarjeta, Apple Pay o Google Pay en la página segura de Stripe y recibes' => 'Nos escribes por WhatsApp, te indicamos cómo pagar el pack de horas y recibes',
		'Stripe: tarjeta, Apple Pay, Google Pay' => 'Por WhatsApp: te indicamos las opciones de pago',
	);

	const IMAGENES = array(
		'OGC-TEMARIO'      => 'img_temario',
		'OGC-SUPUESTOS'    => 'img_supuestos',
		'OGC-PROGRAMACION' => 'img_programacion',
		'OGC-PACK'         => 'img_pack',
		'OGC-PACK-10H'     => 'img_pack_10h',
	);

	/** Notas internas opcionales: si no hay dato, se quitan (con el espacio anterior). */
	const OPCIONALES = '/ ?\[(?:CONFIRMAR:[^\]]*|AÑO Y EDITORIAL|AÑOS EN CADA EMPRESA|NOMBRE Y UNIVERSIDAD DE CADA MÁSTER|CENTRO O CENTROS Y MÓDULOS IMPARTIDOS POR CURSO, SI VICENTE QUIERE PUBLICARLOS)\]/u';

	/** @var array|null */
	private static $cache = null;

	public static function ajustes() {
		if ( null === self::$cache ) {
			$a           = get_option( self::OPCION, array() );
			self::$cache = array();
			foreach ( self::campos() as $k => $c ) {
				self::$cache[ $k ] = is_array( $a ) && isset( $a[ $k ] ) ? (string) $a[ $k ] : '';
			}
		}
		return self::$cache;
	}

	/**
	 * Valida un valor según su tipo. URL: solo https y sin comillas, espacios ni corchetes (se inserta tal cual
	 * en atributos HTML y en JSON-LD). NIF: letras, números y guion. Texto: sin etiquetas.
	 *
	 * @return string Valor limpio o '' si no es válido.
	 */
	public static function limpiar( $tipo, $v ) {
		$v = trim( (string) $v );
		if ( '' === $v ) {
			return '';
		}
		if ( 'url' === $tipo ) {
			return preg_match( '#^https://[^\s"\'<>\\\\\[\]{}`]+$#', $v ) && strlen( $v ) < 500 ? $v : '';
		}
		if ( 'nif' === $tipo ) {
			$v = strtoupper( str_replace( array( ' ', '.' ), '', $v ) );
			return preg_match( '/^[A-Z0-9-]{8,12}$/', $v ) ? $v : '';
		}
		$v = trim( wp_strip_all_tags( $v ) );
		return preg_match( '/^[^\[\]<>"]{1,120}$/u', $v ) ? $v : '';
	}

	/**
	 * Guarda los Ajustes. Devuelve los campos rechazados.
	 */
	public static function guardar( array $entrada ) {
		$out   = array();
		$malos = array();
		foreach ( self::campos() as $k => $c ) {
			$bruto     = isset( $entrada[ $k ] ) ? (string) $entrada[ $k ] : '';
			$out[ $k ] = self::limpiar( $c[1], $bruto );
			if ( '' !== trim( $bruto ) && '' === $out[ $k ] ) {
				$malos[] = $c[0];
			}
		}
		update_option( self::OPCION, $out, false );
		self::$cache = null;
		return $malos;
	}

	public static function enlace_whatsapp( $producto ) {
		return 'https://wa.me/' . self::WHATSAPP . '?text=' . rawurlencode( 'Hola, me interesa ' . $producto . ' de OGC. ¿Cómo puedo comprarlo?' );
	}

	private static function texto_whatsapp( $t ) {
		if ( false !== strpos( $t, 'con tarjeta' ) ) {
			return str_replace( 'con tarjeta', 'por WhatsApp', $t );
		}
		if ( false !== strpos( $t, 'WhatsApp' ) ) {
			return $t;
		}
		$p = strpos( $t, ' · ' );
		return false === $p ? $t . ' por WhatsApp' : substr( $t, 0, $p ) . ' por WhatsApp' . substr( $t, $p );
	}

	/**
	 * Rellena los huecos de un contenido.
	 *
	 * @param string     $html Contenido del manifiesto.
	 * @param array|null $aj   Ajustes (null = los guardados).
	 * @return array array( 'html' => …, 'pendientes' => huecos sin valor ni sustituto, 'notas' => qué se ha hecho )
	 */
	public static function resolver( $html, $aj = null ) {
		$aj         = null === $aj ? self::ajustes() : $aj;
		$notas      = array();
		$sin_stripe = false;

		// 1. Stripe.
		foreach ( self::STRIPE as $clave => $s ) {
			$h = '[ENLACE_STRIPE_' . $clave . ']';
			if ( false === strpos( $html, $h ) ) {
				continue;
			}
			$url = $aj[ $s[0] ] ?? '';
			if ( '' !== $url ) {
				$html    = str_replace( $h, $url, $html );
				$notas[] = 'Stripe ' . strtolower( $clave );
				continue;
			}
			$wa = self::enlace_whatsapp( $s[1] );
			$hq = preg_quote( $h, '/' );
			// Nota del pack «Tarjeta, Apple Pay o Google Pay (Stripe).» junto a su botón: se quita.
			$html = preg_replace( '/(<span class="ogc-precio-nota">[^<]*?IVA[^<.]*\.) Tarjeta, Apple Pay o Google Pay \(Stripe\)\.( [^<]*<\/span><a [^>]*href=")' . $hq . '/u', '$1$2' . $h, $html );
			$html = preg_replace( '/<p class="ogc-opcion-tit">Pago con tarjeta<\/p>(<span class="ogc-precio">[^<]*<\/span><span class="ogc-precio-nota">[^<]*<\/span><a [^>]*href=")' . $hq . '/u', '<p class="ogc-opcion-tit">Compra por WhatsApp</p>$1' . $h, $html );
			// Botones y enlaces: van a WhatsApp con el mensaje escrito y el texto lo dice.
			$html = preg_replace_callback(
				'/(<a\b[^>]*\bhref=")' . $hq . '("[^>]*>)([^<]*)(<\/a>)/u',
				static function ( $m ) use ( $wa ) {
					return $m[1] . esc_attr( $wa ) . $m[2] . self::texto_whatsapp( $m[3] ) . $m[4];
				},
				$html
			);
			// JSON-LD (Offer.url): a la ficha del producto en la tienda.
			$html    = str_replace( '"url": "' . $h . '"', '"url": "' . self::url_sitio( '/tienda/#' . $s[2] ) . '"', $html );
			$notas[] = 'WhatsApp en lugar de Stripe (' . strtolower( $clave ) . ')';
			$sin_stripe = true;
		}
		// Si algún botón de pago de la página va a WhatsApp, las frases que prometen pagar con tarjeta en Stripe
		// se cambian por otras que digan lo que pasa de verdad (se escribe por WhatsApp).
		if ( ! empty( $sin_stripe ) ) {
			$html = str_replace( array_keys( self::FRASES_SIN_STRIPE ), array_values( self::FRASES_SIN_STRIPE ), $html );
		}

		// 2. Foto de Vicente.
		if ( preg_match( '/\[(?:FOTO_VICENTE_\d+PX|URL_FOTO_VICENTE)\]/', $html ) ) {
			$foto = $aj['foto_vicente'] ?? '';
			if ( '' !== $foto ) {
				$html    = preg_replace( '/\[(?:FOTO_VICENTE_\d+PX|URL_FOTO_VICENTE)\]/', $foto, $html );
				$notas[] = 'foto';
			} else {
				// Ficha de autor: se quita la foto y la rejilla pasa a una sola columna.
				$html = preg_replace( '/(<aside class="ogc-autor"[^>]*)>\s*<img\b[^>]*\[FOTO_VICENTE_\d+PX\][^>]*>/u', '$1 style="grid-template-columns:minmax(0,1fr)">', $html );
				$html = preg_replace( '/[ \t]*<img\b[^>]*\[FOTO_VICENTE_\d+PX\][^>]*>[ \t]*\n?/u', '', $html );
				$html = preg_replace( '/\n[ \t]*"image": "\[URL_FOTO_VICENTE\]",/u', '', $html );
				$notas[] = 'sin foto';
			}
		}

		// 3. Imágenes de producto (solo JSON-LD de la tienda).
		foreach ( self::IMAGENES as $clave => $k ) {
			$h = '[URL_IMAGEN_' . $clave . ']';
			if ( false === strpos( $html, $h ) ) {
				continue;
			}
			$v    = $aj[ $k ] ?? '';
			$html = '' !== $v ? str_replace( $h, $v, $html ) : preg_replace( '/\n[ \t]*"image": "' . preg_quote( $h, '/' ) . '",/u', '', $html );
		}

		// 4. Datos legales y formulario.
		if ( false !== strpos( $html, '[NIF]' ) ) {
			$nif  = $aj['nif'] ?? '';
			$html = '' !== $nif ? str_replace( '[NIF]', esc_html( $nif ), $html ) : str_replace( ', [NIF]', '', $html );
		}
		if ( false !== strpos( $html, '[PROVEEDOR_HOSTING]' ) ) {
			$ph   = $aj['proveedor_hosting'] ?? '';
			$html = str_replace( '[PROVEEDOR_HOSTING]', '' !== $ph ? esc_html( $ph ) : 'El proveedor de alojamiento web', $html );
		}
		if ( false !== strpos( $html, '[URL_ACCION_FORMULARIO]' ) ) {
			if ( '' !== ( $aj['form_muestras'] ?? '' ) ) {
				$html = str_replace( '[URL_ACCION_FORMULARIO]', esc_attr( $aj['form_muestras'] ), $html );
			} else {
				// Sin la dirección de MailPoet la página se publica igual: el formulario se cambia por WhatsApp y correo
				// (nunca un botón «Pedir la muestra» que acabe en 404). Al pegar la dirección y sincronizar, vuelve el formulario.
				$html = preg_replace( '#<form\b[^>]*action="\[URL_ACCION_FORMULARIO\]"[^>]*>.*?</form>#s', self::bloque_muestras_sin_formulario(), $html, 1, $hechos );
				if ( $hechos ) {
					$html    = str_replace( '<h2 id="pedir">Formulario de registro</h2>', '<h2 id="pedir">Pide tus muestras</h2>', $html );
					// Los pasos del formulario (rellenar, confirmar el correo, recibir) no aplican: se resumen.
					$html    = preg_replace( '#<p>Para recibir las muestras hay que registrarse[^<]*</p>\s*<ol>.*?</ol>#s', '<p>Escríbenos por WhatsApp o por correo con tu nombre y tu dirección de correo y te enviamos las tres muestras a ese correo.</p>', $html, 1 );
					$notas[] = 'muestras por WhatsApp y correo (falta el formulario)';
				}
			}
		}
		// El formulario ya lleva honeypot y doble confirmación: el hueco del captcha se quita.
		$html = preg_replace( '/[ \t]*<div class="ogc-campo">\[CAPTCHA_SIN_COOKIES_DE_TERCEROS\]<\/div>[ \t]*\n?/u', '', $html );

		// 5. Notas internas opcionales.
		$html = preg_replace( self::OPCIONALES, '', $html );

		return array(
			'html'       => $html,
			'pendientes' => self::pendientes( $html ),
			'notas'      => array_values( array_unique( $notas ) ),
		);
	}

	/** Bloque que sustituye al formulario de muestras mientras no haya dirección de MailPoet en Ajustes. */
	public static function bloque_muestras_sin_formulario() {
		$wa = 'https://wa.me/' . self::WHATSAPP . '?text=' . rawurlencode( 'Hola, quiero las muestras de OGC (tema, práctica y programación). Mi nombre y correo son: ' );
		$co = 'preparador@organizacionygestioncomercial.es';
		return '<div class="ogc-nota ogc-muestras-alternativa"><p>Pide tus muestras escribiéndonos por WhatsApp o a <a href="mailto:' . $co . '?subject=' . rawurlencode( 'Muestras de OGC' ) . '">preparador@<wbr>organizacionygestioncomercial.es</a> indicando tu nombre y correo. Te las enviamos en formato incompleto y con marca de agua.</p>'
			. '<p>Al escribirnos aceptas que usemos tu nombre y tu correo solo para enviarte las muestras, como explica la <a href="/privacidad/">política de privacidad</a> (titular: <a href="/aviso-legal/">aviso legal</a>).</p>'
			. '<p><a class="ogc-btn" href="' . esc_attr( $wa ) . '" rel="nofollow">Pedir las muestras por WhatsApp</a></p></div>';
	}

	/** Huecos que quedan (fuera de comentarios HTML). */
	public static function pendientes( $html ) {
		$sin = preg_replace( '/<!--.*?-->/s', '', (string) $html );
		preg_match_all( '/\[[A-ZÁÉÍÓÚÜÑ_][A-ZÁÉÍÓÚÜÑ0-9_ :\-,.()\/ºª]{2,}\]/u', (string) $sin, $m );
		return array_values( array_unique( $m[0] ) );
	}

	private static function url_sitio( $ruta ) {
		return function_exists( 'home_url' ) ? home_url( $ruta ) : 'https://organizacionygestioncomercial.es' . $ruta;
	}
}
