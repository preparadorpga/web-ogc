<?php
/**
 * Sellado por comprador (1.1.0): usa las plantillas del paquete de materiales y OGC_Sello (PHP puro, milisegundos
 * por documento). Mismo resultado visible que ventas/sellado.py: logo en marca de agua suave, «PROHIBIDA SU VENTA» y
 * nombre y pedido en diagonal; línea de licencia legible en cada página; metadatos; cifrado AES-256 sin contraseña de
 * apertura, con impresión permitida y sin edición ni copia. Conserva los marcadores.
 *
 * Caché en la carpeta privada: sellados/<hash del pedido>/<hash del documento>.pdf. El nombre incluye el sha256 de la
 * plantilla: si el documento se actualiza, se vuelve a sellar solo.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Sellador {

	public static function licencia( array $p ) {
		return sprintf(
			'Licencia de uso personal de %s · %s · n.º de pedido %s · %s. Prohibida su venta, reproducción o difusión (RDL 1/1996, Ley de Propiedad Intelectual)',
			$p['nombre'],
			$p['email'],
			$p['pedido'],
			OGC_Pedidos::fecha( $p )
		);
	}

	public static function carpeta_pedido( array $p ) {
		$s = OGC_Config::sub( 'sellados' );
		return $s . '/' . substr( hash_hmac( 'sha256', 'pedido|' . $p['id'] . '|' . $p['version_enlace'], OGC_Config::clave_firma() ), 0, 32 );
	}

	/** Ruta del archivo listo para servir (sellado si es PDF) o WP_Error. */
	public static function sellado( array $p, array $a ) {
		if ( empty( $a['ruta'] ) || ! is_readable( $a['ruta'] ) ) {
			return new WP_Error( 'ogc_falta', 'Archivo no disponible.' );
		}
		if ( empty( $a['sellar'] ) ) {
			return $a['ruta']; // hoja Excel: se entrega tal cual
		}
		$dir     = self::carpeta_pedido( $p );
		$destino = $dir . '/' . substr( $a['sha256'], 0, 24 ) . '.pdf';
		if ( is_readable( $destino ) && filesize( $destino ) > 0 ) {
			return $destino;
		}
		if ( empty( $a['mapa'] ) ) {
			return new WP_Error( 'ogc_mapa', 'El documento no tiene plantilla de sellado.' );
		}
		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return new WP_Error( 'ogc_carpeta', 'No se puede crear la carpeta de sellados.' );
		}
		try {
			$pdf = OGC_Sello::sellar( (string) file_get_contents( $a['ruta'] ), $a['mapa'], self::textos( $p, $a ) ); // phpcs:ignore
			$tmp = $destino . '.tmp-' . wp_generate_password( 6, false );
			file_put_contents( $tmp, $pdf ); // phpcs:ignore
			rename( $tmp, $destino );
		} catch ( \Throwable $e ) {
			OGC_Pedidos::avisar_admin( 'Error de sellado ' . $p['pedido'], $a['nombre'] . ': ' . $e->getMessage() );
			return new WP_Error( 'ogc_sellado', 'No se ha podido preparar el archivo.' );
		}
		return $destino;
	}

	public static function textos( array $p, array $a ) {
		$lic    = self::licencia( $p );
		$titulo = pathinfo( $a['nombre'], PATHINFO_FILENAME );
		return array(
			'central'  => 'PROHIBIDA SU VENTA',
			'variable' => $p['nombre'] . ' · pedido ' . $p['pedido'],
			'pie'      => $lic,
			'info'     => array(
				'Title'       => $titulo . ' · Licencia de uso personal de ' . $p['nombre'],
				'Author'      => 'Preparador OGC · Vicente Ruiz',
				'Creator'     => 'Preparador OGC · organizacionygestioncomercial.es',
				'Producer'    => 'OGC Ventas ' . OGC_VENTAS_VERSION,
				'Subject'     => $lic,
				'Keywords'    => 'Preparador OGC; pedido ' . $p['pedido'] . '; ' . $p['email'] . '; ' . OGC_Pedidos::fecha( $p ),
				'OGC_Pedido'  => $p['pedido'],
				'OGC_Email'   => $p['email'],
				'OGC_Licencia' => $lic,
			),
		);
	}

	/** Sella todos los archivos del pedido (WP-Cron, en segundo plano). */
	public static function presellar_pedido( $id ) {
		$p = OGC_Pedidos::obtener( $id );
		if ( ! $p || ! OGC_Materiales::hay_materiales() ) {
			return;
		}
		$error = false;
		foreach ( OGC_Config::archivos( $p['producto'] ) as $a ) {
			if ( is_wp_error( self::sellado( $p, $a ) ) ) {
				$error = true;
			}
		}
		OGC_Pedidos::actualizar( $id, array( 'estado' => $error ? 'error' : 'listo' ) );
	}
}
