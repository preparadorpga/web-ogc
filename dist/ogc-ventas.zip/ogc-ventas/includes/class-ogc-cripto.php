<?php
/**
 * Utilidades criptográficas puras (sin WordPress): firmas HMAC de enlaces y cookies, AES-256-GCM del paquete de
 * materiales y verificación Ed25519 del manifiesto. Se prueban en tests/.
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'OGC_TEST' ) ) {
	exit;
}

class OGC_Cripto {

	const MAGIA = 'OGCM1'; // cabecera de cada archivo cifrado: OGCM1 + nonce(12) + cifrado + etiqueta(16)

	/** HMAC-SHA256 en hexadecimal. */
	public static function firma( $clave, $datos ) {
		return hash_hmac( 'sha256', (string) $datos, (string) $clave );
	}

	/** Comprueba una firma hexadecimal en tiempo constante. */
	public static function firma_valida( $clave, $datos, $firma ) {
		$firma = (string) $firma;
		if ( strlen( (string) $clave ) < 32 || ! preg_match( '/^[0-9a-f]{64}$/', $firma ) ) {
			return false;
		}
		return hash_equals( self::firma( $clave, $datos ), $firma );
	}

	/** Valor firmado compacto para cookies: base64url(datos).firma. */
	public static function sellar_valor( $clave, $datos ) {
		$b = rtrim( strtr( base64_encode( (string) $datos ), '+/', '-_' ), '=' );
		return $b . '.' . self::firma( $clave, 'cookie|' . $b );
	}

	/** Devuelve los datos de un valor firmado o null si no es válido. */
	public static function abrir_valor( $clave, $valor ) {
		$valor = (string) $valor;
		if ( strlen( $valor ) > 2048 || ! preg_match( '/^([A-Za-z0-9_-]+)\.([0-9a-f]{64})$/', $valor, $m ) ) {
			return null;
		}
		if ( ! self::firma_valida( $clave, 'cookie|' . $m[1], $m[2] ) ) {
			return null;
		}
		$d = base64_decode( strtr( $m[1], '-_', '+/' ), true );
		return false === $d ? null : $d;
	}

	/** Clave de 32 bytes desde el texto pegado en Ajustes (base64 de 32 bytes, como la genera publicar_materiales.py). */
	public static function clave_materiales( $texto ) {
		$b = base64_decode( trim( (string) $texto ), true );
		return ( false !== $b && 32 === strlen( $b ) ) ? $b : null;
	}

	/** Huella pública de la clave (para comprobar que la pegada es la del paquete sin revelarla). */
	public static function id_clave( $clave_bin ) {
		return substr( hash( 'sha256', 'ogc-materiales-id|' . $clave_bin ), 0, 16 );
	}

	// ------------------------------------------------------------------ Sobre sellado (1.1.1)

	/** Huella de una clave pública X25519 (32 bytes): primeros 16 hex de su sha256. La misma en publicar_materiales.py. */
	public static function huella_publica( $publica_bin ) {
		return 32 === strlen( (string) $publica_bin ) ? substr( hash( 'sha256', (string) $publica_bin ), 0, 16 ) : '';
	}

	/** Genera un par X25519 para sobres sellados (crypto_box). Devuelve el par binario (secreta + pública) o null. */
	public static function nuevo_par() {
		if ( ! function_exists( 'sodium_crypto_box_keypair' ) ) {
			return null;
		}
		return sodium_crypto_box_keypair();
	}

	/** Pública de un par crypto_box (o '' si el par no es válido). */
	public static function publica_de_par( $par ) {
		if ( ! function_exists( 'sodium_crypto_box_publickey' ) || SODIUM_CRYPTO_BOX_KEYPAIRBYTES !== strlen( (string) $par ) ) {
			return '';
		}
		return sodium_crypto_box_publickey( $par );
	}

	/** Envuelve la clave de materiales para una pública X25519 (sobre sellado anónimo). Devuelve base64. Solo pruebas. */
	public static function envolver( $clave_bin, $publica_bin ) {
		return base64_encode( sodium_crypto_box_seal( (string) $clave_bin, (string) $publica_bin ) );
	}

	/** Abre un sobre (base64) con el par del sitio. Devuelve la clave de 32 bytes o null. */
	public static function abrir_sobre( $sobre_b64, $par ) {
		if ( ! function_exists( 'sodium_crypto_box_seal_open' ) || SODIUM_CRYPTO_BOX_KEYPAIRBYTES !== strlen( (string) $par ) ) {
			return null;
		}
		$s = base64_decode( trim( (string) $sobre_b64 ), true );
		if ( false === $s || strlen( $s ) !== 32 + SODIUM_CRYPTO_BOX_SEALBYTES ) {
			return null;
		}
		try {
			$k = sodium_crypto_box_seal_open( $s, $par );
		} catch ( \Throwable $e ) {
			return null;
		}
		return ( false !== $k && 32 === strlen( $k ) ) ? $k : null;
	}

	/** Cifra (solo pruebas y herramientas; el cifrado real lo hace publicar_materiales.py). */
	public static function cifrar_gcm( $plano, $clave, $aad ) {
		$nonce = random_bytes( 12 );
		$tag   = '';
		$c     = openssl_encrypt( $plano, 'aes-256-gcm', $clave, OPENSSL_RAW_DATA, $nonce, $tag, $aad, 16 );
		return self::MAGIA . $nonce . $c . $tag;
	}

	/**
	 * Descifra un archivo del paquete. Devuelve el texto plano o null si la clave, los datos o el AAD no cuadran.
	 * AES-256-GCM con OpenSSL; si no hay OpenSSL con GCM, con libsodium (si el procesador lo admite).
	 */
	public static function descifrar_gcm( $blob, $clave, $aad ) {
		$blob = (string) $blob;
		if ( 32 !== strlen( (string) $clave ) || strlen( $blob ) < 5 + 12 + 16 || self::MAGIA !== substr( $blob, 0, 5 ) ) {
			return null;
		}
		$nonce = substr( $blob, 5, 12 );
		$tag   = substr( $blob, -16 );
		$c     = substr( $blob, 17, -16 );
		if ( function_exists( 'openssl_decrypt' ) && in_array( 'aes-256-gcm', openssl_get_cipher_methods(), true ) ) {
			$p = openssl_decrypt( $c, 'aes-256-gcm', $clave, OPENSSL_RAW_DATA, $nonce, $tag, $aad );
			return false === $p ? null : $p;
		}
		if ( function_exists( 'sodium_crypto_aead_aes256gcm_is_available' ) && sodium_crypto_aead_aes256gcm_is_available() ) {
			$p = sodium_crypto_aead_aes256gcm_decrypt( $c . $tag, $aad, $nonce, $clave );
			return false === $p ? null : $p;
		}
		return null;
	}

	/** Verifica una firma Ed25519 (base64) de los bytes exactos. */
	public static function ed25519_valida( $datos, $firma_b64, $publica_bin ) {
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) || 32 !== strlen( (string) $publica_bin ) ) {
			return false;
		}
		$f = base64_decode( trim( (string) $firma_b64 ), true );
		if ( false === $f || 64 !== strlen( $f ) ) {
			return false;
		}
		try {
			return sodium_crypto_sign_verify_detached( $f, (string) $datos, $publica_bin );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	/** Red aproximada de una IP (/24 en IPv4, /48 en IPv6) para contar «redes distintas». */
	public static function red( $ip ) {
		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			$p = explode( '.', $ip );
			return $p[0] . '.' . $p[1] . '.' . $p[2] . '.0/24';
		}
		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
			$b = inet_pton( $ip );
			return inet_ntop( substr( $b, 0, 6 ) . str_repeat( "\0", 10 ) ) . '/48';
		}
		return '?';
	}
}
