<?php
/**
 * Sellado de PDF en PHP puro (1.1.0): sin FPDI, sin TCPDF, sin vendor/.
 *
 * Trabaja sobre una «plantilla de sellado» preparada por ventas/plantilla_sellado.py (pikepdf) al publicar los
 * materiales: cada página ya lleva, al final de su contenido, una referencia a un flujo de sello (uno por tamaño de
 * página), y en sus recursos la fuente Helvetica-Bold, dos opacidades y la silueta del logo. La plantilla está cifrada
 * (AES-256, R6: se abre sin contraseña, se imprime, no se edita ni se copia) y su «mapa» trae la clave del archivo.
 *
 * Por comprador, este código escribe una versión nueva de esos flujos de sello (marca de agua diagonal con el logo,
 * «PROHIBIDA SU VENTA» y el texto variable, y la línea de licencia legible al pie), cifrados con la clave del archivo,
 * un diccionario /Info nuevo con la licencia y una tabla xref completa. La xref de la plantilla se elimina del
 * resultado, de modo que no queda una «revisión anterior sin sellar» que se pueda recuperar recortando el archivo.
 * Se conservan marcadores, enlaces, etiquetado y cifrado de la plantilla. Es independiente de WordPress (se prueba
 * en tests/). La protección real es la marca personal: ningún sello de PDF es imposible de quitar.
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'OGC_TEST' ) ) {
	exit;
}

class OGC_Sello {

	/** Anchos de Helvetica-Bold (AFM estándar), WinAnsiEncoding, en milésimas de em. */
	const ANCHOS = array( 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584,350,556,350,278,556,500,1000,556,556,333,1000,667,333,1000,350,611,350,350,278,278,500,500,350,556,1000,333,1000,556,333,944,350,500,667,278,333,556,556,556,556,280,556,333,737,370,556,584,333,737,333,400,584,333,333,333,611,556,278,333,333,365,556,834,834,834,611,722,722,722,722,722,722,1000,722,667,667,667,667,278,278,278,278,722,722,778,778,778,778,778,584,778,722,722,722,722,667,667,611,556,556,556,556,556,556,889,556,556,556,556,556,278,278,278,278,611,611,611,611,611,611,611,584,611,611,611,611,611,556,611,556 );

	/** UTF-8 → WinAnsi (cp1252); lo que no exista se translitera o se cambia por «?». */
	public static function a_winansi( $t ) {
		$t = (string) $t;
		$r = @iconv( 'UTF-8', 'CP1252//TRANSLIT', $t ); // phpcs:ignore
		if ( false === $r ) {
			$r = @iconv( 'UTF-8', 'CP1252//IGNORE', $t ); // phpcs:ignore
		}
		return false === $r ? preg_replace( '/[^\x20-\x7E]/', '?', $t ) : $r;
	}

	/** Cadena literal PDF escapada. */
	public static function literal( $cp1252 ) {
		return '(' . strtr( $cp1252, array( '\\' => '\\\\', '(' => '\\(', ')' => '\\)', "\r" => ' ', "\n" => ' ' ) ) . ')';
	}

	/** Ancho en puntos de un texto cp1252 en Helvetica-Bold al tamaño dado. */
	public static function ancho( $cp1252, $tam ) {
		$s = 0;
		$n = strlen( $cp1252 );
		for ( $i = 0; $i < $n; $i++ ) {
			$s += self::ANCHOS[ ord( $cp1252[ $i ] ) ];
		}
		return $s * $tam / 1000;
	}

	private static function num( $x ) {
		return rtrim( rtrim( sprintf( '%.3F', $x ), '0' ), '.' );
	}

	/** Tamaño de letra máximo (entre $max y $min) con el que el texto cabe en $ancho. */
	public static function ajustar( $cp1252, $ancho, $max, $min, $paso ) {
		$t = $max;
		while ( self::ancho( $cp1252, $t ) > $ancho && $t - $paso >= $min ) {
			$t -= $paso;
		}
		return $t;
	}

	/**
	 * Flujo de contenido del sello para una página de caja [x0, y0, x1, y1].
	 *
	 * @param array $caja  Caja de la página.
	 * @param array $logo  [ancho, alto] en píxeles del logo (proporción).
	 * @param array $t     'central' (PROHIBIDA SU VENTA), 'variable' (nombre · pedido), 'pie' (licencia).
	 */
	public static function contenido( array $caja, array $logo, array $t ) {
		list( $x0, $y0, $x1, $y1 ) = array_map( 'floatval', $caja );
		$w   = $x1 - $x0;
		$h   = $y1 - $y0;
		$cen = self::a_winansi( isset( $t['central'] ) ? $t['central'] : 'PROHIBIDA SU VENTA' );
		$var = self::a_winansi( isset( $t['variable'] ) ? $t['variable'] : '' );
		$pie = self::a_winansi( isset( $t['pie'] ) ? $t['pie'] : '' );
		$a   = deg2rad( 35 );
		$c   = cos( $a );
		$s   = sin( $a );
		$t1  = self::ajustar( $cen, $w * 0.9, 46, 20, 2 );
		$t2  = self::ajustar( $var, $w * 0.95, 18, 8, 1 );
		$lw  = $w * 0.42;
		$lh  = $logo[0] > 0 ? $lw * $logo[1] / $logo[0] : 0;
		$o   = "/Artifact BMC\nq\n/OGCa gs\n";
		$o  .= '1 0 0 1 ' . self::num( $x0 + $w / 2 ) . ' ' . self::num( $y0 + $h / 2 ) . " cm\n";
		$o  .= self::num( $c ) . ' ' . self::num( $s ) . ' ' . self::num( -$s ) . ' ' . self::num( $c ) . " 0 0 cm\n";
		if ( $lh > 0 ) {
			$o .= 'q ' . self::num( $lw ) . ' 0 0 ' . self::num( $lh ) . ' ' . self::num( -$lw / 2 ) . ' ' . self::num( $t1 * 1.1 ) . " cm /OGCL Do Q\n";
		}
		$o .= "0.29 0.31 0.333 rg\n";
		$o .= 'BT /OGCF ' . self::num( $t1 ) . ' Tf ' . self::num( -self::ancho( $cen, $t1 ) / 2 ) . ' 0 Td ' . self::literal( $cen ) . " Tj ET\n";
		if ( '' !== $var ) {
			$o .= 'BT /OGCF ' . self::num( $t2 ) . ' Tf ' . self::num( -self::ancho( $var, $t2 ) / 2 ) . ' ' . self::num( -( $t2 + 14 ) ) . ' Td ' . self::literal( $var ) . " Tj ET\n";
		}
		$o .= "Q\n";
		if ( '' !== $pie ) {
			// Línea de licencia legible al pie; si no cabe ni a 5 pt, en dos líneas.
			$lineas = array( $pie );
			$t3     = self::ajustar( $pie, $w - 60, 8.5, 5, 0.5 );
			if ( self::ancho( $pie, $t3 ) > $w - 60 ) {
				$corte  = strrpos( substr( $pie, 0, (int) ( strlen( $pie ) / 2 ) + 20 ), ' ' );
				$corte  = $corte ? $corte : (int) ( strlen( $pie ) / 2 );
				$lineas = array( substr( $pie, 0, $corte ), ltrim( substr( $pie, $corte ) ) );
				$t3     = min( self::ajustar( $lineas[0], $w - 60, 8.5, 4, 0.5 ), self::ajustar( $lineas[1], $w - 60, 8.5, 4, 0.5 ) );
			}
			$o .= "q /OGCb gs 0.122 0.306 0.475 rg\n";
			$y  = $y0 + 12 + ( count( $lineas ) - 1 ) * ( $t3 + 2 );
			foreach ( $lineas as $l ) {
				$o .= 'BT /OGCF ' . self::num( $t3 ) . ' Tf ' . self::num( $x0 + ( $w - self::ancho( $l, $t3 ) ) / 2 ) . ' ' . self::num( $y ) . ' Td ' . self::literal( $l ) . " Tj ET\n";
				$y -= $t3 + 2;
			}
			$o .= "Q\n";
		}
		return $o . "EMC\n";
	}

	/** Cifrado de cadenas y flujos en PDF R6 (AESV3): AES-256-CBC con IV aleatorio delante y relleno PKCS#7. */
	public static function cifrar( $datos, $clave ) {
		$iv = random_bytes( 16 );
		return $iv . openssl_encrypt( $datos, 'aes-256-cbc', $clave, OPENSSL_RAW_DATA, $iv );
	}

	/** Cadena de texto PDF (UTF-16BE con BOM) cifrada, en hexadecimal. */
	public static function cadena( $utf8, $clave ) {
		$u = "\xFE\xFF" . mb_convert_encoding( (string) $utf8, 'UTF-16BE', 'UTF-8' );
		return '<' . bin2hex( self::cifrar( $u, $clave ) ) . '>';
	}

	/** Tabla xref de la plantilla: array( n => array( desplazamiento, generación, 'n'|'f' ) ). */
	public static function leer_xref( $pdf, $off, $size ) {
		if ( 'xref' !== substr( $pdf, $off, 4 ) ) {
			throw new RuntimeException( 'La plantilla no tiene la xref donde dice el mapa.' );
		}
		$trozo = substr( $pdf, $off, 64 + 20 * $size );
		if ( ! preg_match( '/^xref\s+0\s+(\d+)\s*\r?\n/', $trozo, $m ) || (int) $m[1] !== (int) $size ) {
			throw new RuntimeException( 'Cabecera de xref inesperada.' );
		}
		preg_match_all( '/(\d{10}) (\d{5}) ([nf])/', substr( $trozo, strlen( $m[0] ) ), $e, PREG_SET_ORDER );
		if ( count( $e ) < $size ) {
			throw new RuntimeException( 'xref incompleta.' );
		}
		$x = array();
		for ( $i = 0; $i < $size; $i++ ) {
			$x[ $i ] = array( (int) $e[ $i ][1], (int) $e[ $i ][2], $e[ $i ][3] );
		}
		return $x;
	}

	/**
	 * Sella una plantilla. Devuelve los bytes del PDF sellado.
	 *
	 * @param string $pdf  Bytes de la plantilla.
	 * @param array  $mapa Mapa de plantilla_sellado.py (xref, size, raiz, encrypt, id, clave, logo, sellos).
	 * @param array  $t    'central', 'variable', 'pie' y 'info' (array de metadatos: Title, Author, Subject, Keywords, Creator, OGC_Pedido…).
	 */
	public static function sellar( $pdf, array $mapa, array $t ) {
		foreach ( array( 'xref', 'size', 'raiz', 'encrypt', 'id', 'clave', 'sellos' ) as $k ) {
			if ( ! isset( $mapa[ $k ] ) ) {
				throw new RuntimeException( 'Mapa de plantilla incompleto: ' . $k );
			}
		}
		foreach ( array( 'raiz', 'encrypt' ) as $k ) {
			if ( ! preg_match( '/^\d+ \d+ R$/', $mapa[ $k ] ) ) {
				throw new RuntimeException( 'Mapa no válido: ' . $k );
			}
		}
		if ( ! preg_match( '/^\[<[0-9a-fA-F]+><[0-9a-fA-F]+>\]$/', $mapa['id'] ) || ! preg_match( '/^[0-9a-f]{64}$/', $mapa['clave'] ) ) {
			throw new RuntimeException( 'Mapa no válido: id o clave.' );
		}
		$clave = hex2bin( $mapa['clave'] );
		$size  = (int) $mapa['size'];
		$off   = (int) $mapa['xref'];
		$xref  = self::leer_xref( $pdf, $off, $size );
		$out   = substr( $pdf, 0, $off );
		if ( "\n" !== substr( $out, -1 ) ) {
			$out .= "\n";
		}
		$logo = isset( $mapa['logo'] ) ? $mapa['logo'] : array( 0, 0 );
		foreach ( $mapa['sellos'] as $s ) {
			$n = (int) $s['obj'];
			if ( $n < 1 || $n >= $size || 'n' !== $xref[ $n ][2] ) {
				throw new RuntimeException( 'Objeto de sello no válido: ' . $n );
			}
			$datos        = self::cifrar( gzcompress( self::contenido( $s['caja'], $logo, $t ), 6 ), $clave );
			$xref[ $n ]   = array( strlen( $out ), $xref[ $n ][1], 'n' );
			$out         .= $n . ' ' . $xref[ $n ][1] . " obj\n<< /Length " . strlen( $datos ) . " /Filter /FlateDecode >>\nstream\n" . $datos . "\nendstream\nendobj\n";
		}
		// /Info nuevo (cadenas cifradas). Las claves propias solo admiten letras, números y «_».
		$info = '';
		foreach ( ( isset( $t['info'] ) ? (array) $t['info'] : array() ) as $k => $v ) {
			if ( preg_match( '/^[A-Za-z][A-Za-z0-9_]{0,40}$/', (string) $k ) ) {
				$info .= '/' . $k . ' ' . self::cadena( $v, $clave ) . "\n";
			}
		}
		$ni          = $size;
		$xref[ $ni ] = array( strlen( $out ), 0, 'n' );
		$out        .= $ni . " 0 obj\n<<\n" . $info . ">>\nendobj\n";
		$nuevo       = $size + 1;
		$inicio      = strlen( $out );
		$out        .= "xref\n0 " . $nuevo . "\n";
		for ( $i = 0; $i < $nuevo; $i++ ) {
			$out .= sprintf( '%010d %05d %s', $xref[ $i ][0], $xref[ $i ][1], $xref[ $i ][2] ) . " \n";
		}
		$out .= "trailer\n<< /Size " . $nuevo . ' /Root ' . $mapa['raiz'] . ' /Encrypt ' . $mapa['encrypt'] . ' /ID ' . $mapa['id'] . ' /Info ' . $ni . " 0 R >>\nstartxref\n" . $inicio . "\n%%EOF\n";
		return $out;
	}
}
