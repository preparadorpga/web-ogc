<?php
/**
 * Contactos, consentimientos, baja de un clic y formulario de muestras (1.1.0).
 *
 * Muestras (orden de Vicente 12/11/2026 08:54 y 08:58): email + teléfono obligatorios, casilla de privacidad
 * obligatoria, casilla de boletín opcional y NO marcada. Sin doble confirmación: al enviar, la página muestra los
 * cuatro enlaces de descarga y se manda una copia por correo. Las muestras son los PDF ya protegidos (marca «MUESTRA»,
 * formato incompleto), servidos desde la carpeta privada con enlaces firmados de 7 días. Antispam: campo trampa,
 * tiempo mínimo firmado y límites suaves por IP, email y teléfono.
 *
 * Cada consentimiento (y cada baja) queda registrado con fecha, IP, navegador, origen y el texto exacto aceptado.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Contactos {

	const TEXTO_PRIVACIDAD = 'He leído la política de privacidad y acepto que Preparador OGC trate mi email y mi teléfono para enviarme las cuatro muestras y, en relación con ellas, contactarme (obligatoria).';
	const TEXTO_BOLETIN    = 'Quiero recibir el boletín semanal de Preparador OGC con novedades del blog, de convocatorias y normativa y del material (opcional; puedo darme de baja en cualquier momento con el enlace de cada correo).';
	const VIDA_MUESTRA     = 604800; // 7 días
	const MAX_MUESTRAS     = 60;     // descargas de muestras por contacto (suave)

	/** @var array|null Resultado del envío del formulario en esta petición. */
	private static $resultado = null;

	// ------------------------------------------------------------------ Puras

	/** Normaliza y valida un teléfono español o internacional. Devuelve «+34600111222» o ''. */
	public static function telefono( $t ) {
		$t = preg_replace( '/[\s\-\.\(\)\/]/', '', (string) $t );
		if ( 0 === strpos( $t, '00' ) ) {
			$t = '+' . substr( $t, 2 );
		}
		if ( preg_match( '/^[6789]\d{8}$/', $t ) ) {
			return '+34' . $t;
		}
		if ( preg_match( '/^\+34[6789]\d{8}$/', $t ) ) {
			return $t;
		}
		if ( preg_match( '/^\+(?!34)[1-9]\d{7,14}$/', $t ) ) {
			return $t;
		}
		return '';
	}

	/** Firma del enlace de baja. */
	public static function firma_baja( $clave, $id, $email ) {
		return OGC_Cripto::firma( $clave, 'baja|' . (int) $id . '|' . strtolower( $email ) );
	}

	// ------------------------------------------------------------------ Datos

	public static function obtener( $email ) {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'contactos' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE email = %s", strtolower( $email ) ), ARRAY_A ); // phpcs:ignore
	}

	public static function obtener_id( $id ) {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'contactos' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore
	}

	/** Crea o actualiza el contacto. Devuelve su id. */
	public static function guardar( $email, array $datos ) {
		global $wpdb;
		$t     = OGC_Pedidos::tabla( 'contactos' );
		$email = strtolower( $email );
		$c     = self::obtener( $email );
		if ( $c ) {
			$wpdb->update( $t, $datos, array( 'id' => (int) $c['id'] ) );
			return (int) $c['id'];
		}
		$wpdb->insert( $t, array_merge( array( 'email' => $email, 'creado' => current_time( 'mysql', true ), 'ip' => OGC_Config::ip() ), $datos ) );
		return (int) $wpdb->insert_id;
	}

	public static function consentimiento( $email, $tipo, $accion, $texto, $origen ) {
		global $wpdb;
		$wpdb->insert(
			OGC_Pedidos::tabla( 'consentimientos' ),
			array(
				'fecha'  => current_time( 'mysql', true ),
				'email'  => strtolower( $email ),
				'tipo'   => $tipo,
				'accion' => $accion,
				'texto'  => $texto,
				'origen' => mb_substr( $origen, 0, 40 ),
				'ip'     => OGC_Config::ip(),
				'agente' => OGC_Config::agente(),
			)
		);
	}

	public static function alta_boletin( $email, $nombre, $origen, $texto, $detalle = '', $telefono = '' ) {
		if ( ! is_email( $email ) ) {
			return 0;
		}
		$d = array( 'boletin' => 1, 'boletin_desde' => current_time( 'mysql', true ), 'baja' => null );
		if ( $nombre ) {
			$d['nombre'] = mb_substr( $nombre, 0, 120 );
		}
		if ( ! self::obtener( $email ) ) {
			$d['origen'] = $origen;
		}
		$id = self::guardar( $email, $d );
		self::consentimiento( $email, 'boletin', 'alta', $texto, $detalle ? $detalle : $origen );
		return $id;
	}

	public static function baja( array $c, $origen ) {
		global $wpdb;
		$wpdb->update( OGC_Pedidos::tabla( 'contactos' ), array( 'boletin' => 0, 'baja' => current_time( 'mysql', true ) ), array( 'id' => (int) $c['id'] ) );
		self::consentimiento( $c['email'], 'boletin', 'baja', 'Baja del boletín', $origen );
	}

	public static function url_baja( array $c ) {
		return add_query_arg( array( 'ogc_baja' => $c['id'], 's' => self::firma_baja( OGC_Config::clave_firma(), $c['id'], $c['email'] ) ), home_url( '/' ) );
	}

	/** Límite suave: true si aún no se ha superado (y cuenta este intento). */
	public static function limite( $clave, $max, $vida ) {
		$k = 'ogc_lim_' . md5( $clave );
		$n = (int) get_transient( $k );
		if ( $n >= $max ) {
			return false;
		}
		set_transient( $k, $n + 1, $vida );
		return true;
	}

	// ------------------------------------------------------------------ Entrada (init)

	public static function atender() {
		// phpcs:disable WordPress.Security.NonceVerification
		if ( isset( $_GET['ogc_baja'] ) ) {
			self::pagina_baja();
		}
		if ( isset( $_GET['ogc_muestra'] ) ) {
			self::servir_muestra();
		}
		if ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) && isset( $_POST['ogc_muestras'] ) ) { // phpcs:ignore
			self::$resultado = self::procesar_muestras();
			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}
			nocache_headers();
		}
		// phpcs:enable
	}

	private static function pagina_baja() {
		$id = absint( $_GET['ogc_baja'] ); // phpcs:ignore
		$s  = isset( $_GET['s'] ) ? preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$c  = $id ? self::obtener_id( $id ) : null;
		if ( ! $c || ! OGC_Cripto::firma_valida( OGC_Config::clave_firma(), 'baja|' . (int) $c['id'] . '|' . strtolower( $c['email'] ), $s ) ) {
			OGC_Descargas::error( 'Enlace de baja no válido. Escríbenos a ' . OGC_Config::correo() . ' y te damos de baja.', 403 );
		}
		if ( (int) $c['boletin'] ) {
			$post = 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ); // phpcs:ignore
			self::baja( $c, $post ? 'enlace-un-clic-post' : 'enlace-un-clic' );
		}
		OGC_Descargas::cabeceras_privadas();
		OGC_Descargas::pagina( 'Baja del boletín', '<h1>Baja confirmada</h1><p class="aviso">Ya no recibirás el boletín de Preparador OGC en ' . esc_html( $c['email'] ) . '. Si compraste material, seguirás recibiendo solo los avisos de actualización de tu pedido.</p><p><a href="' . esc_url( home_url( '/' ) ) . '">Volver a la web</a></p>' );
	}

	// ------------------------------------------------------------------ Muestras

	private static function procesar_muestras() {
		// phpcs:disable WordPress.Security.NonceVerification
		$email = strtolower( sanitize_email( wp_unslash( isset( $_POST['ogc_email'] ) ? $_POST['ogc_email'] : '' ) ) );
		$telb  = sanitize_text_field( wp_unslash( isset( $_POST['ogc_telefono'] ) ? $_POST['ogc_telefono'] : '' ) );
		$tel   = self::telefono( $telb );
		$priv  = ! empty( $_POST['ogc_privacidad'] );
		$bol   = ! empty( $_POST['ogc_boletin'] );
		$t     = absint( isset( $_POST['ogc_t'] ) ? $_POST['ogc_t'] : 0 );
		$ts    = sanitize_text_field( wp_unslash( isset( $_POST['ogc_ts'] ) ? $_POST['ogc_ts'] : '' ) );
		$trampa = ! empty( $_POST['ogc_web'] );
		// phpcs:enable
		$vals = array( 'email' => $email, 'telefono' => $telb, 'boletin' => $bol );
		if ( $trampa || ! OGC_Cripto::firma_valida( OGC_Config::clave_firma(), 'muestras|' . $t, $ts ) || time() - $t > 30 * DAY_IN_SECONDS ) {
			return array( 'error' => 'No se ha podido enviar el formulario. Recarga la página e inténtalo de nuevo.', 'vals' => $vals );
		}
		if ( time() - $t < 3 ) {
			return array( 'error' => 'Has enviado el formulario demasiado rápido. Espera unos segundos y vuelve a intentarlo.', 'vals' => $vals );
		}
		if ( ! is_email( $email ) ) {
			return array( 'error' => 'Escribe un email válido.', 'vals' => $vals );
		}
		if ( '' === $tel ) {
			return array( 'error' => 'Escribe un teléfono válido: 9 cifras (España) o con prefijo internacional, por ejemplo +34 600 000 000.', 'vals' => $vals );
		}
		if ( ! $priv ) {
			return array( 'error' => 'Para recibir las muestras tienes que aceptar la política de privacidad.', 'vals' => $vals );
		}
		$ip = OGC_Config::ip_hash();
		if ( ! self::limite( 'm_ip_' . $ip, 20, HOUR_IN_SECONDS ) || ! self::limite( 'm_em_' . $email, 6, DAY_IN_SECONDS ) || ! self::limite( 'm_tel_' . $tel, 6, DAY_IN_SECONDS ) ) {
			return array( 'error' => 'Se han hecho demasiadas solicitudes. Inténtalo de nuevo más tarde.', 'vals' => $vals );
		}
		$c  = self::obtener( $email );
		$id = self::guardar( $email, $c ? array( 'telefono' => $tel ) : array( 'telefono' => $tel, 'origen' => 'muestras' ) );
		self::consentimiento( $email, 'privacidad', 'alta', self::TEXTO_PRIVACIDAD, 'formulario-muestras' );
		if ( $bol ) {
			self::alta_boletin( $email, '', 'muestras', self::TEXTO_BOLETIN, 'formulario-muestras' );
		}
		$c      = self::obtener_id( $id );
		$enlaces = self::enlaces_muestras( $c );
		if ( ! $enlaces ) {
			OGC_Pedidos::avisar_admin( 'Muestras pedidas sin materiales en la web', "{$email} ({$tel}) ha pedido las muestras, pero aún no se han descargado los materiales. Envíaselas a mano." );
			return array( 'ok' => true, 'enlaces' => array(), 'email' => $email );
		}
		$lista = '';
		foreach ( $enlaces as $e ) {
			$lista .= '<li><a href="' . OGC_Correo::e( $e['url'] ) . '" style="color:#1F4E79">' . OGC_Correo::e( $e['titulo'] ) . '</a></li>';
		}
		OGC_Correo::enviar(
			$email,
			'Tus muestras de Preparador OGC',
			'Tus cuatro muestras',
			'<p>Gracias por tu interés en el material de Preparador OGC (Organización y Gestión Comercial, 0590-110). Estos son los enlaces de descarga de las cuatro muestras (válidos 7 días):</p><ul>' . $lista . '</ul>'
			. '<p>Son extractos en formato incompleto, para juzgar el nivel antes de comprar. El material completo está en la <a href="' . OGC_Correo::e( home_url( '/tienda/' ) ) . '" style="color:#1F4E79">tienda</a>.</p>'
			. '<p style="font-size:14px">Uso personal: prohibida su reproducción o difusión. Si no has pedido tú estas muestras, ignora este mensaje o escríbenos y borraremos tus datos.</p>'
		);
		return array( 'ok' => true, 'enlaces' => $enlaces, 'email' => $email );
	}

	public static function enlaces_muestras( array $c ) {
		$out = array();
		$e   = time() + self::VIDA_MUESTRA;
		foreach ( OGC_Materiales::muestras() as $i => $m ) {
			$s     = OGC_Cripto::firma( OGC_Config::clave_firma(), 'muestra|' . $c['id'] . '|' . $i . '|' . $e );
			$out[] = array(
				'titulo' => isset( $m['titulo'] ) ? $m['titulo'] : basename( $m['ruta'] ),
				'url'    => add_query_arg( array( 'ogc_muestra' => $c['id'], 'm' => $i, 'e' => $e, 's' => $s ), home_url( '/' ) ),
			);
		}
		return $out;
	}

	private static function servir_muestra() {
		// phpcs:disable WordPress.Security.NonceVerification
		$id = absint( $_GET['ogc_muestra'] );
		$i  = absint( isset( $_GET['m'] ) ? $_GET['m'] : 0 );
		$e  = absint( isset( $_GET['e'] ) ? $_GET['e'] : 0 );
		$s  = isset( $_GET['s'] ) ? preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( $_GET['s'] ) ) : '';
		// phpcs:enable
		$c = $id ? self::obtener_id( $id ) : null;
		if ( ! $c || ! OGC_Cripto::firma_valida( OGC_Config::clave_firma(), 'muestra|' . $id . '|' . $i . '|' . $e, $s ) ) {
			OGC_Descargas::error( 'Enlace no válido.', 403 );
		}
		if ( time() > $e ) {
			OGC_Descargas::error( 'Este enlace ha caducado. Vuelve a pedir las muestras en ' . home_url( '/muestras-gratis/' ) . '.', 410 );
		}
		if ( (int) $c['muestras'] >= self::MAX_MUESTRAS ) {
			OGC_Descargas::error( 'Se ha alcanzado el límite de descargas de muestras. Escríbenos a ' . OGC_Config::correo() . '.', 429 );
		}
		$lista = OGC_Materiales::muestras();
		if ( ! isset( $lista[ $i ] ) ) {
			OGC_Descargas::error( 'Muestra no disponible.', 404 );
		}
		$ruta = OGC_Materiales::ruta_local( $lista[ $i ] );
		if ( ! is_readable( $ruta ) ) {
			OGC_Descargas::error( 'Muestra no disponible en este momento.', 503 );
		}
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'contactos' );
		$wpdb->query( $wpdb->prepare( "UPDATE $t SET muestras = muestras + 1 WHERE id = %d", $id ) ); // phpcs:ignore
		while ( ! defined( 'OGC_TEST' ) && ob_get_level() ) {
			ob_end_clean();
		}
		OGC_Descargas::cabeceras_privadas();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( basename( $lista[ $i ]['ruta'] ) ) . '"' );
		header( 'Content-Length: ' . filesize( $ruta ) );
		readfile( $ruta ); // phpcs:ignore
		OGC_Descargas::fin();
	}

	/** Shortcode [ogc_muestras_formulario]. */
	public static function shortcode() {
		$r = self::$resultado;
		if ( $r && ! empty( $r['ok'] ) ) {
			if ( ! $r['enlaces'] ) {
				return '<div class="ogc-nota" role="status"><p>Hemos recibido tu solicitud. Te enviaremos las cuatro muestras a <strong>' . esc_html( $r['email'] ) . '</strong> en breve.</p></div>';
			}
			$h = '<div class="ogc-nota ogc-muestras-listas" role="status" id="muestras-listas"><p><strong>Tus muestras están listas.</strong> Descárgalas ahora (también te hemos enviado los enlaces a ' . esc_html( $r['email'] ) . '; valen 7 días):</p><ul>';
			foreach ( $r['enlaces'] as $e ) {
				$h .= '<li><a class="ogc-enlace-accion" href="' . esc_url( $e['url'] ) . '" rel="nofollow">' . esc_html( $e['titulo'] ) . '</a></li>';
			}
			return $h . '</ul></div>';
		}
		$v   = $r && isset( $r['vals'] ) ? $r['vals'] : array( 'email' => '', 'telefono' => '', 'boletin' => false );
		$t   = time();
		$url = get_permalink() ? get_permalink() : home_url( '/muestras-gratis/' );
		$h   = $r && ! empty( $r['error'] ) ? '<div class="ogc-nota" role="alert"><p>' . esc_html( $r['error'] ) . '</p></div>' : '';
		$h  .= '<form class="ogc-form" method="post" action="' . esc_url( $url ) . '#pedir">'
			. '<input type="hidden" name="ogc_muestras" value="1"><input type="hidden" name="ogc_t" value="' . (int) $t . '"><input type="hidden" name="ogc_ts" value="' . esc_attr( OGC_Cripto::firma( OGC_Config::clave_firma(), 'muestras|' . $t ) ) . '">'
			. '<div class="ogc-campo"><label for="m-correo">Correo electrónico</label><input id="m-correo" name="ogc_email" type="email" autocomplete="email" maxlength="190" required value="' . esc_attr( $v['email'] ) . '"></div>'
			. '<div class="ogc-campo"><label for="m-tel">Teléfono</label><input id="m-tel" name="ogc_telefono" type="tel" autocomplete="tel" inputmode="tel" maxlength="20" required pattern="[0-9+ ()./-]{9,20}" value="' . esc_attr( $v['telefono'] ) . '"><span class="ogc-ayuda">Móvil o fijo de España (9 cifras) o con prefijo internacional (+…).</span></div>'
			. '<div class="ogc-vh" aria-hidden="true"><label for="m-web">No rellenes este campo</label><input id="m-web" name="ogc_web" type="text" tabindex="-1" autocomplete="off"></div>'
			. '<div class="ogc-campo" style="grid-template-columns:auto 1fr;align-items:start"><input id="m-priv" name="ogc_privacidad" type="checkbox" value="si" required><label for="m-priv" style="font-weight:400">He leído la <a href="/privacidad/">política de privacidad</a> y la <a href="#proteccion-datos">información sobre protección de datos</a> y acepto que se traten mi email y mi teléfono para enviarme las cuatro muestras (obligatoria).</label></div>'
			. '<div class="ogc-campo" style="grid-template-columns:auto 1fr;align-items:start"><input id="m-bol" name="ogc_boletin" type="checkbox" value="si"' . ( ! empty( $v['boletin'] ) ? ' checked' : '' ) . '><label for="m-bol" style="font-weight:400">' . esc_html( self::TEXTO_BOLETIN ) . '</label></div>'
			. '<button type="submit">Descargar las muestras</button></form>';
		return $h;
	}

	// ------------------------------------------------------------------ Boletín desde la página del pedido

	public static function form_boletin_pedido( array $p ) {
		$c = self::obtener( $p['email'] );
		if ( $c && (int) $c['boletin'] ) {
			return '<p><small>Estás suscrito al boletín semanal. Puedes darte de baja con el enlace de cada correo.</small></p>';
		}
		return '<form method="post" class="aviso" style="margin-top:16px"><input type="hidden" name="ogc_bt" value="' . esc_attr( OGC_Cripto::firma( OGC_Config::clave_firma(), 'boletin-pedido|' . $p['id'] . '|' . $p['version_enlace'] ) ) . '">'
			. '<label style="display:flex;gap:8px;align-items:flex-start"><input type="checkbox" name="ogc_boletin" value="si" required> <span>' . esc_html( self::TEXTO_BOLETIN ) . ' Información en la <a href="' . esc_url( home_url( '/privacidad/' ) ) . '">política de privacidad</a>.</span></label>'
			. '<p><button class="btn btn2" type="submit">Suscribirme</button></p></form>';
	}

	/** Procesa la casilla del boletín enviada desde la página del pedido. Devuelve un mensaje o ''. */
	public static function procesar_boletin_pedido( array $p ) {
		if ( 'POST' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) || empty( $_POST['ogc_boletin'] ) ) { // phpcs:ignore
			return '';
		}
		$bt = isset( $_POST['ogc_bt'] ) ? sanitize_text_field( wp_unslash( $_POST['ogc_bt'] ) ) : ''; // phpcs:ignore
		if ( ! OGC_Cripto::firma_valida( OGC_Config::clave_firma(), 'boletin-pedido|' . $p['id'] . '|' . $p['version_enlace'], $bt ) ) {
			return 'No se ha podido guardar la suscripción. Recarga la página.';
		}
		self::alta_boletin( $p['email'], $p['nombre'], 'compra', self::TEXTO_BOLETIN, 'pagina-pedido:' . $p['pedido'] );
		return 'Suscripción al boletín guardada. Gracias.';
	}

	// ------------------------------------------------------------------ Exportación

	public static function exportar_csv() {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'contactos' );
		$k = OGC_Pedidos::tabla( 'consentimientos' );
		$f = (array) $wpdb->get_results( "SELECT * FROM $t ORDER BY id", ARRAY_A ); // phpcs:ignore
		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="ogc_contactos_' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore — BOM para Excel
		fputcsv( $out, array( 'email', 'telefono', 'nombre', 'origen', 'alta_utc', 'ip_alta', 'descargas_muestras', 'boletin', 'boletin_desde_utc', 'baja_utc', 'ultimo_consentimiento_boletin_utc', 'ip_consentimiento', 'texto_aceptado' ), ';' );
		foreach ( $f as $c ) {
			$u = $wpdb->get_row( $wpdb->prepare( "SELECT fecha, ip, texto FROM $k WHERE email = %s AND tipo = 'boletin' AND accion = 'alta' ORDER BY id DESC LIMIT 1", $c['email'] ), ARRAY_A ); // phpcs:ignore
			fputcsv( $out, array_map( array( 'OGC_Pedidos', 'csv_seguro' ), array( $c['email'], $c['telefono'], $c['nombre'], $c['origen'], $c['creado'], $c['ip'], $c['muestras'], $c['boletin'] ? 'sí' : 'no', $c['boletin_desde'], $c['baja'], $u ? $u['fecha'] : '', $u ? $u['ip'] : '', $u ? $u['texto'] : '' ) ), ';' );
		}
		fclose( $out ); // phpcs:ignore
		OGC_Descargas::fin();
	}
}
