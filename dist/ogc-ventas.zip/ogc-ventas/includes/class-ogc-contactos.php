<?php
/**
 * Contactos, consentimientos, baja de un clic y formulario de muestras (1.1.0).
 *
 * Muestras (orden de Vicente 12/11/2026 08:54 y 08:58): email + teléfono obligatorios, casilla de privacidad
 * obligatoria, casilla de boletín opcional y NO marcada. Sin doble confirmación: al enviar, la página muestra los
 * cuatro enlaces de descarga y se manda una copia por correo. Las muestras son los PDF ya protegidos (marca «MUESTRA»,
 * formato incompleto), servidos desde la carpeta privada con enlaces firmados de 7 días. Antispam: campo trampa,
 * tiempo mínimo firmado y límites suaves por IP, email y teléfono.
 *
 * 1.3.0: el texto de privacidad dice expresamente que se avisará si las muestras se actualizan o se añaden nuevas
 * (OGC_Avisos), y la casilla opcional ofrece «avísame de las novedades y del material nuevo» además del boletín. Se
 * guarda contactos.muestras_desde. La baja de un clic vale para todo lo que no es el servicio contratado (boletín,
 * novedades, avisos de muestras y de versión nueva sin actualizaciones vigentes).
 *
 * Cada consentimiento (y cada baja) queda registrado con fecha, IP, navegador, origen y el texto exacto aceptado.
 *
 * 1.3.5 (comité 16/11/2026): FUENTE de cada alta del formulario de muestras. Un script propio y pequeño (wp_footer,
 * sin terceros, sin cookies, sin datos personales) guarda en sessionStorage utm_source, utm_medium, utm_campaign y el
 * DOMINIO del referrer (solo el host, nunca la ruta) de la PRIMERA página vista en la sesión y rellena los campos
 * ocultos ogc_origen_* del formulario. En servidor se sanea (lista blanca, máx. 80) y se guarda en el contacto la
 * primera vez que pide muestras (origen_fuente, origen_medio, origen_campana, origen_ref). Sin UTM: «directo» o el
 * nombre del sitio de procedencia (google, bing, instagram, facebook, chatgpt, perplexity…) o su dominio.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Contactos {

	const TEXTO_PRIVACIDAD = 'He leído la política de privacidad y acepto que Preparador OGC trate mi email y mi teléfono para enviarme las cuatro muestras y, en relación con ellas, contactarme, incluido avisarme por correo cuando las muestras se actualicen o se añadan muestras nuevas (obligatoria; puedo darme de baja de esos avisos con el enlace de cada correo).';
	const TEXTO_BOLETIN    = 'Avísame de las novedades y del material nuevo de Preparador OGC y envíame el boletín semanal (blog, convocatorias y normativa, material) (opcional; puedo darme de baja en cualquier momento con el enlace de cada correo).';
	const VIDA_MUESTRA     = 604800; // 7 días
	const MAX_MUESTRAS     = 60;     // descargas de muestras por contacto (suave)
	const ORIGEN_MAX       = 80;     // longitud máxima de cada dato de origen (1.3.5)

	/** @var array|null Resultado del envío del formulario en esta petición. */
	private static $resultado = null;

	// ------------------------------------------------------------------ Puras

	/** Normaliza y valida un teléfono español o internacional. Devuelve «+34600111222» o ''. */
	public static function telefono( $t ) {
		$t = preg_replace( '/[\s\-\.\(\)\/]/', '', (string) $t );
		if ( 0 === strpos( $t, '00' ) ) {
			$t = '+' . substr( $t, 2 );
		}
		if ( preg_match( '/^[6789]\d{8}$/', $t ) ) {
			return '+34' . $t;
		}
		if ( preg_match( '/^\+34[6789]\d{8}$/', $t ) ) {
			return $t;
		}
		if ( preg_match( '/^\+(?!34)[1-9]\d{7,14}$/', $t ) ) {
			return $t;
		}
		return '';
	}

	/** Sanea un valor UTM: minúsculas, sin acentos, solo [a-z0-9._-], máx. 80. Devuelve '' si no queda nada. */
	public static function origen_texto( $v ) {
		$v = strtolower( strtr( trim( (string) $v ), array( 'Á' => 'a', 'É' => 'e', 'Í' => 'i', 'Ó' => 'o', 'Ú' => 'u', 'Ü' => 'u', 'Ñ' => 'n', 'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n' ) ) );
		$v = preg_replace( '/[\s+]+/', '-', $v );
		$v = preg_replace( '/[^a-z0-9._\-]/', '', $v );
		$v = preg_replace( '/([._\-])[._\-]+/', '$1', $v );
		return trim( substr( trim( $v, '-._' ), 0, self::ORIGEN_MAX ), '-._' );
	}

	/** Sanea el referrer y devuelve SOLO su dominio (sin «www.»), o '' si no es un dominio válido de ≤ 80. */
	public static function origen_host( $v ) {
		$v = strtolower( trim( (string) $v ) );
		if ( false !== strpos( $v, '/' ) ) {
			$h = parse_url( false !== strpos( $v, '//' ) ? $v : '//' . $v, PHP_URL_HOST ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$v = is_string( $h ) ? $h : '';
		}
		$v = preg_replace( '/^www\./', '', trim( $v, '.' ) );
		if ( strlen( $v ) > self::ORIGEN_MAX || ! preg_match( '/^[a-z0-9]([a-z0-9\-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9\-]*[a-z0-9])?)+$/', $v ) ) {
			return '';
		}
		return $v;
	}

	/** Nombre corto de los sitios conocidos (buscadores, redes, asistentes de IA) o '' si no es ninguno. */
	public static function origen_conocido( $host ) {
		$mapa = array(
			'/(^|\.)gemini\.google\.[a-z.]+$/'          => 'gemini',
			'/(^|\.)google\.[a-z]{2,3}(\.[a-z]{2})?$/'  => 'google',
			'/(^|\.)bing\.com$/'                        => 'bing',
			'/(^|\.)copilot\.microsoft\.com$/'          => 'copilot',
			'/(^|\.)duckduckgo\.com$/'                  => 'duckduckgo',
			'/(^|\.)yahoo\.[a-z.]+$/'                   => 'yahoo',
			'/(^|\.)ecosia\.org$/'                      => 'ecosia',
			'/(^|\.)instagram\.com$/'                   => 'instagram',
			'/(^|\.)(facebook\.com|fb\.com|fb\.me)$/'   => 'facebook',
			'/(^|\.)(chatgpt\.com|openai\.com)$/'       => 'chatgpt',
			'/(^|\.)perplexity\.ai$/'                   => 'perplexity',
			'/(^|\.)claude\.ai$/'                       => 'claude',
			'/(^|\.)(t\.co|twitter\.com|x\.com)$/'      => 'x',
			'/(^|\.)(linkedin\.com|lnkd\.in)$/'         => 'linkedin',
			'/(^|\.)(youtube\.com|youtu\.be)$/'         => 'youtube',
			'/(^|\.)tiktok\.com$/'                      => 'tiktok',
			'/(^|\.)(whatsapp\.com|wa\.me)$/'           => 'whatsapp',
			'/(^|\.)(telegram\.org|t\.me)$/'            => 'telegram',
		);
		foreach ( $mapa as $re => $n ) {
			if ( preg_match( $re, (string) $host ) ) {
				return $n;
			}
		}
		return '';
	}

	/**
	 * Fuente de un alta a partir de los campos ocultos ogc_origen_* (ya sin barras). $propio: dominio de la web (las
	 * visitas internas cuentan como «directo»). Devuelve las cuatro columnas del contacto, saneadas.
	 */
	public static function origen_de_post( array $p, $propio = '' ) {
		$src = self::origen_texto( isset( $p['ogc_origen_source'] ) ? $p['ogc_origen_source'] : '' );
		$ref = self::origen_host( isset( $p['ogc_origen_ref'] ) ? $p['ogc_origen_ref'] : '' );
		$pro = self::origen_host( $propio );
		if ( '' !== $ref && '' !== $pro && ( $ref === $pro || substr( $ref, -strlen( '.' . $pro ) ) === '.' . $pro ) ) {
			$ref = '';
		}
		if ( '' !== $src ) {
			$alias  = array( 'ig' => 'instagram', 'fb' => 'facebook', 'tw' => 'x', 'twitter' => 'x', 'yt' => 'youtube', 'wa' => 'whatsapp' );
			$h      = false !== strpos( $src, '.' ) ? self::origen_host( $src ) : '';
			$k      = $h ? self::origen_conocido( $h ) : '';
			$fuente = isset( $alias[ $src ] ) ? $alias[ $src ] : ( $k ? $k : ( $h ? $h : $src ) );
		} elseif ( '' !== $ref ) {
			$k      = self::origen_conocido( $ref );
			$fuente = $k ? $k : $ref;
		} elseif ( ! array_key_exists( 'ogc_origen_ref', $p ) ) {
			$fuente = 'sin-dato'; // formulario sin los campos (página en caché anterior a 1.3.5)
		} else {
			$fuente = 'directo';
		}
		return array(
			'origen_fuente'  => substr( $fuente, 0, self::ORIGEN_MAX ),
			'origen_medio'   => self::origen_texto( isset( $p['ogc_origen_medium'] ) ? $p['ogc_origen_medium'] : '' ),
			'origen_campana' => self::origen_texto( isset( $p['ogc_origen_campaign'] ) ? $p['ogc_origen_campaign'] : '' ),
			'origen_ref'     => $ref,
		);
	}

	/** Firma del enlace de baja. */
	public static function firma_baja( $clave, $id, $email ) {
		return OGC_Cripto::firma( $clave, 'baja|' . (int) $id . '|' . strtolower( $email ) );
	}

	// ------------------------------------------------------------------ Datos

	public static function obtener( $email ) {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'contactos' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE email = %s", strtolower( $email ) ), ARRAY_A ); // phpcs:ignore
	}

	public static function obtener_id( $id ) {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'contactos' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore
	}

	/** Crea o actualiza el contacto. Devuelve su id. */
	public static function guardar( $email, array $datos ) {
		global $wpdb;
		$t     = OGC_Pedidos::tabla( 'contactos' );
		$email = strtolower( $email );
		$c     = self::obtener( $email );
		if ( $c ) {
			$wpdb->update( $t, $datos, array( 'id' => (int) $c['id'] ) );
			return (int) $c['id'];
		}
		$wpdb->insert( $t, array_merge( array( 'email' => $email, 'creado' => current_time( 'mysql', true ), 'ip' => OGC_Config::ip() ), $datos ) );
		return (int) $wpdb->insert_id;
	}

	public static function consentimiento( $email, $tipo, $accion, $texto, $origen ) {
		global $wpdb;
		$wpdb->insert(
			OGC_Pedidos::tabla( 'consentimientos' ),
			array(
				'fecha'  => current_time( 'mysql', true ),
				'email'  => strtolower( $email ),
				'tipo'   => $tipo,
				'accion' => $accion,
				'texto'  => $texto,
				'origen' => mb_substr( $origen, 0, 40 ),
				'ip'     => OGC_Config::ip(),
				'agente' => OGC_Config::agente(),
			)
		);
	}

	public static function alta_boletin( $email, $nombre, $origen, $texto, $detalle = '', $telefono = '' ) {
		if ( ! is_email( $email ) ) {
			return 0;
		}
		$d = array( 'boletin' => 1, 'boletin_desde' => current_time( 'mysql', true ), 'baja' => null );
		if ( $nombre ) {
			$d['nombre'] = mb_substr( $nombre, 0, 120 );
		}
		if ( ! self::obtener( $email ) ) {
			$d['origen'] = $origen;
		}
		$id = self::guardar( $email, $d );
		self::consentimiento( $email, 'boletin', 'alta', $texto, $detalle ? $detalle : $origen );
		return $id;
	}

	public static function baja( array $c, $origen ) {
		global $wpdb;
		$wpdb->update( OGC_Pedidos::tabla( 'contactos' ), array( 'boletin' => 0, 'baja' => current_time( 'mysql', true ) ), array( 'id' => (int) $c['id'] ) );
		self::consentimiento( $c['email'], 'boletin', 'baja', 'Baja del boletín, de los avisos de novedades y de los avisos de muestras', $origen );
	}

	public static function url_baja( array $c ) {
		return add_query_arg( array( 'ogc_baja' => $c['id'], 's' => self::firma_baja( OGC_Config::clave_firma(), $c['id'], $c['email'] ) ), home_url( '/' ) );
	}

	/** Límite suave: true si aún no se ha superado (y cuenta este intento). */
	public static function limite( $clave, $max, $vida ) {
		$k = 'ogc_lim_' . md5( $clave );
		$n = (int) get_transient( $k );
		if ( $n >= $max ) {
			return false;
		}
		set_transient( $k, $n + 1, $vida );
		return true;
	}

	// ------------------------------------------------------------------ Entrada (init)

	public static function atender() {
		// phpcs:disable WordPress.Security.NonceVerification
		if ( isset( $_GET['ogc_baja'] ) ) {
			self::pagina_baja();
		}
		if ( isset( $_GET['ogc_muestra'] ) ) {
			self::servir_muestra();
		}
		if ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) && isset( $_POST['ogc_muestras'] ) ) { // phpcs:ignore
			self::$resultado = self::procesar_muestras();
			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}
			nocache_headers();
		}
		// phpcs:enable
	}

	private static function pagina_baja() {
		$id = absint( $_GET['ogc_baja'] ); // phpcs:ignore
		$s  = isset( $_GET['s'] ) ? preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$c  = $id ? self::obtener_id( $id ) : null;
		if ( ! $c || ! OGC_Cripto::firma_valida( OGC_Config::clave_firma(), 'baja|' . (int) $c['id'] . '|' . strtolower( $c['email'] ), $s ) ) {
			OGC_Descargas::error( 'Enlace de baja no válido. Escríbenos a ' . OGC_Config::correo() . ' y te damos de baja.', 403 );
		}
		if ( (int) $c['boletin'] || empty( $c['baja'] ) ) {
			$post = 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ); // phpcs:ignore
			self::baja( $c, $post ? 'enlace-un-clic-post' : 'enlace-un-clic' );
		}
		OGC_Descargas::cabeceras_privadas();
		OGC_Descargas::pagina( 'Baja de los avisos', '<h1>Baja confirmada</h1><p class="aviso">Ya no recibirás en ' . esc_html( $c['email'] ) . ' el boletín ni los avisos de novedades o de muestras de Preparador OGC. Si compraste material y tienes actualizaciones vigentes, seguirás recibiendo solo los avisos de actualización de tu pedido.</p><p><a href="' . esc_url( home_url( '/' ) ) . '">Volver a la web</a></p>' );
	}

	// ------------------------------------------------------------------ Muestras

	private static function procesar_muestras() {
		// phpcs:disable WordPress.Security.NonceVerification
		$email = strtolower( sanitize_email( wp_unslash( isset( $_POST['ogc_email'] ) ? $_POST['ogc_email'] : '' ) ) );
		$telb  = sanitize_text_field( wp_unslash( isset( $_POST['ogc_telefono'] ) ? $_POST['ogc_telefono'] : '' ) );
		$tel   = self::telefono( $telb );
		$priv  = ! empty( $_POST['ogc_privacidad'] );
		$bol   = ! empty( $_POST['ogc_boletin'] );
		$t     = absint( isset( $_POST['ogc_t'] ) ? $_POST['ogc_t'] : 0 );
		$ts    = sanitize_text_field( wp_unslash( isset( $_POST['ogc_ts'] ) ? $_POST['ogc_ts'] : '' ) );
		$trampa = ! empty( $_POST['ogc_web'] );
		$org    = array();
		foreach ( array( 'ogc_origen_source', 'ogc_origen_medium', 'ogc_origen_campaign', 'ogc_origen_ref' ) as $k ) {
			if ( isset( $_POST[ $k ] ) && is_string( $_POST[ $k ] ) ) {
				$org[ $k ] = substr( wp_unslash( $_POST[ $k ] ), 0, 500 ); // se sanea en origen_de_post()
			}
		}
		// phpcs:enable
		$vals = array( 'email' => $email, 'telefono' => $telb, 'boletin' => $bol );
		if ( $trampa || ! OGC_Cripto::firma_valida( OGC_Config::clave_firma(), 'muestras|' . $t, $ts ) || time() - $t > 30 * DAY_IN_SECONDS ) {
			return array( 'error' => 'No se ha podido enviar el formulario. Recarga la página e inténtalo de nuevo.', 'vals' => $vals );
		}
		if ( time() - $t < 3 ) {
			return array( 'error' => 'Has enviado el formulario demasiado rápido. Espera unos segundos y vuelve a intentarlo.', 'vals' => $vals );
		}
		if ( ! is_email( $email ) ) {
			return array( 'error' => 'Escribe un email válido.', 'vals' => $vals );
		}
		if ( '' === $tel ) {
			return array( 'error' => 'Escribe un teléfono válido: 9 cifras (España) o con prefijo internacional, por ejemplo +34 600 000 000.', 'vals' => $vals );
		}
		if ( ! $priv ) {
			return array( 'error' => 'Para recibir las muestras tienes que aceptar la política de privacidad.', 'vals' => $vals );
		}
		$ip = OGC_Config::ip_hash();
		if ( ! self::limite( 'm_ip_' . $ip, 20, HOUR_IN_SECONDS ) || ! self::limite( 'm_em_' . $email, 6, DAY_IN_SECONDS ) || ! self::limite( 'm_tel_' . $tel, 6, DAY_IN_SECONDS ) ) {
			return array( 'error' => 'Se han hecho demasiadas solicitudes. Inténtalo de nuevo más tarde.', 'vals' => $vals );
		}
		$c  = self::obtener( $email );
		// Nueva petición de muestras = nuevo consentimiento: vuelve a recibir los avisos de muestras (no el boletín).
		$d  = array( 'telefono' => $tel, 'baja' => null );
		if ( ! $c || empty( $c['muestras_desde'] ) ) {
			$d['muestras_desde'] = current_time( 'mysql', true );
		}
		if ( ! $c || empty( $c['origen_fuente'] ) ) {
			// 1.3.5: fuente del alta (se conserva la de la primera petición de muestras).
			$d = array_merge( $d, self::origen_de_post( $org, (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) ) );
		}
		$id = self::guardar( $email, $c ? $d : array_merge( $d, array( 'origen' => 'muestras' ) ) );
		self::consentimiento( $email, 'privacidad', 'alta', self::TEXTO_PRIVACIDAD, 'formulario-muestras' );
		if ( $bol ) {
			self::alta_boletin( $email, '', 'muestras', self::TEXTO_BOLETIN, 'formulario-muestras' );
		}
		$c      = self::obtener_id( $id );
		$enlaces = self::enlaces_muestras( $c );
		if ( ! $enlaces ) {
			OGC_Pedidos::avisar_admin( 'Muestras pedidas sin materiales en la web', "{$email} ({$tel}) ha pedido las muestras, pero aún no se han descargado los materiales. Envíaselas a mano." );
			return array( 'ok' => true, 'enlaces' => array(), 'email' => $email );
		}
		$lista = '';
		foreach ( $enlaces as $e ) {
			$lista .= '<li><a href="' . OGC_Correo::e( $e['url'] ) . '" style="color:#1F4E79">' . OGC_Correo::e( $e['titulo'] ) . '</a></li>';
		}
		OGC_Correo::enviar(
			$email,
			'Tus muestras de Preparador OGC',
			'Tus cuatro muestras',
			'<p>Gracias por tu interés en el material de Preparador OGC (Organización y Gestión Comercial, 0590-110). Estos son los enlaces de descarga de las cuatro muestras (válidos 7 días):</p><ul>' . $lista . '</ul>'
			. '<p>Son extractos en formato incompleto, para juzgar el nivel antes de comprar. El material completo está en la <a href="' . OGC_Correo::e( home_url( '/tienda/' ) ) . '" style="color:#1F4E79">tienda</a>.</p>'
			. '<p style="font-size:14px">Uso personal: prohibida su reproducción o difusión. Si no has pedido tú estas muestras, ignora este mensaje o escríbenos y borraremos tus datos.</p>'
		);
		return array( 'ok' => true, 'enlaces' => $enlaces, 'email' => $email );
	}

	public static function enlaces_muestras( array $c ) {
		$out = array();
		$e   = time() + self::VIDA_MUESTRA;
		foreach ( OGC_Materiales::muestras() as $i => $m ) {
			$s     = OGC_Cripto::firma( OGC_Config::clave_firma(), 'muestra|' . $c['id'] . '|' . $i . '|' . $e );
			$out[] = array(
				'ruta'   => $m['ruta'],
				'titulo' => isset( $m['titulo'] ) ? $m['titulo'] : basename( $m['ruta'] ),
				'url'    => add_query_arg( array( 'ogc_muestra' => $c['id'], 'm' => $i, 'e' => $e, 's' => $s ), home_url( '/' ) ),
			);
		}
		return $out;
	}

	private static function servir_muestra() {
		// phpcs:disable WordPress.Security.NonceVerification
		$id = absint( $_GET['ogc_muestra'] );
		$i  = absint( isset( $_GET['m'] ) ? $_GET['m'] : 0 );
		$e  = absint( isset( $_GET['e'] ) ? $_GET['e'] : 0 );
		$s  = isset( $_GET['s'] ) ? preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( $_GET['s'] ) ) : '';
		// phpcs:enable
		$c = $id ? self::obtener_id( $id ) : null;
		if ( ! $c || ! OGC_Cripto::firma_valida( OGC_Config::clave_firma(), 'muestra|' . $id . '|' . $i . '|' . $e, $s ) ) {
			OGC_Descargas::error( 'Enlace no válido.', 403 );
		}
		if ( time() > $e ) {
			OGC_Descargas::error( 'Este enlace ha caducado. Vuelve a pedir las muestras en ' . home_url( '/muestras-gratis/' ) . '.', 410 );
		}
		if ( (int) $c['muestras'] >= self::MAX_MUESTRAS ) {
			OGC_Descargas::error( 'Se ha alcanzado el límite de descargas de muestras. Escríbenos a ' . OGC_Config::correo() . '.', 429 );
		}
		$lista = OGC_Materiales::muestras();
		if ( ! isset( $lista[ $i ] ) ) {
			OGC_Descargas::error( 'Muestra no disponible.', 404 );
		}
		$ruta = OGC_Materiales::ruta_local( $lista[ $i ] );
		if ( ! is_readable( $ruta ) ) {
			OGC_Descargas::error( 'Muestra no disponible en este momento.', 503 );
		}
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'contactos' );
		$wpdb->query( $wpdb->prepare( "UPDATE $t SET muestras = muestras + 1 WHERE id = %d", $id ) ); // phpcs:ignore
		while ( ! defined( 'OGC_TEST' ) && ob_get_level() ) {
			ob_end_clean();
		}
		OGC_Descargas::cabeceras_privadas();
		header( 'Content-Type: application/pdf' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( basename( $lista[ $i ]['ruta'] ) ) . '"' );
		header( 'Content-Length: ' . filesize( $ruta ) );
		readfile( $ruta ); // phpcs:ignore
		OGC_Descargas::fin();
	}

	/** Shortcode [ogc_muestras_formulario]. */
	public static function shortcode() {
		$r = self::$resultado;
		if ( $r && ! empty( $r['ok'] ) ) {
			if ( ! $r['enlaces'] ) {
				return '<div class="ogc-nota" role="status"><p>Hemos recibido tu solicitud. Te enviaremos las cuatro muestras a <strong>' . esc_html( $r['email'] ) . '</strong> en breve.</p></div>';
			}
			$h = '<div class="ogc-nota ogc-muestras-listas" role="status" id="muestras-listas"><p><strong>Tus muestras están listas.</strong> Descárgalas ahora (también te hemos enviado los enlaces a ' . esc_html( $r['email'] ) . '; valen 7 días):</p><ul>';
			foreach ( $r['enlaces'] as $e ) {
				$h .= '<li><a class="ogc-enlace-accion" href="' . esc_url( $e['url'] ) . '" rel="nofollow">' . esc_html( $e['titulo'] ) . '</a></li>';
			}
			return $h . '</ul></div>';
		}
		$v   = $r && isset( $r['vals'] ) ? $r['vals'] : array( 'email' => '', 'telefono' => '', 'boletin' => false );
		$t   = time();
		$url = get_permalink() ? get_permalink() : home_url( '/muestras-gratis/' );
		$h   = $r && ! empty( $r['error'] ) ? '<div class="ogc-nota" role="alert"><p>' . esc_html( $r['error'] ) . '</p></div>' : '';
		$h  .= '<form class="ogc-form" method="post" action="' . esc_url( $url ) . '#pedir">'
			. '<input type="hidden" name="ogc_muestras" value="1"><input type="hidden" name="ogc_t" value="' . (int) $t . '"><input type="hidden" name="ogc_ts" value="' . esc_attr( OGC_Cripto::firma( OGC_Config::clave_firma(), 'muestras|' . $t ) ) . '">'
			. '<input type="hidden" name="ogc_origen_source" value=""><input type="hidden" name="ogc_origen_medium" value=""><input type="hidden" name="ogc_origen_campaign" value=""><input type="hidden" name="ogc_origen_ref" value="">'
			. '<div class="ogc-campo"><label for="m-correo">Correo electrónico</label><input id="m-correo" name="ogc_email" type="email" autocomplete="email" maxlength="190" required value="' . esc_attr( $v['email'] ) . '"></div>'
			. '<div class="ogc-campo"><label for="m-tel">Teléfono</label><input id="m-tel" name="ogc_telefono" type="tel" autocomplete="tel" inputmode="tel" maxlength="20" required pattern="[0-9+ ()./-]{9,20}" value="' . esc_attr( $v['telefono'] ) . '"><span class="ogc-ayuda">Móvil o fijo de España (9 cifras) o con prefijo internacional (+…).</span></div>'
			. '<div class="ogc-vh" aria-hidden="true"><label for="m-web">No rellenes este campo</label><input id="m-web" name="ogc_web" type="text" tabindex="-1" autocomplete="off"></div>'
			. '<div class="ogc-campo" style="grid-template-columns:auto 1fr;align-items:start"><input id="m-priv" name="ogc_privacidad" type="checkbox" value="si" required><label for="m-priv" style="font-weight:400">He leído la <a href="/privacidad/">política de privacidad</a> y la <a href="#proteccion-datos">información sobre protección de datos</a> y acepto que se traten mi email y mi teléfono para enviarme las cuatro muestras y avisarme por correo si se actualizan o se añaden muestras nuevas (obligatoria).</label></div>'
			. '<div class="ogc-campo" style="grid-template-columns:auto 1fr;align-items:start"><input id="m-bol" name="ogc_boletin" type="checkbox" value="si"' . ( ! empty( $v['boletin'] ) ? ' checked' : '' ) . '><label for="m-bol" style="font-weight:400">' . esc_html( self::TEXTO_BOLETIN ) . '</label></div>'
			. '<button type="submit">Descargar las muestras</button></form>';
		return $h;
	}

	// ------------------------------------------------------------------ Origen de la visita (1.3.5)

	/**
	 * Script propio (sin terceros ni cookies): en la PRIMERA página de la sesión guarda en sessionStorage los UTM y el
	 * dominio del referrer; en cualquier página rellena los campos ocultos ogc_origen_* si hay un formulario.
	 */
	public static function js_origen() {
		return '(function(){var k="ogc_origen",d=null;try{d=JSON.parse(sessionStorage.getItem(k)||"null")}catch(e){}'
			. 'if(!d||typeof d!=="object"){var q={},p=location.search.replace(/^\?/,"").split("&");for(var i=0;i<p.length;i++){var a=p[i].split("=");if(/^utm_(source|medium|campaign)$/.test(a[0])){try{q[a[0]]=decodeURIComponent((a[1]||"").replace(/\+/g," ")).slice(0,80)}catch(e){}}}'
			. 'var h="";try{h=document.referrer?new URL(document.referrer).hostname:""}catch(e){}if(h===location.hostname){h=""}'
			. 'd={source:q.utm_source||"",medium:q.utm_medium||"",campaign:q.utm_campaign||"",ref:h};try{sessionStorage.setItem(k,JSON.stringify(d))}catch(e){}}'
			. 'var f=document.querySelectorAll(\'input[name^="ogc_origen_"]\');for(var j=0;j<f.length;j++){var n=f[j].name.slice(11);if(Object.prototype.hasOwnProperty.call(d,n)){f[j].value=String(d[n]).slice(0,80)}}})();';
	}

	/** wp_footer: imprime el script en las páginas públicas. */
	public static function script_origen() {
		if ( function_exists( 'wp_print_inline_script_tag' ) ) {
			wp_print_inline_script_tag( self::js_origen(), array( 'id' => 'ogc-origen' ) );
			return;
		}
		echo '<script id="ogc-origen">' . self::js_origen() . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/** Altas del formulario de muestras de los últimos $dias días, por fuente: [ fuente => n ], de más a menos. */
	public static function resumen_origenes( $dias = 30 ) {
		global $wpdb;
		$t     = OGC_Pedidos::tabla( 'contactos' );
		$desde = gmdate( 'Y-m-d H:i:s', time() - (int) $dias * DAY_IN_SECONDS );
		$f     = (array) $wpdb->get_results( $wpdb->prepare( "SELECT origen_fuente AS f, COUNT(*) AS n FROM $t WHERE muestras_desde IS NOT NULL AND muestras_desde >= %s GROUP BY origen_fuente ORDER BY n DESC, origen_fuente", $desde ), ARRAY_A ); // phpcs:ignore
		$out   = array();
		foreach ( $f as $r ) {
			$k         = '' === (string) $r['f'] ? 'sin-dato' : (string) $r['f'];
			$out[ $k ] = ( isset( $out[ $k ] ) ? $out[ $k ] : 0 ) + (int) $r['n'];
		}
		arsort( $out );
		return $out;
	}

	// ------------------------------------------------------------------ Boletín desde la página del pedido

	public static function form_boletin_pedido( array $p ) {
		$c = self::obtener( $p['email'] );
		if ( $c && (int) $c['boletin'] ) {
			return '<p><small>Estás suscrito a los avisos de novedades y al boletín semanal. Puedes darte de baja con el enlace de cada correo.</small></p>';
		}
		return '<form method="post" class="aviso" style="margin-top:16px"><input type="hidden" name="ogc_bt" value="' . esc_attr( OGC_Cripto::firma( OGC_Config::clave_firma(), 'boletin-pedido|' . $p['id'] . '|' . $p['version_enlace'] ) ) . '">'
			. '<label style="display:flex;gap:8px;align-items:flex-start"><input type="checkbox" name="ogc_boletin" value="si" required> <span>' . esc_html( self::TEXTO_BOLETIN ) . ' Información en la <a href="' . esc_url( home_url( '/privacidad/' ) ) . '">política de privacidad</a>.</span></label>'
			. '<p><button class="btn btn2" type="submit">Suscribirme</button></p></form>';
	}

	/** Procesa la casilla del boletín enviada desde la página del pedido. Devuelve un mensaje o ''. */
	public static function procesar_boletin_pedido( array $p ) {
		if ( 'POST' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) || empty( $_POST['ogc_boletin'] ) ) { // phpcs:ignore
			return '';
		}
		$bt = isset( $_POST['ogc_bt'] ) ? sanitize_text_field( wp_unslash( $_POST['ogc_bt'] ) ) : ''; // phpcs:ignore
		if ( ! OGC_Cripto::firma_valida( OGC_Config::clave_firma(), 'boletin-pedido|' . $p['id'] . '|' . $p['version_enlace'], $bt ) ) {
			return 'No se ha podido guardar la suscripción. Recarga la página.';
		}
		self::alta_boletin( $p['email'], $p['nombre'], 'compra', self::TEXTO_BOLETIN, 'pagina-pedido:' . $p['pedido'] );
		return 'Suscripción al boletín guardada. Gracias.';
	}

	// ------------------------------------------------------------------ Exportación

	public static function exportar_csv() {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'contactos' );
		$k = OGC_Pedidos::tabla( 'consentimientos' );
		$f = (array) $wpdb->get_results( "SELECT * FROM $t ORDER BY id", ARRAY_A ); // phpcs:ignore
		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="ogc_contactos_' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore — BOM para Excel
		fputcsv( $out, array( 'email', 'telefono', 'nombre', 'origen', 'alta_utc', 'ip_alta', 'descargas_muestras', 'muestras_desde_utc', 'boletin', 'boletin_desde_utc', 'baja_utc', 'ultimo_consentimiento_boletin_utc', 'ip_consentimiento', 'texto_aceptado', 'origen_fuente', 'origen_medio', 'origen_campana', 'origen_ref' ), ';' );
		foreach ( $f as $c ) {
			$u = $wpdb->get_row( $wpdb->prepare( "SELECT fecha, ip, texto FROM $k WHERE email = %s AND tipo = 'boletin' AND accion = 'alta' ORDER BY id DESC LIMIT 1", $c['email'] ), ARRAY_A ); // phpcs:ignore
			fputcsv( $out, array_map( array( 'OGC_Pedidos', 'csv_seguro' ), array( $c['email'], $c['telefono'], $c['nombre'], $c['origen'], $c['creado'], $c['ip'], $c['muestras'], isset( $c['muestras_desde'] ) ? $c['muestras_desde'] : '', $c['boletin'] ? 'sí' : 'no', $c['boletin_desde'], $c['baja'], $u ? $u['fecha'] : '', $u ? $u['ip'] : '', $u ? $u['texto'] : '', isset( $c['origen_fuente'] ) ? $c['origen_fuente'] : '', isset( $c['origen_medio'] ) ? $c['origen_medio'] : '', isset( $c['origen_campana'] ) ? $c['origen_campana'] : '', isset( $c['origen_ref'] ) ? $c['origen_ref'] : '' ) ), ';' );
		}
		fclose( $out ); // phpcs:ignore
		OGC_Descargas::fin();
	}
}
