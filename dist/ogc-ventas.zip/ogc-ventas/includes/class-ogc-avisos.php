<?php
/**
 * Avisos de material y de muestras (1.3.0). Orden de Vicente (12/11/2026 21:24 y 21:28).
 *
 * El paquete de materiales (publicar_materiales.py) trae en el manifiesto firmado la lista «avisos»: una entrada por
 * documento, muestra, producto o novedad, marcada como «nuevo» o «actualizacion», con su nota estructurada (qué
 * cambia, dónde, qué decía y qué dice ahora, y alcance «menor» o «amplio» → recomendación «corrígelo a mano» o
 * «descarga e imprime la versión nueva»). Cada entrada tiene un id: se procesa una sola vez (opción OPC_HECHOS), así que
 * nunca se reenvía lo ya avisado. Si el manifiesto no trae «avisos» (paquetes anteriores a 1.3.0) se deducen de las
 * diferencias entre el manifiesto anterior y el nuevo, como hasta ahora.
 *
 * Destinatarios (planificar(), función pura):
 *   · documento NUEVO o ACTUALIZADO de un producto → compradores de ese producto:
 *       - con actualizaciones vigentes (12 meses): «material» (enlace renovado con el PDF nuevo sellado);
 *       - sin actualizaciones vigentes: «renovar» (aviso de que hay versión nueva y de cómo renovar; no se entrega).
 *   · muestra NUEVA o ACTUALIZADA → contactos que pidieron las muestras (sin baja): «muestra», con enlaces nuevos
 *     firmados de 7 días. Base: el consentimiento del formulario («enviarme las cuatro muestras y, en relación con
 *     ellas, contactarme», que desde 1.3.0 dice expresamente que se le avisará si se actualizan o se añaden).
 *   · algo NUEVO (documento, muestra, producto o novedad suelta) → «novedad» a los compradores (art. 21.2 LSSI) y a los
 *     suscritos a novedades/boletín. A quien solo pidió muestras sin marcar la casilla NO se le envían novedades.
 * Quien se dio de baja no recibe nada comercial (renovar, novedad, muestra); los avisos de material de un pedido con
 * actualizaciones vigentes forman parte del servicio contratado y se envían siempre.
 *
 * Envío: como máximo UN correo de avisos al día por persona, que agrupa todo. Sale en el día: desde que se aplica el
 * paquete se espera REPOSO (para agrupar publicaciones seguidas) y se envía entre las 09:00 y las 22:00 (Madrid) en
 * lotes de 50 cada 5 minutos, con List-Unsubscribe y baja de un clic. «Enviar avisos ahora» (escritorio) envía al
 * momento a cualquier hora. Cada correo queda registrado (tabla ogc_envios) y Vicente recibe el resumen del día.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Avisos {

	const LOTE        = 50;
	const CRON_LOTE   = 'ogc_ventas_avisos_lote';
	const OPC_HECHOS  = 'ogc_ventas_avisos_hechos';
	const OPC_RESUMEN = 'ogc_ventas_avisos_resumen';
	const OPC_FORZAR  = 'ogc_ventas_avisos_forzar';
	const OPC_LATIDO  = 'ogc_ventas_latido';
	const HORA_DESDE  = 9;
	const HORA_HASTA  = 22;
	const REPOSO      = 1200;   // 20 min
	const CADUCIDAD   = 604800; // las entradas de más de 7 días que no se procesaron se marcan sin enviar
	const GRUPOS      = array( 'archivos', 'muestras', 'producto', 'nota' );
	const CLASES      = array( 'material' => 'Material actualizado', 'renovar' => 'Versión nueva (sin actualizaciones vigentes)', 'muestra' => 'Muestras', 'novedad' => 'Novedad' );

	// ------------------------------------------------------------------ Lógica pura

	/** Día de Madrid («2026-11-12») de $ts. */
	public static function dia( $ts ) {
		$d = new DateTime( '@' . (int) $ts );
		$d->setTimezone( new DateTimeZone( 'Europe/Madrid' ) );
		return $d->format( 'Y-m-d' );
	}

	/** ¿Es hora de enviar (09:00-21:59 en Madrid)? */
	public static function en_ventana( $ts ) {
		$d = new DateTime( '@' . (int) $ts );
		$d->setTimezone( new DateTimeZone( 'Europe/Madrid' ) );
		$h = (int) $d->format( 'G' );
		return $h >= self::HORA_DESDE && $h < self::HORA_HASTA;
	}

	/** Título legible a partir de la ruta («temas/TEMA_01_OGC_Economia.pdf» → «TEMA 01 OGC Economia»). */
	public static function titulo_de_ruta( $ruta ) {
		return trim( str_replace( '_', ' ', pathinfo( (string) $ruta, PATHINFO_FILENAME ) ) );
	}

	/** Nota genérica razonable cuando el paquete no trae ninguna. */
	public static function nota_generica( $grupo, $tipo ) {
		if ( 'muestras' === $grupo ) {
			return 'nuevo' === $tipo ? 'Muestra nueva disponible.' : 'Muestra revisada con la versión actual del material.';
		}
		if ( 'producto' === $grupo ) {
			return 'Nuevo material disponible en la tienda.';
		}
		return 'nuevo' === $tipo ? 'Documento nuevo.' : 'Revisión y corrección del documento.';
	}

	/** Recomendación para quien tiene el documento impreso, según el alcance. */
	public static function recomendacion( $tipo, $alcance, $grupo = 'archivos' ) {
		if ( 'nuevo' === $tipo ) {
			return 'muestras' === $grupo ? 'Es una muestra nueva: descárgala con el enlace.' : 'Es un documento nuevo: descárgalo e imprímelo si estudias en papel.';
		}
		if ( 'menor' === $alcance ) {
			return 'Si lo tienes impreso, corrígelo a mano: es un cambio pequeño y localizado (también puedes descargar la versión limpia).';
		}
		if ( 'amplio' === $alcance ) {
			return 'Si lo tienes impreso, descarga e imprime la versión nueva: el cambio es amplio.';
		}
		return 'Si lo tienes impreso, revisa la versión nueva.';
	}

	/** Normaliza una entrada del manifiesto; null si no es válida. */
	public static function normalizar( $x ) {
		if ( ! is_array( $x ) || ! isset( $x['id'], $x['grupo'], $x['tipo'] ) || ! preg_match( '/^[0-9a-f]{16}$/', (string) $x['id'] ) ) {
			return null;
		}
		if ( ! in_array( $x['grupo'], self::GRUPOS, true ) || ! in_array( $x['tipo'], array( 'nuevo', 'actualizacion' ), true ) ) {
			return null;
		}
		$ruta = isset( $x['ruta'] ) ? (string) $x['ruta'] : '';
		if ( in_array( $x['grupo'], array( 'archivos', 'muestras' ), true ) && ! preg_match( '#^[A-Za-z0-9_][A-Za-z0-9_./-]{0,200}\.(pdf|xlsx)$#', $ruta ) ) {
			return null;
		}
		if ( 'producto' === $x['grupo'] && ! preg_match( '/^[a-z0-9_]{1,40}$/', $ruta ) ) {
			return null;
		}
		$t   = static function ( $k, $max ) use ( $x ) {
			return isset( $x[ $k ] ) && is_string( $x[ $k ] ) ? mb_substr( trim( wp_strip_all_tags( $x[ $k ] ) ), 0, $max ) : '';
		};
		$alc = isset( $x['alcance'] ) && in_array( $x['alcance'], array( 'menor', 'amplio' ), true ) ? $x['alcance'] : '';
		$out = array(
			'id'        => $x['id'],
			'grupo'     => $x['grupo'],
			'tipo'      => $x['tipo'],
			'ruta'      => in_array( $x['grupo'], array( 'archivos', 'muestras' ), true ) ? $ruta : $x['grupo'] . ':' . ( '' !== $ruta ? $ruta : $x['id'] ),
			'titulo'    => $t( 'titulo', 200 ),
			'nota'      => $t( 'nota', 1500 ),
			'ubicacion' => $t( 'ubicacion', 400 ),
			'antes'     => $t( 'antes', 600 ),
			'ahora'     => $t( 'ahora', 600 ),
			'alcance'   => $alc,
			'fecha_unix' => isset( $x['fecha_unix'] ) && is_int( $x['fecha_unix'] ) ? $x['fecha_unix'] : 0,
		);
		if ( '' === $out['titulo'] ) {
			$out['titulo'] = in_array( $x['grupo'], array( 'archivos', 'muestras' ), true ) ? self::titulo_de_ruta( $ruta ) : 'Novedad';
		}
		if ( '' === $out['nota'] ) {
			$out['nota'] = self::nota_generica( $x['grupo'], $x['tipo'] );
		}
		return $out;
	}

	/**
	 * Entradas de aviso de un manifiesto. Con «avisos» (1.3.0+): esas. Sin ella: se deducen de las diferencias con el
	 * manifiesto anterior (archivos y muestras; igual que 1.2).
	 */
	public static function entradas( array $m, $antes = null ) {
		$out = array();
		if ( isset( $m['avisos'] ) && is_array( $m['avisos'] ) ) {
			foreach ( $m['avisos'] as $x ) {
				$n = self::normalizar( $x );
				if ( $n ) {
					$out[ $n['id'] ] = $n;
				}
			}
			return array_values( $out );
		}
		if ( ! $antes ) {
			return array();
		}
		$prev = array();
		foreach ( array_merge( isset( $antes['archivos'] ) ? $antes['archivos'] : array(), isset( $antes['muestras'] ) ? $antes['muestras'] : array() ) as $a ) {
			$prev[ $a['ruta'] ] = isset( $a['origen_sha256'] ) ? $a['origen_sha256'] : $a['sha256'];
		}
		foreach ( array( 'archivos', 'muestras' ) as $g ) {
			foreach ( isset( $m[ $g ] ) ? $m[ $g ] : array() as $a ) {
				$h = isset( $a['origen_sha256'] ) ? $a['origen_sha256'] : $a['sha256'];
				if ( isset( $prev[ $a['ruta'] ] ) && $prev[ $a['ruta'] ] === $h ) {
					continue;
				}
				$n = self::normalizar(
					array(
						'id'     => substr( hash( 'sha256', 'legado|' . $a['ruta'] . '|' . $h ), 0, 16 ),
						'grupo'  => $g,
						'tipo'   => isset( $prev[ $a['ruta'] ] ) ? 'actualizacion' : 'nuevo',
						'ruta'   => $a['ruta'],
						'titulo' => isset( $a['titulo'] ) ? $a['titulo'] : '',
						'nota'   => isset( $a['novedades'] ) ? (string) $a['novedades'] : '',
						'fecha_unix' => isset( $m['fecha_unix'] ) ? $m['fecha_unix'] : 0,
					)
				);
				if ( $n ) {
					$out[] = $n;
				}
			}
		}
		return $out;
	}

	/**
	 * Decide quién recibe qué (función pura).
	 *
	 * @param array $entradas       Entradas normalizadas.
	 * @param array $pedidos        Filas con id, email, nombre, producto, vigente (bool). Solo pedidos entregados y sin bloquear.
	 * @param array $contactos      email => array( id, boletin, baja, muestras_desde ).
	 * @param array $rutas_producto producto => array( ruta, … ).
	 * @return array Elementos: email, nombre, clase, pedido_id, contacto_id, aviso_id, grupo, ruta, titulo, tipo, nota, detalle.
	 */
	public static function planificar( array $entradas, array $pedidos, array $contactos, array $rutas_producto ) {
		$items = array();
		$vistos = array();
		$baja  = static function ( $email ) use ( $contactos ) {
			return isset( $contactos[ $email ] ) && ! empty( $contactos[ $email ]['baja'] );
		};
		$cid   = static function ( $email ) use ( $contactos ) {
			return isset( $contactos[ $email ] ) ? (int) $contactos[ $email ]['id'] : 0;
		};
		$compradores = array();
		foreach ( $pedidos as $p ) {
			if ( ! isset( $compradores[ $p['email'] ] ) ) {
				$compradores[ $p['email'] ] = $p['nombre'];
			}
		}
		foreach ( $entradas as $e ) {
			$base = array(
				'aviso_id' => $e['id'],
				'grupo'    => $e['grupo'],
				'ruta'     => $e['ruta'],
				'titulo'   => $e['titulo'],
				'tipo'     => $e['tipo'],
				'nota'     => $e['nota'],
				'detalle'  => wp_json_encode( array( 'ubicacion' => $e['ubicacion'], 'antes' => $e['antes'], 'ahora' => $e['ahora'], 'alcance' => $e['alcance'] ) ),
			);
			$add = static function ( $email, $nombre, $clase, $pid, $c ) use ( &$items, &$vistos, $base ) {
				$k = $email . '|' . $clase . '|' . $base['ruta'] . '|' . $pid;
				if ( ! isset( $vistos[ $k ] ) ) {
					$vistos[ $k ] = 1;
					$items[]      = array_merge( $base, array( 'email' => $email, 'nombre' => (string) $nombre, 'clase' => $clase, 'pedido_id' => (int) $pid, 'contacto_id' => (int) $c ) );
				}
			};
			$informados = array();
			if ( 'archivos' === $e['grupo'] ) {
				foreach ( array( true, false ) as $vig ) {
					foreach ( $pedidos as $p ) {
						$incluye = isset( $rutas_producto[ $p['producto'] ] ) && in_array( $e['ruta'], $rutas_producto[ $p['producto'] ], true );
						if ( ! $incluye || (bool) $p['vigente'] !== $vig ) {
							continue;
						}
						if ( $vig ) {
							$add( $p['email'], $p['nombre'], 'material', $p['id'], $cid( $p['email'] ) );
						} elseif ( ! isset( $informados[ $p['email'] ] ) && ! $baja( $p['email'] ) ) {
							$add( $p['email'], $p['nombre'], 'renovar', $p['id'], $cid( $p['email'] ) );
						}
						$informados[ $p['email'] ] = 1;
					}
				}
			}
			if ( 'muestras' === $e['grupo'] ) {
				foreach ( $contactos as $email => $c ) {
					if ( ! empty( $c['muestras_desde'] ) && empty( $c['baja'] ) ) {
						$add( $email, isset( $c['nombre'] ) ? $c['nombre'] : '', 'muestra', 0, $c['id'] );
						$informados[ $email ] = 1;
					}
				}
			}
			if ( 'nuevo' === $e['tipo'] || in_array( $e['grupo'], array( 'producto', 'nota' ), true ) ) {
				foreach ( $compradores as $email => $nombre ) {
					if ( ! isset( $informados[ $email ] ) && ! $baja( $email ) ) {
						$add( $email, $nombre, 'novedad', 0, $cid( $email ) );
						$informados[ $email ] = 1;
					}
				}
				foreach ( $contactos as $email => $c ) {
					if ( (int) $c['boletin'] && empty( $c['baja'] ) && ! isset( $informados[ $email ] ) ) {
						$add( $email, isset( $c['nombre'] ) ? $c['nombre'] : '', 'novedad', 0, $c['id'] );
						$informados[ $email ] = 1;
					}
				}
			}
		}
		return $items;
	}

	// ------------------------------------------------------------------ Datos

	public static function vigente( array $p, $ahora = null ) {
		$ahora = null === $ahora ? time() : $ahora;
		$hasta = ! empty( $p['actualizaciones_hasta'] ) ? strtotime( $p['actualizaciones_hasta'] . ' UTC' ) : strtotime( $p['creado'] . ' UTC +12 months' );
		return $hasta > $ahora;
	}

	private static function datos_destinatarios() {
		global $wpdb;
		$tp      = OGC_Pedidos::tabla();
		$tc      = OGC_Pedidos::tabla( 'contactos' );
		$pedidos = array();
		foreach ( (array) $wpdb->get_results( "SELECT id, email, nombre, producto, creado, actualizaciones_hasta FROM $tp WHERE notificado = 1 AND bloqueado = 0 ORDER BY id DESC", ARRAY_A ) as $p ) { // phpcs:ignore
			$p['vigente'] = self::vigente( $p );
			$pedidos[]    = $p;
		}
		$contactos = array();
		foreach ( (array) $wpdb->get_results( "SELECT id, email, nombre, boletin, baja, muestras_desde FROM $tc", ARRAY_A ) as $c ) { // phpcs:ignore
			$contactos[ $c['email'] ] = $c;
		}
		$rutas = array();
		foreach ( OGC_Config::PRODUCTOS_VALIDOS as $prod ) {
			$rutas[ $prod ] = wp_list_pluck( OGC_Config::archivos( $prod ), 'rel' );
		}
		return array( $pedidos, $contactos, $rutas );
	}

	/** Mete en la cola las entradas (sin duplicar pendientes). Devuelve cuántos elementos nuevos. */
	public static function encolar( array $entradas ) {
		global $wpdb;
		list( $pedidos, $contactos, $rutas ) = self::datos_destinatarios();
		$t = OGC_Pedidos::tabla( 'cola' );
		$n = 0;
		foreach ( self::planificar( $entradas, $pedidos, $contactos, $rutas ) as $it ) {
			$ya = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE enviado IS NULL AND email = %s AND clase = %s AND ruta = %s AND pedido_id = %d", $it['email'], $it['clase'], $it['ruta'], $it['pedido_id'] ) ); // phpcs:ignore
			if ( $ya ) {
				$wpdb->update( $t, array( 'aviso_id' => $it['aviso_id'], 'titulo' => $it['titulo'], 'nota' => $it['nota'], 'detalle' => $it['detalle'] ), array( 'id' => (int) $ya ) );
				continue;
			}
			$wpdb->insert( $t, array_merge( $it, array( 'creado' => current_time( 'mysql', true ) ) ) );
			++$n;
		}
		return $n;
	}

	/** Avisos pendientes de 1.2.x (tabla ogc_avisos) → cola nueva. Devuelve cuántos. */
	public static function absorber_legado() {
		global $wpdb;
		$ta    = OGC_Pedidos::tabla( 'avisos' );
		$filas = (array) $wpdb->get_results( "SELECT id, pedido_id, ruta, novedades FROM $ta WHERE enviado IS NULL ORDER BY id LIMIT 500", ARRAY_A ); // phpcs:ignore
		$n     = 0;
		$tc    = OGC_Pedidos::tabla( 'cola' );
		foreach ( $filas as $f ) {
			$p = OGC_Pedidos::obtener( (int) $f['pedido_id'] );
			if ( $p && ! $p['bloqueado'] ) {
				$clase = self::vigente( $p ) ? 'material' : 'renovar';
				$ya    = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $tc WHERE enviado IS NULL AND email = %s AND clase = %s AND ruta = %s AND pedido_id = %d", $p['email'], $clase, $f['ruta'], $p['id'] ) ); // phpcs:ignore
				if ( ! $ya ) {
					$wpdb->insert(
						$tc,
						array(
							'creado' => current_time( 'mysql', true ), 'email' => $p['email'], 'nombre' => $p['nombre'], 'clase' => $clase, 'pedido_id' => (int) $p['id'], 'contacto_id' => 0,
							'aviso_id' => 'legado-' . (int) $f['id'], 'grupo' => 'archivos', 'ruta' => $f['ruta'], 'titulo' => self::titulo_de_ruta( $f['ruta'] ),
							'tipo' => 'Documento nuevo.' === $f['novedades'] ? 'nuevo' : 'actualizacion', 'nota' => $f['novedades'], 'detalle' => '{}',
						)
					);
					++$n;
				}
			}
			$wpdb->update( $ta, array( 'enviado' => current_time( 'mysql', true ) ), array( 'id' => (int) $f['id'] ) );
		}
		return $n;
	}

	/**
	 * Procesa las entradas de aviso del manifiesto aplicado que aún no se han tratado. $antes: manifiesto anterior
	 * (null = primera instalación: se marcan como tratadas sin enviar nada). Devuelve líneas para el escritorio.
	 */
	public static function procesar( $antes, array $m ) {
		$hechos = get_option( self::OPC_HECHOS, array() );
		$hechos = is_array( $hechos ) ? $hechos : array();
		$nuevas = array();
		$viejas = 0;
		foreach ( self::entradas( $m, $antes ) as $e ) {
			if ( isset( $hechos[ $e['id'] ] ) ) {
				continue;
			}
			$hechos[ $e['id'] ] = time();
			if ( $e['fecha_unix'] && $e['fecha_unix'] < time() - self::CADUCIDAD ) {
				++$viejas;
				continue;
			}
			$nuevas[] = $e;
		}
		foreach ( $hechos as $id => $t ) {
			if ( $t < time() - 120 * DAY_IN_SECONDS ) {
				unset( $hechos[ $id ] );
			}
		}
		update_option( self::OPC_HECHOS, $hechos, false );
		if ( ! $nuevas ) {
			return $viejas ? array( $viejas . ' avisos antiguos del paquete marcados como tratados (no se envían).' ) : array();
		}
		if ( ! $antes ) {
			return array( 'Primera instalación: ' . count( $nuevas ) . ' avisos del paquete marcados como tratados (no se envían).' );
		}
		$n = self::encolar( $nuevas );
		OGC_Materiales::historial_avisos( $nuevas );
		wp_schedule_single_event( time() + self::REPOSO, self::CRON_LOTE );
		$c = array( 'nuevo' => 0, 'actualizacion' => 0 );
		foreach ( $nuevas as $e ) {
			++$c[ $e['tipo'] ];
		}
		OGC_Seguridad::registrar( null, 'avisos', count( $nuevas ) . ' entradas (' . $c['nuevo'] . ' nuevas, ' . $c['actualizacion'] . ' actualizaciones) → ' . $n . ' avisos en cola' );
		return array( count( $nuevas ) . ' novedades del paquete (' . $c['nuevo'] . ' nuevas, ' . $c['actualizacion'] . ' actualizaciones): ' . $n . ' avisos en cola. Salen hoy (un correo por persona) a partir de ' . (int) ( self::REPOSO / 60 ) . ' minutos, entre las 09:00 y las 22:00, o al pulsar «Enviar avisos ahora».' );
	}

	public static function pendientes( $solo_listos = false ) {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'cola' );
		$w = $solo_listos ? $wpdb->prepare( ' AND creado <= %s', gmdate( 'Y-m-d H:i:s', time() - self::REPOSO ) ) : '';
		return (int) $wpdb->get_var( "SELECT COUNT(DISTINCT email) FROM $t WHERE enviado IS NULL" . $w ); // phpcs:ignore
	}

	// ------------------------------------------------------------------ Envío

	/** Envía un lote. $forzar: a cualquier hora y sin esperar el reposo. Devuelve cuántos correos. */
	public static function enviar( $forzar = false ) {
		global $wpdb;
		self::absorber_legado();
		$dia = self::dia( time() );
		if ( get_option( self::OPC_FORZAR ) === $dia ) {
			$forzar = true;
		}
		if ( ! $forzar && ! self::en_ventana( time() ) ) {
			return 0;
		}
		$t      = OGC_Pedidos::tabla( 'cola' );
		$te     = OGC_Pedidos::tabla( 'envios' );
		$limite = gmdate( 'Y-m-d H:i:s', $forzar ? time() + 60 : time() - self::REPOSO );
		$emails = (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT email FROM $t WHERE enviado IS NULL AND creado <= %s AND email NOT IN (SELECT email FROM $te WHERE dia = %s) ORDER BY email LIMIT %d", $limite, $dia, self::LOTE ) ); // phpcs:ignore
		$n      = 0;
		foreach ( $emails as $email ) {
			if ( self::enviar_a( $email, $dia ) ) {
				++$n;
			}
		}
		if ( count( $emails ) === self::LOTE ) {
			wp_schedule_single_event( time() + 300, self::CRON_LOTE );
		} else {
			$quedan = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE enviado IS NULL AND email NOT IN (SELECT email FROM $te WHERE dia = %s)", $dia ) ); // phpcs:ignore
			if ( ! $quedan ) {
				delete_option( self::OPC_FORZAR );
			} elseif ( ! $forzar ) {
				wp_schedule_single_event( time() + 300, self::CRON_LOTE );
			}
			self::resumen( $dia );
		}
		return $n;
	}

	/** Contacto (con id para la baja) de un email; lo crea si es un comprador sin contacto. */
	private static function contacto( $email, $nombre ) {
		$c = OGC_Contactos::obtener( $email );
		if ( ! $c ) {
			$id = OGC_Contactos::guardar( $email, array( 'nombre' => mb_substr( (string) $nombre, 0, 120 ), 'origen' => 'compra', 'ip' => '' ) );
			$c  = OGC_Contactos::obtener_id( $id );
		}
		return $c;
	}

	/** Bloque de un documento: qué cambia, dónde, antes/ahora y recomendación. */
	public static function html_item( array $it, $con_recomendacion = true ) {
		$d   = json_decode( (string) $it['detalle'], true );
		$d   = is_array( $d ) ? $d : array();
		$e   = array( 'OGC_Correo', 'e' );
		$h   = '<li style="margin-bottom:12px"><strong>' . call_user_func( $e, $it['titulo'] ) . '</strong> · ' . ( 'nuevo' === $it['tipo'] ? 'nuevo' : 'actualizado' ) . '<br>'
			. '<span>' . ( 'nuevo' === $it['tipo'] ? '' : 'Qué cambia: ' ) . call_user_func( $e, $it['nota'] ) . '</span>';
		if ( ! empty( $d['ubicacion'] ) ) {
			$h .= '<br><span>Dónde: ' . call_user_func( $e, $d['ubicacion'] ) . '</span>';
		}
		if ( ! empty( $d['antes'] ) || ! empty( $d['ahora'] ) ) {
			$h .= '<br><span>Antes: «' . call_user_func( $e, ! empty( $d['antes'] ) ? $d['antes'] : '—' ) . '». Ahora: «' . call_user_func( $e, ! empty( $d['ahora'] ) ? $d['ahora'] : '—' ) . '».</span>';
		}
		if ( $con_recomendacion ) {
			$h .= '<br><em>' . call_user_func( $e, self::recomendacion( $it['tipo'], isset( $d['alcance'] ) ? $d['alcance'] : '', $it['grupo'] ) ) . '</em>';
		}
		return $h . '</li>';
	}

	/** Compone y envía el correo del día de un email con todo lo pendiente. */
	public static function enviar_a( $email, $dia ) {
		global $wpdb;
		$t     = OGC_Pedidos::tabla( 'cola' );
		$filas = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE enviado IS NULL AND email = %s ORDER BY id", $email ), ARRAY_A ); // phpcs:ignore
		if ( ! $filas ) {
			return false;
		}
		// Dedupe: una vez por clase+ruta+pedido; si hay «material» de una ruta, no se repite como renovar o novedad.
		$sec    = array( 'material' => array(), 'renovar' => array(), 'muestra' => array(), 'novedad' => array() );
		$vistos = array();
		$mat    = array();
		foreach ( $filas as $f ) {
			if ( 'material' === $f['clase'] ) {
				$mat[ $f['ruta'] ] = 1;
			}
		}
		$nombre = '';
		foreach ( $filas as $f ) {
			$k = $f['clase'] . '|' . $f['ruta'] . '|' . $f['pedido_id'];
			if ( isset( $vistos[ $k ] ) || ( in_array( $f['clase'], array( 'renovar', 'novedad' ), true ) && isset( $mat[ $f['ruta'] ] ) ) || ! isset( $sec[ $f['clase'] ] ) ) {
				continue;
			}
			$vistos[ $k ]          = 1;
			$sec[ $f['clase'] ][] = $f;
			$nombre               = '' !== $nombre ? $nombre : (string) $f['nombre'];
		}
		$c       = self::contacto( $email, $nombre );
		$baja_c  = $c && ! empty( $c['baja'] );
		if ( $baja_c ) { // tras la baja solo sale lo contratado (material vigente)
			$sec['renovar'] = $sec['muestra'] = $sec['novedad'] = array();
		}
		$e       = array( 'OGC_Correo', 'e' );
		$html    = '<p>Hola' . ( '' !== $nombre ? ', ' . call_user_func( $e, $nombre ) : '' ) . ':</p>';
		$docs    = array();
		$pedidos = array();
		// 1. Material de pedidos con actualizaciones vigentes.
		$por_pedido = array();
		foreach ( $sec['material'] as $f ) {
			$por_pedido[ (int) $f['pedido_id'] ][] = $f;
		}
		foreach ( $por_pedido as $pid => $its ) {
			$p = OGC_Pedidos::obtener( $pid );
			if ( ! $p || $p['bloqueado'] ) {
				continue;
			}
			OGC_Pedidos::renovar( $pid );
			$p          = OGC_Pedidos::obtener( $pid );
			$pedidos[]  = $p['pedido'];
			$lista      = '';
			foreach ( $its as $f ) {
				$lista .= self::html_item( $f );
				$docs[] = $f['titulo'];
			}
			$html .= '<h2 style="color:#1F4E79;font-size:18px">Material de tu pedido</h2><p>Hemos actualizado documentos de tu pedido <strong>' . call_user_func( $e, $p['pedido'] ) . '</strong> (' . call_user_func( $e, OGC_Config::nombre_producto( $p['producto'] ) ) . '):</p><ul>' . $lista . '</ul>'
				. '<p style="margin:20px 0">' . OGC_Correo::boton( OGC_Descargas::url_pedido( $p ), 'Ver el material actualizado' ) . '</p>'
				. '<p style="font-size:14px">Tu enlace se ha renovado (los anteriores dejan de funcionar) y vale hasta el ' . call_user_func( $e, get_date_from_gmt( $p['caduca'], 'd/m/Y' ) ) . '. Los documentos nuevos llevan, como siempre, tu nombre, email y número de pedido. Cada archivo actualizado se puede volver a descargar ' . (int) OGC_Config::descargas_archivo() . ' veces.'
				. ( $p['actualizaciones_hasta'] ? ' Actualizaciones incluidas hasta el ' . call_user_func( $e, get_date_from_gmt( $p['actualizaciones_hasta'], 'd/m/Y' ) ) . '.' : '' ) . '</p>';
		}
		// 2. Versión nueva para compradores sin actualizaciones vigentes.
		$renovados  = 0;
		$por_pedido = array();
		foreach ( $sec['renovar'] as $f ) {
			$por_pedido[ (int) $f['pedido_id'] ][] = $f;
		}
		foreach ( $por_pedido as $pid => $its ) {
			$p = OGC_Pedidos::obtener( $pid );
			if ( ! $p || $p['bloqueado'] ) {
				continue;
			}
			$lista = '';
			foreach ( $its as $f ) {
				$lista .= self::html_item( $f, false );
				$docs[] = $f['titulo'];
			}
			++$renovados;
			$hasta = $p['actualizaciones_hasta'] ? get_date_from_gmt( $p['actualizaciones_hasta'], 'd/m/Y' ) : '';
			$html .= '<h2 style="color:#1F4E79;font-size:18px">Hay una versión nueva de tu material</h2><p>Hemos mejorado el material que compraste (pedido <strong>' . call_user_func( $e, $p['pedido'] ) . '</strong>, ' . call_user_func( $e, OGC_Config::nombre_producto( $p['producto'] ) ) . '):</p><ul>' . $lista . '</ul>'
				. '<p>Los 12 meses de actualizaciones incluidas en tu compra terminaron' . ( $hasta ? ' el ' . call_user_func( $e, $hasta ) : '' ) . ', así que esta versión no se incluye en tu pedido (<a href="' . call_user_func( $e, home_url( '/condiciones/' ) ) . '" style="color:#1F4E79">condiciones de venta</a>). Si quieres tenerla, responde a este correo y te contamos cómo renovar tu acceso, o mira el material en la <a href="' . call_user_func( $e, home_url( '/tienda/' ) ) . '" style="color:#1F4E79">tienda</a>.</p>';
		}
		// 3. Muestras nuevas o actualizadas (enlaces firmados de 7 días).
		if ( $sec['muestra'] && $c ) {
			$enl   = array();
			foreach ( OGC_Contactos::enlaces_muestras( $c ) as $x ) {
				$enl[ $x['ruta'] ] = $x;
			}
			$todas_nuevas = true;
			$lista        = '';
			foreach ( $sec['muestra'] as $f ) {
				$todas_nuevas = $todas_nuevas && 'nuevo' === $f['tipo'];
				$li           = self::html_item( $f );
				if ( isset( $enl[ $f['ruta'] ] ) ) {
					$li = substr( $li, 0, -5 ) . '<br><a href="' . call_user_func( $e, $enl[ $f['ruta'] ]['url'] ) . '" style="color:#1F4E79;font-weight:bold">Descargar: ' . call_user_func( $e, $enl[ $f['ruta'] ]['titulo'] ) . '</a></li>';
					unset( $enl[ $f['ruta'] ] );
				}
				$lista .= $li;
				$docs[] = $f['titulo'];
			}
			$html .= '<h2 style="color:#1F4E79;font-size:18px">' . ( $todas_nuevas ? 'Hay muestras nuevas' : 'Tus muestras se han actualizado' ) . '</h2><p>Como pediste las muestras de Preparador OGC, te avisamos de los cambios (los enlaces valen 7 días):</p><ul>' . $lista . '</ul>';
			if ( $enl ) {
				$html .= '<p style="font-size:14px">Las demás muestras, por si las necesitas: ';
				$l     = array();
				foreach ( $enl as $x ) {
					$l[] = '<a href="' . call_user_func( $e, $x['url'] ) . '" style="color:#1F4E79">' . call_user_func( $e, $x['titulo'] ) . '</a>';
				}
				$html .= implode( ' · ', $l ) . '.</p>';
			}
		}
		// 4. Novedades.
		if ( $sec['novedad'] ) {
			$lista = '';
			foreach ( $sec['novedad'] as $f ) {
				$lista .= '<li><strong>' . call_user_func( $e, $f['titulo'] ) . '</strong>: ' . call_user_func( $e, $f['nota'] )
					. ( 'muestras' === $f['grupo'] ? ' <a href="' . call_user_func( $e, home_url( '/muestras-gratis/' ) ) . '" style="color:#1F4E79">Pedir las muestras</a>' : '' ) . '</li>';
				$docs[] = $f['titulo'];
			}
			$html .= '<h2 style="color:#1F4E79;font-size:18px">Novedades en Preparador OGC</h2><ul>' . $lista . '</ul><p>' . OGC_Correo::boton( home_url( '/tienda/' ), 'Ver el material', true ) . '</p>';
		}
		$ids = wp_list_pluck( $filas, 'id' );
		if ( ! $pedidos ) { // ningún pedido con material se ha podido mostrar (bloqueado o borrado)
			$sec['material'] = array();
		}
		if ( ! $renovados ) {
			$sec['renovar'] = array();
		}
		$hay = array_filter( $sec );
		if ( ! $hay || ! $docs ) { // todo descartado (baja, pedido bloqueado…): se marca sin enviar
			self::marcar( $ids, 0 );
			return false;
		}
		if ( $sec['material'] ) {
			$titulo = 'Tu material se ha actualizado';
			$asunto = $titulo . ( 1 === count( $pedidos ) ? ' · pedido ' . $pedidos[0] : '' );
		} elseif ( $sec['muestra'] ) {
			$titulo = isset( $todas_nuevas ) && $todas_nuevas ? 'Nuevas muestras de Preparador OGC' : 'Tus muestras de Preparador OGC se han actualizado';
			$asunto = $titulo;
		} elseif ( $sec['renovar'] ) {
			$titulo = 'Hay una versión nueva de tu material';
			$asunto = $titulo . ' de Preparador OGC';
		} else {
			$titulo = 'Novedades en Preparador OGC';
			$asunto = 1 === count( $sec['novedad'] ) ? 'Novedad en Preparador OGC: ' . $sec['novedad'][0]['titulo'] : $titulo;
		}
		// Pie: por qué lo recibe y baja de un clic.
		$por = array();
		if ( $sec['material'] ) {
			$por[] = 'tienes actualizaciones incluidas en tu compra';
		}
		if ( $sec['renovar'] || ( $sec['novedad'] && OGC_Pedidos::de_email( $email ) ) ) {
			$por[] = 'compraste material de Preparador OGC';
		}
		if ( $sec['muestra'] ) {
			$por[] = 'pediste las muestras y aceptaste que te avisemos de sus cambios';
		}
		if ( $sec['novedad'] && $c && (int) $c['boletin'] ) {
			$por[] = 'te suscribiste a los avisos de novedades y al boletín';
		}
		$baja = $c ? OGC_Contactos::url_baja( $c ) : '';
		$pie  = '<br>Recibes este aviso porque ' . OGC_Correo::e( implode( ', ', $por ) ) . '.'
			. ( $baja ? ' <a href="' . OGC_Correo::e( $baja ) . '" style="color:#1F4E79">Darme de baja de estos avisos con un clic</a>.' : '' )
			. ( $sec['material'] ? ' Los avisos de actualización de tu pedido forman parte del servicio contratado y los seguirás recibiendo mientras duren tus actualizaciones.' : '' );
		$cab  = $baja ? array( 'List-Unsubscribe: <' . $baja . '>, <mailto:' . OGC_Config::correo() . '?subject=Baja%20de%20los%20avisos>', 'List-Unsubscribe-Post: List-Unsubscribe=One-Click' ) : array();
		$ok   = OGC_Correo::enviar( $email, $asunto, $titulo, $html, $cab, $pie );
		$te   = OGC_Pedidos::tabla( 'envios' );
		$wpdb->insert(
			$te,
			array(
				'fecha'      => current_time( 'mysql', true ),
				'dia'        => $dia,
				'email'      => $email,
				'clases'     => implode( ',', array_keys( $hay ) ),
				'documentos' => mb_substr( implode( ' · ', array_unique( $docs ) ), 0, 4000 ),
				'asunto'     => mb_substr( $asunto, 0, 250 ),
				'n'          => count( $docs ),
				'estado'     => $ok ? 'enviado' : 'fallo',
			)
		);
		if ( $ok ) {
			self::marcar( $ids, (int) $wpdb->insert_id );
		}
		return (bool) $ok;
	}

	private static function marcar( array $ids, $envio ) {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'cola' );
		foreach ( $ids as $id ) {
			$wpdb->update( $t, array( 'enviado' => current_time( 'mysql', true ), 'envio_id' => (int) $envio ), array( 'id' => (int) $id ) );
		}
	}

	/** Resumen del día a Vicente con los envíos aún no comunicados. */
	public static function resumen( $dia ) {
		global $wpdb;
		$r     = get_option( self::OPC_RESUMEN, array() );
		$desde = is_array( $r ) && isset( $r['dia'], $r['ultimo'] ) && $r['dia'] === $dia ? (int) $r['ultimo'] : 0;
		$te    = OGC_Pedidos::tabla( 'envios' );
		$filas = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $te WHERE dia = %s AND id > %d ORDER BY id", $dia, $desde ), ARRAY_A ); // phpcs:ignore
		if ( ! $filas ) {
			return false;
		}
		$cuenta = array();
		$fallos = 0;
		$lineas = '';
		foreach ( $filas as $f ) {
			foreach ( explode( ',', $f['clases'] ) as $cl ) {
				$cuenta[ $cl ] = ( isset( $cuenta[ $cl ] ) ? $cuenta[ $cl ] : 0 ) + 1;
			}
			$fallos += 'enviado' === $f['estado'] ? 0 : 1;
			$lineas .= "\n· " . $f['email'] . ' · ' . $f['clases'] . ' · ' . $f['documentos'] . ( 'enviado' === $f['estado'] ? '' : ' · FALLO' );
		}
		$t = count( $filas ) . ' correos de avisos (' . $dia . ')' . ( $desde ? ', además de los ya comunicados hoy' : '' ) . ":\n";
		foreach ( self::CLASES as $k => $txt ) {
			if ( isset( $cuenta[ $k ] ) ) {
				$t .= '· ' . $txt . ': ' . $cuenta[ $k ] . "\n";
			}
		}
		$t .= ( $fallos ? "\n¡" . $fallos . ' correos han fallado! Se reintentan mañana.' . "\n" : '' ) . "\nDetalle:" . $lineas;
		update_option( self::OPC_RESUMEN, array( 'dia' => $dia, 'ultimo' => (int) end( $filas )['id'] ), false );
		return OGC_Pedidos::avisar_admin( 'Avisos enviados hoy: ' . count( $filas ) . ' correos', $t );
	}

	// ------------------------------------------------------------------ Cron y escritorio

	/** Cada hora (desde OGC_Boletin::cron): latido, legado y envío si toca. */
	public static function cron() {
		update_option( self::OPC_LATIDO, time(), false );
		if ( self::pendientes() ) {
			self::enviar( false );
		}
	}

	public static function lote() {
		update_option( self::OPC_LATIDO, time(), false );
		self::enviar( false );
	}

	/** Si hay avisos pendientes y no hay ningún lote programado, programa uno (red de seguridad en cada init). */
	public static function vigilar_cron() {
		if ( get_transient( 'ogc_ventas_vigila' ) ) {
			return;
		}
		set_transient( 'ogc_ventas_vigila', 1, 15 * MINUTE_IN_SECONDS );
		if ( ! wp_next_scheduled( self::CRON_LOTE ) && self::pendientes( true ) && self::en_ventana( time() ) ) {
			wp_schedule_single_event( time() + 30, self::CRON_LOTE );
		}
	}

	/** Botón «Enviar avisos ahora»: aplica el paquete si hay uno nuevo y envía ya (a cualquier hora). */
	public static function enviar_ahora() {
		$l = OGC_Materiales::comprobar( 'manual (avisos)' );
		update_option( self::OPC_FORZAR, self::dia( time() ), false );
		$n   = self::enviar( true );
		$l[] = $n . ' correos de avisos enviados ahora.' . ( self::pendientes() ? ' Quedan ' . self::pendientes() . ' destinatarios: unos en el siguiente lote (5 min) y los que ya han recibido hoy su correo, mañana.' : '' );
		return $l;
	}
}
