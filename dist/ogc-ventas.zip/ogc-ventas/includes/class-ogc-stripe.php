<?php
/**
 * Webhook de Stripe: POST https://organizacionygestioncomercial.es/wp-json/ogc/v1/stripe-webhook
 *
 * Eventos que hay que activar en Stripe para este endpoint:
 *   checkout.session.completed
 *   checkout.session.async_payment_succeeded   (pagos diferidos, p. ej. SEPA)
 *
 * La firma se verifica a mano (sin la librería de Stripe) con el método documentado por Stripe:
 * cabecera Stripe-Signature = "t=<timestamp>,v1=<firma>[,v1=...]", firma = HMAC-SHA256(secreto, "<t>.<cuerpo>").
 */

defined( 'ABSPATH' ) || exit;

class OGC_Stripe {

	const TOLERANCIA = 300; // segundos: se rechazan avisos antiguos (protección contra reenvíos)

	public static function registrar_ruta() {
		register_rest_route(
			'ogc/v1',
			'/stripe-webhook',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'recibir' ),
				'permission_callback' => '__return_true', // la autenticación es la firma de Stripe
			)
		);
	}

	/**
	 * Comprueba la firma. Devuelve true o un texto con el motivo del rechazo.
	 */
	public static function verificar_firma( $cuerpo, $cabecera, $secreto, $ahora = null ) {
		if ( ! $secreto || ! $cabecera ) {
			return 'sin secreto o sin cabecera';
		}
		$t     = null;
		$v1    = array();
		foreach ( explode( ',', $cabecera ) as $parte ) {
			$kv = explode( '=', trim( $parte ), 2 );
			if ( 2 !== count( $kv ) ) {
				continue;
			}
			if ( 't' === $kv[0] ) {
				$t = $kv[1];
			} elseif ( 'v1' === $kv[0] ) {
				$v1[] = $kv[1];
			}
		}
		if ( ! $t || ! ctype_digit( $t ) || ! $v1 ) {
			return 'cabecera mal formada';
		}
		$ahora = $ahora ? $ahora : time();
		if ( abs( $ahora - (int) $t ) > self::TOLERANCIA ) {
			return 'marca de tiempo fuera de tolerancia';
		}
		$esperada = hash_hmac( 'sha256', $t . '.' . $cuerpo, $secreto );
		foreach ( $v1 as $firma ) {
			if ( hash_equals( $esperada, $firma ) ) { // comparación en tiempo constante
				return true;
			}
		}
		return 'firma no válida';
	}

	public static function recibir( WP_REST_Request $req ) {
		$cuerpo = $req->get_body(); // cuerpo en bruto: imprescindible para la firma
		$ok     = self::verificar_firma( $cuerpo, $req->get_header( 'stripe_signature' ), OGC_Config::whsec() );
		if ( true !== $ok ) {
			return new WP_REST_Response( array( 'error' => 'firma' ), 400 ); // sin detalles hacia fuera
		}
		$evento = json_decode( $cuerpo, true );
		if ( ! is_array( $evento ) || empty( $evento['type'] ) || empty( $evento['data']['object'] ) ) {
			return new WP_REST_Response( array( 'error' => 'evento' ), 400 );
		}
		$tipos = array( 'checkout.session.completed', 'checkout.session.async_payment_succeeded' );
		if ( ! in_array( $evento['type'], $tipos, true ) ) {
			return new WP_REST_Response( array( 'ignorado' => $evento['type'] ), 200 );
		}
		$s = $evento['data']['object'];
		if ( ( isset( $s['payment_status'] ) ? $s['payment_status'] : '' ) !== 'paid' ) {
			// Pago aún no confirmado (p. ej. SEPA): llegará async_payment_succeeded.
			return new WP_REST_Response( array( 'pendiente' => true ), 200 );
		}
		if ( empty( $evento['livemode'] ) && 'live' === OGC_Config::modo_stripe() ) {
			return new WP_REST_Response( array( 'ignorado' => 'evento de prueba' ), 200 );
		}

		$producto = OGC_Config::producto_de_sesion( $s );
		$email    = isset( $s['customer_details']['email'] ) ? sanitize_email( $s['customer_details']['email'] ) : '';
		$nombre   = isset( $s['customer_details']['name'] ) ? sanitize_text_field( $s['customer_details']['name'] ) : '';
		// Si el Payment Link tiene un campo personalizado con clave «nombre», manda ese (nombre del opositor).
		foreach ( isset( $s['custom_fields'] ) ? (array) $s['custom_fields'] : array() as $cf ) {
			if ( isset( $cf['key'], $cf['text']['value'] ) && 'nombre' === $cf['key'] && '' !== trim( $cf['text']['value'] ) ) {
				$nombre = sanitize_text_field( $cf['text']['value'] );
			}
		}
		if ( ! $nombre ) {
			$nombre = $email ? strstr( $email, '@', true ) : '';
		}
		$datos = array(
			'stripe_session' => sanitize_text_field( $s['id'] ),
			'nombre'         => $nombre,
			'email'          => $email,
			'producto'       => $producto,
			'importe'        => isset( $s['amount_total'] ) ? (int) $s['amount_total'] : 0,
			'moneda'         => isset( $s['currency'] ) ? sanitize_text_field( $s['currency'] ) : 'eur',
		);
		if ( ! $producto || ! is_email( $email ) ) {
			OGC_Pedidos::avisar_admin( 'Venta de Stripe sin producto o sin email', "Revise la sesión {$datos['stripe_session']} en Stripe: falta el metadato ogc_producto o el email.\n" );
			return new WP_REST_Response( array( 'revisar' => true ), 200 ); // 200: reintentar no lo arreglaría
		}

		$id = OGC_Pedidos::crear( $datos ); // idempotente: el mismo session id no crea dos pedidos
		// Casilla opcional de boletín en el Payment Link (campo personalizado «boletin», tipo desplegable o casilla):
		// solo cuenta si el comprador la eligió expresamente.
		foreach ( isset( $s['custom_fields'] ) ? (array) $s['custom_fields'] : array() as $cf ) {
			if ( isset( $cf['key'] ) && 'boletin' === $cf['key'] && ( ( isset( $cf['dropdown']['value'] ) && 'si' === $cf['dropdown']['value'] ) ) ) {
				OGC_Contactos::alta_boletin( $email, $nombre, 'compra-stripe', OGC_Contactos::TEXTO_BOLETIN, 'stripe:' . $datos['stripe_session'], '' );
			}
		}
		if ( $id && OGC_Pedidos::marcar_notificado( $id ) ) {
			OGC_Pedidos::enviar_enlace( $id );
			OGC_Pedidos::avisar_admin_venta( $id );
			wp_schedule_single_event( time() + 5, 'ogc_ventas_presellar', array( $id ) ); // sella en segundo plano
		}
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}
}
