<?php
/**
 * Pedidos y tablas propias (1.1.0): pedidos, accesos, dispositivos, contactos, consentimientos y avisos de
 * actualización. Correo de compra en HTML y aviso a Vicente.
 *
 * 1.3.0: tablas «cola» (avisos pendientes por persona) y «envios» (registro de cada correo de avisos); columna
 * contactos.muestras_desde (quién pidió las muestras), rellenada con los consentimientos del formulario.
 *
 * 1.2.0: tabla «descargas» (contador por pedido, archivo y versión); las IP de accesos y dispositivos se guardan como
 * hash con sal (HMAC con la clave del sitio) y la red como hash del /24 o /48; los registros anteriores se migran al
 * actualizar. Textos en «tú».
 */

defined( 'ABSPATH' ) || exit;

class OGC_Pedidos {

	const DB_VERSION = '1.3.0';

	public static function tabla( $t = 'pedidos' ) {
		global $wpdb;
		return $wpdb->prefix . 'ogc_' . $t;
	}

	/** Crea o actualiza las tablas (activación y cambio de versión). */
	public static function instalar() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$col = $wpdb->get_charset_collate();
		$p   = self::tabla();
		dbDelta(
			"CREATE TABLE $p (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			creado DATETIME NOT NULL,
			pedido VARCHAR(32) NOT NULL DEFAULT '',
			stripe_session VARCHAR(255) NULL,
			nombre VARCHAR(120) NOT NULL,
			email VARCHAR(190) NOT NULL,
			producto VARCHAR(32) NOT NULL,
			importe INT NOT NULL DEFAULT 0,
			moneda VARCHAR(8) NOT NULL DEFAULT 'eur',
			estado VARCHAR(20) NOT NULL DEFAULT 'pendiente',
			caduca DATETIME NOT NULL,
			version_enlace INT NOT NULL DEFAULT 1,
			descargas INT NOT NULL DEFAULT 0,
			notificado TINYINT NOT NULL DEFAULT 0,
			bloqueado TINYINT NOT NULL DEFAULT 0,
			motivo_bloqueo VARCHAR(190) NOT NULL DEFAULT '',
			actualizaciones_hasta DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY stripe_session (stripe_session),
			KEY email (email)
			) $col;"
		);
		$t = self::tabla( 'accesos' );
		dbDelta(
			"CREATE TABLE $t (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			fecha DATETIME NOT NULL,
			pedido_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			email VARCHAR(190) NOT NULL DEFAULT '',
			tipo VARCHAR(20) NOT NULL DEFAULT '',
			detalle VARCHAR(190) NOT NULL DEFAULT '',
			ip VARCHAR(45) NOT NULL DEFAULT '',
			red VARCHAR(60) NOT NULL DEFAULT '',
			pais CHAR(2) NOT NULL DEFAULT '',
			agente VARCHAR(250) NOT NULL DEFAULT '',
			dispositivo VARCHAR(16) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY pedido_fecha (pedido_id, fecha),
			KEY fecha (fecha)
			) $col;"
		);
		$t = self::tabla( 'dispositivos' );
		dbDelta(
			"CREATE TABLE $t (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			email VARCHAR(190) NOT NULL,
			disp VARCHAR(64) NOT NULL,
			huella VARCHAR(64) NOT NULL DEFAULT '',
			agente VARCHAR(250) NOT NULL DEFAULT '',
			ip VARCHAR(45) NOT NULL DEFAULT '',
			creado DATETIME NOT NULL,
			visto DATETIME NOT NULL,
			estado VARCHAR(12) NOT NULL DEFAULT 'activo',
			PRIMARY KEY  (id),
			UNIQUE KEY email_disp (email, disp),
			KEY email_estado (email, estado)
			) $col;"
		);
		$t = self::tabla( 'contactos' );
		dbDelta(
			"CREATE TABLE $t (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			email VARCHAR(190) NOT NULL,
			telefono VARCHAR(32) NOT NULL DEFAULT '',
			nombre VARCHAR(120) NOT NULL DEFAULT '',
			origen VARCHAR(20) NOT NULL DEFAULT '',
			creado DATETIME NOT NULL,
			ip VARCHAR(45) NOT NULL DEFAULT '',
			muestras INT NOT NULL DEFAULT 0,
			boletin TINYINT NOT NULL DEFAULT 0,
			boletin_desde DATETIME NULL,
			baja DATETIME NULL,
			ultimo_boletin VARCHAR(10) NOT NULL DEFAULT '',
			muestras_desde DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY email (email),
			KEY boletin (boletin)
			) $col;"
		);
		$t = self::tabla( 'consentimientos' );
		dbDelta(
			"CREATE TABLE $t (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			fecha DATETIME NOT NULL,
			email VARCHAR(190) NOT NULL,
			tipo VARCHAR(20) NOT NULL,
			accion VARCHAR(10) NOT NULL,
			texto TEXT NOT NULL,
			origen VARCHAR(40) NOT NULL DEFAULT '',
			ip VARCHAR(45) NOT NULL DEFAULT '',
			agente VARCHAR(250) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY email (email)
			) $col;"
		);
		$t = self::tabla( 'descargas' );
		dbDelta(
			"CREATE TABLE $t (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			pedido_id BIGINT UNSIGNED NOT NULL,
			archivo VARCHAR(190) NOT NULL,
			version VARCHAR(64) NOT NULL,
			n INT NOT NULL DEFAULT 0,
			rechazos INT NOT NULL DEFAULT 0,
			ultima DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY pedido_archivo_version (pedido_id, archivo, version)
			) $col;"
		);
		$t = self::tabla( 'avisos' );
		dbDelta(
			"CREATE TABLE $t (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			creado DATETIME NOT NULL,
			pedido_id BIGINT UNSIGNED NOT NULL,
			ruta VARCHAR(255) NOT NULL,
			novedades TEXT NOT NULL,
			enviado DATETIME NULL,
			PRIMARY KEY  (id),
			KEY pendientes (enviado, pedido_id)
			) $col;"
		);
		$t = self::tabla( 'cola' );
		dbDelta(
			"CREATE TABLE $t (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			creado DATETIME NOT NULL,
			email VARCHAR(190) NOT NULL,
			nombre VARCHAR(120) NOT NULL DEFAULT '',
			clase VARCHAR(12) NOT NULL,
			pedido_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			contacto_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			aviso_id VARCHAR(40) NOT NULL DEFAULT '',
			grupo VARCHAR(12) NOT NULL DEFAULT '',
			ruta VARCHAR(255) NOT NULL DEFAULT '',
			titulo VARCHAR(255) NOT NULL DEFAULT '',
			tipo VARCHAR(14) NOT NULL DEFAULT '',
			nota TEXT NOT NULL,
			detalle TEXT NOT NULL,
			enviado DATETIME NULL,
			envio_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY pendientes (enviado, email)
			) $col;"
		);
		$t = self::tabla( 'envios' );
		dbDelta(
			"CREATE TABLE $t (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			fecha DATETIME NOT NULL,
			dia VARCHAR(10) NOT NULL,
			email VARCHAR(190) NOT NULL,
			clases VARCHAR(60) NOT NULL DEFAULT '',
			documentos TEXT NOT NULL,
			asunto VARCHAR(255) NOT NULL DEFAULT '',
			n INT NOT NULL DEFAULT 0,
			estado VARCHAR(10) NOT NULL DEFAULT 'enviado',
			PRIMARY KEY  (id),
			KEY dia_email (dia, email),
			KEY fecha (fecha)
			) $col;"
		);
		$antes = (string) get_option( 'ogc_ventas_db', '' );
		update_option( 'ogc_ventas_db', self::DB_VERSION, false );
		OGC_Config::clave_firma(); // genera la clave de firma si no hay constante
		OGC_Config::dir();         // crea la carpeta privada
		if ( '' !== $antes && version_compare( $antes, '1.2.0', '<' ) ) {
			// 1.2.0: el total por pedido pasa de 300 a 400 (solo si seguía el valor por defecto anterior).
			$a = get_option( OGC_Config::OPC_AJUSTES, array() );
			if ( is_array( $a ) && isset( $a['descargas_max'] ) && 300 === (int) $a['descargas_max'] ) {
				$a['descargas_max'] = 400;
				update_option( OGC_Config::OPC_AJUSTES, $a, false );
			}
		}
		self::migrar_ips();
		self::migrar_muestras();
	}

	/** 1.3.0: marca quién pidió las muestras (fecha del primer consentimiento del formulario). Devuelve filas. */
	public static function migrar_muestras() {
		global $wpdb;
		$t = self::tabla( 'contactos' );
		$k = self::tabla( 'consentimientos' );
		return (int) $wpdb->query( "UPDATE $t SET muestras_desde = (SELECT MIN(fecha) FROM $k WHERE $k.email = $t.email AND $k.tipo = 'privacidad' AND $k.origen = 'formulario-muestras') WHERE muestras_desde IS NULL AND EXISTS (SELECT 1 FROM $k WHERE $k.email = $t.email AND $k.tipo = 'privacidad' AND $k.origen = 'formulario-muestras')" ); // phpcs:ignore
	}

	public static function quizas_actualizar() {
		if ( self::DB_VERSION !== get_option( 'ogc_ventas_db' ) ) {
			self::instalar();
		} elseif ( ! get_option( 'ogc_ventas_ips_hash' ) ) {
			self::migrar_ips(); // por si la migración quedó a medias (tablas muy grandes)
		}
	}

	/**
	 * 1.2.0: sustituye las IP en claro de accesos y dispositivos por su hash con sal, y la red por el hash del /24 o
	 * /48. Por tandas (máx. 20 000 filas por petición); marca la opción ogc_ventas_ips_hash al terminar. Devuelve las
	 * filas migradas.
	 */
	public static function migrar_ips( $max = 20000 ) {
		global $wpdb;
		$n = 0;
		foreach ( array( 'accesos', 'dispositivos' ) as $tb ) {
			$t = self::tabla( $tb );
			while ( $n < $max ) {
				$filas = (array) $wpdb->get_results( "SELECT id, ip FROM $t WHERE ip <> '' AND ip NOT LIKE 'h:%' ORDER BY id LIMIT 500", ARRAY_A ); // phpcs:ignore
				if ( ! $filas ) {
					break;
				}
				foreach ( $filas as $f ) {
					$d = array( 'ip' => OGC_Config::ip_hash( $f['ip'] ) );
					if ( 'accesos' === $tb ) {
						$d['red'] = OGC_Config::red_hash( $f['ip'] );
					}
					$wpdb->update( $t, $d, array( 'id' => (int) $f['id'] ) );
					++$n;
				}
			}
		}
		if ( $n < $max ) {
			update_option( 'ogc_ventas_ips_hash', time(), false );
		}
		return $n;
	}

	/** Inserta el pedido; si la sesión de Stripe ya existía devuelve el id existente. */
	public static function crear( array $d ) {
		global $wpdb;
		$t = self::tabla();
		if ( ! empty( $d['stripe_session'] ) ) {
			$id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE stripe_session = %s", $d['stripe_session'] ) ); // phpcs:ignore
			if ( $id ) {
				return (int) $id;
			}
		}
		$ok = $wpdb->insert(
			$t,
			array(
				'creado'                => current_time( 'mysql', true ),
				'stripe_session'        => ! empty( $d['stripe_session'] ) ? $d['stripe_session'] : null,
				'nombre'                => mb_substr( $d['nombre'], 0, 80 ),
				'email'                 => strtolower( $d['email'] ),
				'producto'              => $d['producto'],
				'importe'               => (int) $d['importe'],
				'moneda'                => $d['moneda'],
				'estado'                => OGC_Materiales::hay_materiales() ? 'pendiente' : 'manual',
				'caduca'                => gmdate( 'Y-m-d H:i:s', time() + OGC_Config::dias_enlace() * DAY_IN_SECONDS ),
				'actualizaciones_hasta' => gmdate( 'Y-m-d H:i:s', strtotime( '+12 months' ) ),
			)
		);
		if ( ! $ok ) {
			return ! empty( $d['stripe_session'] )
				? (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE stripe_session = %s", $d['stripe_session'] ) ) // phpcs:ignore
				: 0;
		}
		$id = (int) $wpdb->insert_id;
		$wpdb->update( $t, array( 'pedido' => sprintf( 'OGC-%s-%04d', gmdate( 'Y' ), $id ) ), array( 'id' => $id ) );
		self::registrar_csv( $id );
		return $id;
	}

	public static function marcar_notificado( $id ) {
		global $wpdb;
		$t = self::tabla();
		return 1 === (int) $wpdb->query( $wpdb->prepare( "UPDATE $t SET notificado = 1 WHERE id = %d AND notificado = 0", $id ) ); // phpcs:ignore
	}

	public static function obtener( $id ) {
		global $wpdb;
		$t = self::tabla();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore
	}

	public static function de_email( $email ) {
		global $wpdb;
		$t = self::tabla();
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE email = %s ORDER BY id DESC", strtolower( $email ) ), ARRAY_A ); // phpcs:ignore
	}

	public static function actualizar( $id, array $campos ) {
		global $wpdb;
		return $wpdb->update( self::tabla(), $campos, array( 'id' => (int) $id ) );
	}

	public static function fecha( array $p ) {
		return get_date_from_gmt( $p['creado'], 'd/m/Y' );
	}

	/** Nueva caducidad y nueva versión de enlace (los enlaces anteriores dejan de valer). */
	public static function renovar( $id ) {
		global $wpdb;
		$t = self::tabla();
		$wpdb->query( $wpdb->prepare( "UPDATE $t SET caduca = %s, version_enlace = version_enlace + 1, descargas = 0 WHERE id = %d", gmdate( 'Y-m-d H:i:s', time() + OGC_Config::dias_enlace() * DAY_IN_SECONDS ), $id ) ); // phpcs:ignore
	}

	/** Pone a cero el total y los contadores por archivo del pedido (botón del escritorio). */
	public static function reiniciar_descargas( $id ) {
		global $wpdb;
		self::actualizar( $id, array( 'descargas' => 0 ) );
		return $wpdb->delete( self::tabla( 'descargas' ), array( 'pedido_id' => (int) $id ) );
	}

	public static function bloquear( $id, $motivo ) {
		return self::actualizar( $id, array( 'bloqueado' => 1, 'motivo_bloqueo' => mb_substr( (string) $motivo, 0, 180 ) ) );
	}

	public static function desbloquear( $id ) {
		return self::actualizar( $id, array( 'bloqueado' => 0, 'motivo_bloqueo' => '' ) );
	}

	/** Párrafos comunes: cómo se usa el material según la modalidad activa. */
	public static function html_modalidad() {
		$n = OGC_Config::max_dispositivos();
		if ( 'pdf' === OGC_Config::entrega() ) {
			$t = '<p>Desde tu página de descarga puedes bajar cada PDF o todo en un ZIP, en un máximo de <strong>' . $n . ' dispositivos</strong>. Los PDF llevan tu nombre, email y número de pedido en cada página.</p>';
		} else {
			$t = '<p><strong>Lectura online:</strong> puedes leer el material en el lector de tu área privada desde un máximo de <strong>' . $n . ' dispositivos</strong> (ordenador, tableta o móvil).</p>';
			if ( 'ambos' === OGC_Config::entrega() ) {
				$t .= '<p><strong>PDF personal:</strong> además puedes descargar los PDF sellados con tu nombre, email y número de pedido en cada página.</p>';
			}
		}
		$t .= '<p><strong>Primer acceso desde cada navegador:</strong> te pediremos el email de la compra y te enviaremos un código de 6 dígitos para confirmar que eres tú; así ese navegador queda registrado como uno de tus dispositivos. Si necesitas cambiar de dispositivo, escríbenos y liberamos uno.</p>';
		if ( OGC_Config::hay_pdf() ) {
			$t .= '<p style="font-size:14px">Cada archivo se puede descargar como máximo ' . (int) OGC_Config::descargas_archivo() . ' veces en cada versión (si lo actualizamos, vuelves a tener ' . (int) OGC_Config::descargas_archivo() . ' descargas). Guárdalo bien después de descargarlo.</p>';
		}
		return $t;
	}

	/** Correo al comprador (HTML) con el enlace a su página del pedido. */
	public static function enviar_enlace( $id ) {
		$p = self::obtener( $id );
		if ( ! $p ) {
			return false;
		}
		$e      = array( 'OGC_Correo', 'e' );
		$url    = OGC_Descargas::url_pedido( $p );
		$prod   = OGC_Config::nombre_producto( $p['producto'] );
		$caduca = get_date_from_gmt( $p['caduca'], 'd/m/Y' );
		$hasta  = $p['actualizaciones_hasta'] ? get_date_from_gmt( $p['actualizaciones_hasta'], 'd/m/Y' ) : '';
		$c      = '<p>Hola, ' . call_user_func( $e, $p['nombre'] ) . ':</p>'
			. '<p>Gracias por tu compra de <strong>' . call_user_func( $e, $prod ) . '</strong>. Número de pedido: <strong>' . call_user_func( $e, $p['pedido'] ) . '</strong>'
			. ( $p['importe'] ? ' · Importe: ' . call_user_func( $e, number_format( $p['importe'] / 100, 2, ',', '.' ) . ' ' . strtoupper( $p['moneda'] ) ) : '' ) . '.</p>'
			. '<p style="margin:20px 0">' . OGC_Correo::boton( $url, OGC_Config::hay_lector() ? 'Acceder a mi material' : 'Descargar mi material' ) . '</p>'
			. '<p style="font-size:14px">Este enlace es personal y vale hasta el ' . call_user_func( $e, $caduca ) . '. No lo reenvíes: en un navegador nuevo hace falta el código que llega a este email. Si caduca, escríbenos y te lo renovamos.</p>'
			. self::html_modalidad()
			. ( 'manual' === $p['estado'] ? OGC_Correo::nota( 'Tu material se está preparando. Si la página aún no muestra los archivos, recibirás otro aviso en unas horas.' ) : '' )
			. OGC_Correo::nota( '<strong>Licencia de uso personal e intransferible.</strong> El material va personalizado con tu nombre, email y número de pedido. Está prohibida su venta, reproducción o difusión (Real Decreto Legislativo 1/1996, Ley de Propiedad Intelectual). Se registran los accesos (fecha, navegador y la IP cifrada con un código irreversible) para detectar usos no autorizados; un uso anómalo puede suponer el bloqueo del acceso.' )
			. '<p><strong>Actualizaciones:</strong> durante 12 meses' . ( $hasta ? ' (hasta el ' . call_user_func( $e, $hasta ) . ')' : '' ) . ', si un documento cambia por una modificación normativa o de datos, te avisaremos por correo con un enlace renovado.</p>'
			. '<p><strong>Factura:</strong> si la necesitas, responde a este correo con tu nombre o razón social, NIF y domicilio y te la enviamos.</p>'
			. '<p style="font-size:14px"><strong>Confirmación del consentimiento:</strong> antes de pagar aceptaste las <a href="' . call_user_func( $e, home_url( '/condiciones/' ) ) . '" style="color:#1F4E79">condiciones de venta</a> y diste tu consentimiento expreso para recibir el contenido digital de inmediato, reconociendo que con ello pierdes el derecho de desistimiento sobre el material (art. 103.m del TRLGDCU). Las clases, si las has contratado, conservan 14 días naturales de desistimiento.</p>'
			. '<p>Para cualquier duda, responde a este correo o escríbenos a <a href="mailto:' . call_user_func( $e, OGC_Config::correo() ) . '" style="color:#1F4E79">' . call_user_func( $e, OGC_Config::correo() ) . '</a>.</p>';
		return OGC_Correo::enviar( $p['email'], 'Tu material de Preparador OGC · pedido ' . $p['pedido'], 'Tu material ya está disponible', $c );
	}

	public static function avisar_admin( $asunto, $texto ) {
		$c = '<p>' . nl2br( OGC_Correo::e( $texto ) ) . '</p><p><a href="' . OGC_Correo::e( admin_url( 'tools.php?page=ogc-ventas' ) ) . '">Herramientas → OGC Ventas</a></p>';
		return OGC_Correo::enviar( OGC_Config::aviso_email(), '[OGC Ventas] ' . $asunto, $asunto, $c );
	}

	public static function avisar_admin_venta( $id ) {
		$p = self::obtener( $id );
		$t = "Pedido {$p['pedido']} · " . OGC_Config::nombre_producto( $p['producto'] ) . ' · ' . number_format( $p['importe'] / 100, 2, ',', '.' ) . ' ' . strtoupper( $p['moneda'] ) . "\n"
			. "Comprador: {$p['nombre']} <{$p['email']}>\nEstado: {$p['estado']}\nEntrega: " . OGC_Config::ENTREGAS[ OGC_Config::entrega() ] . "\n";
		if ( 'manual' === $p['estado'] ) {
			$t .= "\nLos materiales aún no están en la web (falta la clave o la primera descarga). Puedes sellarlo a mano:\n"
				. "python3 sellar_pedido.py --nombre \"{$p['nombre']}\" --email {$p['email']} --pedido {$p['pedido']} --producto {$p['producto']} --salida entregas\n";
		}
		return self::avisar_admin( 'Nueva venta ' . $p['pedido'], $t );
	}

	/** Línea en <carpeta privada>/registro_ventas.csv. */
	public static function registrar_csv( $id ) {
		$p   = self::obtener( $id );
		$dir = OGC_Config::dir();
		if ( ! $p || ! $dir || ! is_writable( $dir ) ) {
			return;
		}
		$ruta  = $dir . '/registro_ventas.csv';
		$nuevo = ! file_exists( $ruta );
		$fh    = fopen( $ruta, 'a' ); // phpcs:ignore
		if ( ! $fh ) {
			return;
		}
		flock( $fh, LOCK_EX );
		if ( $nuevo ) {
			fputcsv( $fh, array( 'fecha_hora', 'fecha_venta', 'pedido', 'nombre', 'email', 'producto', 'importe', 'moneda', 'stripe_session', 'origen' ) );
		}
		fputcsv( $fh, array_map( array( __CLASS__, 'csv_seguro' ), array( current_time( 'c' ), self::fecha( $p ), $p['pedido'], $p['nombre'], $p['email'], $p['producto'], $p['importe'], $p['moneda'], $p['stripe_session'], $p['stripe_session'] ? 'stripe' : 'manual' ) ) );
		flock( $fh, LOCK_UN );
		fclose( $fh ); // phpcs:ignore
	}

	/** Prefijo «'» si empieza por = + - @ (evita fórmulas al abrir el CSV en Excel). */
	public static function csv_seguro( $v ) {
		return preg_match( '/^[=+\-@\t\r]/', (string) $v ) ? "'" . $v : $v;
	}
}
