<?php
/**
 * Configuración (1.1.0): todo se configura desde el escritorio (Herramientas → OGC Ventas → Ajustes).
 * Las constantes de wp-config.php, si existen, siguen teniendo prioridad (OGC_STRIPE_WEBHOOK_SECRET,
 * OGC_DESCARGA_CLAVE, OGC_VENTAS_DIR, OGC_STRIPE_MODO, OGC_CORREO, OGC_AVISO_EMAIL, OGC_DESCARGA_DIAS, OGC_DESCARGAS_MAX,
 * OGC_MATERIALES_CLAVE).
 *
 * 1.2.0: límite de descargas por archivo y versión (2 por defecto) y total por pedido de 400; producto «pack_programacion».
 *
 * Secretos en opciones NO autocargadas: clave de firma de enlaces (se genera sola), secreto del webhook de Stripe y
 * clave de los materiales. Nunca se muestran enteros en pantalla.
 *
 * 1.1.1: la clave de los materiales ya no hace falta pegarla. El sitio genera una vez su par X25519 (opción no
 * autocargada) y muestra su CLAVE PÚBLICA en Ajustes y en Materiales; publicar_materiales.py --destinatario la añade y
 * el manifiesto firmado lleva la clave de materiales en un sobre sellado para este sitio. Prioridad: constante
 * OGC_MATERIALES_CLAVE de wp-config.php > clave guardada (pegada o abierta del sobre).
 */

defined( 'ABSPATH' ) || exit;

class OGC_Config {

	const PRODUCTOS_VALIDOS = array( 'temario', 'supuestos', 'programacion', 'pack', 'pack_clases', 'pack_programacion' );

	/**
	 * Productos nuevos que se pueden vender aunque el paquete publicado aún no los traiga: nombre y producto cuyos
	 * archivos entrega (si el manifiesto los define, manda el manifiesto).
	 */
	const RESERVA = array(
		'pack_programacion' => array( 'nombre' => 'Pack Programación OGC (5 programaciones modelo + 5 h de corrección y clase)', 'incluye' => array( 'programacion' ) ),
	);

	const OPC_AJUSTES   = 'ogc_ventas_ajustes';
	const OPC_FIRMA     = 'ogc_ventas_clave_firma';
	const OPC_WHSEC     = 'ogc_ventas_whsec';
	const OPC_CLAVE_MAT = 'ogc_ventas_clave_materiales';
	const OPC_PAR_SITIO = 'ogc_ventas_par_sitio'; // par X25519 del sitio (1.1.1), no autocargado
	const OPC_DIR       = 'ogc_ventas_dir';
	const OPC_DIR_AVISO = 'ogc_ventas_dir_aviso';

	const URL_MATERIALES = 'https://raw.githubusercontent.com/preparadorpga/web-ogc/main/materiales/';

	/** Modalidades de entrega (decisión de Vicente 12/11/2026 08:58: «ambos» por defecto). */
	const ENTREGAS = array(
		'pdf'    => 'PDF sellado (descarga)',
		'online' => 'Lector online (máximo de dispositivos, sin descarga)',
		'ambos'  => 'Online + PDF (lector online con máximo de dispositivos y PDF sellado descargable)',
	);

	public static function defectos() {
		return array(
			'modo_stripe'       => 'test',
			'entrega'           => 'ambos',
			'dias_enlace'       => 30,
			'descargas_max'     => 400, // total por pedido (1.2.0: antes 300)
			'descargas_archivo' => 2,   // por archivo y versión (1.2.0)
			'max_dispositivos'  => 2,
			'umbral_redes'      => 5,   // redes IP distintas (/24) en 24 h por pedido
			'umbral_paises'     => 2,   // países distintos en 24 h (si el servidor da el país)
			'umbral_descargas'  => 80,  // descargas en 24 h por pedido
			'bloqueo_auto'      => 0,
			'aviso_email'       => '',
			'url_materiales'    => self::URL_MATERIALES,
			'materiales_auto'   => 1,
			'boletin_activo'    => 1,
			'motor_lector'      => 'auto', // auto | pdfjs | imagen
		);
	}

	/** Valor de una constante de wp-config.php o $defecto. */
	public static function get( $nombre, $defecto = null ) {
		return defined( $nombre ) ? constant( $nombre ) : $defecto;
	}

	public static function ajustes() {
		$a = get_option( self::OPC_AJUSTES, array() );
		return array_merge( self::defectos(), is_array( $a ) ? $a : array() );
	}

	public static function ajuste( $k ) {
		$a = self::ajustes();
		return isset( $a[ $k ] ) ? $a[ $k ] : null;
	}

	public static function entrega() {
		$e = (string) self::ajuste( 'entrega' );
		return isset( self::ENTREGAS[ $e ] ) ? $e : 'ambos';
	}

	public static function hay_lector() {
		return in_array( self::entrega(), array( 'online', 'ambos' ), true );
	}

	public static function hay_pdf() {
		return in_array( self::entrega(), array( 'pdf', 'ambos' ), true );
	}

	public static function max_dispositivos() {
		return max( 1, min( 5, (int) self::ajuste( 'max_dispositivos' ) ) );
	}

	public static function modo_stripe() {
		$c = self::get( 'OGC_STRIPE_MODO' );
		if ( $c ) {
			return 'live' === $c ? 'live' : 'test';
		}
		return 'live' === self::ajuste( 'modo_stripe' ) ? 'live' : 'test';
	}

	public static function dias_enlace() {
		return max( 1, (int) self::get( 'OGC_DESCARGA_DIAS', self::ajuste( 'dias_enlace' ) ) );
	}

	public static function descargas_max() {
		return max( 1, (int) self::get( 'OGC_DESCARGAS_MAX', self::ajuste( 'descargas_max' ) ) );
	}

	/** Descargas permitidas de cada archivo en cada versión (1.2.0). */
	public static function descargas_archivo() {
		return max( 1, min( 50, (int) self::ajuste( 'descargas_archivo' ) ) );
	}

	// ------------------------------------------------------------------ Secretos

	/** Guarda una opción secreta, no autocargada. */
	public static function guardar_secreto( $opcion, $valor ) {
		delete_option( $opcion );
		if ( '' !== (string) $valor ) {
			add_option( $opcion, (string) $valor, '', 'no' );
		}
	}

	/** Clave de firma de enlaces y cookies: constante o, si no existe, generada y guardada la primera vez. */
	public static function clave_firma() {
		$c = (string) self::get( 'OGC_DESCARGA_CLAVE', '' );
		if ( strlen( $c ) >= 32 ) {
			return $c;
		}
		$o = (string) get_option( self::OPC_FIRMA, '' );
		if ( strlen( $o ) < 64 ) {
			$o = bin2hex( random_bytes( 32 ) );
			self::guardar_secreto( self::OPC_FIRMA, $o );
		}
		return $o;
	}

	public static function whsec() {
		$c = (string) self::get( 'OGC_STRIPE_WEBHOOK_SECRET', '' );
		return '' !== $c ? $c : (string) get_option( self::OPC_WHSEC, '' );
	}

	public static function whsec_origen() {
		return self::get( 'OGC_STRIPE_WEBHOOK_SECRET' ) ? 'wp-config.php' : ( get_option( self::OPC_WHSEC ) ? 'Ajustes' : '' );
	}

	public static function clave_materiales() {
		$c = (string) self::get( 'OGC_MATERIALES_CLAVE', '' );
		if ( '' !== $c ) {
			return OGC_Cripto::clave_materiales( $c );
		}
		return OGC_Cripto::clave_materiales( (string) get_option( self::OPC_CLAVE_MAT, '' ) );
	}

	/** De dónde sale la clave de materiales: 'wp-config.php', 'Ajustes' o ''. */
	public static function clave_materiales_origen() {
		return self::get( 'OGC_MATERIALES_CLAVE' ) ? 'wp-config.php' : ( get_option( self::OPC_CLAVE_MAT ) ? 'Ajustes' : '' );
	}

	/** Par X25519 del sitio (binario), generado y guardado (no autocargado) la primera vez. '' si no hay sodium. */
	public static function par_sitio() {
		$o   = (string) get_option( self::OPC_PAR_SITIO, '' );
		$par = base64_decode( $o, true );
		if ( false !== $par && '' !== OGC_Cripto::publica_de_par( $par ) ) {
			return $par;
		}
		$nuevo = OGC_Cripto::nuevo_par();
		if ( null === $nuevo ) {
			return '';
		}
		if ( '' !== $o ) {
			delete_option( self::OPC_PAR_SITIO ); // valor dañado: se sustituye
		}
		if ( ! add_option( self::OPC_PAR_SITIO, base64_encode( $nuevo ), '', 'no' ) ) { // otra petición lo creó a la vez
			$par = base64_decode( (string) get_option( self::OPC_PAR_SITIO, '' ), true );
			return ( false !== $par && '' !== OGC_Cripto::publica_de_par( $par ) ) ? $par : '';
		}
		return $nuevo;
	}

	/** Clave pública del sitio en base64 (la que se da a publicar_materiales.py --destinatario). */
	public static function publica_sitio() {
		$p = OGC_Cripto::publica_de_par( self::par_sitio() );
		return '' === $p ? '' : base64_encode( $p );
	}

	public static function huella_sitio() {
		return OGC_Cripto::huella_publica( OGC_Cripto::publica_de_par( self::par_sitio() ) );
	}

	/** Texto enmascarado para la pantalla: solo los 4 últimos caracteres. */
	public static function mascara( $v ) {
		$v = (string) $v;
		return '' === $v ? '' : str_repeat( '•', 10 ) . substr( $v, -4 );
	}

	// ------------------------------------------------------------------ Correo

	public static function correo() {
		$c = (string) self::get( 'OGC_CORREO', 'preparador@organizacionygestioncomercial.es' );
		return is_email( $c ) ? $c : 'preparador@organizacionygestioncomercial.es';
	}

	public static function aviso_email() {
		$c = (string) self::get( 'OGC_AVISO_EMAIL', self::ajuste( 'aviso_email' ) );
		return is_email( $c ) ? $c : self::correo();
	}

	// ------------------------------------------------------------------ Carpeta privada

	/**
	 * Carpeta privada (sin barra final). Orden: constante OGC_VENTAS_DIR; la guardada; si no hay, se crea
	 * dirname(ABSPATH)/ogc_privado (fuera de public_html) y, si no se puede, wp-content/uploads/ogc_privado_<azar>
	 * con .htaccess de denegación (y se avisa en el escritorio).
	 */
	public static function dir() {
		$d = (string) self::get( 'OGC_VENTAS_DIR', '' );
		if ( '' !== $d ) {
			$r = realpath( $d );
			return $r ? rtrim( $r, '/\\' ) : '';
		}
		$g = (string) get_option( self::OPC_DIR, '' );
		if ( '' !== $g && is_dir( $g ) && is_writable( $g ) ) {
			return rtrim( $g, '/\\' );
		}
		return self::crear_dir();
	}

	public static function crear_dir() {
		$fuera = dirname( rtrim( ABSPATH, '/\\' ) ) . '/ogc_privado';
		$cands = array( $fuera );
		$up    = function_exists( 'wp_upload_dir' ) ? wp_upload_dir( null, false ) : array();
		if ( ! empty( $up['basedir'] ) ) {
			$prev    = (string) get_option( self::OPC_DIR, '' );
			$cands[] = ( '' !== $prev && false !== strpos( $prev, '/ogc_privado_' ) ) ? $prev : $up['basedir'] . '/ogc_privado_' . strtolower( wp_generate_password( 20, false ) );
		}
		foreach ( $cands as $c ) {
			if ( ( is_dir( $c ) || @wp_mkdir_p( $c ) ) && is_writable( $c ) ) { // phpcs:ignore
				$r = rtrim( realpath( $c ), '/\\' );
				self::proteger_dir( $r );
				update_option( self::OPC_DIR, $r, false );
				update_option( self::OPC_DIR_AVISO, self::dentro_de_la_web( $r ) ? 1 : 0, false );
				return $r;
			}
		}
		return '';
	}

	/** .htaccess de denegación e index.php vacío (defensa adicional; fuera de la web no hacen falta). */
	public static function proteger_dir( $d ) {
		if ( ! file_exists( $d . '/.htaccess' ) ) {
			@file_put_contents( $d . '/.htaccess', "Require all denied\nDeny from all\nOptions -Indexes\n" ); // phpcs:ignore
		}
		if ( ! file_exists( $d . '/index.php' ) ) {
			@file_put_contents( $d . '/index.php', "<?php\n// Silencio.\n" ); // phpcs:ignore
		}
	}

	/** Subcarpeta de la carpeta privada (se crea y protege). */
	public static function sub( $nombre ) {
		$d = self::dir();
		if ( '' === $d ) {
			return '';
		}
		$s = $d . '/' . preg_replace( '/[^a-z0-9_-]/', '', $nombre );
		if ( ! is_dir( $s ) ) {
			wp_mkdir_p( $s );
			self::proteger_dir( $s );
		}
		return $s;
	}

	public static function dentro_de_la_web( $ruta ) {
		$web = realpath( ABSPATH );
		return $web && 0 === strpos( rtrim( $ruta, '/\\' ) . '/', rtrim( $web, '/\\' ) . '/' );
	}

	/** Lista de problemas de configuración (vacía si todo está bien). */
	public static function problemas() {
		$p   = array();
		$dir = self::dir();
		if ( '' === $dir ) {
			$p[] = 'No se ha podido crear la carpeta privada. Pide al hosting permiso de escritura en la carpeta de la cuenta o define OGC_VENTAS_DIR.';
		} elseif ( self::dentro_de_la_web( $dir ) ) {
			$p[] = 'La carpeta privada está dentro de public_html (' . $dir . '): está protegida con .htaccess y nombres aleatorios, pero es más seguro fuera. Si el hosting lo permite, crea la carpeta «ogc_privado» junto a public_html y pulsa «Volver a crear la carpeta privada».';
		}
		if ( '' === self::whsec() ) {
			$p[] = 'Falta el secreto del webhook de Stripe (Ajustes).';
		}
		if ( ! self::clave_materiales() && ! OGC_Materiales::hay_materiales() ) {
			$p[] = 'Aún no hay clave de los materiales: envía la clave pública de este sitio (pestaña Materiales, huella ' . self::huella_sitio() . ') a quien publica el paquete para que la añada con publicar_materiales.py --destinatario; después pulsa «Comprobar materiales ahora». No hace falta pegar ninguna clave secreta.';
		} elseif ( ! OGC_Materiales::hay_materiales() ) {
			$p[] = 'Aún no se han descargado los materiales: pulsa «Comprobar materiales ahora» en la pestaña Materiales.';
		}
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			$p[] = 'El servidor no tiene sodium: no se puede verificar la firma del paquete de materiales.';
		}
		return $p;
	}

	// ------------------------------------------------------------------ Productos y archivos

	/** Mapa de productos: el del paquete de materiales firmado o, si no hay, productos.json de la carpeta privada. */
	public static function productos() {
		static $cache = null;
		if ( null === $cache ) {
			$m = OGC_Materiales::manifiesto();
			if ( $m && isset( $m['productos'] ) && is_array( $m['productos'] ) ) {
				$cache = array( 'productos' => $m['productos'], 'stripe_payment_links' => isset( $m['stripe_payment_links'] ) ? $m['stripe_payment_links'] : array() );
			} else {
				$json  = @file_get_contents( self::dir() . '/productos.json' ); // phpcs:ignore
				$cache = $json ? json_decode( $json, true ) : array();
				$cache = is_array( $cache ) ? $cache : array();
			}
		}
		return $cache;
	}

	public static function nombre_producto( $producto ) {
		$p = self::productos();
		if ( isset( $p['productos'][ $producto ]['nombre'] ) ) {
			return $p['productos'][ $producto ]['nombre'];
		}
		return isset( self::RESERVA[ $producto ] ) ? self::RESERVA[ $producto ]['nombre'] : $producto;
	}

	/**
	 * Archivos del producto: array( 'ruta' (plantilla descifrada), 'rel', 'carpeta', 'nombre', 'sellar', 'sha256', 'mapa' ).
	 * Solo archivos del paquete firmado: nunca rutas del sistema de archivos que vengan de fuera.
	 */
	public static function archivos( $producto, $nivel = 0 ) {
		$conf = self::productos();
		if ( $nivel > 3 ) {
			return array();
		}
		if ( isset( $conf['productos'][ $producto ] ) ) {
			$p = $conf['productos'][ $producto ];
		} elseif ( isset( self::RESERVA[ $producto ] ) ) {
			$p = self::RESERVA[ $producto ];
		} else {
			return array();
		}
		if ( isset( $p['incluye'] ) ) {
			$out = array();
			foreach ( (array) $p['incluye'] as $sub ) {
				$out = array_merge( $out, self::archivos( $sub, $nivel + 1 ) );
			}
			return $out;
		}
		$carpeta = isset( $p['carpeta_zip'] ) ? sanitize_file_name( $p['carpeta_zip'] ) : $producto;
		$out     = array();
		$lista   = OGC_Materiales::archivos();
		foreach ( array( 'archivos' => true, 'extras_sin_sellar' => false ) as $clave => $sellar ) {
			foreach ( isset( $p[ $clave ] ) ? (array) $p[ $clave ] : array() as $patron ) {
				$hay = array();
				foreach ( $lista as $rel => $a ) {
					if ( fnmatch( $patron, $rel ) && $a['tipo'] === ( $sellar ? 'pdf' : 'xlsx' ) ) {
						$hay[ $rel ] = $a;
					}
				}
				ksort( $hay );
				foreach ( $hay as $rel => $a ) {
					$ruta = OGC_Materiales::ruta_local( $a );
					$out[] = array(
						'rel'     => $rel,
						'ruta'    => $ruta,
						'carpeta' => $carpeta,
						'nombre'  => basename( $rel ),
						'sellar'  => $sellar,
						'sha256'  => $a['sha256'],
						'mapa'    => isset( $a['mapa'] ) ? $a['mapa'] : null,
						'paginas' => isset( $a['mapa']['paginas'] ) ? (int) $a['mapa']['paginas'] : 0,
					);
				}
			}
		}
		return $out;
	}

	/** Producto de una sesión de Checkout: metadato ogc_producto o mapa de Payment Links. */
	public static function producto_de_sesion( array $s ) {
		$prod = isset( $s['metadata']['ogc_producto'] ) ? (string) $s['metadata']['ogc_producto'] : '';
		if ( ! $prod && ! empty( $s['payment_link'] ) ) {
			$mapa = self::productos();
			$mapa = isset( $mapa['stripe_payment_links'] ) ? $mapa['stripe_payment_links'] : array();
			$prod = isset( $mapa[ $s['payment_link'] ] ) ? (string) $mapa[ $s['payment_link'] ] : '';
		}
		return in_array( $prod, self::PRODUCTOS_VALIDOS, true ) ? $prod : '';
	}

	/** IP del visitante (REMOTE_ADDR; SiteGround la da ya corregida tras su proxy). Solo en memoria: no se guarda en claro. */
	public static function ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : ''; // phpcs:ignore
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
	}

	/** Hash con sal (HMAC con la clave del sitio) de la IP del visitante, o de $ip (1.2.0). */
	public static function ip_hash( $ip = null ) {
		return OGC_Cripto::hash_ip( self::clave_firma(), null === $ip ? self::ip() : $ip );
	}

	/** Hash de la red /24 (IPv4) o /48 (IPv6) del visitante, o de $ip (1.2.0). */
	public static function red_hash( $ip = null ) {
		return OGC_Cripto::hash_red( self::clave_firma(), null === $ip ? self::ip() : $ip );
	}

	public static function agente() {
		return isset( $_SERVER['HTTP_USER_AGENT'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 250 ) : ''; // phpcs:ignore
	}

	/** País, solo si el servidor o una CDN lo da en una cabecera (Cloudflare, GeoIP). Si no, vacío. */
	public static function pais() {
		foreach ( array( 'HTTP_CF_IPCOUNTRY', 'GEOIP_COUNTRY_CODE', 'HTTP_X_COUNTRY_CODE', 'HTTP_X_GEO_COUNTRY' ) as $k ) {
			if ( ! empty( $_SERVER[ $k ] ) && preg_match( '/^[A-Z]{2}$/', (string) $_SERVER[ $k ] ) ) { // phpcs:ignore
				return (string) $_SERVER[ $k ]; // phpcs:ignore
			}
		}
		return '';
	}
}
