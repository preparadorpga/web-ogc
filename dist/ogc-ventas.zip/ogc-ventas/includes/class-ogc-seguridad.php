<?php
/**
 * Vigilancia y dispositivos (1.1.0).
 *
 *  - Registro de cada acceso (página del pedido, descarga, lector, entrada al área): fecha, hash de la IP, hash de la
 *    red /24, país si el servidor lo da, navegador y dispositivo.
 *  - Alerta por email a Vicente (una vez al día por pedido) si en 24 h un pedido se usa desde demasiadas redes o
 *    países distintos, o supera el número de descargas; bloqueo automático opcional (desactivado por defecto).
 *  - Dispositivos: cookie firmada «ogc_disp» (HttpOnly, Secure, SameSite=Lax, 2 años) con un identificador al azar,
 *    más una huella básica (navegador + idioma). Máximo N dispositivos activos por comprador (email); un dispositivo
 *    más queda bloqueado con un mensaje y Vicente puede liberar dispositivos desde el escritorio.
 *
 * 1.2.0 (adoptado de PGA):
 *  - Un dispositivo NUEVO solo se registra después de verificar el email de la compra con un código de 6 dígitos
 *    (OGC_Descargas::verificacion), o si la sesión se abrió con el enlace mágico del área privada (que ya llega a ese
 *    email). Así un enlace reenviado no sirve a otra persona. Vale para el lector y para las descargas.
 *  - Las IP se guardan como hash con sal (HMAC con la clave del sitio) y la «red» como hash del /24 o /48.
 *
 * Límites honestos: borrar las cookies o usar el modo privado cuenta como dispositivo nuevo (por eso el tope frena a
 * quien comparte el acceso); nada de esto impide fotografiar la pantalla. Lo que disuade es la marca personal.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Seguridad {

	const COOKIE = 'ogc_disp';

	// ------------------------------------------------------------------ Lógica pura (se prueba sin WordPress)

	/**
	 * Decide si un dispositivo puede entrar.
	 *
	 * @param array  $activos Identificadores de los dispositivos activos del comprador.
	 * @param string $disp    Identificador del dispositivo actual.
	 * @param int    $max     Máximo de dispositivos.
	 * @return string 'conocido' | 'nuevo' | 'bloqueado'
	 */
	public static function decidir( array $activos, $disp, $max ) {
		if ( in_array( $disp, $activos, true ) ) {
			return 'conocido';
		}
		return count( $activos ) < $max ? 'nuevo' : 'bloqueado';
	}

	/**
	 * ¿Hay que alertar? $accesos: filas de las últimas 24 h con 'red', 'pais', 'tipo'.
	 *
	 * @return array Motivos (vacío si nada anómalo).
	 */
	public static function anomalias( array $accesos, $umbral_redes, $umbral_paises, $umbral_descargas ) {
		$redes  = array();
		$paises = array();
		$desc   = 0;
		foreach ( $accesos as $a ) {
			$redes[ $a['red'] ] = 1;
			if ( '' !== $a['pais'] ) {
				$paises[ $a['pais'] ] = 1;
			}
			if ( 'descarga' === $a['tipo'] ) {
				++$desc;
			}
		}
		$m = array();
		if ( count( $redes ) > $umbral_redes ) {
			$m[] = count( $redes ) . ' redes IP distintas en 24 h (umbral ' . $umbral_redes . ')';
		}
		if ( count( $paises ) > $umbral_paises ) {
			$m[] = count( $paises ) . ' países distintos en 24 h (' . implode( ', ', array_keys( $paises ) ) . ')';
		}
		if ( $desc > $umbral_descargas ) {
			$m[] = $desc . ' descargas en 24 h (umbral ' . $umbral_descargas . ')';
		}
		return $m;
	}

	/** Huella básica del navegador (no identifica a la persona; ayuda a detectar cookies copiadas). */
	public static function huella( $agente, $idioma ) {
		return substr( hash( 'sha256', 'huella|' . (string) $agente . '|' . substr( (string) $idioma, 0, 40 ) ), 0, 32 );
	}

	// ------------------------------------------------------------------ Registro y alertas

	public static function registrar( $pedido, $tipo, $detalle = '', $disp = '' ) {
		global $wpdb;
		$ip = OGC_Config::ip();
		$wpdb->insert(
			OGC_Pedidos::tabla( 'accesos' ),
			array(
				'fecha'       => current_time( 'mysql', true ),
				'pedido_id'   => $pedido ? (int) $pedido['id'] : 0,
				'email'       => $pedido ? $pedido['email'] : '',
				'tipo'        => $tipo,
				'detalle'     => mb_substr( (string) $detalle, 0, 180 ),
				'ip'          => OGC_Config::ip_hash( $ip ),
				'red'         => OGC_Config::red_hash( $ip ),
				'pais'        => OGC_Config::pais(),
				'agente'      => OGC_Config::agente(),
				'dispositivo' => substr( (string) $disp, 0, 16 ),
			)
		);
		if ( $pedido ) {
			self::vigilar( $pedido );
		}
	}

	public static function vigilar( array $p ) {
		global $wpdb;
		$t   = OGC_Pedidos::tabla( 'accesos' );
		$f   = $wpdb->get_results( $wpdb->prepare( "SELECT red, pais, tipo FROM $t WHERE pedido_id = %d AND fecha > %s", $p['id'], gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS ) ), ARRAY_A ); // phpcs:ignore
		$aj  = OGC_Config::ajustes();
		$mot = self::anomalias( (array) $f, (int) $aj['umbral_redes'], (int) $aj['umbral_paises'], (int) $aj['umbral_descargas'] );
		if ( ! $mot || get_transient( 'ogc_alerta_' . $p['id'] ) ) {
			return;
		}
		set_transient( 'ogc_alerta_' . $p['id'], 1, DAY_IN_SECONDS );
		$bloq = ! empty( $aj['bloqueo_auto'] );
		if ( $bloq ) {
			OGC_Pedidos::bloquear( $p['id'], 'Automático: ' . implode( '; ', $mot ) );
		}
		OGC_Pedidos::avisar_admin(
			'Uso anómalo del pedido ' . $p['pedido'],
			"Pedido {$p['pedido']} · {$p['nombre']} <{$p['email']}>\n\n" . implode( "\n", $mot ) . "\n\n"
			. ( $bloq ? 'El pedido se ha BLOQUEADO automáticamente. Puedes desbloquearlo en el escritorio.' : 'No se ha bloqueado (bloqueo automático desactivado). Revisa los accesos y, si procede, bloquea el pedido en Herramientas → OGC Ventas.' )
		);
	}

	// ------------------------------------------------------------------ Dispositivos

	/** Identificador del dispositivo de la cookie firmada, o '' si no hay o no es válida. */
	public static function disp_cookie() {
		$v = isset( $_COOKIE[ self::COOKIE ] ) ? (string) wp_unslash( $_COOKIE[ self::COOKIE ] ) : ''; // phpcs:ignore
		$d = OGC_Cripto::abrir_valor( OGC_Config::clave_firma(), $v );
		return ( null !== $d && preg_match( '/^[0-9a-f]{32}$/', $d ) ) ? $d : '';
	}

	public static function poner_cookie( $nombre, $valor, $caduca ) {
		if ( headers_sent() ) {
			return;
		}
		setcookie(
			$nombre,
			$valor,
			array(
				'expires'  => $caduca,
				'path'     => '/',
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
		$_COOKIE[ $nombre ] = $valor;
	}

	/** Dispositivo actual (lo crea si no hay cookie). */
	public static function disp_actual() {
		$d = self::disp_cookie();
		if ( '' === $d ) {
			$d = bin2hex( random_bytes( 16 ) );
			self::poner_cookie( self::COOKIE, OGC_Cripto::sellar_valor( OGC_Config::clave_firma(), $d ), time() + 2 * YEAR_IN_SECONDS );
		}
		return $d;
	}

	public static function activos( $email ) {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'dispositivos' );
		return (array) $wpdb->get_col( $wpdb->prepare( "SELECT disp FROM $t WHERE email = %s AND estado = 'activo' ORDER BY id", strtolower( $email ) ) ); // phpcs:ignore
	}

	/**
	 * Comprueba el dispositivo para un comprador. Devuelve array( 'ok' => bool, 'disp' => id, 'n' => activos,
	 * 'max' => max, 'verificar' => bool ).
	 * Si el dispositivo es nuevo y cabe: con $verificado (código correcto o sesión del enlace mágico) lo registra; sin
	 * él devuelve ok=false y verificar=true, sin registrar nada. Si no cabe, anota el intento y avisa a Vicente (una
	 * vez al día por comprador).
	 */
	public static function comprobar( array $p, $verificado = false ) {
		global $wpdb;
		$email = strtolower( $p['email'] );
		$disp  = self::disp_actual();
		$max   = OGC_Config::max_dispositivos();
		$act   = self::activos( $email );
		$dec   = self::decidir( $act, $disp, $max );
		$t     = OGC_Pedidos::tabla( 'dispositivos' );
		$ahora = current_time( 'mysql', true );
		$idio  = isset( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ) : ''; // phpcs:ignore
		$hue   = self::huella( OGC_Config::agente(), $idio );
		if ( 'conocido' === $dec ) {
			$prev = $wpdb->get_var( $wpdb->prepare( "SELECT huella FROM $t WHERE email = %s AND disp = %s", $email, $disp ) ); // phpcs:ignore
			$wpdb->update( $t, array( 'visto' => $ahora, 'ip' => OGC_Config::ip_hash() ), array( 'email' => $email, 'disp' => $disp ) );
			if ( $prev && $prev !== $hue ) {
				self::registrar( $p, 'huella', 'La cookie del dispositivo se usa desde otro navegador', $disp );
			}
			return array( 'ok' => true, 'disp' => $disp, 'n' => count( $act ), 'max' => $max, 'verificar' => false );
		}
		if ( 'nuevo' === $dec && ! $verificado ) {
			return array( 'ok' => false, 'disp' => $disp, 'n' => count( $act ), 'max' => $max, 'verificar' => true );
		}
		if ( 'nuevo' === $dec ) {
			// Si este dispositivo se liberó antes, se reactiva; si no, se crea.
			$hay = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE email = %s AND disp = %s", $email, $disp ) ); // phpcs:ignore
			if ( $hay ) {
				$wpdb->update( $t, array( 'estado' => 'activo', 'visto' => $ahora, 'huella' => $hue, 'agente' => OGC_Config::agente(), 'ip' => OGC_Config::ip_hash() ), array( 'id' => (int) $hay ) );
			} else {
				$wpdb->insert( $t, array( 'email' => $email, 'disp' => $disp, 'huella' => $hue, 'agente' => OGC_Config::agente(), 'ip' => OGC_Config::ip_hash(), 'creado' => $ahora, 'visto' => $ahora, 'estado' => 'activo' ) );
			}
			self::registrar( $p, 'dispositivo', 'Dispositivo nuevo registrado tras verificar el email (' . ( count( $act ) + 1 ) . ' de ' . $max . ')', $disp );
			return array( 'ok' => true, 'disp' => $disp, 'n' => count( $act ) + 1, 'max' => $max, 'verificar' => false );
		}
		self::registrar( $p, 'bloqueo', 'Intento desde un dispositivo más del máximo (' . $max . ')', $disp );
		if ( ! get_transient( 'ogc_disp_' . md5( $email ) ) ) {
			set_transient( 'ogc_disp_' . md5( $email ), 1, DAY_IN_SECONDS );
			OGC_Pedidos::avisar_admin( 'Dispositivo bloqueado · ' . $p['pedido'], "{$p['nombre']} <{$email}> ha intentado acceder desde un dispositivo más del máximo ({$max}).\nNavegador: " . OGC_Config::agente() . "\nIP (hash): " . OGC_Config::ip_hash() . "\n\nSi es legítimo (equipo nuevo), libera un dispositivo en Herramientas → OGC Ventas → Dispositivos." );
		}
		return array( 'ok' => false, 'disp' => $disp, 'n' => count( $act ), 'max' => $max, 'verificar' => false );
	}

	public static function liberar( $id ) {
		global $wpdb;
		return $wpdb->update( OGC_Pedidos::tabla( 'dispositivos' ), array( 'estado' => 'liberado' ), array( 'id' => (int) $id ) );
	}
}
