<?php
/**
 * Escritorio → Herramientas → OGC Ventas (1.1.0). Pestañas: Pedidos, Ajustes, Materiales, Contactos, Dispositivos,
 * Accesos, Avisos (1.3.0: estado del cron, pendientes, «Enviar avisos ahora» y registro de envíos) y Boletín. Solo administradores (manage_options) y siempre con nonce.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Admin {

	const PESTANAS = array(
		'pedidos'      => 'Pedidos',
		'ajustes'      => 'Ajustes',
		'materiales'   => 'Materiales',
		'contactos'    => 'Contactos',
		'dispositivos' => 'Dispositivos',
		'accesos'      => 'Accesos',
		'avisos'       => 'Avisos',
		'boletin'      => 'Boletín',
	);

	public static function menu() {
		add_management_page( 'OGC Ventas', 'OGC Ventas', 'manage_options', 'ogc-ventas', array( __CLASS__, 'pagina' ) );
	}

	public static function url( $tab, array $extra = array() ) {
		return add_query_arg( array_merge( array( 'page' => 'ogc-ventas', 'tab' => $tab ), $extra ), admin_url( 'tools.php' ) );
	}

	public static function avisos_configuracion() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'tools_page_ogc-ventas' !== $screen->id ) {
			return;
		}
		foreach ( OGC_Config::problemas() as $p ) {
			echo '<div class="notice notice-warning"><p>' . esc_html( $p ) . '</p></div>';
		}
	}

	private static function form_inicio( $op, $id = 0, $inline = false ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $inline ? ' style="display:inline"' : '' ) . '>';
		wp_nonce_field( 'ogc_ventas_' . $op . '_' . (int) $id );
		echo '<input type="hidden" name="action" value="ogc_ventas_accion"><input type="hidden" name="op" value="' . esc_attr( $op ) . '"><input type="hidden" name="id" value="' . (int) $id . '">';
	}

	private static function boton( $op, $id, $texto, $confirmar = '' ) {
		self::form_inicio( $op, $id, true );
		echo '<button class="button button-small"' . ( $confirmar ? ' onclick="return confirm(\'' . esc_js( $confirmar ) . '\')"' : '' ) . '>' . esc_html( $texto ) . '</button></form> ';
	}

	public static function pagina() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'pedidos'; // phpcs:ignore
		$tab = isset( self::PESTANAS[ $tab ] ) ? $tab : 'pedidos';
		$msg = get_transient( 'ogc_ventas_msg_' . get_current_user_id() );
		delete_transient( 'ogc_ventas_msg_' . get_current_user_id() );
		echo '<div class="wrap"><h1>OGC Ventas <small style="font-size:12px">' . esc_html( OGC_VENTAS_VERSION ) . '</small></h1>';
		if ( $msg ) {
			echo '<div class="notice notice-info"><p>' . wp_kses( implode( '<br>', array_map( 'esc_html', (array) $msg ) ), array( 'br' => array() ) ) . '</p></div>';
		}
		echo '<nav class="nav-tab-wrapper">';
		foreach ( self::PESTANAS as $k => $t ) {
			echo '<a class="nav-tab' . ( $k === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( self::url( $k ) ) . '">' . esc_html( $t ) . '</a>';
		}
		echo '</nav>';
		call_user_func( array( __CLASS__, 'tab_' . $tab ) );
		echo '</div>';
	}

	// ------------------------------------------------------------------ Pedidos

	private static function tab_pedidos() {
		global $wpdb;
		$t     = OGC_Pedidos::tabla();
		$filas = $wpdb->get_results( "SELECT * FROM $t ORDER BY id DESC LIMIT 100", ARRAY_A ); // phpcs:ignore
		echo '<p>Webhook de Stripe: <code>' . esc_html( rest_url( 'ogc/v1/stripe-webhook' ) ) . '</code> · eventos <code>checkout.session.completed</code> y <code>checkout.session.async_payment_succeeded</code> · modo <strong>' . esc_html( OGC_Config::modo_stripe() ) . '</strong> · entrega: <strong>' . esc_html( OGC_Config::ENTREGAS[ OGC_Config::entrega() ] ) . '</strong></p>';
		echo '<table class="widefat striped"><thead><tr><th>Pedido</th><th>Fecha</th><th>Comprador</th><th>Producto</th><th>Importe</th><th>Estado</th><th>Enlace hasta</th><th>Descargas</th><th>Acciones</th></tr></thead><tbody>';
		foreach ( (array) $filas as $p ) {
			$estado = $p['bloqueado'] ? 'BLOQUEADO' . ( $p['motivo_bloqueo'] ? ' (' . $p['motivo_bloqueo'] . ')' : '' ) : $p['estado'];
			echo '<tr><td>' . esc_html( $p['pedido'] ) . '</td><td>' . esc_html( OGC_Pedidos::fecha( $p ) ) . '</td><td>' . esc_html( $p['nombre'] . ' <' . $p['email'] . '>' ) . '</td><td>' . esc_html( $p['producto'] ) . '</td><td>'
				. esc_html( number_format( $p['importe'] / 100, 2, ',', '.' ) . ' ' . $p['moneda'] ) . '</td><td>' . esc_html( $estado ) . '</td><td>' . esc_html( get_date_from_gmt( $p['caduca'], 'd/m/Y' ) ) . '</td><td>' . (int) $p['descargas'] . '</td><td>';
			self::boton( 'reenviar', $p['id'], 'Renovar y reenviar enlace' );
			self::boton( 'reiniciar', $p['id'], 'Reiniciar descargas', '¿Poner a cero las descargas de este pedido (total y por archivo)?' );
			if ( $p['bloqueado'] ) {
				self::boton( 'desbloquear', $p['id'], 'Desbloquear' );
			} else {
				self::boton( 'bloquear', $p['id'], 'Bloquear', '¿Bloquear el acceso a este pedido?' );
			}
			echo '<a class="button button-small" href="' . esc_url( self::url( 'accesos', array( 'pedido' => $p['id'] ) ) ) . '">Accesos</a>';
			echo '</td></tr>';
		}
		echo '</tbody></table>';
		echo '<h2>Pedido manual</h2><p>Para ventas fuera de Stripe (Bizum o transferencia acordados por WhatsApp). Crea el pedido y envía el mismo correo.</p>';
		self::form_inicio( 'manual' );
		echo '<p><label>Nombre <input name="nombre" required maxlength="80"></label> <label>Email <input type="email" name="email" required></label> <label>Producto <select name="producto">';
		foreach ( OGC_Config::PRODUCTOS_VALIDOS as $pr ) {
			echo '<option value="' . esc_attr( $pr ) . '">' . esc_html( OGC_Config::nombre_producto( $pr ) ) . '</option>';
		}
		echo '</select></label> <label>Importe (€) <input name="importe" type="number" step="0.01" min="0"></label> ';
		submit_button( 'Crear y enviar', 'primary', 'submit', false );
		echo '</p></form>';
	}

	// ------------------------------------------------------------------ Ajustes

	private static function tab_ajustes() {
		$a   = OGC_Config::ajustes();
		$wh  = OGC_Config::whsec();
		$cm  = OGC_Config::get( 'OGC_MATERIALES_CLAVE' ) ? 'wp-config.php' : (string) get_option( OGC_Config::OPC_CLAVE_MAT, '' );
		$dir = OGC_Config::dir();
		self::form_inicio( 'ajustes' );
		echo '<table class="form-table" role="presentation">';
		echo '<tr><th>Secreto del webhook de Stripe</th><td><input type="password" name="whsec" autocomplete="new-password" class="regular-text" placeholder="' . esc_attr( $wh ? 'Guardado: ' . OGC_Config::mascara( $wh ) . ' (vacío = no cambiar)' : 'whsec_…' ) . '"'
			. ( OGC_Config::get( 'OGC_STRIPE_WEBHOOK_SECRET' ) ? ' disabled' : '' ) . '><p class="description">Stripe → Desarrolladores → Webhooks → el endpoint → «Secreto de firma». ' . ( OGC_Config::get( 'OGC_STRIPE_WEBHOOK_SECRET' ) ? 'Ahora manda la constante de wp-config.php.' : '' ) . '</p>'
			. '<label><input type="checkbox" name="borrar_whsec" value="1"> Borrar el secreto guardado</label></td></tr>';
		echo '<tr><th>Modo de Stripe</th><td><select name="modo_stripe"' . ( OGC_Config::get( 'OGC_STRIPE_MODO' ) ? ' disabled' : '' ) . '><option value="test"' . selected( $a['modo_stripe'], 'test', false ) . '>Prueba (acepta eventos de prueba y reales)</option><option value="live"' . selected( $a['modo_stripe'], 'live', false ) . '>Real (ignora los eventos de prueba)</option></select></td></tr>';
		echo '<tr><th>Modalidad de entrega</th><td>';
		foreach ( OGC_Config::ENTREGAS as $k => $t ) {
			echo '<label style="display:block"><input type="radio" name="entrega" value="' . esc_attr( $k ) . '"' . checked( OGC_Config::entrega(), $k, false ) . '> ' . esc_html( $t ) . '</label>';
		}
		echo '<p class="description">Decisión de Vicente (12/11/2026): «Online + PDF». Si cambias la modalidad, revisa el texto de las condiciones de venta (fichero ventas/condiciones_modalidades.md).</p></td></tr>';
		echo '<tr><th>Máximo de dispositivos</th><td><input type="number" name="max_dispositivos" min="1" max="5" value="' . (int) $a['max_dispositivos'] . '"> por comprador (lector online y descargas). Cada navegador nuevo se registra solo después de confirmar el email de la compra con un código de 6 dígitos (o de entrar con el enlace de acceso del área privada).</td></tr>';
		echo '<tr><th>Enlace del pedido</th><td><input type="number" name="dias_enlace" min="1" max="365" value="' . (int) $a['dias_enlace'] . '"> días · <input type="number" name="descargas_max" min="1" max="5000" value="' . (int) $a['descargas_max'] . '"> descargas máximas por pedido · <input type="number" name="descargas_archivo" min="1" max="50" value="' . (int) $a['descargas_archivo'] . '" style="width:60px"> por archivo y versión<p class="description">Al superar el límite por archivo, el comprador ve un mensaje claro; si lo intenta 3 veces en 24 h, te llega un aviso. Si un documento se actualiza, la versión nueva vuelve a tener el máximo. «Reiniciar descargas» (pestaña Pedidos) pone a cero los contadores de un pedido.</p></td></tr>';
		echo '<tr><th>Alertas (24 h por pedido)</th><td>Más de <input type="number" name="umbral_redes" min="1" max="100" value="' . (int) $a['umbral_redes'] . '" style="width:60px"> redes IP · más de <input type="number" name="umbral_paises" min="1" max="20" value="' . (int) $a['umbral_paises'] . '" style="width:60px"> países (si el servidor da el país) · más de <input type="number" name="umbral_descargas" min="1" max="5000" value="' . (int) $a['umbral_descargas'] . '" style="width:70px"> descargas'
			. '<br><label><input type="checkbox" name="bloqueo_auto" value="1"' . checked( $a['bloqueo_auto'], 1, false ) . '> Bloquear el pedido automáticamente al superar un umbral (si no, solo se avisa)</label>'
			. '<br>Avisos a: <input type="email" name="aviso_email" value="' . esc_attr( $a['aviso_email'] ) . '" placeholder="' . esc_attr( OGC_Config::correo() ) . '"></td></tr>';
		echo '<tr><th>Clave pública de este sitio</th><td>' . self::caja_publica() . '</td></tr>';
		echo '<tr><th>Clave de los materiales</th><td><input type="password" name="clave_materiales" autocomplete="new-password" class="regular-text" placeholder="' . esc_attr( $cm ? 'Guardada: ' . OGC_Config::mascara( $cm ) . ' (vacío = no cambiar)' : 'Texto base64 de 44 caracteres' ) . '">'
			. ( OGC_Config::get( 'OGC_MATERIALES_CLAVE' ) ? ' disabled' : '' )
			. '<p class="description"><strong>Ya no hace falta pegarla</strong>: el plugin la obtiene sola del sobre sellado para la clave pública de este sitio. Este campo queda como alternativa manual. Origen: <strong>' . esc_html( OGC_Config::clave_materiales_origen() ? OGC_Config::clave_materiales_origen() : 'ninguna todavía' ) . '</strong> · huella: <code>' . esc_html( OGC_Config::clave_materiales() ? OGC_Cripto::id_clave( OGC_Config::clave_materiales() ) : '—' ) . '</code> (debe coincidir con la que da publicar_materiales.py --clave-id).</p></td></tr>';
		echo '<tr><th>Paquete de materiales</th><td><input type="url" name="url_materiales" class="regular-text" value="' . esc_attr( $a['url_materiales'] ) . '"><br><label><input type="checkbox" name="materiales_auto" value="1"' . checked( $a['materiales_auto'], 1, false ) . '> Comprobar cada hora</label></td></tr>';
		echo '<tr><th>Boletín semanal</th><td><label><input type="checkbox" name="boletin_activo" value="1"' . checked( $a['boletin_activo'], 1, false ) . '> Enviar los lunes desde las 09:00 (Madrid) si hay novedades</label></td></tr>';
		echo '<tr><th>Motor del lector</th><td><select name="motor_lector">';
		foreach ( array( 'auto' => 'Automático', 'pdfjs' => 'PDF.js (en el navegador)', 'imagen' => 'Imágenes renderizadas en el servidor' ) as $k => $t ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $a['motor_lector'], $k, false ) . '>' . esc_html( $t ) . '</option>';
		}
		echo '</select><p class="description">Imagick con PDF en este servidor: <strong>' . ( OGC_Descargas::imagick_pdf() ? 'sí' : 'no' ) . '</strong> · motor en uso: <strong>' . esc_html( OGC_Descargas::motor() ) . '</strong>.</p></td></tr>';
		echo '<tr><th>Carpeta privada</th><td><code>' . esc_html( $dir ? $dir : '(sin crear)' ) . '</code> ' . ( $dir && ! OGC_Config::dentro_de_la_web( $dir ) ? '· fuera de public_html ✓' : '' ) . '</td></tr>';
		echo '<tr><th>Clave de firma de enlaces</th><td>' . ( OGC_Config::get( 'OGC_DESCARGA_CLAVE' ) ? 'Constante de wp-config.php' : 'Generada automáticamente y guardada (no se muestra)' ) . '</td></tr>';
		echo '</table>';
		submit_button( 'Guardar ajustes' );
		echo '</form>';
		self::form_inicio( 'carpeta' );
		submit_button( 'Volver a crear la carpeta privada', 'secondary', 'submit', false );
		echo '</form>';
	}

	/** Clave PÚBLICA X25519 del sitio (no es secreta) con su huella y botón de copiar. */
	private static function caja_publica() {
		$pub = OGC_Config::publica_sitio();
		if ( '' === $pub ) {
			return '<p style="color:#b32d2e">Este servidor no tiene sodium: no se puede generar la clave del sitio. Pega la clave de los materiales a mano.</p>';
		}
		return '<input type="text" id="ogc-publica-sitio" readonly class="large-text code" value="' . esc_attr( $pub ) . '" onclick="this.select()"> '
			. '<button type="button" class="button" onclick="var c=document.getElementById(\'ogc-publica-sitio\');c.select();(navigator.clipboard?navigator.clipboard.writeText(c.value):Promise.reject()).then(function(){},function(){document.execCommand(\'copy\');});this.textContent=\'Copiada\';">Copiar clave pública</button>'
			. '<p class="description">Huella: <code>' . esc_html( OGC_Config::huella_sitio() ) . '</code>. Esta clave es PÚBLICA: se puede enviar sin riesgo a quien publica los materiales, que la añade con <code>publicar_materiales.py --destinatario &lt;clave&gt;</code>. El paquete trae entonces la clave de los materiales en un sobre que solo este sitio puede abrir; no hay que pegar ninguna clave secreta.</p>';
	}

	// ------------------------------------------------------------------ Materiales

	private static function tab_materiales() {
		$e = OGC_Materiales::estado();
		$m = OGC_Materiales::manifiesto();
		echo '<p>Paquete: <code>' . esc_html( OGC_Config::ajuste( 'url_materiales' ) ) . '</code></p>';
		echo '<p>Serie aplicada: <strong>' . (int) $e['serie'] . '</strong> · última comprobación: ' . esc_html( $e['comprobado'] ) . ' · resultado: <strong>' . esc_html( $e['resultado'] ) . '</strong>' . ( $e['error'] ? ' · <span style="color:#b32d2e">' . esc_html( $e['error'] ) . '</span>' : '' ) . '</p>';
		echo '<div class="card" style="max-width:820px"><h2>Clave pública de este sitio</h2>' . self::caja_publica() . '</div>';
		self::form_inicio( 'materiales' );
		submit_button( 'Comprobar materiales ahora', 'primary', 'submit', false );
		echo '</form>';
		if ( $m ) {
			echo '<p>' . count( $m['archivos'] ) . ' documentos y ' . count( $m['muestras'] ) . ' muestras · publicado el ' . esc_html( isset( $m['fecha'] ) ? $m['fecha'] : '' ) . '</p>';
			foreach ( OGC_Config::PRODUCTOS_VALIDOS as $p ) {
				echo '<p><strong>' . esc_html( OGC_Config::nombre_producto( $p ) ) . '</strong>: ' . count( OGC_Config::archivos( $p ) ) . ' archivos</p>';
			}
		}
		$h = OGC_Materiales::cambios_recientes( 60 );
		if ( $h ) {
			echo '<h2>Cambios recientes</h2><ul>';
			foreach ( array_reverse( $h ) as $c ) {
				echo '<li>' . esc_html( wp_date( 'd/m/Y H:i', $c['t'] ) . ' · ' . $c['ruta'] . ' · ' . $c['novedades'] ) . '</li>';
			}
			echo '</ul>';
		}
	}

	// ------------------------------------------------------------------ Contactos

	private static function tab_contactos() {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'contactos' );
		$n = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t" ); // phpcs:ignore
		$b = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE boletin = 1 AND baja IS NULL" ); // phpcs:ignore
		echo '<p>' . $n . ' contactos · ' . $b . ' con consentimiento para el boletín.</p>';
		self::form_inicio( 'exportar' );
		submit_button( 'Exportar contactos (CSV)', 'primary', 'submit', false );
		echo '</form>';
		$f = $wpdb->get_results( "SELECT * FROM $t ORDER BY id DESC LIMIT 100", ARRAY_A ); // phpcs:ignore
		echo '<table class="widefat striped" style="margin-top:12px"><thead><tr><th>Email</th><th>Teléfono</th><th>Origen</th><th>Alta</th><th>Muestras</th><th>Boletín / novedades</th><th></th></tr></thead><tbody>';
		foreach ( (array) $f as $c ) {
			echo '<tr><td>' . esc_html( $c['email'] ) . '</td><td>' . esc_html( $c['telefono'] ) . '</td><td>' . esc_html( $c['origen'] ) . '</td><td>' . esc_html( get_date_from_gmt( $c['creado'], 'd/m/Y H:i' ) ) . '</td><td>' . (int) $c['muestras'] . ( ! empty( $c['muestras_desde'] ) ? ' (pedidas el ' . esc_html( get_date_from_gmt( $c['muestras_desde'], 'd/m/Y' ) ) . ')' : '' ) . '</td><td>' . ( $c['boletin'] ? 'sí' : ( $c['baja'] ? 'baja' : 'no' ) ) . '</td><td>';
			if ( $c['boletin'] || ! $c['baja'] ) {
				self::boton( 'baja', $c['id'], 'Dar de baja (boletín y avisos)' );
			}
			self::boton( 'borrar_contacto', $c['id'], 'Borrar (supresión)', '¿Borrar este contacto? Se conserva solo el registro de consentimientos.' );
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	// ------------------------------------------------------------------ Dispositivos y accesos

	private static function tab_dispositivos() {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'dispositivos' );
		$f = $wpdb->get_results( "SELECT * FROM $t ORDER BY email, id LIMIT 300", ARRAY_A ); // phpcs:ignore
		echo '<p>Máximo por comprador: <strong>' . (int) OGC_Config::max_dispositivos() . '</strong>. «Liberar» deja hueco para que el comprador entre desde otro dispositivo (tendrá que volver a confirmar su email con el código). La IP se guarda como hash con sal (no se puede revertir): sirve para ver si dos accesos vienen de la misma conexión.</p>';
		echo '<table class="widefat striped"><thead><tr><th>Comprador</th><th>Navegador</th><th>IP (hash)</th><th>Alta</th><th>Último uso</th><th>Estado</th><th></th></tr></thead><tbody>';
		foreach ( (array) $f as $d ) {
			echo '<tr><td>' . esc_html( $d['email'] ) . '</td><td style="max-width:320px;font-size:11px">' . esc_html( $d['agente'] ) . '</td><td><code>' . esc_html( substr( $d['ip'], 0, 12 ) ) . '</code></td><td>' . esc_html( get_date_from_gmt( $d['creado'], 'd/m/Y H:i' ) ) . '</td><td>' . esc_html( get_date_from_gmt( $d['visto'], 'd/m/Y H:i' ) ) . '</td><td>' . esc_html( $d['estado'] ) . '</td><td>';
			if ( 'activo' === $d['estado'] ) {
				self::boton( 'liberar', $d['id'], 'Liberar' );
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function tab_accesos() {
		global $wpdb;
		$t   = OGC_Pedidos::tabla( 'accesos' );
		$pid = isset( $_GET['pedido'] ) ? absint( $_GET['pedido'] ) : 0; // phpcs:ignore
		$f   = $pid
			? $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE pedido_id = %d ORDER BY id DESC LIMIT 300", $pid ), ARRAY_A ) // phpcs:ignore
			: $wpdb->get_results( "SELECT * FROM $t ORDER BY id DESC LIMIT 300", ARRAY_A ); // phpcs:ignore
		echo '<p>' . ( $pid ? 'Accesos del pedido seleccionado.' : 'Últimos 300 accesos.' ) . ' El país solo aparece si el servidor o una CDN lo indica. La IP y la red se guardan como hash con sal (privacidad): iguales = misma conexión o misma red.</p>';
		echo '<table class="widefat striped"><thead><tr><th>Fecha</th><th>Email</th><th>Tipo</th><th>Detalle</th><th>IP / red (hash)</th><th>País</th><th>Navegador</th></tr></thead><tbody>';
		foreach ( (array) $f as $a ) {
			echo '<tr><td>' . esc_html( get_date_from_gmt( $a['fecha'], 'd/m/Y H:i:s' ) ) . '</td><td>' . esc_html( $a['email'] ) . '</td><td>' . esc_html( $a['tipo'] ) . '</td><td>' . esc_html( $a['detalle'] ) . '</td><td><code>' . esc_html( substr( $a['ip'], 0, 12 ) ) . '</code><br><code>' . esc_html( substr( $a['red'], 0, 12 ) ) . '</code></td><td>' . esc_html( $a['pais'] ) . '</td><td style="font-size:11px;max-width:300px">' . esc_html( $a['agente'] ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	// ------------------------------------------------------------------ Avisos (1.3.0)

	private static function tab_avisos() {
		global $wpdb;
		$tc  = OGC_Pedidos::tabla( 'cola' );
		$te  = OGC_Pedidos::tabla( 'envios' );
		$lat = (int) get_option( OGC_Avisos::OPC_LATIDO, 0 );
		$sig = wp_next_scheduled( 'ogc_ventas_horario' );
		$lot = wp_next_scheduled( OGC_Avisos::CRON_LOTE );
		echo '<p>Cuando se aplica un paquete de materiales con documentos o muestras nuevos o actualizados, se avisa <strong>en el día</strong> (entre las 09:00 y las 22:00, Madrid, unos ' . (int) ( OGC_Avisos::REPOSO / 60 ) . ' minutos después de aplicarlo), con <strong>un solo correo por persona y día</strong> que lo agrupa todo, en lotes de ' . (int) OGC_Avisos::LOTE . ' cada 5 minutos: compradores con actualizaciones vigentes (enlace renovado), compradores sin vigencia (versión nueva y cómo renovar, sin entregarla), quien pidió las muestras (enlaces nuevos) y novedades a compradores y suscritos. Cada correo lleva baja de un clic y List-Unsubscribe; te llega el resumen de cada tanda.</p>';
		$aviso = ( ! $lat || $lat < time() - 2 * HOUR_IN_SECONDS ) ? ' <strong style="color:#b32d2e">· El cron no se ha ejecutado en las últimas 2 horas: revisa WP-Cron (o un cron real del hosting que llame a wp-cron.php).</strong>' : '';
		echo '<p>Último latido del cron: <strong>' . esc_html( $lat ? wp_date( 'd/m/Y H:i', $lat ) : 'nunca' ) . '</strong> · próxima comprobación horaria: ' . esc_html( $sig ? wp_date( 'd/m/Y H:i', $sig ) : '—' ) . ' · próximo lote de avisos: ' . esc_html( $lot ? wp_date( 'd/m/Y H:i', $lot ) : '—' ) . $aviso . '</p>';
		$pend = (array) $wpdb->get_results( "SELECT clase, COUNT(*) AS n, COUNT(DISTINCT email) AS p FROM $tc WHERE enviado IS NULL GROUP BY clase", ARRAY_A ); // phpcs:ignore
		echo '<p>Pendientes: ';
		if ( ! $pend ) {
			echo 'ninguno.';
		}
		foreach ( $pend as $x ) {
			echo esc_html( OGC_Avisos::CLASES[ $x['clase'] ] ?? $x['clase'] ) . ': <strong>' . (int) $x['n'] . '</strong> (' . (int) $x['p'] . ' personas) · ';
		}
		echo '</p>';
		self::form_inicio( 'avisos_ahora' );
		submit_button( 'Enviar avisos ahora', 'primary', 'submit', false, array( 'onclick' => "return confirm('¿Comprobar materiales y enviar ya los avisos pendientes (a cualquier hora)? Cada persona recibe como máximo un correo de avisos al día.')" ) );
		echo '</form>';
		$f = (array) $wpdb->get_results( "SELECT * FROM $te ORDER BY id DESC LIMIT 300", ARRAY_A ); // phpcs:ignore
		echo '<h2>Registro de envíos</h2><table class="widefat striped"><thead><tr><th>Fecha</th><th>Destinatario</th><th>Tipo</th><th>Documentos</th><th>Asunto</th><th>Estado</th></tr></thead><tbody>';
		foreach ( $f as $x ) {
			$tipos = array();
			foreach ( explode( ',', $x['clases'] ) as $cl ) {
				$tipos[] = OGC_Avisos::CLASES[ $cl ] ?? $cl;
			}
			echo '<tr><td>' . esc_html( get_date_from_gmt( $x['fecha'], 'd/m/Y H:i' ) ) . '</td><td>' . esc_html( $x['email'] ) . '</td><td>' . esc_html( implode( ', ', $tipos ) ) . '</td><td style="max-width:420px;font-size:12px">' . esc_html( $x['documentos'] ) . '</td><td>' . esc_html( $x['asunto'] ) . '</td><td>' . esc_html( $x['estado'] ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	// ------------------------------------------------------------------ Boletín

	private static function tab_boletin() {
		$n = OGC_Boletin::novedades( false );
		echo '<p>Se envía los lunes desde las 09:00 (Madrid) a quien dio su consentimiento, solo si hay novedades, en lotes de ' . (int) OGC_Boletin::LOTE . ' cada 5 minutos. Última semana tratada: <code>' . esc_html( (string) get_option( OGC_Boletin::OPC_SEMANA, '—' ) ) . '</code>.</p>';
		echo '<p>Novedades de los últimos 7 días: ' . count( $n['entradas'] ) . ' entradas · ' . count( $n['paginas'] ) . ' páginas de convocatorias/normativa · ' . count( $n['material'] ) . ' documentos · ' . count( $n['notas'] ) . ' notas.</p>';
		echo '<div style="background:#fff;padding:12px;max-width:640px;border:1px solid #ccd0d4">' . wp_kses_post( OGC_Boletin::html_boletin( $n ) ) . '</div>';
		self::form_inicio( 'boletin_prueba' );
		submit_button( 'Enviarme una prueba', 'secondary', 'submit', false );
		echo '</form>';
	}

	// ------------------------------------------------------------------ Acciones

	private static function msg( $m ) {
		set_transient( 'ogc_ventas_msg_' . get_current_user_id(), (array) $m, 120 );
	}

	public static function accion() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sin permiso', 403 );
		}
		// phpcs:disable WordPress.Security.NonceVerification -- check_admin_referer justo debajo.
		$op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		// phpcs:enable
		check_admin_referer( 'ogc_ventas_' . $op . '_' . $id );
		$tab = 'pedidos';
		switch ( $op ) {
			case 'manual':
				$producto = isset( $_POST['producto'] ) ? sanitize_key( wp_unslash( $_POST['producto'] ) ) : '';
				$email    = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
				$nombre   = isset( $_POST['nombre'] ) ? sanitize_text_field( wp_unslash( $_POST['nombre'] ) ) : '';
				$importe  = isset( $_POST['importe'] ) ? (int) round( 100 * (float) $_POST['importe'] ) : 0;
				if ( ! in_array( $producto, OGC_Config::PRODUCTOS_VALIDOS, true ) || ! is_email( $email ) || ! $nombre ) {
					wp_die( 'Datos no válidos' );
				}
				$nuevo = OGC_Pedidos::crear( array( 'stripe_session' => null, 'nombre' => $nombre, 'email' => $email, 'producto' => $producto, 'importe' => $importe, 'moneda' => 'eur' ) );
				if ( $nuevo && OGC_Pedidos::marcar_notificado( $nuevo ) ) {
					OGC_Pedidos::enviar_enlace( $nuevo );
					wp_schedule_single_event( time() + 5, 'ogc_ventas_presellar', array( $nuevo ) );
				}
				self::msg( 'Pedido manual creado y enlace enviado.' );
				break;
			case 'reenviar':
				OGC_Pedidos::renovar( $id );
				OGC_Pedidos::enviar_enlace( $id );
				wp_schedule_single_event( time() + 5, 'ogc_ventas_presellar', array( $id ) );
				self::msg( 'Enlace renovado y reenviado (los anteriores ya no valen).' );
				break;
			case 'reiniciar':
				OGC_Pedidos::reiniciar_descargas( $id );
				self::msg( 'Descargas del pedido puestas a cero (total y por archivo).' );
				break;
			case 'bloquear':
				OGC_Pedidos::bloquear( $id, 'Manual (' . wp_get_current_user()->user_login . ')' );
				self::msg( 'Pedido bloqueado.' );
				break;
			case 'desbloquear':
				OGC_Pedidos::desbloquear( $id );
				self::msg( 'Pedido desbloqueado.' );
				break;
			case 'ajustes':
				$tab = 'ajustes';
				self::msg( self::guardar_ajustes() );
				break;
			case 'carpeta':
				$tab = 'ajustes';
				delete_option( OGC_Config::OPC_DIR );
				$d = OGC_Config::crear_dir();
				self::msg( $d ? 'Carpeta privada: ' . $d . ( OGC_Config::dentro_de_la_web( $d ) ? ' (DENTRO de public_html: protegida con .htaccess)' : ' (fuera de public_html)' ) . '. Vuelve a comprobar los materiales.' : 'No se ha podido crear la carpeta privada.' );
				break;
			case 'materiales':
				$tab = 'materiales';
				self::msg( OGC_Materiales::comprobar( 'manual' ) );
				break;
			case 'exportar':
				OGC_Contactos::exportar_csv();
				break;
			case 'baja':
				$tab = 'contactos';
				$c   = OGC_Contactos::obtener_id( $id );
				if ( $c ) {
					OGC_Contactos::baja( $c, 'escritorio' );
				}
				self::msg( 'Baja registrada (boletín, novedades y avisos de muestras).' );
				break;
			case 'borrar_contacto':
				$tab = 'contactos';
				global $wpdb;
				$wpdb->delete( OGC_Pedidos::tabla( 'contactos' ), array( 'id' => $id ) );
				self::msg( 'Contacto borrado.' );
				break;
			case 'liberar':
				$tab = 'dispositivos';
				OGC_Seguridad::liberar( $id );
				self::msg( 'Dispositivo liberado.' );
				break;
			case 'avisos_ahora':
				$tab = 'avisos';
				self::msg( OGC_Avisos::enviar_ahora() );
				break;
			case 'boletin_prueba':
				$tab = 'boletin';
				OGC_Correo::enviar( OGC_Config::aviso_email(), '[Prueba] Novedades de la semana en Preparador OGC', 'Novedades de la semana en Preparador OGC', OGC_Boletin::html_boletin( OGC_Boletin::novedades( false ) ) );
				self::msg( 'Prueba enviada a ' . OGC_Config::aviso_email() . '.' );
				break;
		}
		wp_safe_redirect( self::url( $tab ) );
		exit;
	}

	private static function guardar_ajustes() {
		// phpcs:disable WordPress.Security.NonceVerification -- comprobado en accion().
		$d   = OGC_Config::defectos();
		$a   = OGC_Config::ajustes();
		$l   = array( 'Ajustes guardados.' );
		$a['modo_stripe']      = ( isset( $_POST['modo_stripe'] ) && 'live' === $_POST['modo_stripe'] ) ? 'live' : ( isset( $_POST['modo_stripe'] ) ? 'test' : $a['modo_stripe'] );
		$ent                   = isset( $_POST['entrega'] ) ? sanitize_key( wp_unslash( $_POST['entrega'] ) ) : 'ambos';
		$a['entrega']          = isset( OGC_Config::ENTREGAS[ $ent ] ) ? $ent : 'ambos';
		foreach ( array( 'max_dispositivos' => array( 1, 5 ), 'dias_enlace' => array( 1, 365 ), 'descargas_max' => array( 1, 5000 ), 'descargas_archivo' => array( 1, 50 ), 'umbral_redes' => array( 1, 100 ), 'umbral_paises' => array( 1, 20 ), 'umbral_descargas' => array( 1, 5000 ) ) as $k => $r ) {
			$a[ $k ] = isset( $_POST[ $k ] ) ? max( $r[0], min( $r[1], (int) $_POST[ $k ] ) ) : $d[ $k ];
		}
		foreach ( array( 'bloqueo_auto', 'materiales_auto', 'boletin_activo' ) as $k ) {
			$a[ $k ] = empty( $_POST[ $k ] ) ? 0 : 1;
		}
		$em               = isset( $_POST['aviso_email'] ) ? sanitize_email( wp_unslash( $_POST['aviso_email'] ) ) : '';
		$a['aviso_email'] = is_email( $em ) ? $em : '';
		$url              = isset( $_POST['url_materiales'] ) ? esc_url_raw( trim( wp_unslash( $_POST['url_materiales'] ) ) ) : '';
		$a['url_materiales'] = preg_match( '#^https://[a-z0-9.-]+/([A-Za-z0-9._~%-]+/)*$#', $url ) ? $url : OGC_Config::URL_MATERIALES;
		$mot              = isset( $_POST['motor_lector'] ) ? sanitize_key( wp_unslash( $_POST['motor_lector'] ) ) : 'auto';
		$a['motor_lector'] = in_array( $mot, array( 'auto', 'pdfjs', 'imagen' ), true ) ? $mot : 'auto';
		update_option( OGC_Config::OPC_AJUSTES, $a, false );
		if ( ! empty( $_POST['borrar_whsec'] ) ) {
			OGC_Config::guardar_secreto( OGC_Config::OPC_WHSEC, '' );
			$l[] = 'Secreto del webhook borrado.';
		} elseif ( ! empty( $_POST['whsec'] ) ) {
			$w = trim( sanitize_text_field( wp_unslash( $_POST['whsec'] ) ) );
			if ( preg_match( '/^whsec_[A-Za-z0-9+\/=_-]{16,200}$/', $w ) ) {
				OGC_Config::guardar_secreto( OGC_Config::OPC_WHSEC, $w );
				$l[] = 'Secreto del webhook guardado (' . OGC_Config::mascara( $w ) . ').';
			} else {
				$l[] = 'El secreto del webhook debe empezar por «whsec_»: no se ha guardado.';
			}
		}
		if ( ! empty( $_POST['clave_materiales'] ) ) {
			$c = trim( sanitize_text_field( wp_unslash( $_POST['clave_materiales'] ) ) );
			if ( OGC_Cripto::clave_materiales( $c ) ) {
				OGC_Config::guardar_secreto( OGC_Config::OPC_CLAVE_MAT, $c );
				$l[] = 'Clave de materiales guardada (huella ' . OGC_Cripto::id_clave( OGC_Cripto::clave_materiales( $c ) ) . '). Pulsa «Comprobar materiales ahora» en la pestaña Materiales.';
			} else {
				$l[] = 'La clave de materiales no es válida (44 caracteres base64): no se ha guardado.';
			}
		}
		// phpcs:enable
		OGC_Materiales::programar();
		return $l;
	}
}
