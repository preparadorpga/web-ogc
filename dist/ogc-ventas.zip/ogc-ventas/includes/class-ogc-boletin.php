<?php
/**
 * Avisos de actualización y boletín semanal (1.1.0).
 *
 * AVISOS: cuando el paquete de materiales trae un documento nuevo o cambiado, se apunta un aviso para cada pedido
 * con actualizaciones vigentes (12 meses) que lo incluye. Una vez al día (desde las 10:00, hora de Madrid) se envía a
 * cada comprador UN solo correo «Tu material se ha actualizado» con todos sus cambios y el enlace renovado (el pedido
 * se renueva: los PDF se vuelven a sellar con la versión nueva).
 *
 * BOLETÍN: los lunes desde las 09:00 (Madrid) se prepara el boletín con las novedades de la semana: entradas del blog
 * publicadas, páginas de convocatorias y normativa que han cambiado (comparando el manifiesto de «OGC Páginas»),
 * material actualizado y las «novedades_semana» del paquete de materiales. Si no hay nada, no se envía. Solo a
 * contactos con consentimiento expreso y sin baja, en lotes de 50 cada 5 minutos, con enlace de baja de un clic
 * (también en las cabeceras List-Unsubscribe y List-Unsubscribe-Post).
 */

defined( 'ABSPATH' ) || exit;

class OGC_Boletin {

	const LOTE         = 50;
	const CRON_LOTE    = 'ogc_ventas_boletin_lote';
	const OPC_CAMPANA  = 'ogc_ventas_boletin_campana';
	const OPC_SEMANA   = 'ogc_ventas_boletin_semana';
	const OPC_AVISOS   = 'ogc_ventas_avisos_dia';
	const OPC_PAGINAS  = 'ogc_ventas_paginas_huella';
	const RE_NORMATIVA = '#^(convocatorias-ogc-por-comunidad|guia-oposiciones-ogc|examenes-oficiales-ogc|calculadora-sorteo-temas-ogc)(/|$)#';

	// ------------------------------------------------------------------ Lógica pura

	/** Semana ISO («2026-W46») si en $ts (Madrid) toca enviar: día $dia (1 = lunes) desde la hora $hora. */
	public static function toca_semana( $ts, $dia = 1, $hora = 9 ) {
		$d = new DateTime( '@' . (int) $ts );
		$d->setTimezone( new DateTimeZone( 'Europe/Madrid' ) );
		if ( (int) $d->format( 'N' ) !== $dia || (int) $d->format( 'G' ) < $hora ) {
			return '';
		}
		return $d->format( 'o-\WW' );
	}

	/** Día («2026-11-12») si en $ts (Madrid) ya son las $hora o más. */
	public static function toca_dia( $ts, $hora = 10 ) {
		$d = new DateTime( '@' . (int) $ts );
		$d->setTimezone( new DateTimeZone( 'Europe/Madrid' ) );
		return (int) $d->format( 'G' ) >= $hora ? $d->format( 'Y-m-d' ) : '';
	}

	/** ¿Hay algo que contar? */
	public static function hay_novedades( array $n ) {
		return ! empty( $n['entradas'] ) || ! empty( $n['paginas'] ) || ! empty( $n['material'] ) || ! empty( $n['notas'] );
	}

	// ------------------------------------------------------------------ Avisos de actualización

	/** Apunta avisos para los pedidos afectados. Devuelve cuántos. */
	public static function registrar_cambios( array $cambios ) {
		global $wpdb;
		$afectados = array();
		foreach ( OGC_Config::PRODUCTOS_VALIDOS as $prod ) {
			foreach ( OGC_Config::archivos( $prod ) as $a ) {
				if ( isset( $cambios[ $a['rel'] ] ) ) {
					$afectados[ $prod ][ $a['rel'] ] = $cambios[ $a['rel'] ];
				}
			}
		}
		if ( ! $afectados ) {
			return 0;
		}
		$tp = OGC_Pedidos::tabla();
		$ta = OGC_Pedidos::tabla( 'avisos' );
		$n  = 0;
		foreach ( $afectados as $prod => $rels ) {
			$ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $tp WHERE producto = %s AND bloqueado = 0 AND notificado = 1 AND COALESCE(actualizaciones_hasta, DATE_ADD(creado, INTERVAL 12 MONTH)) > %s", $prod, current_time( 'mysql', true ) ) ); // phpcs:ignore
			foreach ( (array) $ids as $id ) {
				foreach ( $rels as $rel => $nov ) {
					$wpdb->insert( $ta, array( 'creado' => current_time( 'mysql', true ), 'pedido_id' => (int) $id, 'ruta' => $rel, 'novedades' => $nov ) );
					++$n;
				}
			}
		}
		return $n;
	}

	/** Envía los avisos pendientes agrupados por pedido (máx. LOTE pedidos por ejecución). Devuelve cuántos correos. */
	public static function enviar_avisos() {
		global $wpdb;
		$ta  = OGC_Pedidos::tabla( 'avisos' );
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT pedido_id FROM $ta WHERE enviado IS NULL ORDER BY pedido_id LIMIT %d", self::LOTE ) ); // phpcs:ignore
		$n   = 0;
		foreach ( (array) $ids as $pid ) {
			$filas = $wpdb->get_results( $wpdb->prepare( "SELECT id, ruta, novedades FROM $ta WHERE enviado IS NULL AND pedido_id = %d ORDER BY id", $pid ), ARRAY_A ); // phpcs:ignore
			$p     = OGC_Pedidos::obtener( $pid );
			if ( $p && empty( $p['bloqueado'] ) ) {
				OGC_Pedidos::renovar( $pid );
				$p     = OGC_Pedidos::obtener( $pid );
				$lista = '';
				$vistos = array();
				foreach ( $filas as $f ) {
					if ( isset( $vistos[ $f['ruta'] ] ) ) {
						continue;
					}
					$vistos[ $f['ruta'] ] = 1;
					$lista               .= '<li><strong>' . OGC_Correo::e( pathinfo( $f['ruta'], PATHINFO_FILENAME ) ) . '</strong>: ' . OGC_Correo::e( $f['novedades'] ) . '</li>';
				}
				$c = '<p>Hola, ' . OGC_Correo::e( $p['nombre'] ) . ':</p><p>Hemos actualizado documentos de su pedido <strong>' . OGC_Correo::e( $p['pedido'] ) . '</strong> (' . OGC_Correo::e( OGC_Config::nombre_producto( $p['producto'] ) ) . '):</p><ul>' . $lista . '</ul>'
					. '<p style="margin:20px 0">' . OGC_Correo::boton( OGC_Descargas::url_pedido( $p ), 'Ver el material actualizado' ) . '</p>'
					. '<p style="font-size:14px">Su enlace se ha renovado (los anteriores dejan de funcionar) y vale hasta el ' . OGC_Correo::e( get_date_from_gmt( $p['caduca'], 'd/m/Y' ) ) . '. Los documentos nuevos llevan, como siempre, su nombre, email y número de pedido.'
					. ( $p['actualizaciones_hasta'] ? ' Actualizaciones incluidas hasta el ' . OGC_Correo::e( get_date_from_gmt( $p['actualizaciones_hasta'], 'd/m/Y' ) ) . '.' : '' ) . '</p>';
				OGC_Correo::enviar( $p['email'], 'Tu material se ha actualizado · pedido ' . $p['pedido'], 'Tu material se ha actualizado', $c );
				++$n;
			}
			$wpdb->query( $wpdb->prepare( "UPDATE $ta SET enviado = %s WHERE enviado IS NULL AND pedido_id = %d", current_time( 'mysql', true ), $pid ) ); // phpcs:ignore
		}
		return $n;
	}

	// ------------------------------------------------------------------ Novedades de la semana

	/** Reúne las novedades de los últimos 7 días. $guardar: actualiza la huella de páginas. */
	public static function novedades( $guardar = false ) {
		$desde = time() - 7 * DAY_IN_SECONDS;
		$n     = array( 'entradas' => array(), 'paginas' => array(), 'material' => array(), 'notas' => array() );
		foreach ( get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 20, 'date_query' => array( array( 'after' => gmdate( 'Y-m-d H:i:s', $desde ), 'column' => 'post_date_gmt' ) ) ) ) as $e ) {
			$n['entradas'][] = array( 'titulo' => get_the_title( $e ), 'url' => get_permalink( $e ), 'extracto' => wp_trim_words( get_the_excerpt( $e ), 30 ) );
		}
		// Páginas de convocatorias y normativa que han cambiado (manifiesto de «OGC Páginas»).
		if ( class_exists( 'OGC_Paginas_Manifiesto' ) ) {
			$m      = OGC_Paginas_Manifiesto::cargar();
			$antes  = get_option( self::OPC_PAGINAS, array() );
			$ahora  = array();
			foreach ( ( is_array( $m ) && isset( $m['paginas'] ) ? $m['paginas'] : array() ) as $pg ) {
				if ( ! preg_match( self::RE_NORMATIVA, $pg['ruta'] ) ) {
					continue;
				}
				$h                     = isset( $pg['hash_contenido'] ) ? $pg['hash_contenido'] : ( isset( $pg['hash'] ) ? $pg['hash'] : '' );
				$ahora[ $pg['ruta'] ] = $h;
				if ( is_array( $antes ) && $antes && ( ! isset( $antes[ $pg['ruta'] ] ) || $antes[ $pg['ruta'] ] !== $h ) ) {
					$n['paginas'][] = array( 'titulo' => isset( $pg['titulo_migas'] ) && $pg['titulo_migas'] ? $pg['titulo_migas'] : $pg['titulo'], 'url' => home_url( '/' . $pg['ruta'] . '/' ) );
				}
			}
			if ( $guardar ) {
				update_option( self::OPC_PAGINAS, $ahora, false );
			}
		}
		foreach ( OGC_Materiales::cambios_recientes( 7 ) as $c ) {
			$n['material'][ $c['ruta'] ] = array( 'titulo' => pathinfo( $c['ruta'], PATHINFO_FILENAME ), 'novedades' => $c['novedades'] );
		}
		$n['material'] = array_values( $n['material'] );
		$mm            = OGC_Materiales::manifiesto();
		foreach ( ( $mm && isset( $mm['novedades_semana'] ) && is_array( $mm['novedades_semana'] ) ) ? $mm['novedades_semana'] : array() as $x ) {
			$f = isset( $x['fecha'] ) ? strtotime( $x['fecha'] . ' 12:00 Europe/Madrid' ) : 0;
			if ( $f && $f > $desde && ! empty( $x['texto'] ) ) {
				$n['notas'][] = array( 'texto' => wp_strip_all_tags( $x['texto'] ), 'url' => isset( $x['url'] ) && 0 === strpos( (string) $x['url'], 'https://' ) ? $x['url'] : '' );
			}
		}
		return $n;
	}

	public static function html_boletin( array $n ) {
		$h = '<p>Estas son las novedades de la semana en Preparador OGC (Organización y Gestión Comercial, 0590-110).</p>';
		if ( $n['notas'] ) {
			$h .= '<h2 style="color:#1F4E79;font-size:18px">Lo más importante</h2><ul>';
			foreach ( $n['notas'] as $x ) {
				$h .= '<li>' . OGC_Correo::e( $x['texto'] ) . ( $x['url'] ? ' <a href="' . OGC_Correo::e( $x['url'] ) . '" style="color:#1F4E79">Más información</a>' : '' ) . '</li>';
			}
			$h .= '</ul>';
		}
		if ( $n['paginas'] ) {
			$h .= '<h2 style="color:#1F4E79;font-size:18px">Convocatorias y normativa</h2><p>Hemos revisado y actualizado:</p><ul>';
			foreach ( $n['paginas'] as $x ) {
				$h .= '<li><a href="' . OGC_Correo::e( $x['url'] ) . '" style="color:#1F4E79">' . OGC_Correo::e( $x['titulo'] ) . '</a></li>';
			}
			$h .= '</ul>';
		}
		if ( $n['entradas'] ) {
			$h .= '<h2 style="color:#1F4E79;font-size:18px">Nuevo en el blog</h2><ul>';
			foreach ( $n['entradas'] as $x ) {
				$h .= '<li><a href="' . OGC_Correo::e( $x['url'] ) . '" style="color:#1F4E79"><strong>' . OGC_Correo::e( $x['titulo'] ) . '</strong></a><br><span style="font-size:14px">' . OGC_Correo::e( $x['extracto'] ) . '</span></li>';
			}
			$h .= '</ul>';
		}
		if ( $n['material'] ) {
			$h .= '<h2 style="color:#1F4E79;font-size:18px">Material actualizado</h2><ul>';
			foreach ( $n['material'] as $x ) {
				$h .= '<li><strong>' . OGC_Correo::e( $x['titulo'] ) . '</strong>: ' . OGC_Correo::e( $x['novedades'] ) . '</li>';
			}
			$h .= '</ul><p style="font-size:14px">Si compró el material, ya le hemos enviado por correo el enlace a la versión nueva.</p>';
		}
		return $h . '<p>' . OGC_Correo::boton( home_url( '/tienda/' ), 'Ver el material', true ) . '</p>';
	}

	// ------------------------------------------------------------------ Cron

	public static function programar() {
		if ( ! wp_next_scheduled( 'ogc_ventas_horario' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'ogc_ventas_horario' );
		}
	}

	/** Cada hora: avisos del día y, los lunes, el boletín. */
	public static function cron() {
		// Conservación (política de privacidad): los accesos se guardan 12 meses.
		if ( ! get_transient( 'ogc_ventas_purga' ) ) {
			set_transient( 'ogc_ventas_purga', 1, DAY_IN_SECONDS );
			global $wpdb;
			$tac = OGC_Pedidos::tabla( 'accesos' );
			$wpdb->query( $wpdb->prepare( "DELETE FROM $tac WHERE fecha < %s", gmdate( 'Y-m-d H:i:s', time() - 365 * DAY_IN_SECONDS ) ) ); // phpcs:ignore
		}
		$dia = self::toca_dia( time(), 10 );
		if ( $dia && get_option( self::OPC_AVISOS ) !== $dia ) {
			self::enviar_avisos();
			global $wpdb;
			$ta = OGC_Pedidos::tabla( 'avisos' );
			if ( ! (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ta WHERE enviado IS NULL" ) ) { // phpcs:ignore
				update_option( self::OPC_AVISOS, $dia, false );
			} else {
				wp_schedule_single_event( time() + 300, self::CRON_LOTE );
			}
		}
		$sem = self::toca_semana( time(), 1, 9 );
		if ( $sem && OGC_Config::ajuste( 'boletin_activo' ) && get_option( self::OPC_SEMANA ) !== $sem ) {
			update_option( self::OPC_SEMANA, $sem, false );
			self::preparar( $sem );
		}
	}

	/** Prepara la campaña de la semana (o la descarta si no hay novedades). Devuelve un texto. */
	public static function preparar( $sem, $forzar = false ) {
		$n = self::novedades( true );
		if ( ! self::hay_novedades( $n ) && ! $forzar ) {
			OGC_Seguridad::registrar( null, 'boletin', 'Semana ' . $sem . ': sin novedades, no se envía' );
			return 'Sin novedades esta semana: no se envía el boletín.';
		}
		update_option( self::OPC_CAMPANA, array( 'semana' => $sem, 'asunto' => 'Novedades de la semana en Preparador OGC', 'html' => self::html_boletin( $n ), 'inicio' => time() ), false );
		wp_schedule_single_event( time() + 30, self::CRON_LOTE );
		return 'Boletín de la semana ' . $sem . ' preparado: se envía en lotes de ' . self::LOTE . ' cada 5 minutos.';
	}

	/** Un lote: avisos pendientes y/o boletín. */
	public static function lote() {
		global $wpdb;
		$quedan = false;
		$dia    = self::toca_dia( time(), 10 );
		if ( $dia && get_option( self::OPC_AVISOS ) !== $dia ) {
			self::enviar_avisos();
			$ta = OGC_Pedidos::tabla( 'avisos' );
			if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM $ta WHERE enviado IS NULL" ) ) { // phpcs:ignore
				$quedan = true;
			} else {
				update_option( self::OPC_AVISOS, $dia, false );
			}
		}
		$c = get_option( self::OPC_CAMPANA );
		if ( is_array( $c ) && ! empty( $c['semana'] ) ) {
			$t     = OGC_Pedidos::tabla( 'contactos' );
			$filas = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE boletin = 1 AND baja IS NULL AND ultimo_boletin <> %s ORDER BY id LIMIT %d", $c['semana'], self::LOTE ), ARRAY_A ); // phpcs:ignore
			foreach ( $filas as $ct ) {
				$baja = OGC_Contactos::url_baja( $ct );
				OGC_Correo::enviar(
					$ct['email'],
					$c['asunto'],
					$c['asunto'],
					$c['html'],
					array( 'List-Unsubscribe: <' . $baja . '>, <mailto:' . OGC_Config::correo() . '?subject=Baja%20del%20boletin>', 'List-Unsubscribe-Post: List-Unsubscribe=One-Click' ),
					'<br>Recibe este boletín porque se suscribió expresamente. <a href="' . OGC_Correo::e( $baja ) . '" style="color:#1F4E79">Darme de baja con un clic</a>.'
				);
				$wpdb->update( $t, array( 'ultimo_boletin' => $c['semana'] ), array( 'id' => (int) $ct['id'] ) );
			}
			if ( count( $filas ) === self::LOTE ) {
				$quedan = true;
			} else {
				delete_option( self::OPC_CAMPANA );
			}
		}
		if ( $quedan ) {
			wp_schedule_single_event( time() + 300, self::CRON_LOTE );
		}
	}
}
