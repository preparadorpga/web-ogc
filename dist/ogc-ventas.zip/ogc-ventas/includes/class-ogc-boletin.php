<?php
/**
 * Avisos de actualización y boletín semanal (1.1.0).
 *
 * AVISOS: desde 1.3.0 los lleva OGC_Avisos (material, muestras y novedades; un correo por persona y día, en el día).
 *
 * BOLETÍN: los lunes desde las 09:00 (Madrid) se prepara el boletín con las novedades de la semana: entradas del blog
 * publicadas, páginas de convocatorias y normativa que han cambiado (comparando el manifiesto de «OGC Páginas»),
 * material actualizado y las «novedades_semana» del paquete de materiales. Si no hay nada, no se envía. Solo a
 * contactos con consentimiento expreso y sin baja, en lotes de 50 cada 5 minutos, con enlace de baja de un clic
 * (también en las cabeceras List-Unsubscribe y List-Unsubscribe-Post).
 */

defined( 'ABSPATH' ) || exit;

class OGC_Boletin {

	const LOTE         = 50;
	const CRON_LOTE    = 'ogc_ventas_boletin_lote';
	const OPC_CAMPANA  = 'ogc_ventas_boletin_campana';
	const OPC_SEMANA   = 'ogc_ventas_boletin_semana';
	const OPC_AVISOS   = 'ogc_ventas_avisos_dia';
	const OPC_PAGINAS  = 'ogc_ventas_paginas_huella';
	const RE_NORMATIVA = '#^(convocatorias-ogc-por-comunidad|guia-oposiciones-ogc|examenes-oficiales-ogc|calculadora-sorteo-temas-ogc)(/|$)#';

	// ------------------------------------------------------------------ Lógica pura

	/** Semana ISO («2026-W46») si en $ts (Madrid) toca enviar: día $dia (1 = lunes) desde la hora $hora. */
	public static function toca_semana( $ts, $dia = 1, $hora = 9 ) {
		$d = new DateTime( '@' . (int) $ts );
		$d->setTimezone( new DateTimeZone( 'Europe/Madrid' ) );
		if ( (int) $d->format( 'N' ) !== $dia || (int) $d->format( 'G' ) < $hora ) {
			return '';
		}
		return $d->format( 'o-\WW' );
	}

	/** Día («2026-11-12») si en $ts (Madrid) ya son las $hora o más. */
	public static function toca_dia( $ts, $hora = 10 ) {
		$d = new DateTime( '@' . (int) $ts );
		$d->setTimezone( new DateTimeZone( 'Europe/Madrid' ) );
		return (int) $d->format( 'G' ) >= $hora ? $d->format( 'Y-m-d' ) : '';
	}

	/** ¿Hay algo que contar? */
	public static function hay_novedades( array $n ) {
		return ! empty( $n['entradas'] ) || ! empty( $n['paginas'] ) || ! empty( $n['material'] ) || ! empty( $n['notas'] );
	}

	// ------------------------------------------------------------------ Avisos (compatibilidad con 1.2)

	/** 1.3.0: apunta avisos de documentos actualizados (array ruta => novedades) en la cola nueva. Devuelve cuántos. */
	public static function registrar_cambios( array $cambios ) {
		$e = array();
		foreach ( $cambios as $ruta => $nov ) {
			$n = OGC_Avisos::normalizar( array( 'id' => substr( hash( 'sha256', 'manual|' . microtime( true ) . '|' . $ruta ), 0, 16 ), 'grupo' => 'archivos', 'tipo' => 'actualizacion', 'ruta' => $ruta, 'nota' => (string) $nov ) );
			if ( $n ) {
				$e[] = $n;
			}
		}
		return $e ? OGC_Avisos::encolar( $e ) : 0;
	}

	/** 1.3.0: envía ya los avisos pendientes (un correo por persona y día). Devuelve cuántos correos. */
	public static function enviar_avisos() {
		return OGC_Avisos::enviar( true );
	}

	// ------------------------------------------------------------------ Novedades de la semana

	/** Reúne las novedades de los últimos 7 días. $guardar: actualiza la huella de páginas. */
	public static function novedades( $guardar = false ) {
		$desde = time() - 7 * DAY_IN_SECONDS;
		$n     = array( 'entradas' => array(), 'paginas' => array(), 'material' => array(), 'notas' => array() );
		foreach ( get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 20, 'date_query' => array( array( 'after' => gmdate( 'Y-m-d H:i:s', $desde ), 'column' => 'post_date_gmt' ) ) ) ) as $e ) {
			$n['entradas'][] = array( 'titulo' => get_the_title( $e ), 'url' => get_permalink( $e ), 'extracto' => wp_trim_words( get_the_excerpt( $e ), 30 ) );
		}
		// Páginas de convocatorias y normativa que han cambiado (manifiesto de «OGC Páginas»).
		if ( class_exists( 'OGC_Paginas_Manifiesto' ) ) {
			$m      = OGC_Paginas_Manifiesto::cargar();
			$antes  = get_option( self::OPC_PAGINAS, array() );
			$ahora  = array();
			foreach ( ( is_array( $m ) && isset( $m['paginas'] ) ? $m['paginas'] : array() ) as $pg ) {
				if ( ! preg_match( self::RE_NORMATIVA, $pg['ruta'] ) ) {
					continue;
				}
				$h                     = isset( $pg['hash_contenido'] ) ? $pg['hash_contenido'] : ( isset( $pg['hash'] ) ? $pg['hash'] : '' );
				$ahora[ $pg['ruta'] ] = $h;
				if ( is_array( $antes ) && $antes && ( ! isset( $antes[ $pg['ruta'] ] ) || $antes[ $pg['ruta'] ] !== $h ) ) {
					$n['paginas'][] = array( 'titulo' => isset( $pg['titulo_migas'] ) && $pg['titulo_migas'] ? $pg['titulo_migas'] : $pg['titulo'], 'url' => home_url( '/' . $pg['ruta'] . '/' ) );
				}
			}
			if ( $guardar ) {
				update_option( self::OPC_PAGINAS, $ahora, false );
			}
		}
		foreach ( OGC_Materiales::cambios_recientes( 7 ) as $c ) {
			if ( isset( $c['grupo'] ) && 'muestras' === $c['grupo'] ) {
				continue;
			}
			$n['material'][ $c['ruta'] ] = array( 'titulo' => pathinfo( $c['ruta'], PATHINFO_FILENAME ), 'novedades' => $c['novedades'] );
		}
		$n['material'] = array_values( $n['material'] );
		$mm            = OGC_Materiales::manifiesto();
		foreach ( ( $mm && isset( $mm['novedades_semana'] ) && is_array( $mm['novedades_semana'] ) ) ? $mm['novedades_semana'] : array() as $x ) {
			$f = isset( $x['fecha'] ) ? strtotime( $x['fecha'] . ' 12:00 Europe/Madrid' ) : 0;
			if ( $f && $f > $desde && ! empty( $x['texto'] ) ) {
				$n['notas'][] = array( 'texto' => wp_strip_all_tags( $x['texto'] ), 'url' => isset( $x['url'] ) && 0 === strpos( (string) $x['url'], 'https://' ) ? $x['url'] : '' );
			}
		}
		return $n;
	}

	public static function html_boletin( array $n ) {
		$h = '<p>Estas son las novedades de la semana en Preparador OGC (Organización y Gestión Comercial, 0590-110).</p>';
		if ( $n['notas'] ) {
			$h .= '<h2 style="color:#1F4E79;font-size:18px">Lo más importante</h2><ul>';
			foreach ( $n['notas'] as $x ) {
				$h .= '<li>' . OGC_Correo::e( $x['texto'] ) . ( $x['url'] ? ' <a href="' . OGC_Correo::e( $x['url'] ) . '" style="color:#1F4E79">Más información</a>' : '' ) . '</li>';
			}
			$h .= '</ul>';
		}
		if ( $n['paginas'] ) {
			$h .= '<h2 style="color:#1F4E79;font-size:18px">Convocatorias y normativa</h2><p>Hemos revisado y actualizado:</p><ul>';
			foreach ( $n['paginas'] as $x ) {
				$h .= '<li><a href="' . OGC_Correo::e( $x['url'] ) . '" style="color:#1F4E79">' . OGC_Correo::e( $x['titulo'] ) . '</a></li>';
			}
			$h .= '</ul>';
		}
		if ( $n['entradas'] ) {
			$h .= '<h2 style="color:#1F4E79;font-size:18px">Nuevo en el blog</h2><ul>';
			foreach ( $n['entradas'] as $x ) {
				$h .= '<li><a href="' . OGC_Correo::e( $x['url'] ) . '" style="color:#1F4E79"><strong>' . OGC_Correo::e( $x['titulo'] ) . '</strong></a><br><span style="font-size:14px">' . OGC_Correo::e( $x['extracto'] ) . '</span></li>';
			}
			$h .= '</ul>';
		}
		if ( $n['material'] ) {
			$h .= '<h2 style="color:#1F4E79;font-size:18px">Material actualizado</h2><ul>';
			foreach ( $n['material'] as $x ) {
				$h .= '<li><strong>' . OGC_Correo::e( $x['titulo'] ) . '</strong>: ' . OGC_Correo::e( $x['novedades'] ) . '</li>';
			}
			$h .= '</ul><p style="font-size:14px">Si compraste el material, ya te hemos enviado por correo el enlace a la versión nueva.</p>';
		}
		return $h . '<p>' . OGC_Correo::boton( home_url( '/tienda/' ), 'Ver el material', true ) . '</p>';
	}

	// ------------------------------------------------------------------ Cron

	public static function programar() {
		if ( ! wp_next_scheduled( 'ogc_ventas_horario' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'ogc_ventas_horario' );
		}
	}

	/** Cada hora: avisos (OGC_Avisos) y, los lunes, el boletín. */
	public static function cron() {
		// Conservación (política de privacidad): los accesos se guardan 12 meses.
		if ( ! get_transient( 'ogc_ventas_purga' ) ) {
			set_transient( 'ogc_ventas_purga', 1, DAY_IN_SECONDS );
			global $wpdb;
			$tac = OGC_Pedidos::tabla( 'accesos' );
			$wpdb->query( $wpdb->prepare( "DELETE FROM $tac WHERE fecha < %s", gmdate( 'Y-m-d H:i:s', time() - 365 * DAY_IN_SECONDS ) ) ); // phpcs:ignore
		}
		OGC_Avisos::cron(); // 1.3.0: avisos de material, muestras y novedades (en el día, un correo por persona)
		$sem = self::toca_semana( time(), 1, 9 );
		if ( $sem && OGC_Config::ajuste( 'boletin_activo' ) && get_option( self::OPC_SEMANA ) !== $sem ) {
			update_option( self::OPC_SEMANA, $sem, false );
			self::preparar( $sem );
		}
	}

	/** Prepara la campaña de la semana (o la descarta si no hay novedades). Devuelve un texto. */
	public static function preparar( $sem, $forzar = false ) {
		$n = self::novedades( true );
		if ( ! self::hay_novedades( $n ) && ! $forzar ) {
			OGC_Seguridad::registrar( null, 'boletin', 'Semana ' . $sem . ': sin novedades, no se envía' );
			return 'Sin novedades esta semana: no se envía el boletín.';
		}
		update_option( self::OPC_CAMPANA, array( 'semana' => $sem, 'asunto' => 'Novedades de la semana en Preparador OGC', 'html' => self::html_boletin( $n ), 'inicio' => time() ), false );
		wp_schedule_single_event( time() + 30, self::CRON_LOTE );
		return 'Boletín de la semana ' . $sem . ' preparado: se envía en lotes de ' . self::LOTE . ' cada 5 minutos.';
	}

	/** Un lote del boletín (los avisos tienen su propio lote desde 1.3.0). */
	public static function lote() {
		global $wpdb;
		$quedan = false;
		$c = get_option( self::OPC_CAMPANA );
		if ( is_array( $c ) && ! empty( $c['semana'] ) ) {
			$t     = OGC_Pedidos::tabla( 'contactos' );
			$filas = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE boletin = 1 AND baja IS NULL AND ultimo_boletin <> %s ORDER BY id LIMIT %d", $c['semana'], self::LOTE ), ARRAY_A ); // phpcs:ignore
			foreach ( $filas as $ct ) {
				$baja = OGC_Contactos::url_baja( $ct );
				OGC_Correo::enviar(
					$ct['email'],
					$c['asunto'],
					$c['asunto'],
					$c['html'],
					array( 'List-Unsubscribe: <' . $baja . '>, <mailto:' . OGC_Config::correo() . '?subject=Baja%20del%20boletin>', 'List-Unsubscribe-Post: List-Unsubscribe=One-Click' ),
					'<br>Recibes este boletín porque te suscribiste expresamente. <a href="' . OGC_Correo::e( $baja ) . '" style="color:#1F4E79">Darme de baja con un clic</a>.'
				);
				$wpdb->update( $t, array( 'ultimo_boletin' => $c['semana'] ), array( 'id' => (int) $ct['id'] ) );
			}
			if ( count( $filas ) === self::LOTE ) {
				$quedan = true;
			} else {
				delete_option( self::OPC_CAMPANA );
			}
		}
		if ( $quedan ) {
			wp_schedule_single_event( time() + 300, self::CRON_LOTE );
		}
	}
}
