<?php
/**
 * Secuencia de correos para quien pide las muestras (1.3.6). Orden de Vicente (17/11/2026 22:32).
 *
 *   Día 0: el correo con los enlaces de las muestras (OGC_Contactos, sin cambios).
 *   Día 3: «Cómo organizar el estudio de OGC» (WhatsApp, consejos, 3 artículos del blog, muestra de programación,
 *          clases en directo e individuales).
 *   Día 7: la tienda (precios con tarjeta, packs, clases y fin del precio de lanzamiento el 10/01/2027).
 *
 * Lo envía SOLO el servidor (WP-cron horario del plugin, sin servicios externos ni IA), desde las 10:00 hasta las
 * 22:00 (Madrid), en lotes de 50 cada 5 minutos y como máximo un correo del plugin por persona y día (si ese día ya
 * recibió un aviso, o el boletín del lunes, el seguimiento espera al día siguiente). Cada correo se reserva en la
 * tabla de contactos (seguimiento_3 / seguimiento_7) ANTES de enviarlo, con una actualización condicionada, así que
 * nunca sale dos veces; si wp_mail falla se libera y se reintenta otro día.
 *
 * No reciben la secuencia: quien compra (pedido pagado con el mismo email o venta de clases; compra_desde), quien se
 * da de baja, la alta de prueba de Vicente y el correo del propio plugin. Contactos anteriores a la instalación: el
 * día 3 llega el día siguiente a instalar 1.3.6 (o al cumplirse los 3 días, si es más tarde) y el día 7, cuatro días
 * después del día 3 (o al cumplirse los 7 días, si es más tarde). La fórmula es la misma para todos:
 *   día 3 = máx( día de las muestras + 3, día de instalación + 1 )
 *   día 7 = máx( día de las muestras + 7, día en que salió el día 3 + 4 )
 */

defined( 'ABSPATH' ) || exit;

class OGC_Seguimiento {

	const CRON_LOTE  = 'ogc_ventas_seguimiento_lote';
	const OPC_INICIO = 'ogc_ventas_seguimiento_inicio';
	const LOTE       = 50;
	const HORA_DESDE = 10;
	const HORA_HASTA = 22;
	const PRUEBA     = array( 'preparador@organizacionygestioncomercial.es' );
	const WHATSAPP   = 'https://wa.me/34678872362';
	const WA_TEXTO   = 'Hola, Vicente. He descargado las muestras de OGC y tengo una duda: ';
	const FIN_LANZAMIENTO = '2027-01-11'; // desde este día (Madrid) rigen los precios con la subida del 15 %
	const PASOS      = array( 3 => 'Cómo organizar el estudio (día 3)', 7 => 'La tienda (día 7)' );

	/** Artículos del blog elegidos (los más útiles para organizarse), por orden. Solo se enlazan si están publicados. */
	const ARTICULOS = array( 'plan-estudio-oposiciones-ogc-diciembre-junio', 'que-temas-preparar-ogc', 'como-hacer-programacion-didactica-ogc' );
	/** Si alguno aún no está publicado, se completa con estos (artículos y, al final, guías permanentes de la web). */
	const ARTICULOS_RESERVA = array( 'como-escribir-tema-oposiciones-ogc', 'bolsas-interinos-ogc' );
	const PAGINAS_RESERVA   = array( 'calculadora-sorteo-temas-ogc', 'guia-oposiciones-ogc/examen' );

	/**
	 * Precios con tarjeta de la tienda (ventas/productos.json, BRIEF_OGC.md y ENLACES_DE_PAGO_OGC.md, 16/11/2026):
	 * grupo, nombre, detalle, precio de lanzamiento, precio desde el 11/01/2027 y Payment Link de Stripe.
	 */
	const PRECIOS = array(
		array( 'material', 'Temario completo', '71 temas en PDF', '362,50 €', '416,88 €', 'https://buy.stripe.com/3cI14p4OX3hl38Nclo9IQ00' ),
		array( 'material', 'Supuestos prácticos', '7 dossieres resueltos con sus hojas Excel', '237,50 €', '273,13 €', 'https://buy.stripe.com/3cI4gBbdl3hl8t7adg9IQ01' ),
		array( 'material', 'Programación didáctica', '6 programaciones modelo (6 módulos en 6 comunidades)', '186,25 €', '214,19 €', 'https://buy.stripe.com/aFa4gBa9hbNR6kZ8589IQ02' ),
		array( 'pack', 'Pack completo', 'Temario + supuestos + programación (por separado, 786,25 €)', '623,75 €', '717,31 €', 'https://buy.stripe.com/3cIfZj8198BFaBf1GK9IQ03' ),
		array( 'pack', 'Pack completo + 10 h de clases', 'Los tres materiales y 10 horas de clase individual (623,75 € + 625 €)', '1.248,75 €', '1.436,06 €', 'https://buy.stripe.com/dRm9AV95ddVZdNretw9IQ04' ),
		array( 'pack', 'Pack Programación', 'Las 6 programaciones modelo + 4 h de corrección de tu programación y 1 h de clase (por separado, 536,25 €)', '500 €', '575 €', 'https://buy.stripe.com/eVq3cx1CL4lp4cR7149IQ05' ),
		array( 'clases', 'Pack de 3 horas', '75 € la hora', '225 €', '258,75 €', 'https://buy.stripe.com/fZu6oJ0yHg4738N0CG9IQ06' ),
		array( 'clases', 'Pack de 5 horas', '70 € la hora', '350 €', '402,50 €', 'https://buy.stripe.com/5kQ5kF6X57xB6kZ1GK9IQ07' ),
		array( 'clases', 'Pack de 10 horas', '62,50 € la hora', '625 €', '718,75 €', 'https://buy.stripe.com/6oU9AVa9h7xB8t71GK9IQ08' ),
	);

	// ------------------------------------------------------------------ Lógica pura

	/** Día de Madrid («2026-11-18») de $ts. */
	public static function dia( $ts ) {
		$d = new DateTime( '@' . (int) $ts );
		$d->setTimezone( new DateTimeZone( 'Europe/Madrid' ) );
		return $d->format( 'Y-m-d' );
	}

	/** $dia («Y-m-d») + $n días naturales. */
	public static function mas_dias( $dia, $n ) {
		$d = new DateTime( $dia . ' 12:00', new DateTimeZone( 'Europe/Madrid' ) );
		$d->modify( ( $n >= 0 ? '+' : '' ) . (int) $n . ' days' );
		return $d->format( 'Y-m-d' );
	}

	/** Fecha UTC de MySQL → marca de tiempo (0 si está vacía). */
	public static function ts( $mysql ) {
		return $mysql ? (int) strtotime( $mysql . ' UTC' ) : 0;
	}

	/** ¿Es hora de enviar (10:00-21:59 en Madrid)? */
	public static function en_ventana( $ts ) {
		$d = new DateTime( '@' . (int) $ts );
		$d->setTimezone( new DateTimeZone( 'Europe/Madrid' ) );
		$h = (int) $d->format( 'G' );
		return $h >= self::HORA_DESDE && $h < self::HORA_HASTA;
	}

	/** ¿Es la alta de prueba de Vicente o una dirección del propio plugin? */
	public static function excluido( $email, array $extra = array() ) {
		$e = strtolower( trim( (string) $email ) );
		foreach ( array_merge( self::PRUEBA, $extra ) as $x ) {
			if ( '' !== (string) $x && strtolower( trim( (string) $x ) ) === $e ) {
				return true;
			}
		}
		return false;
	}

	/** Quita de una cabecera los saltos de línea y los caracteres de control (inyección de cabeceras). */
	public static function cabecera( $v ) {
		return trim( preg_replace( '/[\x00-\x1F\x7F]+/', ' ', (string) $v ) );
	}

	/** Email apto para el campo «Para»: válido y sin saltos de línea, comas ni ángulos. */
	public static function email_seguro( $email ) {
		$email = (string) $email;
		return '' !== $email && ! preg_match( '/[\x00-\x1F\x7F,;<>"\s]/', $email ) && is_email( $email );
	}

	/** ¿Rige aún el precio de lanzamiento en $ts (hasta el 10/01/2027 23:59, Madrid)? */
	public static function lanzamiento( $ts ) {
		return self::dia( $ts ) < self::FIN_LANZAMIENTO;
	}

	/**
	 * Paso de la secuencia de un contacto (función pura).
	 *
	 * @param array $c        Fila de contactos (muestras_desde, baja, seguimiento_3, seguimiento_7, email).
	 * @param bool  $compro   Tiene un pedido pagado o una venta de clases con ese email.
	 * @param int   $inicio   Marca de tiempo de la instalación de 1.3.6 (0 = desconocida).
	 * @param int   $ahora    Marca de tiempo actual.
	 * @param bool  $excluido Alta de prueba.
	 * @return array codigo, texto (para el escritorio), toca (0, 3 o 7), fecha (día previsto «Y-m-d» o '').
	 */
	public static function estado( array $c, $compro, $inicio, $ahora, $excluido = false ) {
		$m   = self::ts( isset( $c['muestras_desde'] ) ? $c['muestras_desde'] : '' );
		$s3  = self::ts( isset( $c['seguimiento_3'] ) ? $c['seguimiento_3'] : '' );
		$s7  = self::ts( isset( $c['seguimiento_7'] ) ? $c['seguimiento_7'] : '' );
		$hoy = self::dia( $ahora );
		$f   = static function ( $dia ) {
			return implode( '/', array_reverse( explode( '-', $dia ) ) );
		};
		$hecho = ( $s3 ? ' · día 3 enviado el ' . $f( self::dia( $s3 ) ) : '' ) . ( $s7 ? ' · día 7 enviado el ' . $f( self::dia( $s7 ) ) : '' );
		$r     = static function ( $codigo, $texto, $toca = 0, $fecha = '' ) {
			return array( 'codigo' => $codigo, 'texto' => $texto, 'toca' => $toca, 'fecha' => $fecha );
		};
		if ( ! $m ) {
			return $r( 'sin_muestras', 'No pidió muestras' . $hecho );
		}
		if ( $s7 ) {
			return $r( 'fin', 'Secuencia completa' . $hecho );
		}
		if ( $excluido ) {
			return $r( 'prueba', 'Alta de prueba: no recibe la secuencia' . $hecho );
		}
		if ( ! empty( $c['baja'] ) ) {
			return $r( 'baja', 'Baja: no recibe nada más' . $hecho );
		}
		if ( $compro ) {
			return $r( 'compra', 'Compró: secuencia parada' . $hecho );
		}
		if ( ! $s3 ) {
			$f3 = self::mas_dias( self::dia( $m ), 3 );
			if ( $inicio ) {
				$f3 = max( $f3, self::mas_dias( self::dia( $inicio ), 1 ) );
			}
			return $hoy >= $f3
				? $r( 'toca_3', 'Día 0 hecho · día 3: hoy desde las 10:00 (o en cuanto pase el cron)', 3, $f3 )
				: $r( 'espera_3', 'Día 0 hecho · día 3 previsto el ' . $f( $f3 ), 0, $f3 );
		}
		$f7 = max( self::mas_dias( self::dia( $m ), 7 ), self::mas_dias( self::dia( $s3 ), 4 ) );
		return $hoy >= $f7
			? $r( 'toca_7', 'Día 3 hecho · día 7: hoy desde las 10:00 (o en cuanto pase el cron)' . $hecho, 7, $f7 )
			: $r( 'espera_7', 'Día 3 hecho · día 7 previsto el ' . $f( $f7 ) . $hecho, 0, $f7 );
	}

	// ------------------------------------------------------------------ Datos

	/** Marca de tiempo de la instalación de 1.3.6 (la crea si no existe). */
	public static function inicio() {
		$i = (int) get_option( self::OPC_INICIO, 0 );
		if ( ! $i ) {
			$i = time();
			update_option( self::OPC_INICIO, $i, false );
		}
		return $i;
	}

	/** Correos que nunca reciben la secuencia. */
	public static function excluidos() {
		return array_unique( array_map( 'strtolower', array_merge( self::PRUEBA, array( OGC_Config::correo(), OGC_Config::aviso_email() ) ) ) );
	}

	/** ¿Ha comprado (pedido pagado o clases) con ese email? */
	public static function compro( array $c ) {
		if ( ! empty( $c['compra_desde'] ) ) {
			return true;
		}
		global $wpdb;
		$t = OGC_Pedidos::tabla();
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE email = %s", strtolower( (string) $c['email'] ) ) ) > 0; // phpcs:ignore
	}

	/** Anota la primera compra en el contacto (si existe): para la secuencia. */
	public static function marcar_compra( $email, $ahora = null ) {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'contactos' );
		return $wpdb->query( $wpdb->prepare( "UPDATE $t SET compra_desde = %s WHERE email = %s AND compra_desde IS NULL", gmdate( 'Y-m-d H:i:s', $ahora ? $ahora : time() ), strtolower( trim( (string) $email ) ) ) ); // phpcs:ignore
	}

	/** Al instalar 1.3.6: los contactos con un pedido anterior quedan como compradores. Devuelve filas. */
	public static function migrar_compras() {
		global $wpdb;
		$t = OGC_Pedidos::tabla( 'contactos' );
		$p = OGC_Pedidos::tabla();
		return (int) $wpdb->query( "UPDATE $t SET compra_desde = (SELECT MIN(creado) FROM $p WHERE $p.email = $t.email) WHERE compra_desde IS NULL AND EXISTS (SELECT 1 FROM $p WHERE $p.email = $t.email)" ); // phpcs:ignore
	}

	/** Estado de un contacto para el escritorio. */
	public static function estado_contacto( array $c, $ahora = null ) {
		return self::estado( $c, self::compro( $c ), self::inicio(), $ahora ? $ahora : time(), self::excluido( $c['email'], self::excluidos() ) );
	}

	// ------------------------------------------------------------------ Envío

	/**
	 * Envía los correos que tocan (un lote). $forzar: a cualquier hora (pruebas). Devuelve cuántos correos salieron.
	 */
	public static function enviar( $ahora = null, $forzar = false ) {
		global $wpdb;
		$ahora = $ahora ? (int) $ahora : time();
		if ( ! OGC_Config::ajuste( 'seguimiento_activo' ) || ( ! $forzar && ! self::en_ventana( $ahora ) ) ) {
			return 0;
		}
		$dia    = self::dia( $ahora );
		$lunes  = '1' === ( new DateTime( '@' . $ahora ) )->setTimezone( new DateTimeZone( 'Europe/Madrid' ) )->format( 'N' );
		$semana = ( new DateTime( '@' . $ahora ) )->setTimezone( new DateTimeZone( 'Europe/Madrid' ) )->format( 'o-\WW' );
		$inicio = self::inicio();
		$excl   = self::excluidos();
		$t      = OGC_Pedidos::tabla( 'contactos' );
		$te     = OGC_Pedidos::tabla( 'envios' );
		$filas  = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE muestras_desde IS NOT NULL AND baja IS NULL AND compra_desde IS NULL AND seguimiento_7 IS NULL AND email NOT IN (SELECT email FROM $te WHERE dia = %s) ORDER BY id LIMIT 1000", $dia ), ARRAY_A ); // phpcs:ignore
		$n      = 0;
		$lleno  = false;
		foreach ( $filas as $c ) {
			$e = self::estado( $c, self::compro( $c ), $inicio, $ahora, self::excluido( $c['email'], $excl ) );
			if ( ! $e['toca'] ) {
				continue;
			}
			if ( $lunes && (string) $c['ultimo_boletin'] === $semana ) {
				continue; // hoy ya recibió el boletín: un correo por día
			}
			if ( $n >= self::LOTE ) {
				$lleno = true;
				break;
			}
			if ( self::enviar_paso( $c, $e['toca'], $ahora ) ) {
				++$n;
			}
		}
		if ( $lleno ) {
			wp_schedule_single_event( time() + 300, self::CRON_LOTE );
		}
		return $n;
	}

	/** Reserva y envía el correo del paso 3 o 7 a un contacto. true si salió. */
	public static function enviar_paso( array $c, $paso, $ahora = null ) {
		global $wpdb;
		$paso  = 7 === (int) $paso ? 7 : 3;
		$ahora = $ahora ? (int) $ahora : time();
		if ( ! self::email_seguro( $c['email'] ) ) {
			return false;
		}
		$t     = OGC_Pedidos::tabla( 'contactos' );
		$col   = 'seguimiento_' . $paso;
		$fecha = gmdate( 'Y-m-d H:i:s', $ahora );
		$cond  = 7 === $paso ? ' AND seguimiento_3 IS NOT NULL' : '';
		// Reserva atómica: si otro proceso ya lo envió (o se dio de baja o compró entretanto), no se repite.
		$res = $wpdb->query( $wpdb->prepare( "UPDATE $t SET $col = %s WHERE id = %d AND $col IS NULL AND baja IS NULL AND compra_desde IS NULL" . $cond, $fecha, (int) $c['id'] ) ); // phpcs:ignore
		if ( 1 !== (int) $res ) {
			return false;
		}
		$m    = 3 === $paso ? self::correo_3( $c, $ahora ) : self::correo_7( $c, $ahora );
		$baja = OGC_Contactos::url_baja( $c );
		$cab  = array(
			self::cabecera( 'List-Unsubscribe: <' . $baja . '>, <mailto:' . OGC_Config::correo() . '?subject=Baja%20de%20los%20correos>' ),
			'List-Unsubscribe-Post: List-Unsubscribe=One-Click',
		);
		$pie  = '<br>Recibes este correo porque pediste las muestras de Preparador OGC. Son dos correos de seguimiento y no recibirás ninguno más si compras o te das de baja. <a href="' . OGC_Correo::e( $baja ) . '" style="color:#1F4E79">Darme de baja con un clic</a>.';
		$ok   = OGC_Correo::enviar( $c['email'], self::cabecera( $m['asunto'] ), $m['titulo'], $m['html'], $cab, $pie );
		$wpdb->insert(
			OGC_Pedidos::tabla( 'envios' ),
			array(
				'fecha'      => $fecha,
				'dia'        => self::dia( $ahora ),
				'email'      => strtolower( $c['email'] ),
				'clases'     => 'seguimiento_' . $paso,
				'documentos' => self::PASOS[ $paso ],
				'asunto'     => mb_substr( $m['asunto'], 0, 250 ),
				'n'          => 1,
				'estado'     => $ok ? 'enviado' : 'fallo',
			)
		);
		if ( ! $ok ) { // se libera: se reintenta otro día (el registro de hoy lo frena hasta mañana)
			$wpdb->query( $wpdb->prepare( "UPDATE $t SET $col = NULL WHERE id = %d AND $col = %s", (int) $c['id'], $fecha ) ); // phpcs:ignore
		}
		return (bool) $ok;
	}

	// ------------------------------------------------------------------ Contenido

	/** Enlace de WhatsApp con el mensaje precargado. */
	public static function url_whatsapp() {
		return self::WHATSAPP . '?text=' . rawurlencode( self::WA_TEXTO );
	}

	/**
	 * Hasta 3 lecturas para organizarse: los artículos elegidos que ya estén PUBLICADOS en WordPress (nunca se inventa
	 * una URL: título y enlace salen de la entrada) y, si falta alguno, los de reserva y las guías permanentes.
	 */
	public static function articulos() {
		$out   = array();
		$slugs = array_merge( self::ARTICULOS, self::ARTICULOS_RESERVA );
		$pub   = array();
		if ( function_exists( 'get_posts' ) ) {
			foreach ( (array) get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'post_name__in' => $slugs, 'numberposts' => 20 ) ) as $p ) {
				if ( is_object( $p ) && isset( $p->post_name ) && in_array( $p->post_name, $slugs, true ) && ( ! isset( $p->post_status ) || 'publish' === $p->post_status ) ) {
					$pub[ $p->post_name ] = $p;
				}
			}
		}
		foreach ( $slugs as $s ) {
			if ( count( $out ) < 3 && isset( $pub[ $s ] ) ) {
				$out[] = array( 'titulo' => get_the_title( $pub[ $s ] ), 'url' => get_permalink( $pub[ $s ] ), 'slug' => $s );
			}
		}
		if ( count( $out ) < 3 && function_exists( 'get_page_by_path' ) ) {
			foreach ( self::PAGINAS_RESERVA as $ruta ) {
				$p = get_page_by_path( $ruta );
				if ( count( $out ) < 3 && is_object( $p ) && ( ! isset( $p->post_status ) || 'publish' === $p->post_status ) ) {
					$out[] = array( 'titulo' => get_the_title( $p ), 'url' => get_permalink( $p ), 'slug' => $ruta );
				}
			}
		}
		return $out;
	}

	/** Enlace a la muestra de programación: el enlace firmado nuevo (7 días) o, si no hay materiales, la página. */
	public static function muestra_programacion( array $c ) {
		foreach ( OGC_Contactos::enlaces_muestras( $c ) as $x ) {
			if ( false !== stripos( (string) $x['ruta'], 'programacion' ) ) {
				return array( 'url' => $x['url'], 'titulo' => $x['titulo'], 'firmado' => true );
			}
		}
		return array( 'url' => home_url( '/muestras-gratis/' ), 'titulo' => 'Muestra de programación didáctica', 'firmado' => false );
	}

	private static function lista( array $items ) {
		return '<ul style="padding-left:20px;margin:8px 0 16px">' . implode( '', array_map( static function ( $x ) {
			return '<li style="margin-bottom:8px">' . $x . '</li>';
		}, $items ) ) . '</ul>';
	}

	private static function h2( $t ) {
		return '<h2 style="color:#14284b;font-size:18px;margin:24px 0 8px">' . OGC_Correo::e( $t ) . '</h2>';
	}

	private static function firma() {
		return '<p style="margin-top:20px">Un saludo,<br><strong style="color:#14284b">Vicente Ruiz · Preparador OGC</strong></p>';
	}

	/** Día 3: «Cómo organizar el estudio de OGC». */
	public static function correo_3( array $c, $ahora = null ) {
		$e   = array( 'OGC_Correo', 'e' );
		$prg = self::muestra_programacion( $c );
		$art = self::articulos();
		$h   = '<p>Hola:</p>'
			. '<p>¿Te llegaron bien las muestras? ¿Necesitas algo más o tienes alguna duda? Si te resulta más cómodo, escríbeme por WhatsApp y lo hablamos.</p>'
			. '<p style="margin:16px 0">' . OGC_Correo::boton( self::url_whatsapp(), 'Escribirme por WhatsApp' ) . '</p>'
			. '<p>Mientras tanto, te dejo unas ideas prácticas para repartir el trabajo de aquí a la oposición de 2027.</p>'
			. self::h2( 'El temario: 71 temas en 8 bloques' )
			. self::lista(
				array(
					'<strong>Decide pronto cuántos temas vas a llevar y escríbelo.</strong> En OGC se sacan 4 de los 71 temas y desarrollas uno: no hace falta llevarlos todos, pero sí elegirlos con criterio.',
					'<strong>Reparte la lista entre los 8 bloques.</strong> Si te concentras en dos o tres, aumenta el riesgo de que salgan cuatro temas de bloques que no has tocado.',
					'<strong>Empieza por los temas que rinden dos veces:</strong> los que también usarás en el supuesto (comercio internacional y aduanas, finanzas y medios de pago, transporte) y los que son la base del módulo de tu programación.',
					'<strong>Un tema está preparado cuando lo puedes escribir con el tiempo del examen,</strong> no cuando lo has leído. Funciona bien dedicar un día a la lectura y el esquema y otro a redactarlo con cronómetro.',
				)
			)
			. self::h2( 'Los supuestos prácticos' )
			. self::lista(
				array(
					'Haz primero un supuesto completo sin apuntes: te dirá de dónde partes y qué bloques necesitan más práctica.',
					'Después, uno a la semana con el tiempo real. Corrígelo contra la solución y apunta cada error de concepto: son los que se repiten.',
					'Cuando salga la convocatoria de tu comunidad, mira cuánto pesa la parte práctica y ajusta las horas: si pesa más que el tema, dale más tiempo.',
				)
			)
			. self::h2( 'La programación didáctica' )
			. self::lista(
				array(
					'Elige el módulo cuanto antes y comprueba en la normativa de tu comunidad su atribución a OGC y sus horas.',
					'Tenla terminada antes de la primera prueba: según la comunidad, se entrega antes del examen o a los pocos días.',
					'Aprovecha los fines de semana sin simulacro para avanzar unidades, y deja para el final el guion de la defensa.',
				)
			)
			. '<p>Para ver cómo se concreta todo esto, aquí tienes otra vez la muestra de programación: <a href="' . call_user_func( $e, $prg['url'] ) . '" style="color:#1F4E79;font-weight:bold">' . call_user_func( $e, $prg['titulo'] ) . '</a>' . ( $prg['firmado'] ? ' (el enlace vale 7 días).' : '.' ) . '</p>';
		if ( $art ) {
			$li = array();
			foreach ( $art as $a ) {
				$li[] = '<a href="' . call_user_func( $e, $a['url'] ) . '" style="color:#1F4E79;font-weight:bold">' . call_user_func( $e, $a['titulo'] ) . '</a>';
			}
			$h .= self::h2( 'Para leer con calma' ) . self::lista( $li );
		}
		$h .= OGC_Correo::nota( '<strong style="color:#14284b">Lo que nos diferencia:</strong> en Preparador OGC las clases son en directo e individuales, planificadas contigo: tú y el profesor elegís el día y la hora.<br><a href="' . call_user_func( $e, home_url( '/clases-online-ogc/' ) ) . '" style="color:#1F4E79;font-weight:bold">Ver cómo son las clases</a>' )
			. '<p>Si me respondes a este correo contándome tu comunidad y cómo vas, te leo.</p>'
			. self::firma();
		return array( 'asunto' => 'Cómo organizar el estudio de OGC hasta la oposición de 2027', 'titulo' => 'Cómo organizar el estudio de OGC', 'html' => $h );
	}

	/** Día 7: la tienda, con los precios con tarjeta. */
	public static function correo_7( array $c, $ahora = null ) {
		$e    = array( 'OGC_Correo', 'e' );
		$lanz = self::lanzamiento( $ahora ? $ahora : time() );
		$tab  = static function ( $grupo ) use ( $e, $lanz ) {
			$h = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin:4px 0 12px">';
			foreach ( self::PRECIOS as $p ) {
				if ( $p[0] !== $grupo ) {
					continue;
				}
				$h .= '<tr><td style="padding:8px 8px 8px 0;border-bottom:1px solid #E1E6EC;vertical-align:top"><strong style="color:#14284b">' . call_user_func( $e, $p[1] ) . '</strong><br><span style="font-size:14px">' . call_user_func( $e, $p[2] ) . '</span></td>'
					. '<td style="padding:8px 0;border-bottom:1px solid #E1E6EC;text-align:right;vertical-align:top;white-space:nowrap"><strong style="color:#14284b;font-size:17px">' . call_user_func( $e, $lanz ? $p[3] : $p[4] ) . '</strong>'
					. ( $lanz ? '<br><a href="' . call_user_func( $e, $p[5] ) . '" style="color:#1F4E79;font-size:14px">Comprar con tarjeta</a>' : '' ) . '</td></tr>';
			}
			return $h . '</table>';
		};
		$h = '<p>Hola:</p>'
			. '<p>Hace una semana te envié las muestras. Si te han servido para ver cómo es el material y quieres el completo, lo tienes todo en la tienda, tal cual lo tenemos publicado:</p>'
			. '<p style="margin:16px 0">' . OGC_Correo::boton( home_url( '/tienda/' ), 'Ver la tienda' ) . '</p>';
		if ( $lanz ) {
			$h .= '<div style="background:#FFD23F;color:#14284b;border-radius:6px;padding:12px 16px;margin:16px 0"><strong>Oferta de lanzamiento hasta el 10 de enero de 2027.</strong> Desde el 11 de enero, todos los precios suben un 15 %.</div>';
		}
		$h .= self::h2( 'Material' ) . $tab( 'material' )
			. self::h2( 'Packs' ) . $tab( 'pack' )
			. self::h2( 'Clases en directo e individuales' )
			. '<p>Planificadas contigo: tú y el profesor elegís el día y la hora. Se contratan por packs de horas (<a href="' . call_user_func( $e, home_url( '/clases-online-ogc/' ) ) . '" style="color:#1F4E79">cómo son las clases</a>):</p>'
			. $tab( 'clases' )
			. '<p style="font-size:14px">Precios con tarjeta (pago seguro con Stripe)' . ( $lanz ? ', de lanzamiento' : '' ) . '. El material lleva el IVA del 4 % incluido; las clases están exentas de IVA. En la tienda verás también las ofertas que se piden por WhatsApp.</p>'
			. '<p>Si tienes dudas sobre qué te conviene, respóndeme a este correo o escríbeme por WhatsApp y lo vemos.</p>'
			. '<p>' . OGC_Correo::boton( home_url( '/tienda/' ), 'Ir a la tienda' ) . "\n" . OGC_Correo::boton( self::url_whatsapp(), 'Escribirme por WhatsApp', true ) . '</p>'
			. self::firma();
		return array(
			'asunto' => $lanz ? 'El material completo de OGC, con precio de lanzamiento hasta el 10 de enero' : 'El material completo de Preparador OGC',
			'titulo' => 'El material completo de OGC',
			'html'   => $h,
		);
	}

	// ------------------------------------------------------------------ Cron

	/** Cada hora (desde OGC_Boletin::cron). */
	public static function cron() {
		self::enviar();
	}

	public static function lote() {
		self::enviar();
	}
}
