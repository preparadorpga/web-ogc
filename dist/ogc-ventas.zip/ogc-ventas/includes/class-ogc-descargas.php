<?php
/**
 * Página del pedido, área privada, descargas y lector online (1.1.0).
 *
 *   Página del pedido:  /?ogc_pedido=ID&e=CADUCIDAD&s=FIRMA     (enlace del correo; o sin firma con sesión del área)
 *   Área privada:       /?ogc_area=1                             (entrada por enlace mágico al email, sin contraseñas)
 *   Enlace mágico:      /?ogc_entrar=EMAIL64&e=EXP&s=FIRMA       (30 min, un solo uso)
 *   Archivo:            /?ogc_archivo=ID&f=N|zip&e=EXP&s=FIRMA   (2 h, atado al dispositivo)
 *   Lector:             /?ogc_lector=ID&f=N&e=EXP&s=FIRMA        (2 h, atado al dispositivo)
 *   PDF del lector:     /?ogc_lpdf=ID&f=N&e=EXP&s=FIRMA          (30 min, atado al dispositivo, solo fetch, con Range)
 *   Página como imagen: /?ogc_limg=ID&f=N&n=PAG&e=EXP&s=FIRMA    (si el servidor tiene Imagick con PDF)
 *
 * Todas las firmas son HMAC-SHA256 con la clave de firma (constante OGC_DESCARGA_CLAVE o la generada al instalar)
 * e incluyen la versión del enlace del pedido: «Renovar y reenviar» invalida todo lo anterior. Cabeceras noindex,
 * no-store y no-referrer. Nunca hay una URL pública a un PDF.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Descargas {

	const VIDA_ARCHIVO = 7200;
	const VIDA_LPDF    = 1800;
	const VIDA_MAGICO  = 1800;
	const VIDA_SESION  = 43200;
	const COOKIE_SES   = 'ogc_sesion';

	private static function firma( $datos ) {
		return OGC_Cripto::firma( OGC_Config::clave_firma(), $datos );
	}

	private static function firma_ok( $datos, $s ) {
		return OGC_Cripto::firma_valida( OGC_Config::clave_firma(), $datos, $s );
	}

	/** Fin de la respuesta (en las pruebas sin WordPress lanza una excepción en lugar de terminar). */
	public static function fin() {
		if ( defined( 'OGC_TEST' ) ) {
			throw new OGC_Fin_Prueba();
		}
		exit;
	}

	// ------------------------------------------------------------------ URLs

	public static function url_pedido( array $p ) {
		$e = strtotime( $p['caduca'] . ' UTC' );
		return add_query_arg( array( 'ogc_pedido' => $p['id'], 'e' => $e, 's' => self::firma( "pedido|{$p['id']}|{$p['version_enlace']}|$e" ) ), home_url( '/' ) );
	}

	private static function url_firmada( $tipo, array $p, $f, $vida, $disp, array $extra = array() ) {
		$e = time() + $vida;
		$n = isset( $extra['n'] ) ? (int) $extra['n'] : 0;
		$s = self::firma( "$tipo|{$p['id']}|{$p['version_enlace']}|$f|$n|$e|$disp" );
		return add_query_arg( array_merge( array( 'ogc_' . $tipo => $p['id'], 'f' => $f ), $extra, array( 'e' => $e, 's' => $s ) ), home_url( '/' ) );
	}

	public static function url_archivo( array $p, $f, $disp ) {
		return self::url_firmada( 'archivo', $p, $f, self::VIDA_ARCHIVO, $disp );
	}

	public static function url_lector( array $p, $f, $disp ) {
		return self::url_firmada( 'lector', $p, $f, self::VIDA_ARCHIVO, $disp );
	}

	// ------------------------------------------------------------------ Entrada

	public static function atender() {
		// phpcs:disable WordPress.Security.NonceVerification
		$rutas = array( 'ogc_pedido' => 'pagina_pedido', 'ogc_archivo' => 'servir_archivo', 'ogc_area' => 'area', 'ogc_entrar' => 'entrar', 'ogc_lector' => 'lector', 'ogc_lpdf' => 'lector_pdf', 'ogc_limg' => 'lector_img' );
		foreach ( $rutas as $q => $m ) {
			if ( isset( $_GET[ $q ] ) ) {
				self::$m();
			}
		}
		// phpcs:enable
	}

	public static function cabeceras_privadas() {
		nocache_headers();
		header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private' );
		header( 'X-Robots-Tag: noindex, nofollow, noarchive' );
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // SG Optimizer y otros plugins de caché
		}
	}

	public static function error( $msg, $codigo ) {
		self::cabeceras_privadas();
		status_header( $codigo );
		self::pagina( 'Preparador OGC', '<p class="aviso">' . esc_html( $msg ) . '</p><p><a href="' . esc_url( add_query_arg( 'ogc_area', 1, home_url( '/' ) ) ) . '">Acceder a mi área privada</a> · <a href="mailto:' . esc_attr( OGC_Config::correo() ) . '">' . esc_html( OGC_Config::correo() ) . '</a></p>' );
	}

	/** Página HTML mínima propia (no usa el tema: nada de cachés ni scripts de terceros). */
	public static function pagina( $titulo, $cuerpo, $cabeza = '' ) {
		header( 'Content-Type: text/html; charset=UTF-8' );
		echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="referrer" content="no-referrer">'
			. '<title>' . esc_html( $titulo ) . ' · Preparador OGC</title><style>'
			. 'body{font-family:Calibri,Carlito,Arial,sans-serif;background:#EEF1F4;color:#4A4F55;margin:0;line-height:1.5}'
			. 'header{background:#1F4E79;color:#fff;padding:14px 16px}header a{color:#fff;text-decoration:none}main{max-width:820px;margin:0 auto;padding:16px}'
			. 'h1{color:#1F4E79;font-size:1.5em}h2{color:#1F4E79;font-size:1.15em;margin-top:1.5em}a{color:#2E75B6}'
			. '.btn{display:inline-block;background:#1F4E79;color:#fff;padding:8px 14px;border-radius:6px;text-decoration:none;margin:2px 4px 2px 0;border:0;font:inherit;cursor:pointer}'
			. '.btn2{background:#fff;color:#1F4E79;border:2px solid #1F4E79;padding:6px 12px}.aviso{border-left:4px solid #1F4E79;background:#fff;padding:10px 14px}'
			. '.mal{border-left-color:#B42318}ul.docs{list-style:none;padding:0}ul.docs li{background:#fff;margin:6px 0;padding:10px 12px;border-radius:6px;display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:space-between}'
			. 'ul.docs span{flex:1 1 260px;overflow-wrap:anywhere}input[type=email],input[type=tel]{padding:8px;font:inherit;width:100%;max-width:360px;box-sizing:border-box}small{color:#6B7178}'
			. '</style>' . $cabeza . '</head><body><header><strong><a href="' . esc_url( home_url( '/' ) ) . '">Preparador OGC</a></strong> · Organización y Gestión Comercial</header><main>'
			. $cuerpo . '</main></body></html>';
		self::fin();
	}

	// ------------------------------------------------------------------ Sesión del área

	public static function iniciar_sesion( $email ) {
		$v = OGC_Cripto::sellar_valor( OGC_Config::clave_firma(), 'ses|' . strtolower( $email ) . '|' . ( time() + self::VIDA_SESION ) );
		OGC_Seguridad::poner_cookie( self::COOKIE_SES, $v, time() + self::VIDA_SESION );
	}

	/** Email de la sesión del área o ''. */
	public static function sesion() {
		$v = isset( $_COOKIE[ self::COOKIE_SES ] ) ? (string) wp_unslash( $_COOKIE[ self::COOKIE_SES ] ) : ''; // phpcs:ignore
		$d = OGC_Cripto::abrir_valor( OGC_Config::clave_firma(), $v );
		if ( null === $d || ! preg_match( '/^ses\|(.+)\|(\d+)$/', $d, $m ) || (int) $m[2] < time() ) {
			return '';
		}
		return is_email( $m[1] ) ? $m[1] : '';
	}

	/** ¿El pedido sigue dando acceso por el área (12 meses de actualizaciones)? */
	private static function vigente( array $p ) {
		$hasta = $p['actualizaciones_hasta'] ? strtotime( $p['actualizaciones_hasta'] . ' UTC' ) : strtotime( $p['caduca'] . ' UTC' );
		return time() <= max( $hasta, strtotime( $p['caduca'] . ' UTC' ) );
	}

	// ------------------------------------------------------------------ Validación

	private static function pedido_de_get( $clave ) {
		$id = absint( isset( $_GET[ $clave ] ) ? $_GET[ $clave ] : 0 ); // phpcs:ignore
		$p  = $id ? OGC_Pedidos::obtener( $id ) : null;
		if ( ! $p ) {
			self::error( 'Enlace no válido.', 404 );
		}
		return $p;
	}

	private static function param_firma() {
		// phpcs:disable WordPress.Security.NonceVerification
		$e = absint( isset( $_GET['e'] ) ? $_GET['e'] : 0 );
		$s = isset( $_GET['s'] ) ? preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( $_GET['s'] ) ) : '';
		// phpcs:enable
		return array( $e, $s );
	}

	/** Comprobaciones comunes a cualquier acceso a un pedido: bloqueo, materiales y dispositivo. */
	private static function acceso( array $p ) {
		if ( ! empty( $p['bloqueado'] ) ) {
			OGC_Seguridad::registrar( $p, 'rechazo', 'Pedido bloqueado' );
			self::error( 'El acceso a este pedido está suspendido. Si cree que es un error, escríbanos a ' . OGC_Config::correo() . ' indicando su n.º de pedido.', 403 );
		}
		if ( ! OGC_Config::hay_lector() ) {
			return OGC_Seguridad::disp_actual();
		}
		$r = OGC_Seguridad::comprobar( $p );
		if ( ! $r['ok'] ) {
			self::cabeceras_privadas();
			status_header( 403 );
			self::pagina(
				'Máximo de dispositivos',
				'<h1>Ha alcanzado el máximo de ' . (int) $r['max'] . ' dispositivos</h1>'
				. '<p class="aviso mal">Su licencia permite usar el material en ' . (int) $r['max'] . ' dispositivos y ya están registrados. Este navegador no se ha registrado.</p>'
				. '<p>Si ha cambiado de ordenador, tableta o móvil, o ha borrado los datos del navegador, escríbanos a <a href="mailto:' . esc_attr( OGC_Config::correo() ) . '">' . esc_html( OGC_Config::correo() ) . '</a> con su n.º de pedido (' . esc_html( $p['pedido'] ) . ') y liberaremos uno de los anteriores.</p>'
				. '<p><small>Consejo: no use el modo privado o incógnito para leer el material; cada sesión privada cuenta como un dispositivo nuevo.</small></p>'
			);
		}
		return $r['disp'];
	}

	// ------------------------------------------------------------------ Página del pedido

	private static function pagina_pedido() {
		$p = self::pedido_de_get( 'ogc_pedido' );
		list( $e, $s ) = self::param_firma();
		if ( '' !== $s ) {
			if ( ! $e || ! self::firma_ok( "pedido|{$p['id']}|{$p['version_enlace']}|$e", $s ) ) {
				self::error( 'Enlace no válido.', 403 );
			}
			if ( time() > $e ) {
				self::error( 'Este enlace ha caducado. Pida uno nuevo en su área privada (con su email) o escríbanos a ' . OGC_Config::correo() . ' con su n.º de pedido.', 410 );
			}
		} elseif ( strtolower( $p['email'] ) !== self::sesion() || ! self::vigente( $p ) ) {
			wp_safe_redirect( add_query_arg( 'ogc_area', 1, home_url( '/' ) ) );
			self::fin();
		}
		self::cabeceras_privadas();
		$disp = self::acceso( $p );
		if ( '' !== $s ) {
			self::iniciar_sesion( $p['email'] );
		}
		$msg = OGC_Contactos::procesar_boletin_pedido( $p );
		OGC_Seguridad::registrar( $p, 'pagina', '', $disp );
		self::pagina( OGC_Config::nombre_producto( $p['producto'] ), self::html_pedido( $p, $disp, $msg ) );
	}

	public static function html_pedido( array $p, $disp, $msg = '' ) {
		$prod = OGC_Config::nombre_producto( $p['producto'] );
		$h    = '<h1>' . esc_html( $prod ) . '</h1>';
		$h   .= '<p>Pedido <strong>' . esc_html( $p['pedido'] ) . '</strong> · ' . esc_html( $p['nombre'] ) . ' · ' . esc_html( OGC_Pedidos::fecha( $p ) ) . '</p>';
		if ( $msg ) {
			$h .= '<p class="aviso">' . esc_html( $msg ) . '</p>';
		}
		$archivos = OGC_Materiales::hay_materiales() ? OGC_Config::archivos( $p['producto'] ) : array();
		if ( ! $archivos ) {
			return $h . '<p class="aviso">Su material se está preparando. Recibirá un aviso por email cuando esté listo.</p>';
		}
		if ( OGC_Config::hay_lector() ) {
			$h .= '<p><small>Este navegador está registrado como uno de sus dispositivos (máximo ' . (int) OGC_Config::max_dispositivos() . ').</small></p>';
		}
		if ( OGC_Config::hay_pdf() ) {
			$h .= '<p><a class="btn" href="' . esc_url( self::url_archivo( $p, 'zip', $disp ) ) . '">Descargar todo (ZIP)</a></p>';
		}
		$carpeta = '';
		$h      .= '<ul class="docs">';
		foreach ( $archivos as $i => $a ) {
			if ( $a['carpeta'] !== $carpeta ) {
				$carpeta = $a['carpeta'];
				$h      .= '</ul><h2>' . esc_html( ucfirst( $carpeta ) ) . '</h2><ul class="docs">';
			}
			$h .= '<li><span>' . esc_html( $a['nombre'] ) . '</span><span style="flex:0 0 auto">';
			if ( $a['sellar'] && OGC_Config::hay_lector() ) {
				$h .= '<a class="btn" href="' . esc_url( self::url_lector( $p, $i, $disp ) ) . '">Leer online</a>';
			}
			if ( OGC_Config::hay_pdf() || ! $a['sellar'] ) {
				$h .= '<a class="btn btn2" href="' . esc_url( self::url_archivo( $p, $i, $disp ) ) . '">' . ( $a['sellar'] ? 'Descargar PDF' : 'Descargar Excel' ) . '</a>';
			}
			$h .= '</span></li>';
		}
		$h .= '</ul>';
		$h .= '<p class="aviso"><strong>Licencia de uso personal e intransferible.</strong> Cada página lleva su nombre, email y n.º de pedido. Está prohibida su venta, reproducción o difusión (RDL 1/1996, Ley de Propiedad Intelectual). Se registran los accesos (fecha, IP y navegador) para detectar usos no autorizados; un uso anómalo puede suponer el bloqueo del acceso. Condiciones: <a href="' . esc_url( home_url( '/condiciones/' ) ) . '">condiciones de venta</a>.</p>';
		$h .= OGC_Contactos::form_boletin_pedido( $p );
		$h .= '<p><small>Para volver más tarde: <a href="' . esc_url( add_query_arg( 'ogc_area', 1, home_url( '/' ) ) ) . '">área privada</a> (le enviamos un enlace de acceso a su email). Dudas: <a href="mailto:' . esc_attr( OGC_Config::correo() ) . '">' . esc_html( OGC_Config::correo() ) . '</a>.</small></p>';
		return $h;
	}

	// ------------------------------------------------------------------ Área privada y enlace mágico

	private static function area() {
		self::cabeceras_privadas();
		$email = self::sesion();
		if ( $email ) {
			$h = '<h1>Mi material</h1><p>Sesión iniciada como <strong>' . esc_html( $email ) . '</strong>.</p>';
			$n = 0;
			foreach ( OGC_Pedidos::de_email( $email ) as $p ) {
				if ( ! self::vigente( $p ) ) {
					continue;
				}
				++$n;
				$h .= '<p class="aviso"><strong>' . esc_html( OGC_Config::nombre_producto( $p['producto'] ) ) . '</strong> · pedido ' . esc_html( $p['pedido'] ) . '<br><a class="btn" href="' . esc_url( add_query_arg( 'ogc_pedido', $p['id'], home_url( '/' ) ) ) . '">Abrir</a></p>';
			}
			if ( ! $n ) {
				$h .= '<p class="aviso">No hay pedidos vigentes con este email.</p>';
			}
			self::pagina( 'Mi material', $h );
		}
		$msg = '';
		if ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) && isset( $_POST['ogc_area_email'] ) ) { // phpcs:ignore
			$msg = self::pedir_enlace();
		}
		$t = time();
		$h = '<h1>Acceder a mi material</h1>'
			. ( $msg ? '<p class="aviso">' . esc_html( $msg ) . '</p>' : '' )
			. '<p>Escriba el email con el que compró. Le enviaremos un enlace de acceso válido 30 minutos (sin contraseñas).</p>'
			. '<form method="post" action="' . esc_url( add_query_arg( 'ogc_area', 1, home_url( '/' ) ) ) . '">'
			. '<p><label for="ogc-ae">Email</label><br><input id="ogc-ae" type="email" name="ogc_area_email" required maxlength="190" autocomplete="email"></p>'
			. '<p style="position:absolute;left:-9999px" aria-hidden="true"><label>No rellenar <input type="text" name="ogc_web" tabindex="-1" autocomplete="off"></label></p>'
			. '<input type="hidden" name="ogc_t" value="' . (int) $t . '"><input type="hidden" name="ogc_ts" value="' . esc_attr( self::firma( 'area|' . $t ) ) . '">'
			. '<p><button class="btn" type="submit">Enviarme el enlace</button></p></form>';
		self::pagina( 'Acceder', $h );
	}

	private static function pedir_enlace() {
		// phpcs:disable WordPress.Security.NonceVerification
		$generico = 'Si el email tiene pedidos, en unos minutos recibirá el enlace de acceso. Revise también la carpeta de correo no deseado.';
		$t        = absint( isset( $_POST['ogc_t'] ) ? $_POST['ogc_t'] : 0 );
		$ts       = isset( $_POST['ogc_ts'] ) ? sanitize_text_field( wp_unslash( $_POST['ogc_ts'] ) ) : '';
		if ( ! empty( $_POST['ogc_web'] ) || ! self::firma_ok( 'area|' . $t, $ts ) || time() - $t < 2 || time() - $t > 3600 ) {
			return $generico;
		}
		$email = strtolower( sanitize_email( wp_unslash( $_POST['ogc_area_email'] ) ) );
		// phpcs:enable
		$ip = OGC_Config::ip();
		if ( ! OGC_Contactos::limite( 'area_ip_' . $ip, 10, HOUR_IN_SECONDS ) || ! OGC_Contactos::limite( 'area_em_' . $email, 3, HOUR_IN_SECONDS ) ) {
			return 'Demasiados intentos. Pruebe dentro de una hora.';
		}
		if ( ! is_email( $email ) || ! OGC_Pedidos::de_email( $email ) ) {
			return $generico;
		}
		$e   = time() + self::VIDA_MAGICO;
		$em  = rtrim( strtr( base64_encode( $email ), '+/', '-_' ), '=' );
		$non = wp_generate_password( 12, false );
		$url = add_query_arg( array( 'ogc_entrar' => $em, 'n' => $non, 'e' => $e, 's' => self::firma( "entrar|$email|$non|$e" ) ), home_url( '/' ) );
		OGC_Correo::enviar( $email, 'Acceso a su material de Preparador OGC', 'Acceso a su material', '<p>Pulse el botón para entrar en su área privada. El enlace vale 30 minutos y una sola vez.</p><p>' . OGC_Correo::boton( $url, 'Entrar en mi área' ) . '</p><p style="font-size:14px">Si no lo ha pedido usted, ignore este mensaje.</p>' );
		return $generico;
	}

	private static function entrar() {
		// phpcs:disable WordPress.Security.NonceVerification
		$em  = isset( $_GET['ogc_entrar'] ) ? (string) wp_unslash( $_GET['ogc_entrar'] ) : '';
		$non = isset( $_GET['n'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_GET['n'] ) ) : '';
		// phpcs:enable
		list( $e, $s ) = self::param_firma();
		$email         = strtolower( (string) base64_decode( strtr( $em, '-_', '+/' ), true ) );
		if ( ! is_email( $email ) || ! self::firma_ok( "entrar|$email|$non|$e", $s ) ) {
			self::error( 'Enlace no válido.', 403 );
		}
		if ( time() > $e ) {
			self::error( 'El enlace de acceso ha caducado. Pida otro en el área privada.', 410 );
		}
		if ( ! add_option( 'ogc_magico_' . md5( $non ), time(), '', 'no' ) ) { // un solo uso
			self::error( 'Este enlace de acceso ya se ha usado. Pida otro en el área privada.', 410 );
		}
		wp_schedule_single_event( time() + self::VIDA_MAGICO + 60, 'ogc_ventas_borrar_opcion', array( 'ogc_magico_' . md5( $non ) ) );
		self::iniciar_sesion( $email );
		wp_safe_redirect( add_query_arg( 'ogc_area', 1, home_url( '/' ) ) );
		self::fin();
	}

	// ------------------------------------------------------------------ Archivos

	/** Valida un enlace firmado de archivo/lector: pedido, firma con dispositivo, caducidad y acceso. */
	private static function validar_enlace( $tipo ) {
		$p = self::pedido_de_get( 'ogc_' . $tipo );
		// phpcs:disable WordPress.Security.NonceVerification
		$f = isset( $_GET['f'] ) ? sanitize_key( wp_unslash( $_GET['f'] ) ) : '';
		$n = absint( isset( $_GET['n'] ) ? $_GET['n'] : 0 );
		// phpcs:enable
		list( $e, $s ) = self::param_firma();
		$disp          = OGC_Seguridad::disp_cookie();
		if ( ! $e || ! self::firma_ok( "$tipo|{$p['id']}|{$p['version_enlace']}|$f|$n|$e|$disp", $s ) ) {
			// Firma de otro dispositivo (enlace copiado) o alterada.
			OGC_Seguridad::registrar( $p, 'rechazo', 'Enlace de ' . $tipo . ' no válido o de otro navegador', $disp );
			self::error( 'Enlace no válido en este navegador. Vuelva a abrir su página del pedido desde el área privada.', 403 );
		}
		if ( time() > $e ) {
			self::error( 'Este enlace ha caducado. Vuelva a la página de su pedido para generar uno nuevo.', 410 );
		}
		self::acceso( $p );
		return array( $p, $f, $n, $disp );
	}

	private static function archivo_de( array $p, $f ) {
		$archivos = OGC_Config::archivos( $p['producto'] );
		if ( ! ctype_digit( (string) $f ) || ! isset( $archivos[ (int) $f ] ) ) {
			self::error( 'Archivo no encontrado.', 404 );
		}
		return $archivos[ (int) $f ];
	}

	private static function servir_archivo() {
		list( $p, $f, , $disp ) = self::validar_enlace( 'archivo' );
		if ( (int) $p['descargas'] >= OGC_Config::descargas_max() ) {
			OGC_Seguridad::registrar( $p, 'rechazo', 'Límite de descargas', $disp );
			self::error( 'Se ha alcanzado el límite de descargas de este pedido. Escríbanos a ' . OGC_Config::correo() . '.', 429 );
		}
		if ( 'zip' === $f ) {
			if ( ! OGC_Config::hay_pdf() ) {
				self::error( 'La descarga no está disponible en esta modalidad.', 403 );
			}
			$ruta   = self::zip( $p, OGC_Config::archivos( $p['producto'] ) );
			$nombre = 'OGC_' . $p['pedido'] . '_' . $p['producto'] . '.zip';
			$tipo   = 'application/zip';
		} else {
			$a = self::archivo_de( $p, $f );
			if ( $a['sellar'] && ! OGC_Config::hay_pdf() ) {
				self::error( 'En esta modalidad el material se lee en el lector online.', 403 );
			}
			$ruta   = OGC_Sellador::sellado( $p, $a );
			$nombre = $a['nombre'];
			$tipo   = $a['sellar'] ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
		}
		if ( is_wp_error( $ruta ) ) {
			self::error( 'El archivo se está preparando. Vuelva a intentarlo en unos minutos.', 503 );
		}
		global $wpdb;
		$t = OGC_Pedidos::tabla();
		$wpdb->query( $wpdb->prepare( "UPDATE $t SET descargas = descargas + 1 WHERE id = %d", $p['id'] ) ); // phpcs:ignore
		OGC_Seguridad::registrar( $p, 'descarga', $nombre, $disp );
		self::enviar_archivo( $ruta, $tipo, $nombre, true );
	}

	/** Envía un archivo (con soporte de Range para el lector). */
	private static function enviar_archivo( $ruta, $tipo, $nombre, $adjunto ) {
		while ( ! defined( 'OGC_TEST' ) && ob_get_level() ) {
			ob_end_clean();
		}
		self::cabeceras_privadas();
		$tam = filesize( $ruta );
		header( 'Content-Type: ' . $tipo );
		if ( $adjunto ) {
			header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $nombre ) . '"' );
		}
		header( 'Accept-Ranges: bytes' );
		$ini = 0;
		$fin = $tam - 1;
		if ( ! $adjunto && isset( $_SERVER['HTTP_RANGE'] ) && preg_match( '/^bytes=(\d*)-(\d*)$/', (string) $_SERVER['HTTP_RANGE'], $m ) ) { // phpcs:ignore
			if ( '' === $m[1] ) {
				$ini = max( 0, $tam - (int) $m[2] );
			} else {
				$ini = (int) $m[1];
				$fin = '' === $m[2] ? $fin : min( $fin, (int) $m[2] );
			}
			if ( $ini > $fin || $ini >= $tam ) {
				status_header( 416 );
				header( 'Content-Range: bytes */' . $tam );
				self::fin();
			}
			status_header( 206 );
			header( 'Content-Range: bytes ' . $ini . '-' . $fin . '/' . $tam );
		}
		header( 'Content-Length: ' . ( $fin - $ini + 1 ) );
		$fh = fopen( $ruta, 'rb' ); // phpcs:ignore
		fseek( $fh, $ini );
		$quedan = $fin - $ini + 1;
		while ( $quedan > 0 && ! feof( $fh ) ) {
			$b = fread( $fh, min( 65536, $quedan ) ); // phpcs:ignore
			echo $b; // phpcs:ignore
			$quedan -= strlen( $b );
		}
		fclose( $fh ); // phpcs:ignore
		self::fin();
	}

	/** ZIP con todos los archivos sellados del pedido (caché por versión de los documentos). */
	private static function zip( array $p, array $archivos ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'ogc_zip', 'ZipArchive no disponible' );
		}
		$hash = substr( hash( 'sha256', implode( '|', wp_list_pluck( $archivos, 'sha256' ) ) ), 0, 16 );
		$dir  = OGC_Sellador::carpeta_pedido( $p );
		wp_mkdir_p( $dir );
		$ruta = $dir . '/todo-' . $hash . '.zip';
		if ( is_readable( $ruta ) ) {
			return $ruta;
		}
		@set_time_limit( 600 ); // phpcs:ignore
		$tmp = $ruta . '.tmp-' . wp_generate_password( 6, false );
		$zip = new ZipArchive();
		if ( true !== $zip->open( $tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return new WP_Error( 'ogc_zip', 'No se puede crear el ZIP' );
		}
		$raiz = 'OGC_' . $p['pedido'] . '_' . $p['producto'] . '/';
		foreach ( $archivos as $a ) {
			$s = OGC_Sellador::sellado( $p, $a );
			if ( is_wp_error( $s ) ) {
				$zip->close();
				@unlink( $tmp ); // phpcs:ignore
				return $s;
			}
			$zip->addFile( $s, $raiz . $a['carpeta'] . '/' . $a['nombre'] );
		}
		$zip->addFromString( $raiz . 'LICENCIA.txt', OGC_Sellador::licencia( $p ) . "\n\nProducto: " . OGC_Config::nombre_producto( $p['producto'] ) . "\nPreparador OGC · organizacionygestioncomercial.es · " . OGC_Config::correo() . "\n" );
		$zip->close();
		rename( $tmp, $ruta );
		foreach ( (array) glob( $dir . '/todo-*.zip' ) as $viejo ) {
			if ( $viejo !== $ruta ) {
				@unlink( $viejo ); // phpcs:ignore
			}
		}
		return $ruta;
	}

	// ------------------------------------------------------------------ Lector online

	/** Motor del lector: 'imagen' (páginas renderizadas en el servidor) si hay Imagick con PDF; si no, 'pdfjs'. */
	public static function motor() {
		$m = (string) OGC_Config::ajuste( 'motor_lector' );
		if ( 'pdfjs' === $m ) {
			return 'pdfjs';
		}
		$img = self::imagick_pdf();
		return ( 'imagen' === $m || 'auto' === $m ) && $img ? 'imagen' : 'pdfjs';
	}

	public static function imagick_pdf() {
		static $r = null;
		if ( null === $r ) {
			$r = false;
			if ( class_exists( 'Imagick' ) ) {
				try {
					$r = (bool) Imagick::queryFormats( 'PDF' );
				} catch ( \Throwable $e ) {
					$r = false;
				}
			}
		}
		return $r;
	}

	private static function lector() {
		if ( ! OGC_Config::hay_lector() ) {
			self::error( 'El lector online no está activo.', 404 );
		}
		list( $p, $f, , $disp ) = self::validar_enlace( 'lector' );
		$a = self::archivo_de( $p, $f );
		if ( ! $a['sellar'] ) {
			self::error( 'Este archivo no se puede abrir en el lector.', 404 );
		}
		OGC_Seguridad::registrar( $p, 'lector', $a['nombre'], $disp );
		$motor = self::motor();
		$marca = $p['nombre'] . ' · ' . $p['email'] . ' · ' . $p['pedido'];
		$datos = array(
			'motor'   => $motor,
			'marca'   => $marca,
			'paginas' => (int) $a['paginas'],
			'volver'  => add_query_arg( 'ogc_pedido', $p['id'], home_url( '/' ) ),
		);
		if ( 'imagen' === $motor ) {
			$urls = array();
			for ( $i = 1; $i <= (int) $a['paginas']; $i++ ) {
				$urls[] = self::url_firmada( 'limg', $p, $f, self::VIDA_ARCHIVO, $disp, array( 'n' => $i ) );
			}
			$datos['imagenes'] = $urls;
		} else {
			$base               = plugins_url( 'assets/pdfjs/', OGC_VENTAS_PLUGIN_DIR . '/ogc-ventas.php' );
			$datos['pdf']       = self::url_firmada( 'lpdf', $p, $f, self::VIDA_LPDF, $disp );
			$datos['lib']       = $base . 'pdf.min.js?v=' . OGC_VENTAS_VERSION;
			$datos['worker']    = $base . 'pdf.worker.min.js?v=' . OGC_VENTAS_VERSION;
			$datos['fuentes']   = $base . 'standard_fonts/';
		}
		self::cabeceras_privadas();
		header( "Content-Security-Policy: default-src 'self'; img-src 'self' data: blob:; script-src 'self' 'unsafe-inline'; worker-src 'self' blob:; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'self'; object-src 'none'" );
		$css = '<style>body{background:#525659}main{max-width:none;padding:8px}#ogc-paginas{display:flex;flex-direction:column;align-items:center;gap:12px}'
			. '.pag{position:relative;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.4);max-width:100%;user-select:none;-webkit-user-select:none}'
			. '.pag canvas,.pag img{display:block;max-width:100%;height:auto;pointer-events:none}'
			. '.marca{position:absolute;inset:0;overflow:hidden;pointer-events:none;display:flex;flex-wrap:wrap;align-content:space-around;justify-content:space-around;opacity:.13;color:#1F4E79;font-weight:bold;font-size:clamp(10px,1.6vw,16px)}'
			. '.marca span{transform:rotate(-30deg);white-space:nowrap;padding:28px 10px}.barra{position:sticky;top:0;z-index:2;background:#1F4E79;color:#fff;padding:8px 12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}'
			. '.barra a,.barra button{color:#fff;background:transparent;border:1px solid #fff;border-radius:4px;padding:4px 10px;font:inherit;text-decoration:none;cursor:pointer}'
			. '@media print{body{display:none!important}}</style>';
		$h  = '<div class="barra"><a href="' . esc_url( $datos['volver'] ) . '">← Volver</a><strong style="flex:1">' . esc_html( $a['nombre'] ) . '</strong>'
			. '<button type="button" id="ogc-menos" aria-label="Reducir">−</button><button type="button" id="ogc-mas" aria-label="Ampliar">+</button></div>'
			. '<p id="ogc-estado" style="color:#fff;text-align:center">Cargando…</p><div id="ogc-paginas" data-ogc="' . esc_attr( wp_json_encode( $datos ) ) . '"></div>'
			. '<p style="color:#ddd;text-align:center;font-size:13px">Licencia de uso personal de ' . esc_html( $marca ) . '. Prohibida su difusión. Accesos registrados.</p>';
		$h .= '<script type="module">' . self::js_lector() . '</script>';
		self::pagina( $a['nombre'], $h, $css );
	}

	/** JavaScript del lector (sin descarga ni impresión; páginas bajo demanda). */
	private static function js_lector() {
		return <<<'JS'
const c=document.getElementById('ogc-paginas'),d=JSON.parse(c.dataset.ogc),est=document.getElementById('ogc-estado');
let escala=1.3;
const marca=()=>{const m=document.createElement('div');m.className='marca';for(let i=0;i<12;i++){const s=document.createElement('span');s.textContent=d.marca;m.appendChild(s);}return m;};
document.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&['s','p','u'].includes(e.key.toLowerCase())){e.preventDefault();}});
const obs=new IntersectionObserver(es=>{for(const e of es){if(e.isIntersecting){obs.unobserve(e.target);e.target._pintar&&e.target._pintar();}}},{rootMargin:'800px'});
function hueco(n,w,h){const p=document.createElement('div');p.className='pag';p.style.width=w+'px';p.style.aspectRatio=w+'/'+h;p.dataset.n=n;p.appendChild(marca());c.appendChild(p);return p;}
if(d.motor==='imagen'){
  est.remove();
  d.imagenes.forEach((u,i)=>{const p=hueco(i+1,Math.round(595*escala),Math.round(842*escala));p._pintar=()=>{const im=new Image();im.alt='Página '+(i+1);im.draggable=false;im.onerror=()=>location.reload();im.src=u;im.onload=()=>{p.style.aspectRatio='';p.style.height='auto';};p.prepend(im);};obs.observe(p);});
  document.getElementById('ogc-mas').onclick=()=>{escala*=1.15;c.querySelectorAll('.pag').forEach(p=>p.style.width=Math.round(595*escala)+'px');};
  document.getElementById('ogc-menos').onclick=()=>{escala/=1.15;c.querySelectorAll('.pag').forEach(p=>p.style.width=Math.round(595*escala)+'px');};
}else{
  const lib=await import(d.lib);lib.GlobalWorkerOptions.workerSrc=d.worker;
  let doc;
  try{doc=await lib.getDocument({url:d.pdf,disableAutoFetch:true,disableStream:true,rangeChunkSize:262144,standardFontDataUrl:d.fuentes,isEvalSupported:false,enableXfa:false}).promise;}
  catch(e){est.textContent='No se ha podido abrir el documento. Vuelva a la página del pedido y ábralo de nuevo.';throw e;}
  est.remove();
  const pags=[];
  for(let n=1;n<=doc.numPages;n++){
    const pg=n===1?await doc.getPage(1):null;const vp0=pg?pg.getViewport({scale:1}):{width:595,height:842};
    const p=hueco(n,Math.round(vp0.width*escala),Math.round(vp0.height*escala));pags.push(p);
    p._pintar=async()=>{const page=await doc.getPage(n);const r=window.devicePixelRatio||1;const vp=page.getViewport({scale:escala*r});
      const cv=document.createElement('canvas');cv.width=vp.width;cv.height=vp.height;cv.style.width=(vp.width/r)+'px';
      await page.render({canvasContext:cv.getContext('2d'),viewport:vp,annotationMode:0}).promise;
      p.querySelector('canvas')?.remove();p.style.aspectRatio='';p.prepend(cv);};
    obs.observe(p);
  }
  const rehacer=()=>{pags.forEach(p=>{p.style.width=Math.round(595*escala)+'px';if(p.querySelector('canvas')){p._pintar();}});};
  document.getElementById('ogc-mas').onclick=()=>{escala*=1.15;rehacer();};
  document.getElementById('ogc-menos').onclick=()=>{escala/=1.15;rehacer();};
}
JS;
	}

	/** PDF sellado para PDF.js: solo peticiones fetch del propio lector (no navegación directa), con Range. */
	private static function lector_pdf() {
		list( $p, $f, , $disp ) = self::validar_enlace( 'lpdf' );
		$dest = isset( $_SERVER['HTTP_SEC_FETCH_DEST'] ) ? (string) $_SERVER['HTTP_SEC_FETCH_DEST'] : ''; // phpcs:ignore
		if ( in_array( $dest, array( 'document', 'iframe', 'embed', 'object' ), true ) ) {
			self::error( 'Este enlace solo funciona dentro del lector.', 403 );
		}
		$a    = self::archivo_de( $p, $f );
		$ruta = OGC_Sellador::sellado( $p, $a );
		if ( is_wp_error( $ruta ) ) {
			self::error( 'El documento se está preparando.', 503 );
		}
		self::enviar_archivo( $ruta, 'application/pdf', $a['nombre'], false );
	}

	/** Página renderizada en el servidor (Imagick + Ghostscript) con marca de agua. */
	private static function lector_img() {
		list( $p, $f, $n, $disp ) = self::validar_enlace( 'limg' );
		if ( ! self::imagick_pdf() ) {
			self::error( 'Motor de imágenes no disponible.', 404 );
		}
		$a = self::archivo_de( $p, $f );
		if ( $n < 1 || $n > (int) $a['paginas'] ) {
			self::error( 'Página no encontrada.', 404 );
		}
		$ruta = OGC_Sellador::sellado( $p, $a );
		if ( is_wp_error( $ruta ) ) {
			self::error( 'El documento se está preparando.', 503 );
		}
		$cache = OGC_Sellador::carpeta_pedido( $p ) . '/img-' . substr( $a['sha256'], 0, 16 ) . '-' . $n . '.jpg';
		if ( ! is_readable( $cache ) ) {
			try {
				@set_time_limit( 60 ); // phpcs:ignore
				$im = new Imagick();
				$im->setResolution( 120, 120 );
				$im->readImage( $ruta . '[' . ( $n - 1 ) . ']' );
				$im->setImageBackgroundColor( 'white' );
				$im = $im->mergeImageLayers( Imagick::LAYERMETHOD_FLATTEN );
				$dr = new ImagickDraw();
				$dr->setFillColor( new ImagickPixel( 'rgba(31,78,121,0.13)' ) );
				$dr->setFontSize( 18 );
				$w    = $im->getImageWidth();
				$hh   = $im->getImageHeight();
				$text = $p['nombre'] . ' · ' . $p['email'] . ' · ' . $p['pedido'];
				for ( $y = 80; $y < $hh; $y += 220 ) {
					$im->annotateImage( $dr, 30, $y, -30, $text );
					$im->annotateImage( $dr, (int) ( $w / 2 ), $y + 110, -30, $text );
				}
				$im->setImageFormat( 'jpeg' );
				$im->setImageCompressionQuality( 78 );
				$im->stripImage();
				$tmp = $cache . '.tmp-' . wp_generate_password( 6, false );
				$im->writeImage( $tmp );
				rename( $tmp, $cache );
			} catch ( \Throwable $e ) {
				self::error( 'No se ha podido mostrar la página.', 500 );
			}
		}
		self::enviar_archivo( $cache, 'image/jpeg', 'pagina.jpg', false );
	}
}
