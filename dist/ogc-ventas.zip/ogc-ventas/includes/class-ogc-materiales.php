<?php
/**
 * Materiales en el hosting SIN FTP (1.1.0).
 *
 * Fuente: repositorio público GitHub preparadorpga/web-ogc, carpeta materiales/ (lo publica
 * ventas/publicar_materiales.py). Allí solo hay archivos CIFRADOS (AES-256-GCM, uno por documento, clave de 32 bytes
 * que solo tienen el equipo de publicación y este plugin) y un manifiesto firmado con Ed25519 (la misma clave que
 * usa «OGC Páginas»). El repositorio no contiene ningún PDF legible.
 *
 * Cada hora (WP-Cron) y con «Comprobar materiales ahora»:
 *   1. descarga manifiesto.json y .sig (https, sin redirecciones, tamaño máximo) y verifica la firma Ed25519;
 *   2. exige serie creciente (anti-reversión) y que la clave pegada en Ajustes sea la del paquete (clave_id);
 *   3. descarga solo los archivos cuyo hash ha cambiado (incremental), comprueba tamaño y sha256 del cifrado, los
 *      descifra (AES-256-GCM con AAD = ruta + hash) y comprueba el sha256 del resultado; escribe de forma atómica en
 *      la carpeta privada con nombre no adivinable;
 *   4. cuando todo está, cambia al manifiesto nuevo, borra lo que ya no figura y, si un documento de un producto ha
 *      cambiado, deja avisos para los compradores con actualizaciones vigentes (se envían agrupados una vez al día).
 * Si se acaba el tiempo o el presupuesto de bytes de una ejecución, continúa en la siguiente (un minuto después).
 */

defined( 'ABSPATH' ) || exit;

class OGC_Materiales {

	/** Clave pública Ed25519 de Preparador OGC (la misma que CLAVE_PUBLICA de «OGC Páginas»). */
	const CLAVE_PUBLICA = 'ugbcuuCLyxi4XdOZpFfFPXVf5CSTb3wnPtgALby01bM=';

	const OPC_ESTADO    = 'ogc_ventas_mat_estado';
	const OPC_HISTORIAL = 'ogc_ventas_mat_historial';
	const OPC_CERROJO   = 'ogc_ventas_mat_cerrojo';
	const CRON          = 'ogc_ventas_materiales_cron';
	const CRON_SEGUIR   = 'ogc_ventas_materiales_seguir';

	const MAX_MANIFIESTO = 8388608;
	const MAX_ARCHIVO    = 52428800; // 50 MB por archivo cifrado
	const PRESUPUESTO    = 41943040; // 40 MB por ejecución
	const TIEMPO         = 25;       // segundos por ejecución
	const FECHA_MINIMA   = 1767225600;

	private static $man = null;
	private static $man_leido = false;

	// ------------------------------------------------------------------ Clave pública

	/** Clave pública en uso: si «OGC Páginas» la ha sustituido en sus Ajustes (rotación), se usa la misma. */
	public static function publica() {
		if ( class_exists( 'OGC_Paginas_Sync' ) && method_exists( 'OGC_Paginas_Sync', 'clave_publica' ) ) {
			$c = OGC_Paginas_Sync::clave_publica();
			if ( is_array( $c ) && 32 === strlen( (string) $c[0] ) ) {
				return $c[0];
			}
		}
		return base64_decode( self::CLAVE_PUBLICA );
	}

	// ------------------------------------------------------------------ Validación pura

	/**
	 * Valida el JSON de un manifiesto ya verificado. Devuelve el array o un texto con el motivo.
	 * $serie_max: anti-reversión (0 = sin comprobar).
	 */
	public static function validar( $json, $serie_max = 0, $clave_id = '' ) {
		$m = json_decode( (string) $json, true );
		if ( ! is_array( $m ) || 'ogc-materiales' !== ( isset( $m['tipo'] ) ? $m['tipo'] : '' ) || 1 !== ( isset( $m['formato'] ) ? $m['formato'] : 0 ) ) {
			return 'el manifiesto no es de materiales de OGC';
		}
		if ( ! isset( $m['serie'], $m['fecha_unix'] ) || ! is_int( $m['serie'] ) || ! is_int( $m['fecha_unix'] ) ) {
			return 'faltan la serie o la fecha';
		}
		if ( $m['fecha_unix'] < self::FECHA_MINIMA || $m['fecha_unix'] > time() + 86400 ) {
			return 'fecha no razonable';
		}
		if ( $serie_max && $m['serie'] < $serie_max ) {
			return 'reversion';
		}
		if ( '' !== $clave_id && ( ! isset( $m['clave_id'] ) || ! hash_equals( (string) $m['clave_id'], $clave_id ) ) ) {
			return 'la clave de materiales pegada en Ajustes no es la de este paquete';
		}
		$vistos = array();
		foreach ( array( 'archivos', 'muestras' ) as $grupo ) {
			if ( ! isset( $m[ $grupo ] ) || ! is_array( $m[ $grupo ] ) ) {
				return 'falta la lista ' . $grupo;
			}
			foreach ( $m[ $grupo ] as $a ) {
				$v = self::validar_archivo( $a );
				if ( true !== $v ) {
					return $v;
				}
				if ( isset( $vistos[ $a['ruta'] ] ) ) {
					return 'ruta repetida: ' . $a['ruta'];
				}
				$vistos[ $a['ruta'] ] = 1;
			}
		}
		if ( ! isset( $m['productos'] ) || ! is_array( $m['productos'] ) ) {
			return 'faltan los productos';
		}
		return $m;
	}

	public static function validar_archivo( $a ) {
		if ( ! is_array( $a ) || ! isset( $a['ruta'], $a['tipo'], $a['blob'], $a['sha256'], $a['bytes'], $a['sha256_cifrado'], $a['bytes_cifrado'] ) ) {
			return 'archivo incompleto en el manifiesto';
		}
		if ( ! preg_match( '#^[A-Za-z0-9_][A-Za-z0-9_./-]{0,200}\.(pdf|xlsx)$#', $a['ruta'] ) || false !== strpos( $a['ruta'], '..' ) || false !== strpos( $a['ruta'], '//' ) ) {
			return 'ruta no permitida: ' . $a['ruta'];
		}
		if ( ! in_array( $a['tipo'], array( 'pdf', 'xlsx' ), true ) || substr( $a['ruta'], -strlen( $a['tipo'] ) ) !== $a['tipo'] ) {
			return 'tipo no permitido: ' . $a['ruta'];
		}
		if ( ! preg_match( '#^b/[0-9a-f]{32}\.bin$#', $a['blob'] ) || ! preg_match( '/^[0-9a-f]{64}$/', $a['sha256'] ) || ! preg_match( '/^[0-9a-f]{64}$/', $a['sha256_cifrado'] ) ) {
			return 'datos no válidos: ' . $a['ruta'];
		}
		if ( ! is_int( $a['bytes_cifrado'] ) || $a['bytes_cifrado'] > self::MAX_ARCHIVO || $a['bytes_cifrado'] < 33 ) {
			return 'tamaño no permitido: ' . $a['ruta'];
		}
		if ( 'pdf' === $a['tipo'] && isset( $a['mapa'] ) && ! is_array( $a['mapa'] ) ) {
			return 'mapa no válido: ' . $a['ruta'];
		}
		return true;
	}

	/** AAD del cifrado de un archivo: lo ata a su ruta y a su contenido. */
	public static function aad( array $a ) {
		return 'ogc-materiales|1|' . $a['ruta'] . '|' . $a['sha256'];
	}

	/** Comprueba y descifra los bytes descargados. Devuelve el contenido o un texto de error (array('error'=>…)). */
	public static function abrir_blob( array $a, $blob, $clave ) {
		if ( strlen( $blob ) !== (int) $a['bytes_cifrado'] || ! hash_equals( $a['sha256_cifrado'], hash( 'sha256', $blob ) ) ) {
			return array( 'error' => 'el archivo cifrado no coincide con el manifiesto firmado' );
		}
		$p = OGC_Cripto::descifrar_gcm( $blob, $clave, self::aad( $a ) );
		if ( null === $p ) {
			return array( 'error' => 'no se puede descifrar (clave distinta o archivo alterado)' );
		}
		if ( strlen( $p ) !== (int) $a['bytes'] || ! hash_equals( $a['sha256'], hash( 'sha256', $p ) ) ) {
			return array( 'error' => 'el contenido descifrado no coincide con su hash' );
		}
		$ok = 'pdf' === $a['tipo'] ? ( 0 === strpos( $p, '%PDF-' ) ) : ( 0 === strpos( $p, "PK\x03\x04" ) );
		return $ok ? $p : array( 'error' => 'el contenido no es del tipo esperado' );
	}

	// ------------------------------------------------------------------ Manifiesto local

	public static function dir_local() {
		return OGC_Config::sub( 'materiales' );
	}

	/** Ruta local (nombre no adivinable) de un archivo del manifiesto. */
	public static function ruta_local( array $a ) {
		$d = self::dir_local();
		return '' === $d ? '' : $d . '/' . substr( hash_hmac( 'sha256', $a['ruta'] . '|' . $a['sha256'], OGC_Config::clave_firma() ), 0, 40 ) . '.dat';
	}

	/** Manifiesto aplicado (firma verificada de nuevo al leerlo) o null. */
	public static function manifiesto() {
		if ( self::$man_leido ) {
			return self::$man;
		}
		self::$man_leido = true;
		$d = self::dir_local();
		if ( '' === $d || ! is_readable( $d . '/manifiesto.json' ) ) {
			return null;
		}
		$json = (string) file_get_contents( $d . '/manifiesto.json' ); // phpcs:ignore
		$sig  = (string) @file_get_contents( $d . '/manifiesto.sig' ); // phpcs:ignore
		if ( ! OGC_Cripto::ed25519_valida( $json, $sig, self::publica() ) ) {
			return null;
		}
		$m         = self::validar( $json );
		self::$man = is_array( $m ) ? $m : null;
		return self::$man;
	}

	public static function olvidar() {
		self::$man       = null;
		self::$man_leido = false;
	}

	/** Archivos del manifiesto aplicado indexados por ruta. */
	public static function archivos() {
		$m   = self::manifiesto();
		$out = array();
		foreach ( $m ? $m['archivos'] : array() as $a ) {
			$out[ $a['ruta'] ] = $a;
		}
		return $out;
	}

	public static function muestras() {
		$m = self::manifiesto();
		return $m ? $m['muestras'] : array();
	}

	public static function hay_materiales() {
		$m = self::manifiesto();
		return $m && count( $m['archivos'] ) > 0;
	}

	public static function estado() {
		$e = get_option( self::OPC_ESTADO, array() );
		return array_merge( array( 'serie' => 0, 'serie_max' => 0, 'comprobado' => '', 'resultado' => '', 'error' => '', 'pendientes' => 0 ), is_array( $e ) ? $e : array() );
	}

	private static function guardar_estado( array $e ) {
		update_option( self::OPC_ESTADO, $e, false );
	}

	// ------------------------------------------------------------------ Descarga

	private static function url_base() {
		$u = (string) OGC_Config::ajuste( 'url_materiales' );
		return preg_match( '#^https://[a-z0-9.-]+/([A-Za-z0-9._~%-]+/)*$#', $u ) ? $u : OGC_Config::URL_MATERIALES;
	}

	/** @return string|WP_Error */
	public static function descargar( $rel, $max ) {
		if ( ! preg_match( '#^[a-z0-9][a-z0-9._/-]*$#', $rel ) || false !== strpos( $rel, '..' ) ) {
			return new WP_Error( 'ogc_ruta', 'ruta no permitida' );
		}
		$cab = array();
		$tok = (string) get_option( 'ogc_paginas_sync_token', '' ); // si el repositorio pasa a privado, el token de «OGC Páginas»
		$url = self::url_base() . $rel;
		if ( '' !== $tok && in_array( wp_parse_url( $url, PHP_URL_HOST ), array( 'raw.githubusercontent.com', 'api.github.com' ), true ) ) {
			$cab['Authorization'] = 'Bearer ' . $tok;
		}
		$r = wp_safe_remote_get(
			$url . '?t=' . time(), // evita cachés intermedias
			array( 'timeout' => 60, 'redirection' => 0, 'limit_response_size' => $max + 1, 'headers' => $cab, 'user-agent' => 'OGC-Ventas/' . OGC_VENTAS_VERSION )
		);
		if ( is_wp_error( $r ) ) {
			return new WP_Error( 'ogc_red', $rel . ': ' . $r->get_error_message() );
		}
		if ( 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			return new WP_Error( 'ogc_http', $rel . ': HTTP ' . (int) wp_remote_retrieve_response_code( $r ) );
		}
		$b = (string) wp_remote_retrieve_body( $r );
		return strlen( $b ) > $max ? new WP_Error( 'ogc_tam', $rel . ': demasiado grande' ) : $b;
	}

	private static function escribir( $ruta, $datos ) {
		$tmp = $ruta . '.tmp-' . wp_generate_password( 8, false );
		if ( false === file_put_contents( $tmp, $datos ) ) { // phpcs:ignore
			return false;
		}
		@chmod( $tmp, 0600 ); // phpcs:ignore
		if ( ! @rename( $tmp, $ruta ) ) { // phpcs:ignore
			@unlink( $tmp ); // phpcs:ignore
			return false;
		}
		return true;
	}

	// ------------------------------------------------------------------ Cron

	public static function programar() {
		if ( OGC_Config::ajuste( 'materiales_auto' ) && ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 120, 'hourly', self::CRON );
		} elseif ( ! OGC_Config::ajuste( 'materiales_auto' ) && wp_next_scheduled( self::CRON ) ) {
			wp_clear_scheduled_hook( self::CRON );
		}
	}

	public static function cron() {
		self::comprobar( 'automática' );
	}

	/** Comprueba y aplica. Devuelve líneas para el escritorio. */
	public static function comprobar( $quien = 'manual' ) {
		if ( ! add_option( self::OPC_CERROJO, time(), '', 'no' ) ) {
			$t = (int) get_option( self::OPC_CERROJO, 0 );
			if ( $t > time() - 10 * MINUTE_IN_SECONDS ) {
				return array( 'Ya hay una comprobación en curso.' );
			}
			update_option( self::OPC_CERROJO, time(), false );
		}
		try {
			return self::comprobar_sin_cerrojo( $quien );
		} finally {
			delete_option( self::OPC_CERROJO );
		}
	}

	private static function fallo( array $e, $msg ) {
		$repetido     = ( $e['error'] === $msg );
		$e['error']   = $msg;
		$e['resultado'] = 'error';
		self::guardar_estado( $e );
		if ( ! $repetido ) {
			OGC_Pedidos::avisar_admin( 'Materiales: no se ha podido actualizar', $msg . "\n\nLa web sigue con los materiales anteriores. Detalle en Herramientas → OGC Ventas → Materiales." );
		}
		return array( 'No se ha aplicado nada: ' . $msg );
	}

	private static function comprobar_sin_cerrojo( $quien ) {
		@set_time_limit( 120 ); // phpcs:ignore
		$e               = self::estado();
		$e['comprobado'] = current_time( 'mysql' );
		$clave           = OGC_Config::clave_materiales();
		$d               = self::dir_local();
		if ( ! $clave ) {
			return self::fallo( $e, 'falta la clave de los materiales en Ajustes' );
		}
		if ( '' === $d ) {
			return self::fallo( $e, 'no hay carpeta privada' );
		}
		$json = self::descargar( 'manifiesto.json', self::MAX_MANIFIESTO );
		if ( is_wp_error( $json ) ) {
			return self::fallo( $e, 'descarga: ' . $json->get_error_message() );
		}
		$sig = self::descargar( 'manifiesto.sig', 1024 );
		if ( is_wp_error( $sig ) ) {
			return self::fallo( $e, 'descarga: ' . $sig->get_error_message() );
		}
		if ( ! OGC_Cripto::ed25519_valida( $json, $sig, self::publica() ) ) {
			return self::fallo( $e, 'FIRMA NO VÁLIDA: el paquete de materiales no lo ha firmado Preparador OGC' );
		}
		$m = self::validar( $json, (int) $e['serie_max'], OGC_Cripto::id_clave( $clave ) );
		if ( 'reversion' === $m ) {
			return self::fallo( $e, 'el paquete publicado es anterior al aplicado (anti-reversión)' );
		}
		if ( ! is_array( $m ) ) {
			return self::fallo( $e, $m );
		}
		$actual = self::manifiesto();
		if ( $actual && $actual['serie'] === $m['serie'] && 0 === (int) $e['pendientes'] ) {
			$e['resultado'] = 'al_dia';
			$e['error']     = '';
			self::guardar_estado( $e );
			return array( 'Sin novedades: los materiales (serie ' . $m['serie'] . ') están al día.' );
		}
		// Descarga incremental.
		$inicio = time();
		$bytes  = 0;
		$falta  = 0;
		$nuevos = 0;
		foreach ( array_merge( $m['archivos'], $m['muestras'] ) as $a ) {
			$ruta = self::ruta_local( $a );
			if ( is_readable( $ruta ) && filesize( $ruta ) === (int) $a['bytes'] && hash_equals( $a['sha256'], (string) hash_file( 'sha256', $ruta ) ) ) {
				continue;
			}
			if ( $bytes > self::PRESUPUESTO || time() - $inicio > self::TIEMPO ) {
				++$falta;
				continue;
			}
			$blob = self::descargar( $a['blob'], self::MAX_ARCHIVO );
			if ( is_wp_error( $blob ) ) {
				return self::fallo( $e, 'archivo ' . $a['ruta'] . ': ' . $blob->get_error_message() );
			}
			$bytes += strlen( $blob );
			$p      = self::abrir_blob( $a, $blob, $clave );
			if ( is_array( $p ) ) {
				return self::fallo( $e, 'archivo ' . $a['ruta'] . ': ' . $p['error'] );
			}
			if ( ! self::escribir( $ruta, $p ) ) {
				return self::fallo( $e, 'no se puede escribir en la carpeta privada' );
			}
			++$nuevos;
		}
		if ( $falta ) {
			$e['pendientes'] = $falta;
			$e['resultado']  = 'en_curso';
			$e['error']      = '';
			self::guardar_estado( $e );
			wp_schedule_single_event( time() + 60, self::CRON_SEGUIR );
			return array( 'Descargados ' . $nuevos . ' archivos; faltan ' . $falta . ': se continúa en un minuto.' );
		}
		// Todo descargado y verificado: se cambia al manifiesto nuevo.
		$cambios = $actual ? self::cambios( $actual, $m ) : array(); // primera instalación: nada que avisar
		if ( ! self::escribir( $d . '/manifiesto.json', $json ) || ! self::escribir( $d . '/manifiesto.sig', $sig ) ) {
			return self::fallo( $e, 'no se puede guardar el manifiesto' );
		}
		self::olvidar();
		self::limpiar( $m );
		$e = array_merge( $e, array( 'serie' => $m['serie'], 'serie_max' => max( (int) $e['serie_max'], $m['serie'] ), 'resultado' => 'aplicado', 'error' => '', 'pendientes' => 0, 'aplicado' => current_time( 'mysql' ) ) );
		self::guardar_estado( $e );
		$lineas = array( 'Materiales actualizados a la serie ' . $m['serie'] . ' (' . count( $m['archivos'] ) . ' documentos, ' . count( $m['muestras'] ) . ' muestras; ' . $nuevos . ' descargados ahora).' );
		if ( $actual && $cambios ) {
			$n        = OGC_Boletin::registrar_cambios( $cambios );
			$lineas[] = count( $cambios ) . ' documentos cambiados: ' . $n . ' avisos a compradores en cola (se envían agrupados una vez al día).';
		}
		self::historial( $cambios, $m );
		return $lineas;
	}

	/** Archivos (no muestras) nuevos o cambiados entre dos manifiestos: array( ruta => novedades ). */
	public static function cambios( $antes, array $despues ) {
		// Se compara el hash del ORIGINAL (origen_sha256) si está: rehacer las plantillas o cambiar la clave no es un
		// cambio de contenido y no debe avisar a los compradores.
		$h    = static function ( $a ) {
			return isset( $a['origen_sha256'] ) ? $a['origen_sha256'] : $a['sha256'];
		};
		$prev = array();
		foreach ( $antes ? $antes['archivos'] : array() as $a ) {
			$prev[ $a['ruta'] ] = $h( $a );
		}
		$out = array();
		foreach ( $despues['archivos'] as $a ) {
			if ( ! isset( $prev[ $a['ruta'] ] ) || $prev[ $a['ruta'] ] !== $h( $a ) ) {
				$nov                = isset( $a['novedades'] ) ? trim( wp_strip_all_tags( (string) $a['novedades'] ) ) : '';
				$out[ $a['ruta'] ] = '' !== $nov ? $nov : ( isset( $prev[ $a['ruta'] ] ) ? 'Revisión y corrección del documento.' : 'Documento nuevo.' );
			}
		}
		return $out;
	}

	private static function historial( array $cambios, array $m ) {
		$h = get_option( self::OPC_HISTORIAL, array() );
		$h = is_array( $h ) ? $h : array();
		foreach ( $cambios as $ruta => $nov ) {
			$h[] = array( 't' => time(), 'ruta' => $ruta, 'novedades' => $nov );
		}
		update_option( self::OPC_HISTORIAL, array_slice( $h, -300 ), false );
	}

	/** Cambios de material de los últimos $dias (para el boletín). */
	public static function cambios_recientes( $dias = 7 ) {
		$out = array();
		foreach ( (array) get_option( self::OPC_HISTORIAL, array() ) as $c ) {
			if ( isset( $c['t'] ) && $c['t'] > time() - $dias * DAY_IN_SECONDS ) {
				$out[] = $c;
			}
		}
		return $out;
	}

	/** Borra de la carpeta los archivos que ya no figuran en el manifiesto. */
	private static function limpiar( array $m ) {
		$d      = self::dir_local();
		$quiero = array( 'manifiesto.json' => 1, 'manifiesto.sig' => 1, '.htaccess' => 1, 'index.php' => 1 );
		foreach ( array_merge( $m['archivos'], $m['muestras'] ) as $a ) {
			$quiero[ basename( self::ruta_local( $a ) ) ] = 1;
		}
		foreach ( (array) scandir( $d ) as $f ) {
			if ( '.' !== $f && '..' !== $f && ! isset( $quiero[ $f ] ) && is_file( $d . '/' . $f ) ) {
				@unlink( $d . '/' . $f ); // phpcs:ignore
			}
		}
	}
}
