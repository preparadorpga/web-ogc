<?php
/**
 * Correos en HTML con los colores de la web (azul #1F4E79, gris #4A4F55, fondo #EEF1F4) y versión de texto.
 * Salen con wp_mail (SMTP de SiteGround o el plugin SMTP que esté configurado), remitente y «responder a»
 * preparador@organizacionygestioncomercial.es.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Correo {

	const AZUL = '#1F4E79';
	const GRIS = '#4A4F55';

	private static $alt = '';

	/** Añade el texto plano como alternativa (multipart/alternative). */
	public static function phpmailer( $phpmailer ) {
		if ( '' !== self::$alt ) {
			$phpmailer->AltBody = self::$alt; // phpcs:ignore WordPress.NamingConventions
		}
	}

	public static function e( $t ) {
		return htmlspecialchars( (string) $t, ENT_QUOTES, 'UTF-8' );
	}

	public static function boton( $url, $texto, $secundario = false ) {
		$bg = $secundario ? '#ffffff' : self::AZUL;
		$co = $secundario ? self::AZUL : '#ffffff';
		return '<a href="' . self::e( $url ) . '" style="display:inline-block;background:' . $bg . ';color:' . $co . ';border:2px solid ' . self::AZUL . ';padding:12px 22px;border-radius:6px;font-weight:bold;text-decoration:none;margin:4px 8px 4px 0">' . self::e( $texto ) . '</a>';
	}

	public static function nota( $html ) {
		return '<div style="border-left:4px solid ' . self::AZUL . ';background:#F4F7FA;padding:10px 14px;margin:16px 0;font-size:14px">' . $html . '</div>';
	}

	/** Plantilla completa. $cuerpo es HTML ya escapado. */
	public static function plantilla( $titulo, $cuerpo, $pie_extra = '' ) {
		$web = function_exists( 'home_url' ) ? home_url( '/' ) : 'https://organizacionygestioncomercial.es/';
		return '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . self::e( $titulo ) . '</title></head>'
			. '<body style="margin:0;padding:0;background:#EEF1F4;font-family:Calibri,Carlito,Arial,Helvetica,sans-serif;color:' . self::GRIS . ';font-size:16px;line-height:1.5">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#EEF1F4"><tr><td align="center" style="padding:24px 12px">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:620px;background:#ffffff;border-radius:8px;overflow:hidden">'
			. '<tr><td style="background:' . self::AZUL . ';color:#ffffff;padding:18px 24px;font-size:18px"><strong>Preparador OGC</strong><br><span style="font-size:13px;opacity:.85">Organización y Gestión Comercial · 0590-110</span></td></tr>'
			. '<tr><td style="padding:24px"><h1 style="font-size:22px;color:' . self::AZUL . ';margin:0 0 16px">' . self::e( $titulo ) . '</h1>' . $cuerpo . '</td></tr>'
			. '<tr><td style="padding:16px 24px;background:#F4F7FA;font-size:12px;color:#6B7178">Preparador OGC · <a href="' . self::e( $web ) . '" style="color:' . self::AZUL . '">organizacionygestioncomercial.es</a> · <a href="mailto:' . self::e( OGC_Config::correo() ) . '" style="color:' . self::AZUL . '">' . self::e( OGC_Config::correo() ) . '</a>' . $pie_extra . '</td></tr>'
			. '</table></td></tr></table></body></html>';
	}

	/** Texto plano a partir del HTML del cuerpo (enlaces como «texto: url»). */
	public static function texto( $html ) {
		$t = preg_replace( '#<a [^>]*href="([^"]+)"[^>]*>(.*?)</a>#s', '$2: $1', $html );
		$t = preg_replace( '#<(br|/p|/li|/h1|/h2|/div|/tr)[^>]*>#i', "\n", $t );
		$t = preg_replace( '#<li[^>]*>#i', '- ', $t );
		$t = html_entity_decode( wp_strip_all_tags( $t ), ENT_QUOTES, 'UTF-8' );
		return trim( preg_replace( "/\n{3,}/", "\n\n", preg_replace( "/[ \t]+/", ' ', $t ) ) );
	}

	/**
	 * Envía un correo HTML + texto.
	 *
	 * @param array $extra Cabeceras adicionales (p. ej. List-Unsubscribe).
	 */
	public static function enviar( $para, $asunto, $titulo, $cuerpo, array $extra = array(), $pie_extra = '' ) {
		$c   = OGC_Config::correo();
		$cab = array_merge(
			array(
				'Content-Type: text/html; charset=UTF-8',
				'From: Preparador OGC <' . $c . '>',
				'Reply-To: Preparador OGC <' . $c . '>',
			),
			$extra
		);
		self::$alt = $titulo . "\n\n" . self::texto( $cuerpo ) . "\n\n--\nPreparador OGC · " . ( function_exists( 'home_url' ) ? home_url( '/' ) : '' ) . ' · ' . $c;
		add_action( 'phpmailer_init', array( __CLASS__, 'phpmailer' ) );
		$ok = wp_mail( $para, $asunto, self::plantilla( $titulo, $cuerpo, $pie_extra ), $cab );
		remove_action( 'phpmailer_init', array( __CLASS__, 'phpmailer' ) );
		self::$alt = '';
		return $ok;
	}
}
