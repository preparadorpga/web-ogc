<?php
/**
 * Plugin Name:       OGC Ventas · entrega protegida del material
 * Description:       Stripe Payment Links → webhook → pedido, correo al comprador y aviso a Vicente. Materiales cifrados descargados del paquete firmado de GitHub, sellados por comprador en PHP puro; PDF sellado y/o lector online con máximo de dispositivos (cada navegador nuevo se verifica con un código enviado al email de la compra); límite de descargas por archivo y versión; IP guardadas como hash; vigilancia de accesos; avisos en el día de material actualizado o nuevo (compradores), de muestras (quien las pidió) y de novedades (compradores y suscritos), un correo por persona y día con registro; boletín semanal con consentimiento; formulario de muestras.
 * Version:           1.3.2
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Preparador OGC
 * License:           GPL-2.0-or-later
 * Text Domain:       ogc-ventas
 *
 * Se instala y configura desde el escritorio (Plugins → Añadir nuevo → Subir; Herramientas → OGC Ventas → Ajustes).
 * No hace falta tocar wp-config.php ni usar FTP. Si wp-config.php define OGC_STRIPE_WEBHOOK_SECRET, OGC_DESCARGA_CLAVE,
 * OGC_VENTAS_DIR, OGC_STRIPE_MODO, OGC_CORREO, OGC_AVISO_EMAIL, OGC_DESCARGA_DIAS u OGC_DESCARGAS_MAX, mandan esas
 * constantes. No necesita vendor/ ni Composer.
 */

defined( 'ABSPATH' ) || exit;

define( 'OGC_VENTAS_VERSION', '1.3.2' );
define( 'OGC_VENTAS_PLUGIN_DIR', __DIR__ );

foreach ( array( 'cripto', 'sello', 'config', 'correo', 'materiales', 'stripe', 'pedidos', 'sellador', 'seguridad', 'descargas', 'contactos', 'boletin', 'avisos', 'admin' ) as $ogc_c ) {
	require_once __DIR__ . '/includes/class-ogc-' . $ogc_c . '.php';
}
unset( $ogc_c );

register_activation_hook( __FILE__, array( 'OGC_Ventas', 'activar' ) );
register_deactivation_hook( __FILE__, array( 'OGC_Ventas', 'desactivar' ) );

class OGC_Ventas {
	public static function activar() {
		OGC_Pedidos::instalar();
		OGC_Materiales::programar();
		OGC_Boletin::programar();
	}

	public static function desactivar() {
		foreach ( array( OGC_Materiales::CRON, OGC_Materiales::CRON_SEGUIR, 'ogc_ventas_horario', OGC_Boletin::CRON_LOTE, OGC_Avisos::CRON_LOTE ) as $h ) {
			wp_clear_scheduled_hook( $h );
		}
	}

	public static function init() {
		OGC_Pedidos::quizas_actualizar();
		OGC_Materiales::programar();
		OGC_Boletin::programar();
		OGC_Avisos::vigilar_cron();
		OGC_Contactos::atender();
		OGC_Descargas::atender();
	}
}

add_action( 'init', array( 'OGC_Ventas', 'init' ), 5 );
add_action( 'rest_api_init', array( 'OGC_Stripe', 'registrar_ruta' ) );
add_action( 'ogc_ventas_presellar', array( 'OGC_Sellador', 'presellar_pedido' ) );
add_action( OGC_Materiales::CRON, array( 'OGC_Materiales', 'cron' ) );
add_action( OGC_Materiales::CRON_SEGUIR, array( 'OGC_Materiales', 'cron' ) );
add_action( 'ogc_ventas_horario', array( 'OGC_Boletin', 'cron' ) );
add_action( OGC_Boletin::CRON_LOTE, array( 'OGC_Boletin', 'lote' ) );
add_action( OGC_Avisos::CRON_LOTE, array( 'OGC_Avisos', 'lote' ) );
add_action( 'ogc_ventas_borrar_opcion', 'delete_option' );
add_action( 'admin_menu', array( 'OGC_Admin', 'menu' ) );
add_action( 'admin_post_ogc_ventas_accion', array( 'OGC_Admin', 'accion' ) );
add_action( 'admin_notices', array( 'OGC_Admin', 'avisos_configuracion' ) );
add_shortcode( 'ogc_muestras_formulario', array( 'OGC_Contactos', 'shortcode' ) );
add_shortcode( 'ogc_area', static function () {
	return '<p><a class="ogc-btn" href="' . esc_url( add_query_arg( 'ogc_area', 1, home_url( '/' ) ) ) . '" rel="nofollow">Acceder a mi material</a></p>';
} );
