=== OGC Ventas · entrega protegida del material ===
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.2.0
License: GPL-2.0-or-later

Plugin privado de Preparador OGC. Stripe Payment Links → webhook → pedido → correo al comprador (HTML) y aviso a
Vicente → material en el área privada: lector online (máximo de dispositivos) y/o PDF sellado con los datos del
comprador. Materiales cifrados descargados del paquete firmado de GitHub (sin FTP). Avisos de actualización, boletín
semanal con consentimiento y baja de un clic, formulario de muestras [ogc_muestras_formulario].

Instalación (todo desde el escritorio, sin wp-config.php ni FTP):
1. Plugins → Añadir nuevo → Subir plugin → ogc-ventas.zip → Instalar → Activar.
2. Herramientas → OGC Ventas → Ajustes: pegar el secreto del webhook de Stripe (whsec_…); elegir modo de Stripe y
   modalidad de entrega (por defecto «Online + PDF»). Guardar. La clave de materiales llega sola en el sobre sellado.
3. Pestaña Materiales → «Comprobar materiales ahora» (hasta que diga «aplicado»).
Instrucciones completas: ventas/LEEME_SELLADO.md, sección 1.1.

No necesita vendor/ ni Composer: el sellado se hace en PHP puro sobre plantillas preparadas al publicar.
El visor usa PDF.js 6.2.108 (Apache-2.0) servido desde assets/pdfjs/ (sin CDN).

== Changelog ==
= 1.2.0 (12/11/2026) =
* Verificación del email con código de 6 dígitos antes de registrar un navegador nuevo (lector o descargas), aunque se llegue con el enlace del correo: 15 min, 5 intentos, reenvío cada 60 s como mínimo, límites por IP y por pedido. El enlace mágico del área privada cuenta como verificación.
* Límite de 2 descargas por archivo y versión (configurable) además del total por pedido, que pasa a 400; mensaje claro y aviso a Vicente si se insiste (3 intentos en 24 h). Botón «Reiniciar descargas».
* Privacidad: IP de accesos y dispositivos como hash con sal (HMAC con la clave del sitio); redes como hash del /24 o /48. Migración automática de los registros anteriores.
* Todos los textos al comprador en «tú». Producto «pack_programacion».
= 1.1.1 (12/11/2026) =
* Clave de materiales por sobre sellado: el sitio genera su par X25519 y muestra su clave PÚBLICA (Ajustes y Materiales, con botón Copiar); el paquete firmado lleva la clave envuelta para el sitio (publicar_materiales.py --destinatario). Ya no hay que pegar ninguna clave secreta (sigue como alternativa manual; manda OGC_MATERIALES_CLAVE de wp-config.php si existe).
= 1.1.0 (12/11/2026) =
* Instalación y configuración desde el escritorio (clave de firma generada, carpeta privada fuera de public_html creada sola).
* Materiales cifrados (AES-256-GCM) con manifiesto firmado (Ed25519) desde GitHub, incrementales, cada hora.
* Sellado en PHP puro (sin FPDI/TCPDF): conserva marcadores; sin «revisión sin sellar» recuperable.
* Modalidades PDF sellado / Lector online / Online + PDF; máximo de dispositivos con cookie firmada; liberar desde el escritorio.
* Registro de accesos, alertas por redes/países/descargas, bloqueo manual u opcionalmente automático.
* Correos en HTML; avisos de actualización agrupados (1 al día); boletín semanal (lunes 09:00 Madrid) solo con novedades.
* Formulario de muestras (email + teléfono, sin doble confirmación), contactos y consentimientos exportables a CSV.
= 1.0.2 =
* Hojas Excel de soluciones (sin sellar).
