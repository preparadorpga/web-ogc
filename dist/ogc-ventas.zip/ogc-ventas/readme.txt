=== OGC Ventas · entrega protegida del material ===
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.3.2
License: GPL-2.0-or-later

Plugin privado de Preparador OGC. Stripe Payment Links → webhook → pedido → correo al comprador (HTML) y aviso a
Vicente → material en el área privada: lector online (máximo de dispositivos) y/o PDF sellado con los datos del
comprador. Materiales cifrados descargados del paquete firmado de GitHub (sin FTP). Avisos de actualización, boletín
semanal con consentimiento y baja de un clic, formulario de muestras [ogc_muestras_formulario].

Instalación (todo desde el escritorio, sin wp-config.php ni FTP):
1. Plugins → Añadir nuevo → Subir plugin → ogc-ventas.zip → Instalar → Activar.
2. Herramientas → OGC Ventas → Ajustes: pegar el secreto del webhook de Stripe (whsec_…); elegir modo de Stripe y
   modalidad de entrega (por defecto «Online + PDF»). Guardar. La clave de materiales llega sola en el sobre sellado.
3. Pestaña Materiales → «Comprobar materiales ahora» (hasta que diga «aplicado»).
Instrucciones completas: ventas/LEEME_SELLADO.md, sección 1.1.

No necesita vendor/ ni Composer: el sellado se hace en PHP puro sobre plantillas preparadas al publicar.
El visor usa PDF.js 6.2.108 (Apache-2.0) servido desde assets/pdfjs/ (sin CDN).

== Changelog ==
= 1.3.2 (13/11/2026) =
* Correo de muestras: cada muestra aparece con su título del manifiesto (los avisos de resellado traían solo «Muestras»).
* Pruebas: el filtro de Stripe de 1.3.1 (web=pga ignorada sin alerta; sin marca de OGC ignorada; clases → aviso a Vicente sin pedido; temario → pedido) y los avisos de muestras calculados a partir del paquete real. Sin cambios en a quién se envía: quien solo pidió muestras sin la casilla sigue sin recibir novedades.
= 1.3.1 (13/11/2026) =
* Cuenta de Stripe compartida con PGA y PCO: el webhook solo procesa sesiones de OGC (metadata web=ogc, ogc_producto o Payment Link de OGC) e ignora las demás sin alertas. Las ventas de clases (ogc_producto=clases…) avisan a Vicente para agendarlas y no crean pedido.
= 1.3.0 (12/11/2026) =
* Avisos en el día (orden de Vicente 12/11/2026 21:24 y 21:28). El paquete de materiales lleva la lista firmada «avisos» (documento, muestra, producto o novedad; «nuevo» o «actualizacion»; nota con qué cambia, dónde, qué decía y qué dice, y alcance menor/amplio → «corrígelo a mano» o «descarga e imprime la versión nueva»). Cada entrada se trata una sola vez; los paquetes sin «avisos» se comparan como antes.
* Material actualizado o nuevo → todos los compradores del producto: con actualizaciones vigentes, enlace renovado con el PDF nuevo sellado; sin vigencia, aviso de versión nueva y cómo renovar (no se entrega).
* Muestra nueva o actualizada → quien pidió las muestras (sin baja), con enlaces firmados nuevos de 7 días. Texto de privacidad del formulario: avisos si las muestras se actualizan o se añaden.
* Algo nuevo → «Novedad» a compradores (art. 21.2 LSSI) y suscritos; nunca a quien solo pidió muestras sin la casilla, que ahora ofrece «avísame de las novedades y del material nuevo».
* Un solo correo de avisos por persona y día, entre las 09:00 y las 22:00 (Madrid), unos 20 minutos después de aplicar el paquete; lotes de 50 cada 5 minutos; List-Unsubscribe y baja de un clic (vale para todo menos el material contratado). Registro de cada envío (pestaña Avisos), resumen a Vicente, latido del cron y botón «Enviar avisos ahora». Los avisos pendientes de 1.2 se pasan a la cola nueva sin duplicar.
= 1.2.1 (12/11/2026) =
* Textos del formulario, del aviso de privacidad y del correo de muestras: «cuatro muestras» (Tema 1, supuesto práctico, supuesto de aduanas y programación didáctica). La lista de enlaces sigue saliendo del manifiesto.
= 1.2.0 (12/11/2026) =
* Verificación del email con código de 6 dígitos antes de registrar un navegador nuevo (lector o descargas), aunque se llegue con el enlace del correo: 15 min, 5 intentos, reenvío cada 60 s como mínimo, límites por IP y por pedido. El enlace mágico del área privada cuenta como verificación.
* Límite de 2 descargas por archivo y versión (configurable) además del total por pedido, que pasa a 400; mensaje claro y aviso a Vicente si se insiste (3 intentos en 24 h). Botón «Reiniciar descargas».
* Privacidad: IP de accesos y dispositivos como hash con sal (HMAC con la clave del sitio); redes como hash del /24 o /48. Migración automática de los registros anteriores.
* Todos los textos al comprador en «tú». Producto «pack_programacion».
= 1.1.1 (12/11/2026) =
* Clave de materiales por sobre sellado: el sitio genera su par X25519 y muestra su clave PÚBLICA (Ajustes y Materiales, con botón Copiar); el paquete firmado lleva la clave envuelta para el sitio (publicar_materiales.py --destinatario). Ya no hay que pegar ninguna clave secreta (sigue como alternativa manual; manda OGC_MATERIALES_CLAVE de wp-config.php si existe).
= 1.1.0 (12/11/2026) =
* Instalación y configuración desde el escritorio (clave de firma generada, carpeta privada fuera de public_html creada sola).
* Materiales cifrados (AES-256-GCM) con manifiesto firmado (Ed25519) desde GitHub, incrementales, cada hora.
* Sellado en PHP puro (sin FPDI/TCPDF): conserva marcadores; sin «revisión sin sellar» recuperable.
* Modalidades PDF sellado / Lector online / Online + PDF; máximo de dispositivos con cookie firmada; liberar desde el escritorio.
* Registro de accesos, alertas por redes/países/descargas, bloqueo manual u opcionalmente automático.
* Correos en HTML; avisos de actualización agrupados (1 al día); boletín semanal (lunes 09:00 Madrid) solo con novedades.
* Formulario de muestras (email + teléfono, sin doble confirmación), contactos y consentimientos exportables a CSV.
= 1.0.2 =
* Hojas Excel de soluciones (sin sellar).
