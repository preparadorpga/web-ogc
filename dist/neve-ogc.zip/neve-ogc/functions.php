<?php
/**
 * Neve OGC · tema hijo de Neve para Preparador OGC.
 *
 * Qué hace:
 *  1. Carga ogc-wp.css (misma carpeta) después de los estilos de Neve.
 *     La versión es la fecha del archivo: al subir un CSS nuevo, el navegador no usa la copia vieja.
 *  2. Quita el script y los estilos de emojis de WordPress (una petición y unos 5 KB que no se usan).
 *
 * Qué NO hace: no cambia plantillas, ni el contenido, ni las URL, ni nada de Yoast.
 * Los ajustes del personalizador de Neve se heredan del tema padre.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'wp_enqueue_scripts',
	function () {
		$archivo = get_stylesheet_directory() . '/ogc-wp.css';
		if ( ! file_exists( $archivo ) ) {
			return;
		}
		wp_enqueue_style(
			'ogc-wp',
			get_stylesheet_directory_uri() . '/ogc-wp.css',
			array(),
			(string) filemtime( $archivo )
		);
	},
	20 // Después de Neve (prioridad 10), para que estas reglas ganen a igual especificidad.
);

// Emojis de WordPress: no se usan en el sitio.
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );
