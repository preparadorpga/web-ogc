<?php
/**
 * Cola: WP-Cron cada 15 minutos con candado, horario de Madrid, reintentos con espera creciente y avisos.
 *
 * Cada pasada:
 *   1. Si hace más de una hora de la última comprobación, descarga el manifiesto firmado (OGC_Redes_Manifiesto).
 *   2. Si la conexión con Meta está bien y no está «Pausar todo»: descarga con antelación (36 h) los medios de lo
 *      próximo, publica lo que ya ha llegado a su hora (como máximo 48 h de retraso; si no, «vencida» y solo a mano)
 *      y limpia los medios de lo publicado hace más de 14 días.
 * Idempotencia: el estado de cada pieza (por su id: A03, R01…) se guarda tras cada paso; una pieza publicada no
 * vuelve a enviarse nunca, ni aunque el manifiesto cambie.
 * Reintentos: 15 min, 1 h, 4 h, 12 h y 24 h. Al tercer fallo, un email al administrador (una vez por pieza). Tras
 * el sexto, se para hasta que alguien pulse «Publicar ahora».
 */

defined( 'ABSPATH' ) || exit;

class OGC_Redes_Cola {

	const CRON        = 'ogc_redes_cron';
	const INTERVALO   = 'ogc_redes_15min';
	const OPC_PIEZAS  = 'ogc_redes_piezas';
	const OPC_CERROJO = 'ogc_redes_cerrojo';
	const ZONA        = 'Europe/Madrid';

	const ESPERAS        = array( 900, 3600, 14400, 43200, 86400 );
	const AVISO_TRAS     = 3;
	const MAX_INTENTOS   = 6;
	const RETRASO_MAX    = 172800;  // 48 h.
	const ANTELACION     = 129600;  // 36 h.
	const LIMPIAR_TRAS   = 1209600; // 14 días.
	const CERROJO_VIEJO  = 840;     // 14 min.
	const POR_PASADA     = 3;

	/** @var callable|null Reloj (pruebas). */
	public static $reloj = null;
	/** @var callable|null Espera (pruebas). */
	public static $dormidor = null;

	public static function ahora() {
		return self::$reloj ? (int) call_user_func( self::$reloj ) : time();
	}

	public static function dormir( $s ) {
		if ( self::$dormidor ) {
			call_user_func( self::$dormidor, $s );
		} else {
			sleep( (int) $s );
		}
	}

	/** Fecha y hora de Madrid → marca Unix (UTC), con el cambio de hora correcto. null si no es válida. */
	public static function utc_de( $fecha, $hora ) {
		$d = DateTimeImmutable::createFromFormat( '!Y-m-d H:i', $fecha . ' ' . $hora, new DateTimeZone( self::ZONA ) );
		$e = DateTimeImmutable::getLastErrors();
		if ( ! $d || ( is_array( $e ) && ( $e['warning_count'] || $e['error_count'] ) ) ) {
			return null;
		}
		return $d->getTimestamp();
	}

	public static function madrid( $ts, $formato = 'd/m/Y H:i' ) {
		return ( new DateTimeImmutable( '@' . (int) $ts ) )->setTimezone( new DateTimeZone( self::ZONA ) )->format( $formato );
	}

	// ---------------------------------------------------------------- WP-Cron

	public static function intervalos( $s ) {
		$s[ self::INTERVALO ] = array(
			'interval' => 900,
			'display'  => 'Cada 15 minutos (OGC Redes)',
		);
		return $s;
	}

	public static function programar() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 60, self::INTERVALO, self::CRON );
		}
	}

	public static function activar() {
		add_filter( 'cron_schedules', array( __CLASS__, 'intervalos' ) );
		self::programar();
	}

	public static function desactivar() {
		wp_clear_scheduled_hook( self::CRON );
		delete_option( self::OPC_CERROJO );
	}

	// ---------------------------------------------------------------- Estado de cada pieza

	public static function piezas() {
		$p = get_option( self::OPC_PIEZAS, array() );
		return is_array( $p ) ? $p : array();
	}

	public static function pieza( $id ) {
		$p = self::piezas();
		return array_merge(
			array(
				'ig'            => '',   // '' | contenedores | publicando | publicado.
				'ig_contenedor' => '',
				'ig_creado'     => 0,
				'ig_id'         => '',
				'ig_enlace'     => '',
				'ig_fecha'      => 0,
				'ig_dudoso'     => 0,
				'fb'            => '',   // '' | enviando | publicado | omitido.
				'fb_id'         => '',
				'fb_enlace'     => '',
				'fb_fecha'      => 0,
				'fb_dudoso'     => 0,
				'intentos'      => 0,
				'proximo'       => 0,
				'error'         => '',
				'error_fecha'   => 0,
				'avisado'       => 0,
				'parada'        => 0,
				'limpio'        => 0,
			),
			isset( $p[ $id ] ) && is_array( $p[ $id ] ) ? $p[ $id ] : array()
		);
	}

	public static function guardar_pieza( $id, array $st ) {
		$p        = self::piezas();
		$p[ $id ] = $st;
		update_option( self::OPC_PIEZAS, $p, false );
	}

	public static function terminada( array $st ) {
		return 'publicado' === $st['ig'] && in_array( $st['fb'], array( 'publicado', 'omitido' ), true );
	}

	/** Situación de una pieza para la tabla: [clave, texto]. */
	public static function situacion( array $p, array $st ) {
		$t = self::utc_de( $p['fecha'], $p['hora'] );
		if ( self::terminada( $st ) ) {
			return array( 'publicado', 'Publicada' );
		}
		if ( '' !== $p['retenida'] && 'publicado' !== $st['ig'] ) {
			return array( 'retenida', 'Retenida: ' . $p['retenida'] );
		}
		if ( $st['parada'] ) {
			return array( 'error', 'Parada tras ' . $st['intentos'] . ' fallos: ' . $st['error'] );
		}
		if ( $st['ig_dudoso'] || $st['fb_dudoso'] ) {
			return array( 'error', 'Revisar: ' . $st['error'] );
		}
		if ( $st['intentos'] ) {
			return array( 'error', 'Error (' . $st['intentos'] . ' intento' . ( 1 === $st['intentos'] ? '' : 's' ) . '; siguiente: ' . self::madrid( $st['proximo'] ) . '): ' . $st['error'] );
		}
		if ( in_array( $st['ig'], array( 'contenedores', 'publicando' ), true ) ) {
			return array( 'proceso', 'En proceso (Instagram está preparando el medio)' );
		}
		if ( 'publicado' === $st['ig'] ) {
			return array( 'proceso', 'En Instagram; falta Facebook' );
		}
		if ( self::ahora() - $t > self::RETRASO_MAX ) {
			return array( 'vencida', 'Vencida (pasaron más de 48 h): solo con «Publicar ahora»' );
		}
		return array( 'pendiente', 'Pendiente' );
	}

	// ---------------------------------------------------------------- Candado

	private static function cerrar() {
		if ( add_option( self::OPC_CERROJO, self::ahora(), '', 'no' ) ) {
			return true;
		}
		$t = (int) get_option( self::OPC_CERROJO, 0 );
		if ( $t && $t < self::ahora() - self::CERROJO_VIEJO ) {
			delete_option( self::OPC_CERROJO );
			return add_option( self::OPC_CERROJO, self::ahora(), '', 'no' );
		}
		return false;
	}

	private static function abrir() {
		delete_option( self::OPC_CERROJO );
	}

	// ---------------------------------------------------------------- Pasada del cron

	public static function cron() {
		if ( ! self::cerrar() ) {
			return array( 'Ya hay una pasada en curso.' );
		}
		$out = array();
		try {
			$out = self::pasada();
		} finally {
			self::abrir();
		}
		return $out;
	}

	/** «Publicar ahora»: mismo candado que el cron (nunca dos procesos a la vez con la misma pieza). */
	public static function cron_manual( $id ) {
		if ( ! self::cerrar() ) {
			return array( 'Ahora mismo se está publicando algo (pasada automática). Prueba dentro de un par de minutos.' );
		}
		try {
			OGC_Redes_Registro::anotar( $id . ' · «Publicar ahora» pulsado.' );
			return array( self::procesar( $id, true ) );
		} finally {
			self::abrir();
		}
	}

	public static function pasada() {
		$out = array();
		$me  = OGC_Redes_Manifiesto::estado();
		if ( self::ahora() - (int) $me['comprobado'] >= 3300 || ! OGC_Redes_Manifiesto::actual() ) {
			$out[] = OGC_Redes_Manifiesto::actualizar();
		}
		if ( OGC_Redes_Ajustes::get( 'pausa' ) ) {
			$out[] = 'Pausado: no se publica nada.';
			return $out;
		}
		if ( ! OGC_Redes_Ajustes::conectado() ) {
			$out[] = 'Sin conexión con Meta: no se publica nada.';
			return $out;
		}
		$ahora = self::ahora();
		$hecho = 0;
		foreach ( OGC_Redes_Manifiesto::publicaciones() as $id => $p ) {
			$t  = self::utc_de( $p['fecha'], $p['hora'] );
			$st = self::pieza( $id );
			if ( self::terminada( $st ) ) {
				if ( ! $st['limpio'] && max( (int) $st['ig_fecha'], (int) $st['fb_fecha'] ) < $ahora - self::LIMPIAR_TRAS ) {
					OGC_Redes_Manifiesto::borrar_medios( $id );
					$st['limpio'] = 1;
					self::guardar_pieza( $id, $st );
				}
				continue;
			}
			if ( '' !== $p['retenida'] && 'publicado' !== $st['ig'] ) {
				continue;
			}
			if ( $t > $ahora ) {
				if ( $t - $ahora <= self::ANTELACION ) {
					$r = OGC_Redes_Manifiesto::asegurar_medios( $p );
					if ( OGC_Redes_Graph::es_fallo( $r ) ) {
						$out[] = $id . ': medios aún no descargados (' . $r->mensaje . ')';
					}
				}
				continue;
			}
			$empezada = '' !== $st['ig'] || '' !== $st['fb'];
			if ( ! $empezada && $ahora - $t > self::RETRASO_MAX ) {
				continue; // Vencida: solo a mano.
			}
			if ( $st['parada'] || $st['ig_dudoso'] || $st['fb_dudoso'] || $st['proximo'] > $ahora ) {
				continue;
			}
			if ( $hecho >= self::POR_PASADA ) {
				break;
			}
			++$hecho;
			$out[] = self::procesar( $id, false );
			if ( ! OGC_Redes_Ajustes::conectado() ) {
				break; // El token se ha invalidado: no se sigue.
			}
		}
		return $out;
	}

	/**
	 * Publica una pieza (o sigue donde se quedó). $manual = «Publicar ahora»: ignora la hora, las esperas y la parada,
	 * pero NUNCA la vuelve a publicar si ya está publicada, ni publica una pieza retenida.
	 */
	public static function procesar( $id, $manual = false ) {
		$pubs = OGC_Redes_Manifiesto::publicaciones();
		if ( ! isset( $pubs[ $id ] ) ) {
			return $id . ': no está en la cola.';
		}
		$p  = $pubs[ $id ];
		$st = self::pieza( $id );
		if ( self::terminada( $st ) ) {
			return $id . ': ya estaba publicada; no se repite.';
		}
		if ( '' !== $p['retenida'] && 'publicado' !== $st['ig'] ) {
			return $id . ': retenida (' . $p['retenida'] . '); no se publica.';
		}
		if ( ! OGC_Redes_Ajustes::conectado() ) {
			return $id . ': sin conexión con Meta.';
		}
		$forzar_fb = $manual && $st['fb_dudoso'];
		if ( $manual ) {
			if ( $st['ig_dudoso'] ) {
				// Revisado a mano: se vuelve a empezar (la búsqueda por el pie sigue evitando un duplicado).
				$st['ig']            = '';
				$st['ig_contenedor'] = '';
			}
			$st['parada']    = 0;
			$st['proximo']   = 0;
			$st['ig_dudoso'] = 0;
			$st['fb_dudoso'] = 0;
			self::guardar_pieza( $id, $st );
		}
		$r = OGC_Redes_Publicador::instagram( $p, $st );
		if ( 'esperando' === $r ) {
			return $id . ': Instagram sigue preparando el medio; se seguirá en la próxima pasada.';
		}
		if ( true === $r ) {
			$r = OGC_Redes_Publicador::facebook( $p, $st, $forzar_fb );
		}
		if ( true !== $r ) {
			return self::fallo( $id, $st, $r );
		}
		$st['intentos'] = 0;
		$st['proximo']  = 0;
		$st['error']    = '';
		self::guardar_pieza( $id, $st );
		return $id . ': publicada' . ( $st['ig_enlace'] ? ' · ' . $st['ig_enlace'] : '' ) . ( $st['fb_enlace'] ? ' · ' . $st['fb_enlace'] : '' );
	}

	private static function fallo( $id, array $st, OGC_Redes_Fallo $f ) {
		$st                = array_merge( self::pieza( $id ), array_intersect_key( $st, self::pieza( $id ) ) );
		$st['intentos']    = (int) $st['intentos'] + 1;
		$st['error']       = (string) $f;
		$st['error_fecha'] = self::ahora();
		$st['proximo']     = self::ahora() + self::ESPERAS[ min( $st['intentos'], count( self::ESPERAS ) ) - 1 ];
		if ( $st['intentos'] >= self::MAX_INTENTOS ) {
			$st['parada'] = 1;
		}
		if ( $f->token_invalido() ) {
			self::token_caducado( $f );
		}
		if ( $st['intentos'] >= self::AVISO_TRAS && ! $st['avisado'] ) {
			$st['avisado'] = 1;
			self::avisar(
				'[OGC Redes] No se ha podido publicar ' . $id,
				"La publicación $id ha fallado " . $st['intentos'] . " veces.\n\nÚltimo error: " . $st['error'] .
				"\n\nSe seguirá intentando (" . ( $st['parada'] ? 'ya no: está parada hasta que pulses «Publicar ahora»' : 'siguiente intento: ' . self::madrid( $st['proximo'] ) ) . ").\n" .
				'Estado y botón «Publicar ahora»: ' . self::url_admin() . "\n\nNunca se publica dos veces la misma pieza."
			);
		}
		self::guardar_pieza( $id, $st );
		OGC_Redes_Registro::anotar( $id . ' · FALLO ' . $st['intentos'] . ': ' . $st['error'] );
		return $id . ': error (' . $st['error'] . ')';
	}

	public static function token_caducado( OGC_Redes_Fallo $f ) {
		$c = OGC_Redes_Ajustes::conexion();
		if ( 'caducado' === $c['estado'] ) {
			return;
		}
		OGC_Redes_Ajustes::guardar_conexion( array( 'estado' => 'caducado' ) );
		OGC_Redes_Registro::anotar( 'Conexión con Meta no válida: ' . $f );
		self::avisar(
			'[OGC Redes] Hay que volver a conectar con Facebook e Instagram',
			"Meta ha rechazado el token de la página (" . $f . ").\nPasa si cambias la contraseña de Facebook, quitas el permiso a la app o dejas de ser administrador de la página.\n\n" .
			"Arreglo (1 minuto): entra en " . self::url_admin( 'conexion' ) . " y pulsa «Conectar con Facebook e Instagram».\nLas publicaciones pendientes esperan; se reanudan solas al conectar (las de más de 48 h, solo con «Publicar ahora»)."
		);
	}

	public static function avisar( $asunto, $texto ) {
		wp_mail( OGC_Redes_Ajustes::email_aviso(), $asunto, OGC_Redes_Cripto::limpiar( $texto ) );
	}

	public static function url_admin( $pestana = 'estado' ) {
		return function_exists( 'admin_url' ) ? admin_url( 'options-general.php?page=ogc-redes&tab=' . $pestana ) : '';
	}
}
