<?php
/**
 * Registro de actividad (últimas 200 líneas, opción no autocargada). Todo pasa por OGC_Redes_Cripto::limpiar():
 * nunca se guarda un token, un secreto ni un «code».
 */

defined( 'ABSPATH' ) || exit;

class OGC_Redes_Registro {

	const OPC = 'ogc_redes_registro';
	const MAX = 200;

	public static function anotar( $texto ) {
		$l   = get_option( self::OPC, array() );
		$l   = is_array( $l ) ? $l : array();
		$l[] = array( OGC_Redes_Cola::ahora(), OGC_Redes_Cripto::limpiar( $texto ) );
		if ( count( $l ) > self::MAX ) {
			$l = array_slice( $l, -self::MAX );
		}
		update_option( self::OPC, $l, false );
	}

	public static function lineas() {
		$l = get_option( self::OPC, array() );
		return is_array( $l ) ? array_reverse( $l ) : array();
	}
}
