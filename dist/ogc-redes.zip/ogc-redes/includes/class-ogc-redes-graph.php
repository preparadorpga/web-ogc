<?php
/**
 * Cliente mínimo de la Graph API de Meta (graph.facebook.com/<versión>/).
 *
 * - El token va en el cuerpo (POST) o en la consulta (GET) junto con appsecret_proof; nunca se escribe en registros:
 *   los mensajes de error solo llevan la ruta y el texto de Meta, pasado por OGC_Redes_Cripto::limpiar().
 * - $transporte permite sustituir HTTP por un simulador en las pruebas (tests/pruebas.php).
 */

defined( 'ABSPATH' ) || exit;

class OGC_Redes_Fallo {
	public $mensaje;
	public $codigo;
	public $subcodigo;
	public $http;

	public function __construct( $mensaje, $codigo = 0, $subcodigo = 0, $http = 0 ) {
		$this->mensaje   = OGC_Redes_Cripto::limpiar( $mensaje );
		$this->codigo    = (int) $codigo;
		$this->subcodigo = (int) $subcodigo;
		$this->http      = (int) $http;
	}

	/** Token caducado, revocado o sin permisos: hay que volver a conectar. */
	public function token_invalido() {
		return in_array( $this->codigo, array( 190, 102 ), true ) || ( 10 === $this->codigo && 403 === $this->http ) || in_array( $this->subcodigo, array( 458, 459, 460, 463, 464, 467 ), true );
	}

	public function __toString() {
		return $this->mensaje . ( $this->codigo ? ' (código ' . $this->codigo . ( $this->subcodigo ? '/' . $this->subcodigo : '' ) . ')' : '' );
	}
}

class OGC_Redes_Graph {

	const HOST    = 'https://graph.facebook.com/';
	const TIMEOUT = 60;

	/** @var callable|null function( $metodo, $url, array $params ): array( 'code' => int, 'body' => string ) | OGC_Redes_Fallo */
	public static $transporte = null;

	public static function es_fallo( $r ) {
		return $r instanceof OGC_Redes_Fallo;
	}

	/**
	 * @param string      $metodo GET o POST.
	 * @param string      $ruta   Sin barra inicial: «12345/media», «oauth/access_token»…
	 * @param array       $params Parámetros.
	 * @param string|null $token  Token (se añade con appsecret_proof).
	 * @return array|OGC_Redes_Fallo
	 */
	public static function llamar( $metodo, $ruta, array $params = array(), $token = null ) {
		if ( ! preg_match( '#^[A-Za-z0-9_/]+$#', $ruta ) ) {
			return new OGC_Redes_Fallo( 'Ruta de la Graph API no válida.' );
		}
		if ( null !== $token && '' !== $token ) {
			$params['access_token'] = $token;
			$secreto                = OGC_Redes_Ajustes::secreto();
			if ( '' !== $secreto ) {
				$params['appsecret_proof'] = hash_hmac( 'sha256', $token, $secreto );
			}
		}
		$url = self::HOST . OGC_Redes_Ajustes::get( 'version' ) . '/' . $ruta;
		$r   = self::$transporte ? call_user_func( self::$transporte, $metodo, $url, $params ) : self::http( $metodo, $url, $params );
		if ( self::es_fallo( $r ) ) {
			$r->mensaje = self::ruta_publica( $ruta ) . ': ' . $r->mensaje;
			return $r;
		}
		$json = json_decode( (string) $r['body'], true );
		if ( isset( $json['error'] ) && is_array( $json['error'] ) ) {
			$e = $json['error'];
			$m = isset( $e['error_user_msg'] ) && '' !== $e['error_user_msg'] ? $e['error_user_msg'] : ( $e['message'] ?? 'error' );
			return new OGC_Redes_Fallo( self::ruta_publica( $ruta ) . ': ' . $m, $e['code'] ?? 0, $e['error_subcode'] ?? 0, $r['code'] );
		}
		if ( (int) $r['code'] < 200 || (int) $r['code'] >= 300 || ! is_array( $json ) ) {
			return new OGC_Redes_Fallo( self::ruta_publica( $ruta ) . ': respuesta HTTP ' . (int) $r['code'], 0, 0, $r['code'] );
		}
		return $json;
	}

	/** Ruta sin identificadores largos para los mensajes («<id>/media»). */
	private static function ruta_publica( $ruta ) {
		return preg_replace( '/[0-9]{6,}/', '<id>', $ruta );
	}

	private static function http( $metodo, $url, array $params ) {
		$args = array(
			'timeout'     => self::TIMEOUT,
			'redirection' => 0,
			'user-agent'  => 'OGC-Redes/' . OGC_REDES_VERSION,
		);
		if ( 'GET' === $metodo ) {
			$r = wp_remote_get( $url . '?' . http_build_query( $params, '', '&' ), $args );
		} else {
			$args['body'] = $params;
			$r            = wp_remote_post( $url, $args );
		}
		if ( is_wp_error( $r ) ) {
			return new OGC_Redes_Fallo( 'sin respuesta de Meta (' . $r->get_error_message() . ')' );
		}
		return array(
			'code' => (int) wp_remote_retrieve_response_code( $r ),
			'body' => (string) wp_remote_retrieve_body( $r ),
		);
	}
}
