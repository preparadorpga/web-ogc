<?php
/**
 * Ajustes y datos de la conexión. Todo en opciones NO autocargadas; los secretos, cifrados (OGC_Redes_Cripto).
 */

defined( 'ABSPATH' ) || exit;

class OGC_Redes_Ajustes {

	const OPC         = 'ogc_redes_ajustes';
	const OPC_CONEXION = 'ogc_redes_conexion';

	const VERSION_API = 'v26.0';  // Graph API más reciente (29/07/2026). Se puede cambiar en Ajustes.
	const URL_DEFECTO = 'https://raw.githubusercontent.com/preparadorpga/web-ogc/main/sync/redes/';

	/** Permisos mínimos (Facebook Login con «scope»; con Facebook Login para empresas se usa el ID de configuración). */
	const PERMISOS = array( 'instagram_basic', 'instagram_content_publish', 'pages_show_list', 'pages_read_engagement', 'pages_manage_posts', 'publish_video', 'business_management' );

	public static function todos() {
		$a = get_option( self::OPC, array() );
		$a = is_array( $a ) ? $a : array();
		return array(
			'app_id'      => isset( $a['app_id'] ) ? (string) $a['app_id'] : '',
			'app_secret'  => isset( $a['app_secret'] ) ? (string) $a['app_secret'] : '', // Cifrado.
			'config_id'   => isset( $a['config_id'] ) ? (string) $a['config_id'] : '',
			'version'     => isset( $a['version'] ) && self::version_valida( $a['version'] ) ? $a['version'] : self::VERSION_API,
			'url'         => isset( $a['url'] ) && self::url_valida( $a['url'] ) ? $a['url'] : self::URL_DEFECTO,
			'ig_esperada' => isset( $a['ig_esperada'] ) ? (string) $a['ig_esperada'] : 'preparadorogc',
			'facebook'    => isset( $a['facebook'] ) ? (bool) $a['facebook'] : true,
			'pausa'       => ! empty( $a['pausa'] ),
			'email'       => isset( $a['email'] ) ? (string) $a['email'] : '',
		);
	}

	public static function get( $k ) {
		$t = self::todos();
		return $t[ $k ] ?? null;
	}

	public static function guardar( array $cambios ) {
		$a = array_merge( self::todos(), $cambios );
		update_option( self::OPC, $a, false );
	}

	public static function version_valida( $v ) {
		return is_string( $v ) && (bool) preg_match( '/^v[0-9]{2}\.0$/', $v );
	}

	public static function url_valida( $u ) {
		return is_string( $u ) && strlen( $u ) < 300 && (bool) preg_match( '#^https://[a-z0-9]([a-z0-9.-]*[a-z0-9])?/([A-Za-z0-9._~%-]+/)*$#', $u ) && false === strpos( $u, '..' );
	}

	public static function app_id_valido( $id ) {
		return is_string( $id ) && (bool) preg_match( '/^[0-9]{6,20}$/', $id );
	}

	public static function secreto() {
		return OGC_Redes_Cripto::descifrar( self::get( 'app_secret' ) );
	}

	public static function email_aviso() {
		$e = self::get( 'email' );
		if ( $e && function_exists( 'is_email' ) && is_email( $e ) ) {
			return $e;
		}
		return (string) get_option( 'admin_email' );
	}

	// ---------------------------------------------------------------- Conexión

	public static function conexion() {
		$c = get_option( self::OPC_CONEXION, array() );
		return array_merge(
			array(
				'page_id'    => '',
				'page_name'  => '',
				'page_token' => '', // Cifrado.
				'ig_id'      => '',
				'ig_usuario' => '',
				'conectado'  => 0,
				'estado'     => '',  // ok | caducado.
				'avisado'    => 0,
			),
			is_array( $c ) ? $c : array()
		);
	}

	public static function guardar_conexion( array $c ) {
		update_option( self::OPC_CONEXION, array_merge( self::conexion(), $c ), false );
	}

	public static function token_pagina() {
		return OGC_Redes_Cripto::descifrar( self::conexion()['page_token'] );
	}

	public static function conectado() {
		$c = self::conexion();
		return '' !== $c['ig_id'] && '' !== $c['page_id'] && 'ok' === $c['estado'] && '' !== self::token_pagina();
	}
}
