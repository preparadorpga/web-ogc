<?php
/**
 * Publicación de UNA pieza en Instagram (Graph API, contenedores) y en la página de Facebook.
 *
 * Instagram (por pasos, guardando el estado tras cada uno para no repetir nada si el proceso se corta):
 *   1. Antes de crear nada, mira las últimas publicaciones de la cuenta: si ya hay una con el mismo pie, la da por
 *      publicada (por ejemplo, si alguien la subió a mano) y no la repite.
 *   2. Contenedores: carrusel = un hijo por imagen (is_carousel_item, alt_text) y el padre CAROUSEL con children;
 *      imagen = image_url + alt_text; vídeo y reel = REELS con video_url y share_to_feed=true.
 *   3. Espera a status_code=FINISHED (consulta cada pocos segundos dentro de un margen; si no ha terminado, sigue en la
 *      siguiente pasada del cron). EXPIRED o ERROR → se crean de nuevo en el siguiente intento.
 *   4. Marca «publicando» ANTES de media_publish. Si al volver a entrar está en «publicando» o el contenedor dice
 *      PUBLISHED, NO vuelve a publicar: recupera el id y el enlace de la lista de publicaciones.
 * Facebook: fotos (una o varias con attached_media) o vídeo (file_url) con el pie de Facebook (URL con UTM). Mismo
 * esquema: comprobación previa por el texto, «enviando» antes de la llamada y nunca un reenvío automático dudoso.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Redes_Publicador {

	const ESPERA_MAX  = 75;  // Segundos de espera de FINISHED dentro de una misma pasada.
	const INTERVALO   = 5;
	const CADUCIDAD   = 82800; // 23 h: un contenedor más viejo se rehace (Meta lo caduca a las 24 h).

	/** Huella del pie para reconocer una publicación ya hecha. */
	public static function huella( $texto ) {
		$t = function_exists( 'mb_strtolower' ) ? mb_strtolower( (string) $texto, 'UTF-8' ) : strtolower( (string) $texto );
		$t = preg_replace( '/https?:\/\/\S+/u', '', $t );
		$t = trim( preg_replace( '/[^\p{L}\p{N}]+/u', ' ', $t ) );
		return function_exists( 'mb_substr' ) ? mb_substr( $t, 0, 120, 'UTF-8' ) : substr( $t, 0, 120 );
	}

	// ================================================================= Instagram

	/** @return true|'esperando'|OGC_Redes_Fallo */
	public static function instagram( array $p, array &$st ) {
		if ( 'publicado' === ( $st['ig'] ?? '' ) ) {
			return true;
		}
		$c   = OGC_Redes_Ajustes::conexion();
		$tok = OGC_Redes_Ajustes::token_pagina();
		$ig  = $c['ig_id'];

		// Se cortó justo al publicar: nunca se vuelve a llamar a media_publish sin saber qué pasó.
		if ( 'publicando' === ( $st['ig'] ?? '' ) ) {
			return self::recuperar_ig( $p, $st, $ig, $tok );
		}

		if ( empty( $st['ig_contenedor'] ) || ( OGC_Redes_Cola::ahora() - (int) ( $st['ig_creado'] ?? 0 ) ) > self::CADUCIDAD ) {
			$ya = self::buscar_ig( $p, $ig, $tok );
			if ( OGC_Redes_Graph::es_fallo( $ya ) ) {
				return $ya;
			}
			if ( $ya ) {
				return self::marcar_ig( $st, $p, $ya['id'], $ya['permalink'] ?? '', 'ya estaba en Instagram (no se repite)' );
			}
			$ok = OGC_Redes_Manifiesto::asegurar_medios( $p );
			if ( true !== $ok ) {
				return $ok;
			}
			$cont = self::crear_contenedores( $p, $ig, $tok );
			if ( OGC_Redes_Graph::es_fallo( $cont ) ) {
				return $cont;
			}
			$st['ig']            = 'contenedores';
			$st['ig_contenedor'] = $cont;
			$st['ig_creado']     = OGC_Redes_Cola::ahora();
			OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
			OGC_Redes_Registro::anotar( $p['id'] . ' · contenedor de Instagram creado (' . $p['tipo'] . ').' );
		}

		// Espera a FINISHED.
		$esperado = 0;
		while ( true ) {
			$s = OGC_Redes_Graph::llamar( 'GET', $st['ig_contenedor'], array( 'fields' => 'status_code,status' ), $tok );
			if ( OGC_Redes_Graph::es_fallo( $s ) ) {
				return $s;
			}
			$code = (string) ( $s['status_code'] ?? '' );
			if ( 'FINISHED' === $code ) {
				break;
			}
			if ( 'PUBLISHED' === $code ) {
				return self::recuperar_ig( $p, $st, $ig, $tok );
			}
			if ( 'ERROR' === $code || 'EXPIRED' === $code ) {
				$st['ig']            = '';
				$st['ig_contenedor'] = '';
				OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
				return new OGC_Redes_Fallo( 'Instagram no ha podido procesar el medio (' . $code . ( isset( $s['status'] ) ? ': ' . $s['status'] : '' ) . '). Se volverá a crear el contenedor.' );
			}
			if ( $esperado >= self::ESPERA_MAX ) {
				OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
				return 'esperando';
			}
			OGC_Redes_Cola::dormir( self::INTERVALO );
			$esperado += self::INTERVALO;
		}

		// Publicar (marcado ANTES de llamar).
		$st['ig'] = 'publicando';
		OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
		$r = OGC_Redes_Graph::llamar( 'POST', $ig . '/media_publish', array( 'creation_id' => $st['ig_contenedor'] ), $tok );
		if ( OGC_Redes_Graph::es_fallo( $r ) || empty( $r['id'] ) ) {
			$s = OGC_Redes_Graph::llamar( 'GET', $st['ig_contenedor'], array( 'fields' => 'status_code' ), $tok );
			if ( ! OGC_Redes_Graph::es_fallo( $s ) && 'PUBLISHED' === ( $s['status_code'] ?? '' ) ) {
				return self::recuperar_ig( $p, $st, $ig, $tok );
			}
			if ( ! OGC_Redes_Graph::es_fallo( $s ) ) {
				// Meta confirma que no se ha publicado: se puede reintentar con el mismo contenedor.
				$st['ig'] = 'contenedores';
				OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
			}
			return OGC_Redes_Graph::es_fallo( $r ) ? $r : new OGC_Redes_Fallo( 'media_publish no ha devuelto id' );
		}
		$enlace = '';
		$d      = OGC_Redes_Graph::llamar( 'GET', (string) $r['id'], array( 'fields' => 'permalink' ), $tok );
		if ( ! OGC_Redes_Graph::es_fallo( $d ) ) {
			$enlace = (string) ( $d['permalink'] ?? '' );
		}
		return self::marcar_ig( $st, $p, (string) $r['id'], $enlace, 'publicada en Instagram' );
	}

	private static function marcar_ig( array &$st, array $p, $id, $enlace, $nota ) {
		$st['ig']        = 'publicado';
		$st['ig_id']     = (string) $id;
		$st['ig_enlace'] = self::enlace_valido( $enlace, 'instagram.com' );
		$st['ig_fecha']  = OGC_Redes_Cola::ahora();
		OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
		OGC_Redes_Registro::anotar( $p['id'] . ' · ' . $nota . ( $st['ig_enlace'] ? ': ' . $st['ig_enlace'] : '' ) );
		return true;
	}

	/** Estado «publicando» o contenedor PUBLISHED: se busca, nunca se vuelve a publicar. */
	private static function recuperar_ig( array $p, array &$st, $ig, $tok ) {
		$s = empty( $st['ig_contenedor'] ) ? null : OGC_Redes_Graph::llamar( 'GET', $st['ig_contenedor'], array( 'fields' => 'status_code' ), $tok );
		if ( is_array( $s ) && 'FINISHED' === ( $s['status_code'] ?? '' ) ) {
			// Meta dice que el contenedor sigue sin publicar: se puede volver a intentar media_publish.
			$st['ig'] = 'contenedores';
			OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
			return new OGC_Redes_Fallo( 'La publicación anterior se cortó antes de terminar; se reintentará con el mismo contenedor.' );
		}
		$ya = self::buscar_ig( $p, $ig, $tok );
		if ( OGC_Redes_Graph::es_fallo( $ya ) ) {
			return $ya;
		}
		if ( $ya ) {
			return self::marcar_ig( $st, $p, $ya['id'], $ya['permalink'] ?? '', 'publicada en Instagram (recuperado el enlace)' );
		}
		if ( is_array( $s ) && 'PUBLISHED' === ( $s['status_code'] ?? '' ) ) {
			return self::marcar_ig( $st, $p, '', '', 'publicada en Instagram (sin enlace todavía)' );
		}
		// No se sabe: no se repite. Queda para revisión manual.
		$st['ig_dudoso'] = 1;
		OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
		return new OGC_Redes_Fallo( 'No se puede confirmar si se publicó en Instagram: revisa el perfil. No se repetirá sola; «Publicar ahora» la vuelve a intentar.' );
	}

	/** @return array|null|OGC_Redes_Fallo Publicación de la cuenta con el mismo pie. */
	public static function buscar_ig( array $p, $ig, $tok ) {
		$r = OGC_Redes_Graph::llamar( 'GET', $ig . '/media', array( 'fields' => 'id,caption,permalink,timestamp', 'limit' => 25 ), $tok );
		if ( OGC_Redes_Graph::es_fallo( $r ) ) {
			return $r;
		}
		$h = self::huella( $p['pie_ig'] );
		foreach ( (array) ( $r['data'] ?? array() ) as $m ) {
			if ( is_array( $m ) && isset( $m['id'] ) && self::huella( $m['caption'] ?? '' ) === $h ) {
				return $m;
			}
		}
		return null;
	}

	/** @return string|OGC_Redes_Fallo Id del contenedor que se publica. */
	private static function crear_contenedores( array $p, $ig, $tok ) {
		$urls = array();
		foreach ( $p['medios'] as $x ) {
			$urls[] = array( OGC_Redes_Manifiesto::url_publica( $x ), (string) ( $x['alt'] ?? '' ) );
		}
		if ( 'CAROUSEL' === $p['tipo'] ) {
			$hijos = array();
			foreach ( $urls as $u ) {
				$q = array(
					'image_url'        => $u[0],
					'is_carousel_item' => 'true',
				);
				if ( '' !== $u[1] ) {
					$q['alt_text'] = $u[1];
				}
				$r = OGC_Redes_Graph::llamar( 'POST', $ig . '/media', $q, $tok );
				if ( OGC_Redes_Graph::es_fallo( $r ) ) {
					return $r;
				}
				if ( empty( $r['id'] ) ) {
					return new OGC_Redes_Fallo( 'Instagram no ha devuelto el id de una imagen del carrusel.' );
				}
				$hijos[] = (string) $r['id'];
			}
			$q = array(
				'media_type' => 'CAROUSEL',
				'children'   => implode( ',', $hijos ),
				'caption'    => $p['pie_ig'],
			);
		} elseif ( 'IMAGE' === $p['tipo'] ) {
			$q = array(
				'image_url' => $urls[0][0],
				'caption'   => $p['pie_ig'],
			);
			if ( '' !== $urls[0][1] ) {
				$q['alt_text'] = $urls[0][1];
			}
		} else {
			$q = array(
				'media_type'    => 'REELS',
				'video_url'     => $urls[0][0],
				'caption'       => $p['pie_ig'],
				'share_to_feed' => 'true',
			);
		}
		$r = OGC_Redes_Graph::llamar( 'POST', $ig . '/media', $q, $tok );
		if ( OGC_Redes_Graph::es_fallo( $r ) ) {
			return $r;
		}
		return empty( $r['id'] ) ? new OGC_Redes_Fallo( 'Instagram no ha devuelto el id del contenedor.' ) : (string) $r['id'];
	}

	// ================================================================= Facebook

	/** @return true|OGC_Redes_Fallo */
	public static function facebook( array $p, array &$st, $forzar = false ) {
		$f = $st['fb'] ?? '';
		if ( 'publicado' === $f || 'omitido' === $f ) {
			return true;
		}
		if ( ! OGC_Redes_Ajustes::get( 'facebook' ) ) {
			$st['fb'] = 'omitido';
			OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
			return true;
		}
		$c    = OGC_Redes_Ajustes::conexion();
		$tok  = OGC_Redes_Ajustes::token_pagina();
		$page = $c['page_id'];

		$ya = self::buscar_fb( $p, $page, $tok );
		if ( OGC_Redes_Graph::es_fallo( $ya ) ) {
			return $ya;
		}
		if ( $ya ) {
			return self::marcar_fb( $st, $p, $ya['id'], $ya['permalink_url'] ?? '', 'ya estaba en Facebook (no se repite)' );
		}
		if ( 'enviando' === $f && ! $forzar ) {
			$st['fb_dudoso'] = 1;
			OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
			return new OGC_Redes_Fallo( 'El envío anterior a Facebook se cortó y la publicación no aparece todavía (los vídeos tardan): revisa la página. No se repetirá sola; «Publicar ahora» la vuelve a intentar.' );
		}
		$ok = OGC_Redes_Manifiesto::asegurar_medios( $p );
		if ( true !== $ok ) {
			return $ok;
		}
		$st['fb']        = 'enviando';
		$st['fb_dudoso'] = 0;
		OGC_Redes_Cola::guardar_pieza( $p['id'], $st );

		$msg = $p['pie_fb'];
		$m0  = $p['medios'][0];
		if ( 'REELS' === $p['tipo'] ) {
			$r = OGC_Redes_Graph::llamar(
				'POST',
				$page . '/videos',
				array(
					'file_url'    => OGC_Redes_Manifiesto::url_publica( $m0 ),
					'description' => $msg,
				),
				$tok
			);
			$id = is_array( $r ) ? (string) ( $r['id'] ?? '' ) : '';
		} elseif ( 'IMAGE' === $p['tipo'] ) {
			$r  = OGC_Redes_Graph::llamar(
				'POST',
				$page . '/photos',
				array(
					'url'       => OGC_Redes_Manifiesto::url_publica( $m0 ),
					'message'   => $msg,
					'published' => 'true',
				),
				$tok
			);
			$id = is_array( $r ) ? (string) ( $r['post_id'] ?? ( $r['id'] ?? '' ) ) : '';
		} else {
			$fotos = array();
			foreach ( $p['medios'] as $x ) {
				$q = OGC_Redes_Graph::llamar(
					'POST',
					$page . '/photos',
					array(
						'url'       => OGC_Redes_Manifiesto::url_publica( $x ),
						'published' => 'false',
					),
					$tok
				);
				if ( OGC_Redes_Graph::es_fallo( $q ) || empty( $q['id'] ) ) {
					// Las fotos sin publicar no se ven: no hay publicación a medias. Se puede reintentar.
					$st['fb'] = '';
					OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
					return OGC_Redes_Graph::es_fallo( $q ) ? $q : new OGC_Redes_Fallo( 'Facebook no ha devuelto el id de una foto.' );
				}
				$fotos[] = wp_json_encode( array( 'media_fbid' => (string) $q['id'] ) );
			}
			$r  = OGC_Redes_Graph::llamar(
				'POST',
				$page . '/feed',
				array(
					'message'        => $msg,
					'attached_media' => $fotos,
				),
				$tok
			);
			$id = is_array( $r ) ? (string) ( $r['id'] ?? '' ) : '';
		}
		if ( OGC_Redes_Graph::es_fallo( $r ) || '' === $id ) {
			// Error devuelto por Meta: no se ha creado la publicación.
			$st['fb'] = '';
			OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
			return OGC_Redes_Graph::es_fallo( $r ) ? $r : new OGC_Redes_Fallo( 'Facebook no ha devuelto el id de la publicación.' );
		}
		$enlace = '';
		$d      = OGC_Redes_Graph::llamar( 'GET', $id, array( 'fields' => 'permalink_url' ), $tok );
		if ( ! OGC_Redes_Graph::es_fallo( $d ) ) {
			$enlace = (string) ( $d['permalink_url'] ?? '' );
			if ( '' !== $enlace && '/' === $enlace[0] ) {
				$enlace = 'https://www.facebook.com' . $enlace;
			}
		}
		return self::marcar_fb( $st, $p, $id, $enlace, 'publicada en Facebook' );
	}

	private static function marcar_fb( array &$st, array $p, $id, $enlace, $nota ) {
		$st['fb']        = 'publicado';
		$st['fb_id']     = (string) $id;
		$st['fb_enlace'] = self::enlace_valido( $enlace, 'facebook.com' );
		$st['fb_fecha']  = OGC_Redes_Cola::ahora();
		$st['fb_dudoso'] = 0;
		OGC_Redes_Cola::guardar_pieza( $p['id'], $st );
		OGC_Redes_Registro::anotar( $p['id'] . ' · ' . $nota . ( $st['fb_enlace'] ? ': ' . $st['fb_enlace'] : '' ) );
		return true;
	}

	/** @return array|null|OGC_Redes_Fallo */
	public static function buscar_fb( array $p, $page, $tok ) {
		$r = OGC_Redes_Graph::llamar( 'GET', $page . '/published_posts', array( 'fields' => 'id,message,permalink_url,created_time', 'limit' => 25 ), $tok );
		if ( OGC_Redes_Graph::es_fallo( $r ) ) {
			return $r;
		}
		$h = self::huella( $p['pie_fb'] );
		foreach ( (array) ( $r['data'] ?? array() ) as $m ) {
			if ( is_array( $m ) && isset( $m['id'] ) && self::huella( $m['message'] ?? '' ) === $h ) {
				return $m;
			}
		}
		return null;
	}

	private static function enlace_valido( $u, $dominio ) {
		$u = (string) $u;
		return preg_match( '#^https://([a-z0-9-]+\.)*' . preg_quote( $dominio, '#' ) . '/[^\s"<>]*$#i', $u ) ? $u : '';
	}
}
