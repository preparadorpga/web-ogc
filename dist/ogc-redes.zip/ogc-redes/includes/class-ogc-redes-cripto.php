<?php
/**
 * Cifrado de secretos (App Secret y token de página) con la sal del sitio.
 *
 * sodium_crypto_secretbox (XSalsa20-Poly1305) con una clave derivada de wp_salt( 'auth' ) (AUTH_KEY + AUTH_SALT de
 * wp-config.php). Lo guardado en la base de datos no sirve sin wp-config.php. Si las sales cambian, el valor deja de
 * poder abrirse y el plugin pide «Conectar» otra vez (nunca falla en silencio).
 */

defined( 'ABSPATH' ) || exit;

class OGC_Redes_Cripto {

	const PREFIJO = 'r1:';

	/** @var string|null Clave fija para las pruebas. */
	public static $clave_pruebas = null;

	private static function clave() {
		if ( null !== self::$clave_pruebas ) {
			return self::$clave_pruebas;
		}
		$sal = function_exists( 'wp_salt' ) ? wp_salt( 'auth' ) : '';
		if ( defined( 'AUTH_KEY' ) ) {
			$sal .= AUTH_KEY;
		}
		return hash_hmac( 'sha256', 'ogc-redes|secretos|v1', $sal, true );
	}

	public static function cifrar( $texto ) {
		$texto = (string) $texto;
		if ( '' === $texto ) {
			return '';
		}
		$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		return self::PREFIJO . base64_encode( $nonce . sodium_crypto_secretbox( $texto, $nonce, self::clave() ) );
	}

	/** @return string Texto en claro o '' si no se puede abrir. */
	public static function descifrar( $guardado ) {
		$guardado = (string) $guardado;
		if ( 0 !== strpos( $guardado, self::PREFIJO ) ) {
			return '';
		}
		$b = base64_decode( substr( $guardado, strlen( self::PREFIJO ) ), true );
		if ( false === $b || strlen( $b ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES + SODIUM_CRYPTO_SECRETBOX_MACBYTES ) {
			return '';
		}
		$t = sodium_crypto_secretbox_open( substr( $b, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), substr( $b, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), self::clave() );
		return false === $t ? '' : $t;
	}

	/** Quita de un texto cualquier cosa con forma de token de Meta (para registros y avisos). */
	public static function limpiar( $texto ) {
		$t = preg_replace( '/\bEA[A-Za-z0-9]{20,}\b/', '[token]', (string) $texto );
		$t = preg_replace( '/(access_token|client_secret|appsecret_proof|fb_exchange_token|code)=[^&\s"\']+/i', '$1=[oculto]', $t );
		return $t;
	}
}
