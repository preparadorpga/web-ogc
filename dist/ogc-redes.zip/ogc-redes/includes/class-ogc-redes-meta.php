<?php
/**
 * Conexión única con Meta (Facebook Login, flujo de servidor con «code»).
 *
 *   1. «Conectar» → https://www.facebook.com/<versión>/dialog/oauth con client_id, redirect_uri (admin-post.php?action=
 *      ogc_redes_oauth), state aleatorio atado al usuario (10 min) y los permisos mínimos (o el ID de configuración de
 *      Facebook Login para empresas, si se ha puesto).
 *   2. Vuelta: comprueba state y capacidad; cambia el code por un token de usuario (oauth/access_token, con el App
 *      Secret, desde el servidor) y este por uno de larga duración (fb_exchange_token).
 *   3. me/accounts con instagram_business_account: elige la página que tiene la cuenta de Instagram esperada
 *      (@preparadorogc) o, si hay varias, deja elegir. Su token de página, obtenido con un token de usuario de larga
 *      duración, no caduca.
 *   4. Guarda cifrados el token de página; el token de usuario no se guarda.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Redes_Meta {

	const TRANS_STATE   = 'ogc_redes_state_';
	const TRANS_PAGINAS = 'ogc_redes_paginas_';

	public static function redirect_uri() {
		return admin_url( 'admin-post.php?action=ogc_redes_oauth' );
	}

	public static function listo_para_conectar() {
		return OGC_Redes_Ajustes::app_id_valido( OGC_Redes_Ajustes::get( 'app_id' ) ) && '' !== OGC_Redes_Ajustes::secreto();
	}

	public static function url_login() {
		$state = bin2hex( random_bytes( 16 ) );
		set_transient( self::TRANS_STATE . get_current_user_id(), $state, 600 );
		$q = array(
			'client_id'     => OGC_Redes_Ajustes::get( 'app_id' ),
			'redirect_uri'  => self::redirect_uri(),
			'state'         => $state,
			'response_type' => 'code',
		);
		$cfg = OGC_Redes_Ajustes::get( 'config_id' );
		if ( '' !== $cfg ) {
			$q['config_id'] = $cfg;
		} else {
			$q['scope'] = implode( ',', OGC_Redes_Ajustes::PERMISOS );
		}
		return 'https://www.facebook.com/' . OGC_Redes_Ajustes::get( 'version' ) . '/dialog/oauth?' . http_build_query( $q, '', '&' );
	}

	/** @return true|string */
	public static function comprobar_state( $state ) {
		$k   = self::TRANS_STATE . get_current_user_id();
		$esp = (string) get_transient( $k );
		delete_transient( $k );
		if ( '' === $esp || ! is_string( $state ) || ! hash_equals( $esp, $state ) ) {
			return 'La conexión ha caducado o no la has iniciado desde esta pantalla. Pulsa «Conectar» otra vez.';
		}
		return true;
	}

	/**
	 * Cambia el code por el token de larga duración y lee las páginas. @return array|string Páginas o motivo.
	 */
	public static function canjear( $code ) {
		$app = OGC_Redes_Ajustes::get( 'app_id' );
		$sec = OGC_Redes_Ajustes::secreto();
		$r   = OGC_Redes_Graph::llamar(
			'GET',
			'oauth/access_token',
			array(
				'client_id'     => $app,
				'client_secret' => $sec,
				'redirect_uri'  => self::redirect_uri(),
				'code'          => (string) $code,
			)
		);
		if ( OGC_Redes_Graph::es_fallo( $r ) || empty( $r['access_token'] ) ) {
			return 'Meta no ha aceptado el código: ' . ( OGC_Redes_Graph::es_fallo( $r ) ? $r : 'sin token' );
		}
		$l = OGC_Redes_Graph::llamar(
			'GET',
			'oauth/access_token',
			array(
				'grant_type'        => 'fb_exchange_token',
				'client_id'         => $app,
				'client_secret'     => $sec,
				'fb_exchange_token' => $r['access_token'],
			)
		);
		if ( OGC_Redes_Graph::es_fallo( $l ) || empty( $l['access_token'] ) ) {
			return 'No se ha podido obtener el token de larga duración: ' . ( OGC_Redes_Graph::es_fallo( $l ) ? $l : 'sin token' );
		}
		$p = OGC_Redes_Graph::llamar(
			'GET',
			'me/accounts',
			array(
				'fields' => 'id,name,access_token,tasks,instagram_business_account{id,username}',
				'limit'  => 100,
			),
			$l['access_token']
		);
		if ( OGC_Redes_Graph::es_fallo( $p ) ) {
			return 'No se han podido leer tus páginas: ' . $p;
		}
		$paginas = array();
		foreach ( (array) ( $p['data'] ?? array() ) as $x ) {
			if ( ! is_array( $x ) || empty( $x['id'] ) || empty( $x['access_token'] ) ) {
				continue;
			}
			$paginas[] = array(
				'page_id'    => (string) $x['id'],
				'page_name'  => (string) ( $x['name'] ?? '' ),
				'page_token' => (string) $x['access_token'],
				'ig_id'      => (string) ( $x['instagram_business_account']['id'] ?? '' ),
				'ig_usuario' => (string) ( $x['instagram_business_account']['username'] ?? '' ),
			);
		}
		if ( ! $paginas ) {
			return 'Tu usuario no administra ninguna página de Facebook (o no la has marcado al conectar). Crea la página, vincula Instagram y conecta de nuevo.';
		}
		return $paginas;
	}

	/** Elige la página: la que tiene @preparadorogc; si no, la única con Instagram. @return array|null */
	public static function elegir( array $paginas ) {
		$esperada = strtolower( ltrim( (string) OGC_Redes_Ajustes::get( 'ig_esperada' ), '@' ) );
		$con_ig   = array_values( array_filter( $paginas, function ( $x ) { return '' !== $x['ig_id']; } ) );
		foreach ( $con_ig as $x ) {
			if ( '' !== $esperada && strtolower( $x['ig_usuario'] ) === $esperada ) {
				return $x;
			}
		}
		return 1 === count( $con_ig ) ? $con_ig[0] : null;
	}

	/** Guarda la página elegida (token cifrado). */
	public static function guardar_pagina( array $x ) {
		OGC_Redes_Ajustes::guardar_conexion(
			array(
				'page_id'    => $x['page_id'],
				'page_name'  => $x['page_name'],
				'page_token' => OGC_Redes_Cripto::cifrar( $x['page_token'] ),
				'ig_id'      => $x['ig_id'],
				'ig_usuario' => $x['ig_usuario'],
				'conectado'  => OGC_Redes_Cola::ahora(),
				'estado'     => 'ok',
				'avisado'    => 0,
			)
		);
		OGC_Redes_Registro::anotar( 'Conectado: página «' . $x['page_name'] . '» e Instagram @' . $x['ig_usuario'] . '.' );
	}

	/** Lista temporal de páginas para elegir (cifrada, 10 minutos). */
	public static function guardar_lista( array $paginas ) {
		set_transient( self::TRANS_PAGINAS . get_current_user_id(), OGC_Redes_Cripto::cifrar( wp_json_encode( $paginas ) ), 600 );
	}

	public static function leer_lista() {
		$j = OGC_Redes_Cripto::descifrar( (string) get_transient( self::TRANS_PAGINAS . get_current_user_id() ) );
		$l = json_decode( $j, true );
		return is_array( $l ) ? $l : array();
	}

	public static function borrar_lista() {
		delete_transient( self::TRANS_PAGINAS . get_current_user_id() );
	}

	/** Comprueba la conexión. @return string[] */
	public static function comprobar() {
		$c   = OGC_Redes_Ajustes::conexion();
		$tok = OGC_Redes_Ajustes::token_pagina();
		if ( '' === $tok ) {
			return array( 'No hay conexión guardada (o no se puede descifrar: ¿han cambiado las sales de wp-config.php?). Pulsa «Conectar».' );
		}
		$o = array();
		$r = OGC_Redes_Graph::llamar( 'GET', $c['ig_id'], array( 'fields' => 'username,media_count' ), $tok );
		if ( OGC_Redes_Graph::es_fallo( $r ) ) {
			if ( $r->token_invalido() ) {
				OGC_Redes_Cola::token_caducado( $r );
			}
			return array( 'Instagram: ' . $r );
		}
		$o[] = 'Instagram @' . ( $r['username'] ?? '?' ) . ': conexión correcta (' . (int) ( $r['media_count'] ?? 0 ) . ' publicaciones).';
		$l   = OGC_Redes_Graph::llamar( 'GET', $c['ig_id'] . '/content_publishing_limit', array( 'fields' => 'quota_usage,config' ), $tok );
		if ( ! OGC_Redes_Graph::es_fallo( $l ) && isset( $l['data'][0] ) ) {
			$o[] = 'Publicaciones por API en las últimas 24 h: ' . (int) ( $l['data'][0]['quota_usage'] ?? 0 ) . ' de ' . (int) ( $l['data'][0]['config']['quota_total'] ?? 0 ) . '.';
		}
		$f = OGC_Redes_Graph::llamar( 'GET', $c['page_id'], array( 'fields' => 'name' ), $tok );
		$o[] = OGC_Redes_Graph::es_fallo( $f ) ? 'Facebook: ' . $f : 'Página de Facebook «' . ( $f['name'] ?? '' ) . '»: conexión correcta.';
		if ( 'caducado' === $c['estado'] && ! OGC_Redes_Graph::es_fallo( $f ) ) {
			OGC_Redes_Ajustes::guardar_conexion( array( 'estado' => 'ok' ) );
		}
		return $o;
	}
}
