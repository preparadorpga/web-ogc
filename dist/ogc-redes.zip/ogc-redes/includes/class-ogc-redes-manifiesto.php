<?php
/**
 * Manifiesto FIRMADO de la cola (web-ogc/sync/redes/manifiesto.json + manifiesto.sig) y medios.
 *
 * - Firma Ed25519 de los bytes exactos del JSON con la MISMA clave que OGC Páginas (CLAVE_PUBLICA es la de
 *   OGC_Paginas_Sync). La privada solo está en el equipo de publicación (redes/publicacion/publicar_redes.py).
 * - Anti-reversión: nunca se acepta una serie menor que la mayor aplicada.
 * - Medios: solo medios/<id>/<nombre>-<sha10>.(jpg|mp4), tamaño y sha256 firmados, tipo comprobado por los bytes.
 *   Se copian a wp-content/uploads/ogc-redes/ para que Meta los descargue de una URL estable del propio dominio,
 *   con el content-type correcto (image/jpeg, video/mp4).
 * - El JSON se trata solo como datos.
 */

defined( 'ABSPATH' ) || exit;

class OGC_Redes_Manifiesto {

	const CLAVE_PUBLICA = 'ugbcuuCLyxi4XdOZpFfFPXVf5CSTb3wnPtgALby01bM=';

	const OPC        = 'ogc_redes_manifiesto';   // array( json, firma ) del aplicado (no autocargada).
	const OPC_ESTADO = 'ogc_redes_manifiesto_estado';

	const MAX_MANIFIESTO = 4194304;     // 4 MB.
	const MAX_FIRMA      = 1024;
	const MAX_IMAGEN     = 8388608;     // 8 MB (límite de Instagram).
	const MAX_VIDEO      = 104857600;   // 100 MB.
	const MAX_PIE        = 2200;
	const FECHA_MINIMA   = 1767225600;  // 01/01/2026.
	const CARPETA        = 'ogc-redes';

	const TIPOS   = array( 'IMAGE', 'CAROUSEL', 'REELS' );
	const FORMATOS = array( 'imagen', 'carrusel', 'video', 'reel' );

	/** @var callable|null function( $url, $max, $destino ): string|true|OGC_Redes_Fallo (pruebas). */
	public static $descargador = null;

	/** @var string|null Clave pública sustituta (solo pruebas). */
	public static $clave = null;

	/** @var array|null */
	private static $cache = null;

	// ---------------------------------------------------------------- Firma y validación

	/** @return true|string */
	public static function verificar_firma( $json, $firma_texto, $clave = null ) {
		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return 'Este servidor no tiene sodium: no se puede verificar la firma.';
		}
		$firma = base64_decode( trim( (string) $firma_texto ), true );
		if ( false === $firma || 64 !== strlen( $firma ) ) {
			return 'La firma (manifiesto.sig) no tiene el formato esperado.';
		}
		$clave = null === $clave ? ( null !== self::$clave ? self::$clave : base64_decode( self::CLAVE_PUBLICA ) ) : $clave;
		try {
			$ok = sodium_crypto_sign_verify_detached( $firma, (string) $json, $clave );
		} catch ( Throwable $e ) {
			$ok = false;
		}
		return $ok ? true : 'FIRMA NO VÁLIDA: el manifiesto no lo ha firmado Preparador OGC (o se ha alterado). No se aplica nada.';
	}

	/**
	 * @param string $json      Bytes con firma ya verificada.
	 * @param int    $serie_max Mayor serie aplicada (anti-reversión; 0 = no comprobar).
	 * @return array|string Manifiesto o motivo del rechazo ('reversion' si es anterior o igual).
	 */
	public static function validar( $json, $serie_max = 0 ) {
		$m = json_decode( (string) $json, true );
		if ( ! is_array( $m ) || 'ogc-redes' !== ( $m['tipo'] ?? '' ) || 1 !== ( $m['formato'] ?? 0 ) ) {
			return 'Formato: no es un manifiesto de OGC Redes (formato 1).';
		}
		if ( ! is_int( $m['serie'] ?? null ) || ! is_int( $m['fecha_unix'] ?? null ) || $m['serie'] < 1 ) {
			return 'Formato: faltan la serie o la fecha.';
		}
		if ( $m['fecha_unix'] < self::FECHA_MINIMA || $m['fecha_unix'] > OGC_Redes_Cola::ahora() + 86400 ) {
			return 'Fecha del manifiesto no razonable: no se aplica.';
		}
		if ( $serie_max && $m['serie'] <= $serie_max ) {
			return 'reversion';
		}
		if ( ! isset( $m['publicaciones'] ) || ! is_array( $m['publicaciones'] ) || count( $m['publicaciones'] ) > 500 ) {
			return 'Formato: lista de publicaciones no válida.';
		}
		$ids = array();
		foreach ( $m['publicaciones'] as $p ) {
			$e = self::validar_publicacion( $p );
			if ( true !== $e ) {
				return 'Publicación ' . ( is_array( $p ) && isset( $p['id'] ) && is_string( $p['id'] ) ? substr( preg_replace( '/[^A-Za-z0-9]/', '', $p['id'] ), 0, 8 ) : '?' ) . ': ' . $e;
			}
			if ( isset( $ids[ $p['id'] ] ) ) {
				return 'Publicación ' . $p['id'] . ' repetida.';
			}
			$ids[ $p['id'] ] = 1;
		}
		return $m;
	}

	/** @return true|string */
	public static function validar_publicacion( $p ) {
		if ( ! is_array( $p ) || ! is_string( $p['id'] ?? null ) || ! preg_match( '/^[A-Z][0-9]{2,3}$/', $p['id'] ) ) {
			return 'id no válido';
		}
		if ( ! is_string( $p['fecha'] ?? null ) || ! preg_match( '/^20[0-9]{2}-[01][0-9]-[0-3][0-9]$/', $p['fecha'] ) || ! is_string( $p['hora'] ?? null ) || ! preg_match( '/^[0-2][0-9]:[0-5][0-9]$/', $p['hora'] ) ) {
			return 'fecha u hora no válidas';
		}
		if ( 'Europe/Madrid' !== ( $p['zona'] ?? '' ) || null === OGC_Redes_Cola::utc_de( $p['fecha'], $p['hora'] ) ) {
			return 'zona horaria no válida';
		}
		if ( ! in_array( $p['tipo'] ?? '', self::TIPOS, true ) || ! in_array( $p['formato'] ?? '', self::FORMATOS, true ) ) {
			return 'tipo no válido';
		}
		foreach ( array( 'pie_ig', 'pie_fb' ) as $k ) {
			if ( ! is_string( $p[ $k ] ?? null ) || '' === trim( $p[ $k ] ) || self::longitud( $p[ $k ] ) > self::MAX_PIE ) {
				return 'pie vacío o de más de 2.200 caracteres';
			}
		}
		if ( ! is_string( $p['retenida'] ?? '' ) ) {
			return 'campo «retenida» no válido';
		}
		$med = $p['medios'] ?? null;
		if ( ! is_array( $med ) || ! $med ) {
			return 'sin medios';
		}
		$n = count( $med );
		if ( ( 'CAROUSEL' === $p['tipo'] && ( $n < 2 || $n > 10 ) ) || ( 'CAROUSEL' !== $p['tipo'] && 1 !== $n ) ) {
			return 'número de medios no válido para ' . $p['tipo'];
		}
		foreach ( $med as $x ) {
			$e = self::validar_medio( $x );
			if ( true !== $e ) {
				return $e;
			}
			$es_video = 'mp4' === $x['ext'];
			if ( ( 'REELS' === $p['tipo'] ) !== $es_video ) {
				return 'el tipo ' . $p['tipo'] . ' no admite ' . $x['ext'];
			}
		}
		return true;
	}

	private static function longitud( $t ) {
		return function_exists( 'mb_strlen' ) ? mb_strlen( $t, 'UTF-8' ) : strlen( utf8_decode( $t ) );
	}

	/** @return true|string (añade 'ext' al medio por referencia de la copia validada en medios()). */
	public static function validar_medio( &$x ) {
		if ( ! is_array( $x ) || ! is_string( $x['ruta'] ?? null ) || ! preg_match( '#^medios/[a-z0-9]{2,4}/[a-z0-9_-]{1,40}-[0-9a-f]{10}\.(jpg|mp4)$#', $x['ruta'], $mm ) ) {
			return 'ruta de medio no permitida';
		}
		$x['ext'] = $mm[1];
		$mime     = 'jpg' === $mm[1] ? 'image/jpeg' : 'video/mp4';
		if ( ( $x['tipo'] ?? '' ) !== $mime ) {
			return 'tipo de medio no coincide con la extensión';
		}
		$max = 'jpg' === $mm[1] ? self::MAX_IMAGEN : self::MAX_VIDEO;
		if ( ! is_int( $x['bytes'] ?? null ) || $x['bytes'] < 100 || $x['bytes'] > $max ) {
			return 'tamaño de medio no permitido';
		}
		if ( ! is_string( $x['sha256'] ?? null ) || ! preg_match( '/^[0-9a-f]{64}$/', $x['sha256'] ) || substr( $x['sha256'], 0, 10 ) !== substr( $x['ruta'], -14, 10 ) ) {
			return 'sha256 de medio no válido';
		}
		if ( isset( $x['alt'] ) && ( ! is_string( $x['alt'] ) || self::longitud( $x['alt'] ) > 1000 ) ) {
			return 'texto alternativo no válido';
		}
		return true;
	}

	// ---------------------------------------------------------------- Estado y almacén

	public static function estado() {
		$e = get_option( self::OPC_ESTADO, array() );
		return array_merge(
			array(
				'serie'      => 0,
				'serie_max'  => 0,
				'fecha'      => '',
				'comprobado' => 0,
				'resultado'  => '',
				'error'      => '',
			),
			is_array( $e ) ? $e : array()
		);
	}

	private static function guardar_estado( array $e ) {
		update_option( self::OPC_ESTADO, $e, false );
	}

	/** Manifiesto aplicado (firma verificada otra vez al leerlo) o null. */
	public static function actual() {
		if ( null !== self::$cache ) {
			return self::$cache ? self::$cache : null;
		}
		self::$cache = false;
		$x           = get_option( self::OPC, null );
		if ( is_array( $x ) && isset( $x[0], $x[1] ) && true === self::verificar_firma( $x[0], $x[1] ) ) {
			$m = self::validar( $x[0] );
			if ( is_array( $m ) ) {
				self::$cache = $m;
			}
		}
		return self::$cache ? self::$cache : null;
	}

	public static function olvidar_cache() {
		self::$cache = null;
	}

	/** @return array<string,array> Publicaciones por id. */
	public static function publicaciones() {
		$m = self::actual();
		$o = array();
		foreach ( $m ? $m['publicaciones'] : array() as $p ) {
			foreach ( $p['medios'] as $i => $x ) {
				self::validar_medio( $p['medios'][ $i ] );
			}
			$o[ $p['id'] ] = $p;
		}
		return $o;
	}

	// ---------------------------------------------------------------- Descarga

	public static function descargar( $relativa, $max, $destino = null ) {
		if ( ! preg_match( '#^[a-z0-9][a-z0-9._/-]*$#', $relativa ) || false !== strpos( $relativa, '..' ) || false !== strpos( $relativa, '//' ) ) {
			return new OGC_Redes_Fallo( 'ruta no permitida' );
		}
		$url = OGC_Redes_Ajustes::get( 'url' ) . $relativa;
		if ( self::$descargador ) {
			return call_user_func( self::$descargador, $url, $max, $destino );
		}
		$args = array(
			'timeout'             => null === $destino ? 20 : 180,
			'redirection'         => 0,
			'limit_response_size' => $max + 1,
			'user-agent'          => 'OGC-Redes/' . OGC_REDES_VERSION,
		);
		if ( null !== $destino ) {
			$args['stream']   = true;
			$args['filename'] = $destino;
		}
		$r = wp_safe_remote_get( $url, $args );
		if ( is_wp_error( $r ) ) {
			return new OGC_Redes_Fallo( $relativa . ': ' . $r->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		if ( 200 !== $code ) {
			return new OGC_Redes_Fallo( $relativa . ': HTTP ' . $code );
		}
		if ( null !== $destino ) {
			return true;
		}
		$b = (string) wp_remote_retrieve_body( $r );
		return strlen( $b ) > $max ? new OGC_Redes_Fallo( $relativa . ': demasiado grande' ) : $b;
	}

	/**
	 * Descarga, verifica y aplica el manifiesto si hay uno nuevo. Devuelve una línea para el aviso.
	 */
	public static function actualizar() {
		$est               = self::estado();
		$est['comprobado'] = OGC_Redes_Cola::ahora();
		$json              = self::descargar( 'manifiesto.json', self::MAX_MANIFIESTO );
		$firma             = OGC_Redes_Graph::es_fallo( $json ) ? $json : self::descargar( 'manifiesto.sig', self::MAX_FIRMA );
		if ( OGC_Redes_Graph::es_fallo( $firma ) ) {
			$est['resultado'] = 'error';
			$est['error']     = 'Descarga: ' . $firma->mensaje;
			self::guardar_estado( $est );
			return 'No se ha podido descargar el manifiesto: ' . $firma->mensaje;
		}
		$ok = self::verificar_firma( $json, $firma );
		if ( true !== $ok ) {
			$est['resultado'] = 'error';
			$est['error']     = $ok;
			self::guardar_estado( $est );
			OGC_Redes_Registro::anotar( 'Manifiesto rechazado: ' . $ok );
			return $ok;
		}
		$m = self::validar( $json, (int) $est['serie_max'] );
		if ( 'reversion' === $m ) {
			$serie            = (int) ( json_decode( $json, true )['serie'] ?? 0 );
			$est['resultado'] = $serie === (int) $est['serie_max'] ? 'al_dia' : 'reversion';
			$est['error']     = '';
			self::guardar_estado( $est );
			return 'al_dia' === $est['resultado'] ? 'Cola al día (serie ' . $serie . ').' : 'El manifiesto publicado es anterior al aplicado: no se aplica.';
		}
		if ( ! is_array( $m ) ) {
			$est['resultado'] = 'error';
			$est['error']     = $m;
			self::guardar_estado( $est );
			OGC_Redes_Registro::anotar( 'Manifiesto rechazado: ' . $m );
			return 'Manifiesto rechazado: ' . $m;
		}
		update_option( self::OPC, array( $json, trim( (string) $firma ) ), false );
		self::$cache      = null;
		$est['serie']     = $m['serie'];
		$est['serie_max'] = max( (int) $est['serie_max'], $m['serie'] );
		$est['fecha']     = (string) ( $m['fecha'] ?? '' );
		$est['resultado'] = 'aplicado';
		$est['error']     = '';
		self::guardar_estado( $est );
		OGC_Redes_Registro::anotar( 'Manifiesto aplicado: serie ' . $m['serie'] . ', ' . count( $m['publicaciones'] ) . ' publicaciones.' );
		return 'Cola actualizada: serie ' . $m['serie'] . ', ' . count( $m['publicaciones'] ) . ' publicaciones.';
	}

	// ---------------------------------------------------------------- Medios locales

	public static function dir_base() {
		$u = wp_upload_dir( null, false );
		return array( rtrim( $u['basedir'], '/\\' ) . '/' . self::CARPETA, rtrim( $u['baseurl'], '/' ) . '/' . self::CARPETA );
	}

	/** Ruta local de medios/<id>/<archivo> → uploads/ogc-redes/<id>/<archivo>. */
	public static function ruta_local( array $x ) {
		return self::dir_base()[0] . '/' . substr( $x['ruta'], 7 );
	}

	public static function url_publica( array $x ) {
		$u = self::dir_base()[1] . '/' . substr( $x['ruta'], 7 );
		return preg_replace( '#^http://#', 'https://', $u );
	}

	private static function preparar_carpeta() {
		$d = self::dir_base()[0];
		if ( ! is_dir( $d ) && ! wp_mkdir_p( $d ) ) {
			return false;
		}
		if ( ! file_exists( $d . '/index.html' ) ) {
			file_put_contents( $d . '/index.html', '' );
		}
		if ( ! file_exists( $d . '/.htaccess' ) ) {
			file_put_contents( $d . '/.htaccess', "Options -Indexes\nAddType image/jpeg .jpg\nAddType video/mp4 .mp4\n<FilesMatch \"\\.(php|phtml|phar|html?)$\">\nRequire all denied\n</FilesMatch>\n" );
		}
		return true;
	}

	public static function tipo_por_bytes( $cabecera ) {
		if ( 0 === strpos( $cabecera, "\xFF\xD8\xFF" ) ) {
			return 'jpg';
		}
		if ( 'ftyp' === substr( $cabecera, 4, 4 ) ) {
			return 'mp4';
		}
		return '';
	}

	/** El archivo local existe y coincide con lo firmado. */
	public static function medio_listo( array $x ) {
		$f = self::ruta_local( $x );
		return is_readable( $f ) && filesize( $f ) === $x['bytes'] && hash_equals( $x['sha256'], (string) hash_file( 'sha256', $f ) );
	}

	/**
	 * Descarga y verifica los medios de una publicación. @return true|OGC_Redes_Fallo
	 */
	public static function asegurar_medios( array $p ) {
		if ( ! self::preparar_carpeta() ) {
			return new OGC_Redes_Fallo( 'No se puede escribir en wp-content/uploads/ogc-redes/.' );
		}
		foreach ( $p['medios'] as $x ) {
			if ( ! isset( $x['ext'] ) ) {
				self::validar_medio( $x );
			}
			if ( self::medio_listo( $x ) ) {
				continue;
			}
			$final = self::ruta_local( $x );
			if ( ! is_dir( dirname( $final ) ) && ! wp_mkdir_p( dirname( $final ) ) ) {
				return new OGC_Redes_Fallo( 'No se puede crear la carpeta de ' . $p['id'] . '.' );
			}
			$tmp = $final . '.descarga';
			$r   = self::descargar( $x['ruta'], $x['bytes'], $tmp );
			if ( OGC_Redes_Graph::es_fallo( $r ) ) {
				@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				return $r;
			}
			$ok = is_readable( $tmp ) && filesize( $tmp ) === $x['bytes'] && hash_equals( $x['sha256'], (string) hash_file( 'sha256', $tmp ) );
			$fh = $ok ? fopen( $tmp, 'rb' ) : false;
			$ok = $ok && $fh && self::tipo_por_bytes( (string) fread( $fh, 16 ) ) === $x['ext'];
			if ( $fh ) {
				fclose( $fh );
			}
			if ( ! $ok || ! rename( $tmp, $final ) ) {
				@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
				return new OGC_Redes_Fallo( $x['ruta'] . ': el archivo descargado no coincide con el firmado (tamaño, sha256 o tipo).' );
			}
		}
		return true;
	}

	/** Borra los medios de una publicación (tras publicarla y pasado un margen). */
	public static function borrar_medios( $id ) {
		$id = strtolower( preg_replace( '/[^A-Za-z0-9]/', '', (string) $id ) );
		$d  = self::dir_base()[0] . '/' . $id;
		if ( '' === $id || ! is_dir( $d ) ) {
			return;
		}
		foreach ( (array) glob( $d . '/*' ) as $f ) {
			if ( is_file( $f ) ) {
				unlink( $f );
			}
		}
		@rmdir( $d ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
}
