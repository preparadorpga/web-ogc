<?php
/**
 * Pantalla Ajustes → OGC Redes: pestañas Estado (cola), Conexión (App ID, App Secret, Conectar) y Registro.
 * Todas las acciones: capacidad manage_options + nonce + admin-post.php (POST), salida escapada, secretos nunca
 * mostrados (solo «guardado»).
 */

defined( 'ABSPATH' ) || exit;

class OGC_Redes_Admin {

	const CAP  = 'manage_options';
	const SLUG = 'ogc-redes';

	public static function iniciar() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		foreach ( array( 'guardar', 'conectar', 'elegir', 'desconectar', 'publicar', 'pausa', 'actualizar', 'comprobar' ) as $a ) {
			add_action( 'admin_post_ogc_redes_' . $a, array( __CLASS__, 'accion_' . $a ) );
		}
		add_action( 'admin_post_ogc_redes_oauth', array( __CLASS__, 'oauth' ) );
		add_action( 'admin_notices', array( __CLASS__, 'aviso_global' ) );
	}

	public static function menu() {
		add_options_page( 'OGC Redes', 'OGC Redes', self::CAP, self::SLUG, array( __CLASS__, 'pantalla' ) );
	}

	// ---------------------------------------------------------------- Utilidades

	private static function exigir( $accion ) {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'No tienes permiso para esto.', 'ogc-redes' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'ogc_redes_' . $accion );
	}

	private static function volver( $tab, $lineas ) {
		set_transient( 'ogc_redes_aviso_' . get_current_user_id(), array_map( array( 'OGC_Redes_Cripto', 'limpiar' ), (array) $lineas ), 120 );
		wp_safe_redirect( OGC_Redes_Cola::url_admin( $tab ) );
		exit;
	}

	private static function boton( $accion, $texto, $campos = array(), $clase = 'button', $confirmar = '' ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin:0 6px 6px 0">';
		echo '<input type="hidden" name="action" value="ogc_redes_' . esc_attr( $accion ) . '">';
		wp_nonce_field( 'ogc_redes_' . $accion );
		foreach ( $campos as $k => $v ) {
			echo '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
		}
		$on = $confirmar ? ' onclick="return confirm(\'' . esc_js( $confirmar ) . '\')"' : '';
		echo '<button type="submit" class="' . esc_attr( $clase ) . '"' . $on . '>' . esc_html( $texto ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public static function aviso_global() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$c = OGC_Redes_Ajustes::conexion();
		if ( 'caducado' === $c['estado'] ) {
			echo '<div class="notice notice-error"><p><strong>OGC Redes:</strong> ' . esc_html__( 'Meta ha rechazado la conexión. Las publicaciones esperan hasta que pulses «Conectar con Facebook e Instagram».', 'ogc-redes' ) . ' <a href="' . esc_url( OGC_Redes_Cola::url_admin( 'conexion' ) ) . '">' . esc_html__( 'Ir a Conexión', 'ogc-redes' ) . '</a></p></div>';
		}
	}

	// ---------------------------------------------------------------- Pantalla

	public static function pantalla() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'estado'; // phpcs:ignore WordPress.Security.NonceVerification
		$tabs = array(
			'estado'   => 'Estado',
			'conexion' => 'Conexión',
			'registro' => 'Registro',
		);
		$tab  = isset( $tabs[ $tab ] ) ? $tab : 'estado';
		echo '<div class="wrap"><h1>OGC Redes <small style="font-weight:400">' . esc_html( OGC_REDES_VERSION ) . '</small></h1>';
		$k = 'ogc_redes_aviso_' . get_current_user_id();
		$a = get_transient( $k );
		if ( $a ) {
			delete_transient( $k );
			echo '<div class="notice notice-info is-dismissible">';
			foreach ( (array) $a as $l ) {
				echo '<p>' . esc_html( $l ) . '</p>';
			}
			echo '</div>';
		}
		echo '<nav class="nav-tab-wrapper">';
		foreach ( $tabs as $t => $n ) {
			echo '<a class="nav-tab' . ( $t === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( OGC_Redes_Cola::url_admin( $t ) ) . '">' . esc_html( $n ) . '</a>';
		}
		echo '</nav><div style="margin-top:16px">';
		call_user_func( array( __CLASS__, 'pestana_' . $tab ) );
		echo '</div></div>';
	}

	private static function pestana_estado() {
		$c  = OGC_Redes_Ajustes::conexion();
		$me = OGC_Redes_Manifiesto::estado();
		echo '<p>';
		if ( OGC_Redes_Ajustes::conectado() ) {
			echo '<strong style="color:#0a7a32">● ' . esc_html__( 'Conectado', 'ogc-redes' ) . '</strong>: Instagram @' . esc_html( $c['ig_usuario'] ) . ' · ' . esc_html( $c['page_name'] );
		} else {
			echo '<strong style="color:#b32d2e">● ' . esc_html__( 'Sin conexión con Meta', 'ogc-redes' ) . '</strong> — <a href="' . esc_url( OGC_Redes_Cola::url_admin( 'conexion' ) ) . '">' . esc_html__( 'Conectar', 'ogc-redes' ) . '</a>';
		}
		echo '<br>' . esc_html( sprintf( 'Cola: serie %d · comprobada %s · %s', (int) $me['serie'], $me['comprobado'] ? OGC_Redes_Cola::madrid( $me['comprobado'] ) : 'nunca', $me['error'] ? 'último error: ' . $me['error'] : 'sin errores' ) );
		$sig = wp_next_scheduled( OGC_Redes_Cola::CRON );
		echo '<br>' . esc_html( 'Próxima pasada automática: ' . ( $sig ? OGC_Redes_Cola::madrid( $sig ) : 'no programada' ) . ' (cada 15 minutos; horas de Madrid).' ) . '</p>';

		$pausa = OGC_Redes_Ajustes::get( 'pausa' );
		if ( $pausa ) {
			echo '<div class="notice notice-warning inline"><p><strong>' . esc_html__( 'TODO PAUSADO: no se publica nada hasta que pulses «Reanudar».', 'ogc-redes' ) . '</strong></p></div>';
		}
		self::boton( 'pausa', $pausa ? 'Reanudar' : 'Pausar todo', array( 'pausa' => $pausa ? '0' : '1' ), $pausa ? 'button button-primary' : 'button' );
		self::boton( 'actualizar', 'Descargar la cola ahora' );

		$pubs = OGC_Redes_Manifiesto::publicaciones();
		if ( ! $pubs ) {
			echo '<p>' . esc_html__( 'Todavía no hay cola: pulsa «Descargar la cola ahora».', 'ogc-redes' ) . '</p>';
			return;
		}
		$colores = array(
			'publicado' => '#0a7a32',
			'pendiente' => '#1d2327',
			'proceso'   => '#996800',
			'retenida'  => '#646970',
			'vencida'   => '#b32d2e',
			'error'     => '#b32d2e',
		);
		echo '<table class="widefat striped" style="margin-top:8px"><thead><tr><th>Pieza</th><th>Fecha (Madrid)</th><th>Tipo</th><th>Estado</th><th>Enlaces</th><th></th></tr></thead><tbody>';
		foreach ( $pubs as $id => $p ) {
			$st = OGC_Redes_Cola::pieza( $id );
			$s  = OGC_Redes_Cola::situacion( $p, $st );
			echo '<tr><td><strong>' . esc_html( $id ) . '</strong><br><small>' . esc_html( $p['descripcion'] ?? '' ) . '</small></td>';
			echo '<td>' . esc_html( gmdate( 'd/m/Y', strtotime( $p['fecha'] ) ) . ' ' . $p['hora'] ) . '</td>';
			echo '<td>' . esc_html( $p['formato'] . ' · ' . count( $p['medios'] ) ) . '</td>';
			echo '<td style="color:' . esc_attr( $colores[ $s[0] ] ) . '">' . esc_html( $s[1] ) . '</td><td>';
			if ( $st['ig_enlace'] ) {
				echo '<a href="' . esc_url( $st['ig_enlace'] ) . '" target="_blank" rel="noopener">Instagram</a> ';
			} elseif ( 'publicado' === $st['ig'] ) {
				echo 'Instagram ✓ ';
			}
			if ( $st['fb_enlace'] ) {
				echo '<a href="' . esc_url( $st['fb_enlace'] ) . '" target="_blank" rel="noopener">Facebook</a>';
			} elseif ( 'publicado' === $st['fb'] ) {
				echo 'Facebook ✓';
			}
			echo '</td><td>';
			if ( ! OGC_Redes_Cola::terminada( $st ) && 'retenida' !== $s[0] && OGC_Redes_Ajustes::conectado() ) {
				self::boton( 'publicar', 'Publicar ahora', array( 'id' => $id ), 'button button-small', '¿Publicar ' . $id . ' ahora en Instagram y Facebook? (nunca se publica dos veces)' );
			}
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function pestana_conexion() {
		$a = OGC_Redes_Ajustes::todos();
		$c = OGC_Redes_Ajustes::conexion();
		echo '<h2>' . esc_html__( '1. Datos de la app de Meta', 'ogc-redes' ) . '</h2>';
		echo '<p>' . esc_html__( 'URI de redirección que hay que poner en la app (Inicio de sesión con Facebook → Configuración → URI de redireccionamiento de OAuth válidos):', 'ogc-redes' ) . '<br><code>' . esc_html( OGC_Redes_Meta::redirect_uri() ) . '</code></p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="ogc_redes_guardar">';
		wp_nonce_field( 'ogc_redes_guardar' );
		echo '<table class="form-table" role="presentation">';
		echo '<tr><th><label for="ogc_app_id">App ID</label></th><td><input id="ogc_app_id" name="app_id" class="regular-text" inputmode="numeric" autocomplete="off" value="' . esc_attr( $a['app_id'] ) . '"></td></tr>';
		echo '<tr><th><label for="ogc_app_secret">App Secret</label></th><td><input id="ogc_app_secret" name="app_secret" type="password" class="regular-text" autocomplete="new-password" value="" placeholder="' . esc_attr( '' !== $a['app_secret'] ? '•••••••• guardado (déjalo vacío para no cambiarlo)' : 'pégalo aquí' ) . '">';
		echo '<p class="description">' . esc_html__( 'Se guarda cifrado con las sales de wp-config.php y no se vuelve a mostrar nunca.', 'ogc-redes' ) . '</p></td></tr>';
		echo '<tr><th><label for="ogc_config">ID de configuración</label></th><td><input id="ogc_config" name="config_id" class="regular-text" autocomplete="off" value="' . esc_attr( $a['config_id'] ) . '"><p class="description">' . esc_html__( 'Solo si la app usa «Inicio de sesión con Facebook para empresas». Vacío = permisos clásicos (scope).', 'ogc-redes' ) . '</p></td></tr>';
		echo '<tr><th><label for="ogc_ig">Cuenta de Instagram</label></th><td>@<input id="ogc_ig" name="ig_esperada" value="' . esc_attr( $a['ig_esperada'] ) . '"></td></tr>';
		echo '<tr><th>Facebook</th><td><label><input type="checkbox" name="facebook" value="1"' . checked( $a['facebook'], true, false ) . '> ' . esc_html__( 'Publicar también en la página de Facebook', 'ogc-redes' ) . '</label></td></tr>';
		echo '<tr><th><label for="ogc_email">Email de avisos</label></th><td><input id="ogc_email" name="email" type="email" class="regular-text" value="' . esc_attr( $a['email'] ) . '" placeholder="' . esc_attr( (string) get_option( 'admin_email' ) ) . '"></td></tr>';
		echo '<tr><th><label for="ogc_ver">Versión de la Graph API</label></th><td><input id="ogc_ver" name="version" value="' . esc_attr( $a['version'] ) . '" size="6"></td></tr>';
		echo '<tr><th><label for="ogc_url">URL de la cola</label></th><td><input id="ogc_url" name="url" class="large-text" value="' . esc_attr( $a['url'] ) . '"></td></tr>';
		echo '</table>';
		submit_button( 'Guardar' );
		echo '</form>';

		echo '<h2>' . esc_html__( '2. Conexión', 'ogc-redes' ) . '</h2>';
		if ( '' !== $c['page_id'] ) {
			echo '<p>' . esc_html( sprintf( 'Página: %s · Instagram: @%s · conectado el %s · estado: %s', $c['page_name'], $c['ig_usuario'], $c['conectado'] ? OGC_Redes_Cola::madrid( $c['conectado'] ) : '-', 'ok' === $c['estado'] ? 'correcto' : 'HAY QUE VOLVER A CONECTAR' ) ) . '</p>';
		}
		$lista = OGC_Redes_Meta::leer_lista();
		if ( $lista ) {
			echo '<p><strong>' . esc_html__( 'Elige la página de Facebook que tiene vinculada la cuenta de Instagram:', 'ogc-redes' ) . '</strong></p>';
			foreach ( $lista as $i => $x ) {
				self::boton( 'elegir', $x['page_name'] . ( $x['ig_usuario'] ? ' · @' . $x['ig_usuario'] : ' · (sin Instagram)' ), array( 'i' => (string) $i ), 'button' );
			}
		}
		if ( OGC_Redes_Meta::listo_para_conectar() ) {
			self::boton( 'conectar', 'Conectar con Facebook e Instagram', array(), 'button button-primary button-hero' );
		} else {
			echo '<p>' . esc_html__( 'Guarda primero el App ID y el App Secret.', 'ogc-redes' ) . '</p>';
		}
		if ( '' !== $c['page_id'] ) {
			echo '<p>';
			self::boton( 'comprobar', 'Comprobar la conexión' );
			self::boton( 'desconectar', 'Desconectar', array(), 'button button-link-delete', '¿Borrar la conexión? Hasta volver a conectar no se publicará nada.' );
			echo '</p>';
		}
	}

	private static function pestana_registro() {
		echo '<table class="widefat striped"><thead><tr><th style="width:150px">Fecha (Madrid)</th><th>Qué ha pasado</th></tr></thead><tbody>';
		foreach ( OGC_Redes_Registro::lineas() as $l ) {
			echo '<tr><td>' . esc_html( OGC_Redes_Cola::madrid( $l[0] ) ) . '</td><td>' . esc_html( $l[1] ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	// ---------------------------------------------------------------- Acciones

	public static function accion_guardar() {
		self::exigir( 'guardar' );
		$l   = array();
		$in  = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification
		$new = array(
			'config_id'   => preg_replace( '/[^0-9]/', '', (string) ( $in['config_id'] ?? '' ) ),
			'ig_esperada' => preg_replace( '/[^A-Za-z0-9._]/', '', (string) ( $in['ig_esperada'] ?? '' ) ),
			'facebook'    => ! empty( $in['facebook'] ),
			'email'       => sanitize_email( (string) ( $in['email'] ?? '' ) ),
		);
		$id = trim( (string) ( $in['app_id'] ?? '' ) );
		if ( OGC_Redes_Ajustes::app_id_valido( $id ) ) {
			$new['app_id'] = $id;
		} elseif ( '' !== $id ) {
			$l[] = 'El App ID tiene que ser solo números: no se ha cambiado.';
		}
		$sec = trim( (string) ( $in['app_secret'] ?? '' ) );
		if ( '' !== $sec ) {
			if ( preg_match( '/^[a-f0-9]{32}$/i', $sec ) ) {
				$new['app_secret'] = OGC_Redes_Cripto::cifrar( $sec );
				$l[]               = 'App Secret guardado (cifrado).';
			} else {
				$l[] = 'El App Secret tiene que tener 32 caracteres (0-9, a-f): no se ha guardado.';
			}
		}
		$v = trim( (string) ( $in['version'] ?? '' ) );
		if ( OGC_Redes_Ajustes::version_valida( $v ) ) {
			$new['version'] = $v;
		}
		$u = trim( (string) ( $in['url'] ?? '' ) );
		if ( '' !== $u && '/' !== substr( $u, -1 ) ) {
			$u .= '/';
		}
		if ( OGC_Redes_Ajustes::url_valida( $u ) ) {
			$new['url'] = $u;
		}
		OGC_Redes_Ajustes::guardar( $new );
		array_unshift( $l, 'Ajustes guardados.' );
		self::volver( 'conexion', $l );
	}

	public static function accion_conectar() {
		self::exigir( 'conectar' );
		if ( ! OGC_Redes_Meta::listo_para_conectar() ) {
			self::volver( 'conexion', 'Falta el App ID o el App Secret.' );
		}
		wp_redirect( OGC_Redes_Meta::url_login() ); // phpcs:ignore WordPress.Security.SafeRedirect -- facebook.com.
		exit;
	}

	/** Vuelta de Facebook (GET). La protege el «state» (atado al usuario, un solo uso, 10 min). */
	public static function oauth() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'No tienes permiso para esto.', 'ogc-redes' ), '', array( 'response' => 403 ) );
		}
		// phpcs:disable WordPress.Security.NonceVerification
		$state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
		$ok    = OGC_Redes_Meta::comprobar_state( $state );
		if ( true !== $ok ) {
			self::volver( 'conexion', $ok );
		}
		if ( isset( $_GET['error'] ) ) {
			$m = isset( $_GET['error_description'] ) ? sanitize_text_field( wp_unslash( $_GET['error_description'] ) ) : sanitize_text_field( wp_unslash( $_GET['error'] ) );
			self::volver( 'conexion', 'Facebook no ha dado permiso: ' . $m );
		}
		$code = isset( $_GET['code'] ) ? preg_replace( '/[^A-Za-z0-9_#\-]/', '', wp_unslash( $_GET['code'] ) ) : '';
		// phpcs:enable
		if ( '' === $code ) {
			self::volver( 'conexion', 'Facebook no ha devuelto el código.' );
		}
		$paginas = OGC_Redes_Meta::canjear( $code );
		if ( ! is_array( $paginas ) ) {
			self::volver( 'conexion', $paginas );
		}
		$x = OGC_Redes_Meta::elegir( $paginas );
		if ( $x ) {
			OGC_Redes_Meta::guardar_pagina( $x );
			OGC_Redes_Meta::borrar_lista();
			self::volver( 'conexion', array_merge( array( 'Conectado: «' . $x['page_name'] . '» e Instagram @' . $x['ig_usuario'] . '. Ya no tienes que hacer nada más.' ), OGC_Redes_Meta::comprobar() ) );
		}
		OGC_Redes_Meta::guardar_lista( $paginas );
		self::volver( 'conexion', 'Elige abajo la página que tiene vinculado Instagram.' );
	}

	public static function accion_elegir() {
		self::exigir( 'elegir' );
		$i = isset( $_POST['i'] ) ? (int) $_POST['i'] : -1; // phpcs:ignore WordPress.Security.NonceVerification
		$l = OGC_Redes_Meta::leer_lista();
		if ( ! isset( $l[ $i ] ) ) {
			self::volver( 'conexion', 'La lista ha caducado: pulsa «Conectar» otra vez.' );
		}
		if ( '' === $l[ $i ]['ig_id'] ) {
			self::volver( 'conexion', 'Esa página no tiene una cuenta profesional de Instagram vinculada. Vincúlala (Configuración de la página → Cuentas vinculadas → Instagram) y conecta otra vez.' );
		}
		OGC_Redes_Meta::guardar_pagina( $l[ $i ] );
		OGC_Redes_Meta::borrar_lista();
		self::volver( 'conexion', array_merge( array( 'Conectado.' ), OGC_Redes_Meta::comprobar() ) );
	}

	public static function accion_desconectar() {
		self::exigir( 'desconectar' );
		delete_option( OGC_Redes_Ajustes::OPC_CONEXION );
		OGC_Redes_Registro::anotar( 'Conexión borrada a mano.' );
		self::volver( 'conexion', 'Conexión borrada.' );
	}

	public static function accion_comprobar() {
		self::exigir( 'comprobar' );
		self::volver( 'conexion', OGC_Redes_Meta::comprobar() );
	}

	public static function accion_publicar() {
		self::exigir( 'publicar' );
		$id = isset( $_POST['id'] ) ? preg_replace( '/[^A-Z0-9]/', '', strtoupper( (string) wp_unslash( $_POST['id'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		$l = OGC_Redes_Cola::cron_manual( $id );
		self::volver( 'estado', $l );
	}

	public static function accion_pausa() {
		self::exigir( 'pausa' );
		$p = ! empty( $_POST['pausa'] ); // phpcs:ignore WordPress.Security.NonceVerification
		OGC_Redes_Ajustes::guardar( array( 'pausa' => $p ) );
		OGC_Redes_Registro::anotar( $p ? 'TODO PAUSADO a mano.' : 'Publicación automática reanudada.' );
		self::volver( 'estado', $p ? 'Todo pausado: no se publicará nada hasta que pulses «Reanudar».' : 'Reanudado.' );
	}

	public static function accion_actualizar() {
		self::exigir( 'actualizar' );
		self::volver( 'estado', OGC_Redes_Manifiesto::actualizar() );
	}
}
