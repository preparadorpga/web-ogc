<?php
/**
 * Plugin Name:       OGC Redes · Instagram y Facebook automáticos
 * Description:       Publica sola, desde el servidor, la cola de Instagram (@preparadorogc) y de la página de Facebook de Preparador OGC: descarga el manifiesto FIRMADO (Ed25519, la misma clave que OGC Páginas) y los medios del repositorio web-ogc, los sirve desde wp-content/uploads/ogc-redes/ y, a su hora (Europe/Madrid), crea los contenedores en la Graph API, espera a FINISHED y publica. Sin publicar nunca dos veces la misma pieza, con reintentos y aviso por email. Conexión única con Facebook Login (token de página que no caduca, cifrado).
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Preparador OGC
 * License:           GPL-2.0-or-later
 * Text Domain:       ogc-redes
 *
 * Ajustes → OGC Redes. Pasos para conectar: redes/CONECTAR_META_VICENTE.md.
 */

defined( 'ABSPATH' ) || exit;

define( 'OGC_REDES_VERSION', '1.0.0' );
define( 'OGC_REDES_DIR', __DIR__ );

foreach ( array( 'cripto', 'ajustes', 'registro', 'graph', 'manifiesto', 'publicador', 'cola', 'meta', 'admin' ) as $ogc_r ) {
	require_once __DIR__ . '/includes/class-ogc-redes-' . $ogc_r . '.php';
}
unset( $ogc_r );

register_activation_hook( __FILE__, array( 'OGC_Redes_Cola', 'activar' ) );
register_deactivation_hook( __FILE__, array( 'OGC_Redes_Cola', 'desactivar' ) );

add_filter( 'cron_schedules', array( 'OGC_Redes_Cola', 'intervalos' ) );
add_action( 'init', array( 'OGC_Redes_Cola', 'programar' ) );
add_action( OGC_Redes_Cola::CRON, array( 'OGC_Redes_Cola', 'cron' ) );

if ( is_admin() ) {
	OGC_Redes_Admin::iniciar();
}
