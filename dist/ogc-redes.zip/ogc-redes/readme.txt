=== OGC Redes · Instagram y Facebook automáticos ===
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Plugin privado de Preparador OGC. Publica sola, desde el servidor, la cola de Instagram (@preparadorogc) y de la
página de Facebook, sin depender de ningún ordenador.

Cómo funciona:
* Cada hora descarga el manifiesto FIRMADO (Ed25519, misma clave que OGC Páginas) de
  https://raw.githubusercontent.com/preparadorpga/web-ogc/main/sync/redes/ y, 36 h antes de cada publicación, sus
  medios (JPEG 1080×1350 y MP4 H.264 + AAC), que guarda en wp-content/uploads/ogc-redes/ tras comprobar tamaño,
  sha256 y tipo.
* WP-Cron cada 15 minutos (con candado): a la hora de Madrid de cada pieza crea los contenedores de la Graph API
  (carrusel: hijos y padre; imagen; vídeo y reel como REELS con share_to_feed), espera a FINISHED, publica y guarda el
  enlace. Después, la misma pieza en la página de Facebook (fotos o vídeo) con la URL con UTM.
* Nunca publica dos veces la misma pieza (estado por id guardado tras cada paso, comprobación por el pie antes de
  crear nada y recuperación si se corta justo al publicar). Reintentos a los 15 min, 1 h, 4 h, 12 h y 24 h; email al
  tercer fallo; tras el sexto, espera a «Publicar ahora». Más de 48 h tarde: solo a mano.
* Ajustes → OGC Redes: Estado (cola, «Publicar ahora», «Pausar todo»), Conexión (App ID, App Secret, «Conectar con
  Facebook e Instagram») y Registro. El App Secret y el token de página se guardan cifrados con las sales de
  wp-config.php y no se muestran nunca.

Instalación: Plugins → Añadir nuevo → Subir plugin → ogc-redes.zip → Activar. Conexión: redes/CONECTAR_META_VICENTE.md.
Recomendado: un cron real en SiteGround (Site Tools → Devs → Cron Jobs) cada 15 minutos que llame a
https://organizacionygestioncomercial.es/wp-cron.php?doing_wp_cron para que la hora sea exacta aunque no haya visitas.

== Changelog ==
= 1.0.0 (19/11/2026) =
* Primera versión (orden de Vicente, 19/11/2026 19:29): Instagram y Facebook automáticos desde el servidor.
