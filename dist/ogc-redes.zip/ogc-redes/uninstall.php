<?php
/**
 * Desinstalación: borra ajustes, conexión (tokens cifrados), estado y registro. Los medios de
 * wp-content/uploads/ogc-redes/ se borran también. Las publicaciones ya hechas en Instagram y Facebook no se tocan.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

foreach ( array( 'ogc_redes_ajustes', 'ogc_redes_conexion', 'ogc_redes_manifiesto', 'ogc_redes_manifiesto_estado', 'ogc_redes_piezas', 'ogc_redes_registro', 'ogc_redes_cerrojo' ) as $ogc_o ) {
	delete_option( $ogc_o );
}
wp_clear_scheduled_hook( 'ogc_redes_cron' );

$ogc_u = wp_upload_dir( null, false );
$ogc_d = rtrim( $ogc_u['basedir'], '/\\' ) . '/ogc-redes';
if ( is_dir( $ogc_d ) ) {
	$ogc_it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $ogc_d, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
	foreach ( $ogc_it as $ogc_f ) {
		$ogc_f->isDir() ? rmdir( $ogc_f->getPathname() ) : unlink( $ogc_f->getPathname() );
	}
	rmdir( $ogc_d );
}
